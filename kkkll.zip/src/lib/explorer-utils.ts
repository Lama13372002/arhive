// Explorer URLs for supported USDT networks in this project
export const EXPLORER_URLS: Record<string, { name: string; baseUrl: string; txPath: string }> = {
  TRON: {
    name: 'TronScan',
    baseUrl: 'https://tronscan.org',
    txPath: '/#/transaction/'
  },
  ETH: {
    name: 'Etherscan',
    baseUrl: 'https://etherscan.io',
    txPath: '/tx/'
  },
  BSC: {
    name: 'BscScan',
    baseUrl: 'https://bscscan.com',
    txPath: '/tx/'
  },
  POLYGON: {
    name: 'PolygonScan',
    baseUrl: 'https://polygonscan.com',
    txPath: '/tx/'
  },
  TON: {
    name: 'TONScan',
    baseUrl: 'https://tonscan.org',
    txPath: '/tx/'
  }
};

/**
 * Get explorer URL for a transaction hash on a specific network
 */
export function getExplorerUrl(network: string, txHash: string): string | null {
  const explorer = EXPLORER_URLS[network.toUpperCase()];
  if (!explorer || !txHash) return null;

  return `${explorer.baseUrl}${explorer.txPath}${txHash}`;
}

/**
 * Get explorer name for a specific network
 */
export function getExplorerName(network: string): string {
  const explorer = EXPLORER_URLS[network.toUpperCase()];
  return explorer?.name || 'Explorer';
}

/**
 * Check if explorer is supported for a network
 */
export function isExplorerSupported(network: string): boolean {
  return network.toUpperCase() in EXPLORER_URLS;
}
