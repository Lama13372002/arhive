import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Генерирует случайную комиссию от 1.5% до 2.5%
 * Каждый вызов возвращает новое значение
 */
export function generateRandomFee(): number {
  const minFee = 1.5; // 1.5%
  const maxFee = 2.5; // 2.5%

  // Генерируем случайное число с двумя знаками после запятой
  const randomFee = Math.random() * (maxFee - minFee) + minFee;
  return Math.round(randomFee * 100) / 100; // Округляем до 2 знаков после запятой
}

/**
 * Рассчитывает сумму к оплате на основе желаемой суммы к получению и комиссии
 * @param desiredAmount - сумма которую хочет получить пользователь
 * @param feePercent - процент комиссии
 * @returns объект с расчётами
 */
export function calculateDepositWithFee(desiredAmount: number, feePercent: number) {
  const feeMultiplier = feePercent / 100;
  const payAmount = desiredAmount / (1 - feeMultiplier);
  const feeAmount = payAmount - desiredAmount;

  return {
    desired_amount: desiredAmount,      // Желаемая сумма к получению
    pay_amount: payAmount,             // Сумма к оплате
    fee_amount: feeAmount,             // Размер комиссии
    fee_percent: feePercent            // Процент комиссии
  };
}
