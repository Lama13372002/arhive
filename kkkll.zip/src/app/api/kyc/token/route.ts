import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { createAccessToken, getEnv } from '@/lib/sumsub';
import { UserQueryResult, SumsubAccessTokenResponse } from '@/types';

export async function POST(req: NextRequest) {
  try {
    const { userId, email, phone } = await req.json();
    if (!userId) return NextResponse.json({ error: 'userId is required' }, { status: 400 });

    const levelName = getEnv('SUMSUB_LEVEL_NAME');

    // Ensure user exists
    const userRes = await db.query('SELECT id, kyc_status FROM users WHERE telegram_id = $1', [userId]);
    if (userRes.rowCount === 0) return NextResponse.json({ error: 'User not found' }, { status: 404 });
    const u = userRes.rows[0] as UserQueryResult;

    // Upsert sumsub_applications record to pending
    await db.query(
      `INSERT INTO sumsub_applications (user_id, external_applicant_id, review_status)
       VALUES ($1, $2, 'pending')
       ON CONFLICT (user_id, external_applicant_id)
       DO UPDATE SET review_status = 'pending', updated_at = now()`,
      [u.id, String(userId)]
    );

    // Update user's aggregate kyc status to pending
    await db.query('UPDATE users SET kyc_status = $1, updated_at = now() WHERE id = $2', ['pending', u.id]);

    const tokenResp = await createAccessToken({
      levelName,
      userId: String(userId),
      applicantIdentifiers: { email, phone },
      ttlInSecs: 600,
    });

    return NextResponse.json({ token: (tokenResp as SumsubAccessTokenResponse).token });
  } catch (e: unknown) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Internal error' }, { status: 500 });
  }
}
