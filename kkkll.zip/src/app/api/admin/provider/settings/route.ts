import { NextRequest } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const provider = searchParams.get('provider');
    const q = provider ? `SELECT provider, key, value, updated_at FROM provider_settings WHERE provider = $1 ORDER BY key` : `SELECT provider, key, value, updated_at FROM provider_settings ORDER BY provider, key`;
    const res = await db.query(q, provider ? [provider] : undefined);
    return Response.json({ success: true, data: { items: res.rows } });
  } catch (e) {
    return Response.json({ success: false, error: 'DB_ERROR', details: (e as Error).message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { provider, key, value } = body;
    if (!provider || !key) return Response.json({ success: false, error: 'BAD_REQUEST' }, { status: 400 });
    await db.query(
      `INSERT INTO provider_settings(provider, key, value) VALUES($1,$2,$3::jsonb) ON CONFLICT(provider,key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`,
      [provider, key, JSON.stringify(value)]
    );
    return Response.json({ success: true });
  } catch (e) {
    return Response.json({ success: false, error: 'DB_ERROR', details: (e as Error).message }, { status: 500 });
  }
}
