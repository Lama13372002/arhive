import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { PoolClient } from 'pg';

function today(): string { return new Date().toISOString().slice(0,10); }
function addDays(date: string, days: number): string {
  try {
    const d = new Date(date + 'T00:00:00Z');
    if (isNaN(d.getTime())) {
      throw new Error(`Invalid date in addDays: ${date}`);
    }
    d.setUTCDate(d.getUTCDate() + days);
    const result = d.toISOString().slice(0,10);
    return result;
  } catch (error) {
    throw new Error(`addDays failed for date: ${date}, days: ${days}, error: ${error}`);
  }
}

export async function GET(request: NextRequest) {
  const debugInfo: string[] = [];

  try {
    debugInfo.push('1. Parsing URL params');
    const { searchParams } = new URL(request.url);
    const user_id = searchParams.get('user_id'); // telegram_id
    debugInfo.push(`2. Received user_id: ${user_id}`);

    if (!user_id) {
      debugInfo.push('3. ERROR: User ID is missing');
      return NextResponse.json({
        success: false,
        error: 'User ID is required',
        debug: debugInfo
      }, { status: 400 });
    }

    debugInfo.push('4. Querying user from database');
    const userRes = await db.query('SELECT id FROM users WHERE telegram_id = $1', [user_id]);
    debugInfo.push(`5. User query result: ${userRes.rows.length} rows found`);

    if (userRes.rows.length === 0) {
      debugInfo.push('6. ERROR: User not found in database');
      return NextResponse.json({
        success: false,
        error: 'User not found',
        debug: debugInfo
      }, { status: 404 });
    }

    const uid = userRes.rows[0].id as number;
    debugInfo.push(`7. User internal ID: ${uid}`);

    debugInfo.push('8. Querying investments from database');
    const invRes = await db.query(
      `SELECT i.id, i.amount, i.daily_percent, i.term_days, i.start_date, i.end_date,
              i.status, i.created_at, i.principal_returned, i.withdrawal_request_id,
              t.code, t.name_ru, t.name_en, t.tariff_type, t.is_perpetual, t.auto_return_principal
       FROM investments i
       JOIN tariff_plans t ON t.id = i.tariff_id
       WHERE i.user_id = $1 AND i.status IN ('active', 'withdrawal_requested')
       ORDER BY i.created_at DESC`,
      [uid]
    );

    debugInfo.push(`9. Investments query result: ${invRes.rows.length} rows found`);
    if (invRes.rows.length > 0) {
      debugInfo.push(`10. First investment: ID=${invRes.rows[0].id}, Amount=${invRes.rows[0].amount}, Status=${invRes.rows[0].status}`);
    }

    const todayISO = new Date().toISOString().slice(0,10);
    debugInfo.push(`11. Today date: ${todayISO}`);

    debugInfo.push('12. Processing investments data');
    const list = invRes.rows.map((r: Record<string, unknown>, index: number) => {
      debugInfo.push(`13.${index}: Processing investment ID=${r.id}, start_date=${r.start_date}, end_date=${r.end_date}`);

      // Безопасная обработка дат
      let start: Date;
      let end: Date;

      try {
        const startStr = r.start_date as string;
        const endStr = r.end_date as string;

        debugInfo.push(`13.${index}.1: Raw dates - start: "${startStr}", end: "${endStr}"`);

        start = new Date(startStr);
        if (isNaN(start.getTime())) {
          throw new Error(`Invalid start_date: ${startStr}`);
        }

        end = new Date(endStr);
        if (isNaN(end.getTime())) {
          throw new Error(`Invalid end_date: ${endStr}`);
        }

        debugInfo.push(`13.${index}.2: Parsed dates - start: ${start.toISOString()}, end: ${end.toISOString()}`);
      } catch (dateError) {
        debugInfo.push(`13.${index}.ERROR: Date parsing failed - ${dateError}`);
        throw dateError;
      }

      const totalDays = Number(r.term_days);

      // Используем точное время создания инвестиции для расчета дней
      const createdTime = new Date(r.created_at as string);
      const elapsed = Math.min(Math.max(0, Math.floor((new Date().getTime() - createdTime.getTime()) / (1000*60*60*24))), totalDays);
      const daysLeft = Math.max(0, totalDays - elapsed);
      const dailyPercent = Number(r.daily_percent);
      const amount = Number(r.amount);
      const dailyProfit = amount * dailyPercent; // fraction

      // Конвертируем даты в правильный формат YYYY-MM-DD
      const startDateFormatted = start.toISOString().slice(0,10);
      const endDateFormatted = end.toISOString().slice(0,10);

      debugInfo.push(`13.${index}.3: Formatted dates - start: ${startDateFormatted}, end: ${endDateFormatted}`);

      return {
        id: Number(r.id),
        planCode: String(r.code as string),
        planName: String(((r.name_en as string) || (r.name_ru as string))),
        amount,
        dailyPercent: dailyPercent * 100,
        termDays: totalDays,
        startDate: startDateFormatted,
        endDate: endDateFormatted,
        daysLeft,
        totalDays,
        dailyProfit,
        status: String(r.status as string),
        createdAt: String(r.created_at as string),
        principal_returned: Boolean(r.principal_returned),
        withdrawal_request_id: r.withdrawal_request_id ? Number(r.withdrawal_request_id) : undefined,
        tariff_type: String(r.tariff_type as string),
        is_perpetual: Boolean(r.is_perpetual),
        auto_return_principal: Boolean(r.auto_return_principal),
      };
    });

    // compute claimable per investment in one go
    const ids = list.map(i => i.id);
    const claimableMap = new Map<number, number>();
    if (ids.length) {
      // last accrued date per investment
      const accRows = await db.query(
        `SELECT a.investment_id, MAX(a.accrual_date) as last_date
         FROM accruals a
         WHERE a.investment_id = ANY($1)
         GROUP BY a.investment_id`,
        [ids]
      );
      const lastMap = new Map<number, string>();
      for (const row of accRows.rows as Array<Record<string, unknown>>) {
        lastMap.set(Number(row.investment_id), String(row.last_date));
      }
      for (const it of list) {
        try {
          debugInfo.push(`Claimable calc for investment ${it.id}: createdAt=${it.createdAt}`);

          const now = new Date();
          const createdTime = new Date(it.createdAt);

          // Calculate hours since creation
          const hoursSinceCreation = (now.getTime() - createdTime.getTime()) / (1000 * 60 * 60);
          const fullPeriodsAvailable = Math.floor(hoursSinceCreation / 24);

          debugInfo.push(`Hours since creation for ${it.id}: ${hoursSinceCreation}, full periods: ${fullPeriodsAvailable}`);

          // Check if investment period has ended
          const endTime = new Date(it.endDate);
          const maxHoursSinceCreation = (Math.min(now.getTime(), endTime.getTime()) - createdTime.getTime()) / (1000 * 60 * 60);
          const maxFullPeriods = Math.floor(maxHoursSinceCreation / 24);

          const periodsToCount = Math.min(fullPeriodsAvailable, maxFullPeriods);
          debugInfo.push(`Periods to count for ${it.id}: ${periodsToCount} (max: ${maxFullPeriods})`);

          // Check how many periods were already claimed
          const lastAccrualEntries = await db.query(
            `SELECT COUNT(*) as claimed_periods FROM accruals WHERE investment_id = $1`,
            [it.id]
          );
          const claimedPeriods = Number(lastAccrualEntries.rows[0]?.claimed_periods || 0);
          debugInfo.push(`Already claimed periods for ${it.id}: ${claimedPeriods}`);

          // For perpetual plans: calculate claimable periods (available - already claimed)
          // For fixed-term plans: show total accumulated profit from accruals table
          let claimableAmount = 0;

          if (it.is_perpetual) {
            // Perpetual plans: show available balance for withdrawal
            const claimablePeriods = Math.max(0, periodsToCount - claimedPeriods);
            claimableAmount = claimablePeriods * (it.amount * (it.dailyPercent/100));
            debugInfo.push(`Claimable calculation for ${it.id}: ${claimablePeriods} periods, amount: ${claimableAmount}`);
          } else {
            // Fixed-term plans: show total accumulated profit from accruals
            const accumulatedResult = await db.query(
              `SELECT COALESCE(SUM(profit_amount), 0) as total_accumulated FROM accruals WHERE investment_id = $1`,
              [it.id]
            );
            claimableAmount = Number(accumulatedResult.rows[0]?.total_accumulated || 0);
            debugInfo.push(`Accumulated calculation for ${it.id}: total accumulated amount: ${claimableAmount}`);
          }

          if (claimableAmount > 0) claimableMap.set(it.id, claimableAmount);
        } catch (calcError) {
          debugInfo.push(`Claimable calc ERROR for investment ${it.id}: ${calcError}`);
          // Продолжаем обработку других инвестиций
        }
      }
    }

    debugInfo.push(`13. Processed ${list.length} investments`);
    debugInfo.push(`14. Claimable amounts calculated for ${claimableMap.size} investments`);

    const withClaimable = list.map(it => ({ ...it, claimableAmount: claimableMap.get(it.id) || 0 }));
    debugInfo.push(`15. Final result prepared with ${withClaimable.length} investments`);

    return NextResponse.json({
      success: true,
      data: withClaimable,
      debug: debugInfo
    });
  } catch (e) {
    debugInfo.push(`ERROR: ${e instanceof Error ? e.message : String(e)}`);
    debugInfo.push(`Stack: ${e instanceof Error ? e.stack : 'No stack trace'}`);

    console.error('Investments list error:', e);
    console.error('Debug info:', debugInfo);

    return NextResponse.json({
      success: false,
      error: 'Internal server error',
      debug: debugInfo,
      errorDetails: e instanceof Error ? e.message : String(e)
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const debugInfo: string[] = [];
  const body = await request.json().catch(() => null) as Record<string, unknown> | null;

  try {
    debugInfo.push('POST: 1. Parsing request body');
    const { user_id, tariff_code, amount } = (body || {}) as { user_id?: string; tariff_code?: string; amount?: number };
    debugInfo.push(`POST: 2. Received: user_id=${user_id}, tariff_code=${tariff_code}, amount=${amount}`);

    if (!user_id || !tariff_code || !amount) {
      debugInfo.push('POST: 3. ERROR: Missing required fields');
      return NextResponse.json({
        success: false,
        error: 'user_id, tariff_code and amount are required',
        debug: debugInfo
      }, { status: 400 });
    }

    const amt = Number(amount);
    debugInfo.push(`POST: 4. Parsed amount: ${amt}`);
    if (!isFinite(amt) || amt <= 0) {
      debugInfo.push('POST: 5. ERROR: Invalid amount');
      return NextResponse.json({
        success: false,
        error: 'Invalid amount',
        debug: debugInfo
      }, { status: 400 });
    }

    debugInfo.push('POST: 6. Starting database transaction');
    return await db.transaction(async (client: PoolClient) => {
      debugInfo.push('POST: 7. Looking up user in database');
      const userRes = await client.query('SELECT id FROM users WHERE telegram_id = $1', [user_id]);
      debugInfo.push(`POST: 8. User lookup result: ${userRes.rows.length} rows`);

      if (userRes.rows.length === 0) {
        debugInfo.push('POST: 9. ERROR: User not found');
        return NextResponse.json({
          success: false,
          error: 'User not found',
          debug: debugInfo
        }, { status: 404 });
      }

      const uid = Number(userRes.rows[0].id);
      debugInfo.push(`POST: 10. User internal ID: ${uid}`);

      debugInfo.push('POST: 11. Looking up tariff plan');
      const tRes = await client.query('SELECT id, min_amount, max_amount, term_days, daily_percent FROM tariff_plans WHERE code = $1 AND is_active = true', [tariff_code]);
      debugInfo.push(`POST: 12. Tariff lookup result: ${tRes.rows.length} rows`);

      if (tRes.rows.length === 0) {
        debugInfo.push('POST: 13. ERROR: Tariff not found or inactive');
        return NextResponse.json({
          success: false,
          error: 'Tariff not found or inactive',
          debug: debugInfo
        }, { status: 400 });
      }

      const tariff = tRes.rows[0] as Record<string, unknown>;
      debugInfo.push(`POST: 14. Tariff found: ID=${tariff.id}, min=${tariff.min_amount}, max=${tariff.max_amount}`);

      if (amt < Number(tariff.min_amount) || amt > Number(tariff.max_amount)) {
        debugInfo.push(`POST: 15. ERROR: Amount ${amt} not in range [${tariff.min_amount}, ${tariff.max_amount}]`);
        return NextResponse.json({
          success: false,
          error: `Amount must be between ${Number(tariff.min_amount)} and ${Number(tariff.max_amount)}`,
          debug: debugInfo
        }, { status: 400 });
      }

      // Check balance
      debugInfo.push('POST: 16. Checking user balance');
      const balRes = await client.query('SELECT available FROM users_balance WHERE user_id = $1 AND currency = $2 FOR UPDATE', [uid, 'USDT']);
      const available = balRes.rows.length ? Number(balRes.rows[0].available) : 0;
      debugInfo.push(`POST: 17. Available balance: ${available} USDT (required: ${amt})`);

      if (available < amt) {
        debugInfo.push('POST: 18. ERROR: Insufficient balance');
        return NextResponse.json({
          success: false,
          error: 'Insufficient balance',
          debug: debugInfo
        }, { status: 400 });
      }

      const start = today();
      const end = addDays(start, Number(tariff.term_days));
      debugInfo.push(`POST: 19. Investment period: ${start} to ${end}`);

      debugInfo.push('POST: 20. Creating investment record');
      const invRes = await client.query(
        `INSERT INTO investments(user_id, tariff_id, amount, daily_percent, term_days, start_date, end_date, status)
         VALUES ($1,$2,$3,$4,$5,$6,$7,'active') RETURNING id`,
        [uid, Number(tariff.id), amt, Number(tariff.daily_percent), Number(tariff.term_days), start, end]
      );
      const investmentId = Number(invRes.rows[0].id);
      debugInfo.push(`POST: 21. Investment created with ID: ${investmentId}`);

      // Ledger lock: move from available to locked
      debugInfo.push('POST: 22. Creating ledger entry');
      await client.query(
        `INSERT INTO ledger_entries(user_id, currency, entry_type, amount, balance_available_delta, balance_locked_delta, related_investment_id)
         VALUES ($1,$2,'investment_buy_lock',$3,$4,$5,$6)`,
        [uid, 'USDT', amt, -amt, amt, investmentId]
      );
      debugInfo.push('POST: 23. Ledger entry created successfully');

      debugInfo.push('POST: 24. Investment creation completed successfully');
      return NextResponse.json({
        success: true,
        data: { investment_id: investmentId },
        debug: debugInfo
      });
    });
  } catch (e) {
    debugInfo.push(`POST: ERROR: ${e instanceof Error ? e.message : String(e)}`);
    debugInfo.push(`POST: Stack: ${e instanceof Error ? e.stack : 'No stack trace'}`);

    console.error('Investment buy error:', e);
    console.error('POST Debug info:', debugInfo);

    return NextResponse.json({
      success: false,
      error: 'Internal server error',
      debug: debugInfo,
      errorDetails: e instanceof Error ? e.message : String(e)
    }, { status: 500 });
  }
}
