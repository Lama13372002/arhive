import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const telegram_id = searchParams.get('telegram_id');
    if (!telegram_id) {
      return NextResponse.json({ success: false, error: 'Telegram ID is required' }, { status: 400 });
    }

    const userRes = await db.query('SELECT ref_code FROM users WHERE telegram_id = $1', [telegram_id]);
    if (userRes.rows.length === 0) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 });
    }

    const refCode = String(userRes.rows[0].ref_code);
    const bot = process.env.BOT_USERNAME;
    const shortName = process.env.WEBAPP_SHORT_NAME;
    if (!bot || !shortName) {
      return NextResponse.json({ success: false, error: 'BOT_USERNAME or WEBAPP_SHORT_NAME is not configured' }, { status: 500 });
    }

    // Web App short_name deep link
    const link_app = `https://t.me/${bot}/${encodeURIComponent(shortName)}?startapp=${encodeURIComponent(refCode)}`;

    return NextResponse.json({ success: true, data: { link: link_app, link_app, ref_code: refCode } });
  } catch (e) {
    console.error('Referral link error:', e);
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 });
  }
}
