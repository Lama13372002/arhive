'use client';

import { useState, useEffect, useCallback } from 'react';
import { ArrowUpRight, ArrowDownRight, TrendingUp, Wallet, Users, Eye, EyeOff, Loader2, ExternalLink } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useTelegram } from '@/components/providers/telegram-provider';
import { NetworkInfo } from '@/types';
import { DepositEstimate } from '@/components/ui/deposit-estimate';
import { getExplorerUrl, getExplorerName, isExplorerSupported } from '@/lib/explorer-utils';
import { useVerificationStatus } from '@/hooks/use-verification-status';
import { useDepositEstimate } from '@/hooks/use-deposit-estimate';

export function DashboardTab() {
  const { user } = useTelegram();
  const { isVerified } = useVerificationStatus();
  const [balanceVisible, setBalanceVisible] = useState(true);
  const [isLoaded, setIsLoaded] = useState(false);
  const [depositOpen, setDepositOpen] = useState(false);
  const [withdrawOpen, setWithdrawOpen] = useState(false);
  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawAddress, setWithdrawAddress] = useState('');
  const [selectedNetwork, setSelectedNetwork] = useState('TRON');
  const { toast } = useToast();

  const [stats, setStats] = useState({
    available: 0,
    locked: 0,
    bonus: 0,
    total: 0,
    roi: 0,
    weeklyGrowth: 0,
    activeInvestments: 0,
    totalReferrals: 0,
  });

  // New state for NowPayments-like flow
  const [isDepositLoading, setIsDepositLoading] = useState(false);
  const [isWithdrawLoading, setIsWithdrawLoading] = useState(false);
  const [generatedOrderId, setGeneratedOrderId] = useState<string | null>(null);
  const [generatedAddress, setGeneratedAddress] = useState<string | null>(null);
  const [isCheckingDeposit, setIsCheckingDeposit] = useState(false);
  const [depositTxHash, setDepositTxHash] = useState<string | null>(null);
  const [depositNetwork, setDepositNetwork] = useState<string | null>(null);
  const [depositNetworks, setDepositNetworks] = useState<NetworkInfo[]>([]);
  const [withdrawNetworks, setWithdrawNetworks] = useState<NetworkInfo[]>([]);
  const [isNetworksLoading, setIsNetworksLoading] = useState(true);
  const [cancelLockTime, setCancelLockTime] = useState<number | null>(null);
  const [depositAmountWithFee, setDepositAmountWithFee] = useState<string>('');

  // Хук для получения расчета депозита с комиссией
  const { estimate, fetchEstimate } = useDepositEstimate();

  // Загрузка сетей из API
  const loadNetworks = useCallback(async () => {
    try {
      setIsNetworksLoading(true);
      const [depositRes, withdrawRes] = await Promise.all([
        fetch('/api/user/networks?type=payment', { cache: 'no-store' }),
        fetch('/api/user/networks?type=payout', { cache: 'no-store' })
      ]);

      const [depositData, withdrawData] = await Promise.all([
        depositRes.json(),
        withdrawRes.json()
      ]);

      if (depositData.success) {
        setDepositNetworks(depositData.data.networks);
      }
      if (withdrawData.success) {
        setWithdrawNetworks(withdrawData.data.networks);
      }

      // Устанавливаем TRON как выбранную сеть, если доступна, иначе первую доступную
      if (depositData.success && depositData.data.networks.length > 0) {
        const tronNetwork = depositData.data.networks.find((n: NetworkInfo) => n.value === 'TRON');
        setSelectedNetwork(tronNetwork ? 'TRON' : depositData.data.networks[0].value);
      }
    } catch (error) {
      console.error('Failed to load networks:', error);
      toast({
        title: "Error",
        description: "Failed to load payment networks",
        variant: "destructive",
      });
    } finally {
      setIsNetworksLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    loadNetworks();
  }, [loadNetworks]);

  // Получаем расчет депозита когда изменяется сумма или сеть
  useEffect(() => {
    if (depositAmount && parseFloat(depositAmount) > 0) {
      fetchEstimate(depositAmount, selectedNetwork);
    }
  }, [depositAmount, selectedNetwork, fetchEstimate]);

  // Обновляем сумму с комиссией когда получили расчет
  useEffect(() => {
    if (estimate?.pay_amount) {
      setDepositAmountWithFee(estimate.pay_amount.toFixed(2));
    }
  }, [estimate]);

  // Автоматическая проверка депозита в реальном времени
  useEffect(() => {
    if (!generatedOrderId || isCheckingDeposit) return;

    const interval = setInterval(async () => {
      try {
        const res = await fetch('/api/deposits/check', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ order_id: generatedOrderId })
        });
        const data = await res.json();
        if (data.success) {
          const status = data.data?.status;
          const txHash = data.data?.tx_hash;
          const network = data.data?.network;

          // Сохраняем данные о транзакции если они есть
          if (txHash && !depositTxHash) {
            setDepositTxHash(txHash);
            toast({ title: 'Transaction detected', description: 'Transaction found in blockchain scanner!' });
          }
          if (network) {
            setDepositNetwork(network);
          }

          if (status === 'confirmed') {
            toast({ title: 'Deposit confirmed', description: 'Funds have been credited to your balance.' });
            setDepositOpen(false);
            setGeneratedOrderId(null);
            setGeneratedAddress(null);
            setDepositTxHash(null);
            setDepositNetwork(null);
            // Перезагружаем баланс
            if (user?.id) {
              try {
                const res = await fetch(`/api/user/balance?user_id=${user.id}`);
                const data = await res.json();
                if (data.success) {
                  setStats((prev) => ({ ...prev, available: data.data.available || prev.available }));
                }
              } catch {}
            }
          }
        }
      } catch (e) {
        // Игнорируем ошибки автоматической проверки
      }
    }, 5000); // Проверяем каждые 5 секунд

    return () => clearInterval(interval);
  }, [generatedOrderId, isCheckingDeposit, depositTxHash, toast, user?.id]);

  useEffect(() => {
    async function load() {
      if (!user?.id) return;
      try {
        const res = await fetch(`/api/user/balance?user_id=${user.id}`);
        const data = await res.json();
        if (data.success) {
          setStats({
            available: data.data.available || 0,
            locked: data.data.locked || 0,
            bonus: data.data.bonus || 0,
            total: (data.data.total_balance || 0),
            roi: data.data.roi ? Number(data.data.roi) : 0,
            weeklyGrowth: data.data.weekly_growth ? Number(data.data.weekly_growth) : 0,
            activeInvestments: data.data.active_plans || 0,
            totalReferrals: data.data.referrals || 0,
          });
        }
      } catch (e) {
        console.warn('Dashboard load error', e);
      }
    }
    load();
  }, [user?.id]);

  // 5-секундный лок кнопки Cancel при генерации адреса
  useEffect(() => {
    if (generatedAddress) {
      setCancelLockTime(5);
      const interval = setInterval(() => {
        setCancelLockTime(prev => {
          if (prev === null || prev <= 1) {
            clearInterval(interval);
            return null;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    } else {
      setCancelLockTime(null);
    }
  }, [generatedAddress]);

  const reloadBalance = async () => {
    if (!user?.id) return;
    try {
      const res = await fetch(`/api/user/balance?user_id=${user.id}`);
      const data = await res.json();
      if (data.success) {
        setStats((prev) => ({ ...prev, available: data.data.available || prev.available }));
      }
    } catch {}
  };

  const formatBalance = (amount: number) => {
    return balanceVisible ? `${amount.toFixed(2)} USDT` : '••••• USDT';
  };

  const handleDeposit = async () => {
    if (!user?.id) {
      toast({ title: 'Error', description: 'User not authenticated', variant: 'destructive' });
      return;
    }
    const selectedNetworkInfo = depositNetworks.find(n => n.value === selectedNetwork);
    const minAmount = selectedNetworkInfo?.min_amount || 10;

    if (!depositAmount || parseFloat(depositAmount) < minAmount) {
      toast({ title: 'Invalid Amount', description: `Minimum deposit amount is ${minAmount} USDT`, variant: 'destructive' });
      return;
    }
    try {
      setIsDepositLoading(true);
      const response = await fetch('/api/deposits/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: depositAmount, network: selectedNetwork, user_id: user.id })
      });
      const result = await response.json();
      if (result.success) {
        toast({ title: 'Deposit Created', description: 'Payment address generated successfully' });
        if (result.data.address) {
          setGeneratedAddress(result.data.address);
          setGeneratedOrderId(result.data.order_id || null);
        }
        setDepositAmount('');
      } else {
        toast({ title: 'Error', description: result.error || 'Failed to create deposit', variant: 'destructive' });
      }
    } catch (e) {
      toast({ title: 'Error', description: 'Failed to create deposit. Please try again.', variant: 'destructive' });
    } finally {
      setIsDepositLoading(false);
    }
  };

  const handleCheckDeposit = async () => {
    if (!generatedOrderId) return;
    try {
      setIsCheckingDeposit(true);
      const res = await fetch('/api/deposits/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ order_id: generatedOrderId })
      });
      const data = await res.json();
      if (data.success) {
        const status = data.data?.status;
        const txHash = data.data?.tx_hash;
        const network = data.data?.network;

        // Сохраняем данные о транзакции если они есть
        if (txHash) {
          setDepositTxHash(txHash);
        }
        if (network) {
          setDepositNetwork(network);
        }

        if (status === 'confirmed') {
          toast({ title: 'Deposit confirmed', description: 'Funds have been credited to your balance.' });
          setDepositOpen(false);
          setGeneratedOrderId(null);
          setGeneratedAddress(null);
          setDepositTxHash(null);
          setDepositNetwork(null);
          await reloadBalance();
        } else if (status === 'pending') {
          toast({ title: 'Awaiting confirmations', description: 'Please wait for blockchain confirmations.' });
        } else if (status === 'failed' || status === 'expired') {
          toast({ title: 'Payment not completed', description: 'The payment failed or expired.', variant: 'destructive' });
        }
      } else {
        toast({ title: 'Error', description: data.error || 'Failed to check deposit', variant: 'destructive' });
      }
    } catch (e) {
      toast({ title: 'Error', description: 'Failed to check deposit', variant: 'destructive' });
    } finally {
      setIsCheckingDeposit(false);
    }
  };

  const handleWithdraw = async () => {
    if (!user?.id) {
      toast({ title: 'Error', description: 'User not authenticated', variant: 'destructive' });
      return;
    }

    // Check verification status before allowing withdrawal
    if (!isVerified) {
      toast({
        title: "Verification Required",
        description: "You need to complete verification before making withdrawals. Please verify your identity first.",
        variant: "destructive",
      });
      return;
    }
    if (!withdrawAmount || !withdrawAddress) {
      toast({ title: 'Missing Information', description: 'Please fill in all required fields', variant: 'destructive' });
      return;
    }
    const amount = parseFloat(withdrawAmount);
    const selectedNetworkInfo = withdrawNetworks.find(n => n.value === selectedNetwork);
    const minAmount = selectedNetworkInfo?.min_amount || 10;

    if (amount < minAmount) {
      toast({ title: 'Invalid Amount', description: `Minimum withdrawal amount is ${minAmount} USDT`, variant: 'destructive' });
      return;
    }
    if (amount > stats.available) {
      toast({ title: 'Insufficient Balance', description: "Not enough available balance", variant: 'destructive' });
      return;
    }
    try {
      setIsWithdrawLoading(true);
      const response = await fetch('/api/withdrawals/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: withdrawAmount, address: withdrawAddress, network: selectedNetwork, user_id: user.id })
      });
      const result = await response.json();
      if (result.success) {
        toast({ title: 'Withdrawal Request Submitted', description: 'Your withdrawal will be processed by admin within 24 hours' });
        setWithdrawOpen(false);
        setWithdrawAmount('');
        setWithdrawAddress('');
        await reloadBalance();
      } else {
        toast({ title: 'Error', description: result.error || 'Failed to create withdrawal', variant: 'destructive' });
      }
    } catch (e) {
      toast({ title: 'Error', description: 'Failed to create withdrawal. Please try again.', variant: 'destructive' });
    } finally {
      setIsWithdrawLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied', description: 'Copied to clipboard' });
  };

  return (
    <div className="space-y-6">
      {/* Balance Cards */}
      <div className="space-y-4">
        {/* Main Balance Card */}
        <Card className={`transition-all duration-700 ${
          isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
        } border border-border/60 bg-card shadow-sm hover:shadow-md rounded-2xl`}>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base font-semibold">Available Balance</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setBalanceVisible(!balanceVisible)}
                className="text-muted-foreground hover:text-foreground transition-colors rounded-full w-8 h-8 p-0"
              >
                {balanceVisible ? <Eye size={16} /> : <EyeOff size={16} />}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-6">
              <div className={`text-4xl font-bold tracking-tight ${
                balanceVisible ? 'opacity-100' : 'opacity-90'
              }`}>
                {formatBalance(stats.available)}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1 p-4 rounded-xl bg-card/60 border border-border/60 hover:border-warning/40 transition-colors">
                  <p className="text-xs text-muted-foreground">Locked</p>
                  <p className="text-sm font-medium text-warning">{formatBalance(stats.locked)}</p>
                </div>
                <div className="space-y-1 p-4 rounded-xl bg-card/60 border border-border/60 hover:border-primary/40 transition-colors">
                  <p className="text-xs text-muted-foreground">Bonus</p>
                  <p className="text-sm font-medium text-primary">{formatBalance(stats.bonus)}</p>
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <Dialog open={depositOpen} onOpenChange={(open) => {
                  setDepositOpen(open);
                  if (!open) {
                    setGeneratedOrderId(null);
                    setGeneratedAddress(null);
                    setDepositAmount('');
                    setDepositTxHash(null);
                    setDepositNetwork(null);
                    setDepositAmountWithFee('');
                  }
                }}>
                  <DialogTrigger asChild>
                    <Button
                      className="flex-1 h-11 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90"
                      size="default"
                    >
                      <ArrowDownRight size={18} className="mr-2" />
                      Deposit
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md mx-auto max-h-[90vh] overflow-y-auto bg-card border border-border/60 shadow-xl rounded-2xl">
                    <DialogHeader className="pb-3 border-b border-border/60">
                      <DialogTitle className="text-xl font-semibold flex items-center">
                        <div className="mr-3 rounded-full p-2 border border-border/60 bg-card">
                          <ArrowDownRight size={20} className="text-primary" />
                        </div>
                        Deposit USDT
                      </DialogTitle>
                    </DialogHeader>

                    <div className="space-y-6 pt-2">
                      {!generatedAddress && (
                        <>
                          <div className="space-y-2">
                            <Label htmlFor="deposit-amount" className="text-sm font-medium text-white">Amount (USDT)</Label>
                            <Input
                              id="deposit-amount"
                              type="number"
                              placeholder={`Minimum: ${depositNetworks.find(n => n.value === selectedNetwork)?.min_amount || 10} USDT`}
                              value={depositAmount}
                              onChange={(e) => setDepositAmount(e.target.value)}
                              className="h-12 rounded-xl bg-card/60 border border-border/60 focus-visible:ring-1 focus-visible:ring-primary text-white"
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="deposit-network" className="text-sm font-medium text-white">Network</Label>
                            <Select value={selectedNetwork} onValueChange={setSelectedNetwork}>
                              <SelectTrigger className="h-12 rounded-xl bg-card/60 border border-border/60 focus-visible:ring-1 focus-visible:ring-primary text-white">
                                <SelectValue placeholder="Select network" />
                              </SelectTrigger>
                              <SelectContent className="bg-card border border-border/60 rounded-xl shadow-lg">
                                {depositNetworks.map((network) => (
                                  <SelectItem key={network.value} value={network.value} className="focus:bg-muted/30 text-white">
                                    {network.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <DepositEstimate amount={depositAmount} network={selectedNetwork} className="" />

                          <div className="rounded-2xl p-4 border border-border/60 bg-card/50">
                            <div className="flex justify-between text-sm mb-2">
                              <span className="text-muted-foreground font-medium">Network:</span>
                              <span className="text-foreground font-semibold">{depositNetworks.find(n => n.value === selectedNetwork)?.label}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground font-medium">Static Fee:</span>
                              <span className="text-foreground font-semibold">{depositNetworks.find(n => n.value === selectedNetwork)?.fee}</span>
                            </div>
                          </div>
                        </>
                      )}

                      {generatedAddress && (
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label className="text-sm text-white">Payment address</Label>
                            <div className="flex items-center justify-between rounded-xl border border-border/60 bg-card/60 px-3 py-2">
                              <span className="text-sm break-all pr-4 text-white">{generatedAddress}</span>
                              <Button variant="secondary" size="sm" onClick={() => copyToClipboard(generatedAddress!)} className="ml-3 flex-shrink-0">Copy</Button>
                            </div>
                          </div>

                          {/* Блок с суммой для отправки */}
                          <div className="rounded-xl border border-yellow-500/30 bg-yellow-500/10 p-4">
                            <div className="space-y-3">
                              <Label className="text-sm font-medium text-yellow-200">Amount to send</Label>
                              <div className="flex items-center justify-between rounded-lg border border-yellow-500/30 bg-card/60 px-3 py-2">
                                <span className="text-lg font-bold text-yellow-100">{depositAmountWithFee || depositAmount} USDT</span>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => copyToClipboard(depositAmountWithFee || depositAmount)}
                                  className="ml-3 flex-shrink-0 border-yellow-500/30 text-yellow-200 hover:bg-yellow-500/20"
                                >
                                  Copy
                                </Button>
                              </div>
                              <p className="text-xs text-yellow-200/80 font-medium">
                                You must send amount not lower than those specified here.
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-3">
                            <Button onClick={handleCheckDeposit} disabled={isCheckingDeposit} className="flex-1">
                              {isCheckingDeposit ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : null}
                              Check payment
                            </Button>
                            <Button
                              variant="ghost"
                              disabled={!depositTxHash || !depositNetwork}
                              onClick={() => {
                                if (depositTxHash && depositNetwork) {
                                  const explorerUrl = getExplorerUrl(depositNetwork, depositTxHash);
                                  if (explorerUrl) {
                                    window.open(explorerUrl, '_blank');
                                  }
                                }
                              }}
                            >
                              <ExternalLink className="h-4 w-4 mr-2"/>
                              {depositNetwork ? getExplorerName(depositNetwork) : 'Explorer'}
                            </Button>
                          </div>
                        </div>
                      )}

                      <div className="flex gap-3 pt-2">
                        <Button
                          variant="outline"
                          disabled={!!generatedAddress && cancelLockTime !== null}
                          onClick={() => {
                            setDepositOpen(false);
                            setGeneratedOrderId(null);
                            setGeneratedAddress(null);
                            setDepositAmount('');
                            setDepositTxHash(null);
                            setDepositNetwork(null);
                            setDepositAmountWithFee('');
                          }}
                          className="flex-1 h-11 rounded-xl text-white border-white/20 hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {!!generatedAddress && cancelLockTime !== null ? `Cancel (${cancelLockTime}s)` : 'Cancel'}
                        </Button>
                        {!generatedAddress && (
                          <Button onClick={handleDeposit} disabled={isDepositLoading} className="flex-1 h-11 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90">
                            {isDepositLoading ? (<><Loader2 className="mr-2 h-4 w-4 animate-spin" />Creating...</>) : ('Generate Address')}
                          </Button>
                        )}
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>

                {/* Withdraw Dialog */}
                <Dialog open={withdrawOpen} onOpenChange={setWithdrawOpen}>
                  <DialogTrigger asChild>
                    <Button
                      className="flex-1 h-11 rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      size="default"
                      onClick={(e) => {
                        if (!isVerified) {
                          e.preventDefault();
                          toast({
                            title: "Verification Required",
                            description: "You need to complete verification before making withdrawals. Please verify your identity first.",
                            variant: "destructive",
                          });
                        }
                      }}
                    >
                      <ArrowUpRight size={18} className="mr-2" />
                      Withdraw
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md mx-auto max-h-[90vh] overflow-y-auto bg-card border border-border/60 shadow-xl rounded-2xl">
                    <DialogHeader className="pb-3 border-b border-border/60">
                      <DialogTitle className="text-xl font-semibold flex items-center">
                        <div className="mr-3 rounded-full p-2 border border-border/60 bg-card">
                          <ArrowUpRight size={20} className="text-destructive" />
                        </div>
                        Withdraw USDT
                      </DialogTitle>
                    </DialogHeader>

                    <div className="space-y-6 pt-2">
                      {/* Amount */}
                      <div className="space-y-2">
                        <Label htmlFor="withdraw-amount" className="text-sm font-medium text-white">Amount (USDT)</Label>
                        <Input
                          id="withdraw-amount"
                          type="number"
                          placeholder={`Minimum: ${withdrawNetworks.find(n => n.value === selectedNetwork)?.min_amount || 10} USDT`}
                          value={withdrawAmount}
                          onChange={(e) => setWithdrawAmount(e.target.value)}
                          className="h-12 rounded-xl bg-card/60 border border-border/60 focus-visible:ring-1 focus-visible:ring-destructive text-white"
                        />
                      </div>
                      {/* Address */}
                      <div className="space-y-2">
                        <Label htmlFor="withdraw-address" className="text-sm font-medium text-white">Wallet Address</Label>
                        <Input id="withdraw-address" placeholder="Enter your wallet address" value={withdrawAddress} onChange={(e) => setWithdrawAddress(e.target.value)} className="h-12 rounded-xl bg-card/60 border border-border/60 focus-visible:ring-1 focus-visible:ring-destructive text-white" />
                      </div>
                      {/* Network */}
                      <div className="space-y-2">
                        <Label htmlFor="withdraw-network" className="text-sm font-medium text-white">Network</Label>
                        <Select value={selectedNetwork} onValueChange={setSelectedNetwork}>
                          <SelectTrigger className="h-12 rounded-xl bg-card/60 border border-border/60 focus-visible:ring-1 focus-visible:ring-destructive text-white">
                            <SelectValue placeholder="Select network" />
                          </SelectTrigger>
                          <SelectContent className="bg-card border border-border/60 rounded-xl shadow-lg">
                            {withdrawNetworks.map((network) => (
                              <SelectItem key={network.value} value={network.value} className="focus:bg-muted/30 text-white">
                                {network.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      {/* Summary */}
                      <div className="rounded-2xl p-4 border border-border/60 bg-card/50">
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-muted-foreground font-medium">Amount:</span>
                          <span className="font-semibold text-white">{withdrawAmount || '0'} USDT</span>
                        </div>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-muted-foreground font-medium">Fee:</span>
                          <span className="font-semibold text-white">{(() => {
                            if (!withdrawAmount) return '0 USDT';
                            const amount = parseFloat(withdrawAmount);
                            const networkInfo = withdrawNetworks.find(n => n.value === selectedNetwork);
                            if (!networkInfo) return '0 USDT';
                            let totalFee = networkInfo.fee_fixed || 0;
                            if (networkInfo.fee_percent > 0) {
                              totalFee += amount * networkInfo.fee_percent;
                            }
                            return `${totalFee.toFixed(2)} USDT`;
                          })()}</span>
                        </div>
                        <div className="flex justify-between text-sm font-medium border-t border-border/60 pt-3">
                          <span className="text-muted-foreground">You will receive:</span>
                          <span className="text-destructive font-bold text-lg">{(() => {
                            if (!withdrawAmount) return '0';
                            const amount = parseFloat(withdrawAmount);
                            const networkInfo = withdrawNetworks.find(n => n.value === selectedNetwork);
                            if (!networkInfo) return amount.toFixed(2);

                            let totalFee = networkInfo.fee_fixed || 0;
                            if (networkInfo.fee_percent > 0) {
                              totalFee += amount * networkInfo.fee_percent;
                            }

                            return (amount - totalFee).toFixed(2);
                          })()} USDT</span>
                        </div>
                      </div>

                      <div className="flex gap-3 pt-2">
                        <Button variant="outline" onClick={() => setWithdrawOpen(false)} className="flex-1 h-11 rounded-xl text-white border-white/20 hover:bg-white/10">Cancel</Button>
                        <Button onClick={handleWithdraw} disabled={isWithdrawLoading} className="flex-1 h-11 rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90">
                          {isWithdrawLoading ? (<><Loader2 className="mr-2 h-4 w-4 animate-spin" />Submitting...</>) : ('Submit Withdrawal')}
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* ROI Card */}
        <Card className={`transition-all duration-700 ${
          isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
        } border border-border/60 bg-card shadow-sm hover:shadow-md rounded-2xl`} style={{ animationDelay: '100ms' }}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-muted/40 flex items-center justify-center">
                  <TrendingUp size={20} className="text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium">ROI</p>
                  <p className="text-2xl font-bold text-foreground">
                    {stats.roi.toFixed(2)}%
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">Weekly Growth</p>
                <p className="text-lg font-semibold text-primary">
                  +{stats.weeklyGrowth.toFixed(2)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      {/* Performance Section */}
      <div className={`space-y-4 transition-all duration-700 ${
        isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
      }`} style={{ animationDelay: '200ms' }}>
        <h3 className="text-lg font-semibold">Performance</h3>

        <div className="grid grid-cols-2 gap-4">
          <Card className="border border-border/60 bg-card shadow-sm hover:shadow-md rounded-2xl cursor-pointer group transition-transform hover:-translate-y-0.5">
            <CardContent className="p-4 text-center">
              <Wallet size={24} className="mx-auto mb-2 text-primary" />
              <p className="text-2xl font-bold">{stats.activeInvestments}</p>
              <p className="text-xs text-muted-foreground">Active Plans</p>
            </CardContent>
          </Card>

          <Card className="border border-border/60 bg-card shadow-sm hover:shadow-md rounded-2xl cursor-pointer group transition-transform hover:-translate-y-0.5">
            <CardContent className="p-4 text-center">
              <Users size={24} className="mx-auto mb-2 text-primary" />
              <p className="text-2xl font-bold">{stats.totalReferrals}</p>
              <p className="text-xs text-muted-foreground">Referrals</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
