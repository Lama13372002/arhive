import { useState, useEffect, useCallback, useRef } from 'react';

export type KycStatus = 'not_started' | 'pending' | 'completed' | 'declined';

export function useKycStatus(userId?: number) {
  const [kycStatus, setKycStatus] = useState<KycStatus>('not_started');
  const [isLoading, setIsLoading] = useState(true);
  const lastStatusRef = useRef<KycStatus>('not_started');

  const fetchStatus = useCallback(async () => {
    if (!userId) {
      setIsLoading(false);
      return;
    }

    try {
      const res = await fetch(`/api/verification/status?userId=${userId}`, {
        cache: 'no-store'
      });
      const data = await res.json();

      if (res.ok && data.kycStatus) {
        const newStatus = data.kycStatus;

        // Если статус изменился с pending на not_started, это означает сброс
        if (lastStatusRef.current === 'pending' && newStatus === 'not_started') {
          console.log('KYC status was reset due to incomplete verification');
        }

        setKycStatus(newStatus);
        lastStatusRef.current = newStatus;
      }
    } catch (error) {
      console.error('Failed to fetch KYC status:', error);
    } finally {
      setIsLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    fetchStatus();

    // Автоматически проверяем статус каждые 5 секунд для случаев сброса
    const interval = setInterval(() => {
      if (kycStatus === 'pending') {
        fetchStatus();
      }
    }, 5000);

    // Проверяем статус при возврате в приложение (focus)
    const handleFocus = () => {
      if (kycStatus === 'pending') {
        fetchStatus();
      }
    };

    const handleVisibilityChange = () => {
      if (!document.hidden && kycStatus === 'pending') {
        fetchStatus();
      }
    };

    window.addEventListener('focus', handleFocus);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      clearInterval(interval);
      window.removeEventListener('focus', handleFocus);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [fetchStatus, kycStatus]);

  return { kycStatus, isLoading, refetch: fetchStatus };
}
