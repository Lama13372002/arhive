const cron = require('node-cron');

// Конфигурация по умолчанию
let cronSettings = {
  check_interval_minutes: 10,
  timezone: "UTC"
};

// Загрузка настроек из базы данных (если нужно)
async function loadCronSettings() {
  try {
    // Можно добавить загрузку из БД, пока используем дефолтные
    console.log('📋 Using cron settings:', cronSettings);
  } catch (error) {
    console.error('❌ Failed to load cron settings, using defaults:', error);
  }
}

// Функция автоматических начислений
async function runAccruals() {
  const startTime = Date.now();
  console.log(`🚀 [${new Date().toISOString()}] Запуск автоматических начислений...`);

  try {
    // Получаем URL приложения из переменных окружения
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL || 'http://localhost:3000';
    const apiUrl = `${appUrl}/api/admin/accruals/auto-run`;

    console.log(`📡 Запрос к: ${apiUrl}`);

    // Делаем запрос к API для начислений
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Internal-AccrualsMonitor'
      },
      timeout: 30000 // 30 секунд таймаут
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const result = await response.json();
    const duration = Date.now() - startTime;

    if (result.success) {
      console.log(`✅ [${new Date().toISOString()}] Начисления выполнены за ${duration}ms:`, result.message);
    } else {
      console.error(`❌ [${new Date().toISOString()}] Ошибка начислений:`, result.error);
    }

    return result;
  } catch (error) {
    const duration = Date.now() - startTime;
    console.error(`❌ [${new Date().toISOString()}] Ошибка при выполнении начислений за ${duration}ms:`, error.message);
    return { success: false, error: error.message };
  }
}

// Проверка доступности API
async function checkApiHealth() {
  try {
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL || 'http://localhost:3000';
    const healthUrl = `${appUrl}/api/cron/init`;

    const response = await fetch(healthUrl, {
      method: 'GET',
      headers: {
        'User-Agent': 'Internal-AccrualsMonitor'
      },
      timeout: 10000
    });

    if (response.ok) {
      console.log('✅ API доступен');
      return true;
    } else {
      console.log('⚠️ API недоступен:', response.status);
      return false;
    }
  } catch (error) {
    console.log('⚠️ API недоступен:', error.message);
    return false;
  }
}

// Основная функция запуска
async function startAccrualsMonitor() {
  console.log('🚀 Запуск Accruals Monitor...');

  // Загружаем настройки
  await loadCronSettings();

  // Ждем доступности API
  console.log('🔍 Ожидание доступности API...');
  while (true) {
    if (await checkApiHealth()) {
      break;
    }
    console.log('⏳ API недоступен, ожидание 10 секунд...');
    await new Promise(resolve => setTimeout(resolve, 10000));
  }

  console.log('✅ API доступен, запуск cron задач...');

  // Настройка cron задачи
  const interval = cronSettings.check_interval_minutes;
  const timezone = cronSettings.timezone;
  const schedulePattern = `*/${interval} * * * *`;

  console.log(`⏰ Расписание начислений: каждые ${interval} минут (timezone: ${timezone})`);

  // Запуск cron задачи
  cron.schedule(schedulePattern, async () => {
    await runAccruals();
  }, {
    timezone: timezone
  });

  // Первый запуск через 30 секунд после старта
  setTimeout(async () => {
    console.log('🎯 Первый запуск начислений...');
    await runAccruals();
  }, 30000);

  console.log('✅ Accruals Monitor успешно запущен!');
}

// Обработка сигналов завершения
process.on('SIGINT', () => {
  console.log('🛑 Получен SIGINT, завершение работы...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('🛑 Получен SIGTERM, завершение работы...');
  process.exit(0);
});

// Обработка необработанных ошибок
process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught Exception:', error);
  process.exit(1);
});

// Запуск
startAccrualsMonitor().catch(error => {
  console.error('❌ Критическая ошибка при запуске:', error);
  process.exit(1);
});
