#!/bin/bash

# Цвета для красивого вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🚀 Скрипт управления Accruals Monitor${NC}"
echo ""

case "$1" in
  "start")
    echo -e "${YELLOW}📦 Запуск accruals-monitor через PM2...${NC}"
    # Создаем директорию для логов если не существует
    mkdir -p .pm2

    # Останавливаем если уже запущен
    pm2 stop accruals-monitor 2>/dev/null || true
    pm2 delete accruals-monitor 2>/dev/null || true

    # Запускаем с конфигурацией
    pm2 start accruals-monitor.config.js

    echo -e "${GREEN}✅ Accruals-monitor запущен!${NC}"
    echo ""
    echo -e "${BLUE}📊 Информация о процессе:${NC}"
    pm2 list accruals-monitor
    echo ""
    echo -e "${BLUE}📋 Полезные команды:${NC}"
    echo "  pm2 logs accruals-monitor    - просмотр логов"
    echo "  pm2 monit                    - мониторинг"
    echo "  pm2 restart accruals-monitor - перезапуск"
    echo "  ./manage-accruals-monitor.sh stop - остановка"
    ;;

  "stop")
    echo -e "${YELLOW}🛑 Остановка accruals-monitor...${NC}"
    pm2 stop accruals-monitor
    pm2 delete accruals-monitor
    echo -e "${GREEN}✅ Accruals-monitor остановлен!${NC}"
    ;;

  "restart")
    echo -e "${YELLOW}🔄 Перезапуск accruals-monitor...${NC}"
    pm2 restart accruals-monitor
    echo -e "${GREEN}✅ Accruals-monitor перезапущен!${NC}"
    ;;

  "status")
    echo -e "${BLUE}📊 Статус accruals-monitor:${NC}"
    pm2 list accruals-monitor
    ;;

  "logs")
    echo -e "${BLUE}📋 Логи accruals-monitor:${NC}"
    pm2 logs accruals-monitor --lines 50
    ;;

  "setup")
    echo -e "${YELLOW}🔧 Установка зависимостей...${NC}"

    # Проверяем наличие PM2
    if ! command -v pm2 &> /dev/null; then
      echo -e "${YELLOW}📦 Установка PM2...${NC}"
      npm install -g pm2
    else
      echo -e "${GREEN}✅ PM2 уже установлен${NC}"
    fi

    # Проверяем наличие node-cron
    if ! node -e "require('node-cron')" 2>/dev/null; then
      echo -e "${YELLOW}📦 Установка node-cron...${NC}"
      npm install node-cron
    else
      echo -e "${GREEN}✅ node-cron уже установлен${NC}"
    fi

    # Создаем директорию для логов
    mkdir -p .pm2

    # Делаем скрипт исполняемым
    chmod +x manage-accruals-monitor.sh

    echo -e "${GREEN}✅ Настройка завершена!${NC}"
    echo -e "${BLUE}💡 Теперь можно запустить: ./manage-accruals-monitor.sh start${NC}"
    ;;

  "autostart")
    echo -e "${YELLOW}🔧 Настройка автозапуска...${NC}"

    # Сохраняем текущую конфигурацию PM2
    pm2 save

    # Генерируем startup скрипт
    echo -e "${BLUE}💡 Выполните следующую команду с правами sudo:${NC}"
    pm2 startup

    echo ""
    echo -e "${GREEN}✅ После выполнения команды выше accruals-monitor будет автоматически запускаться при перезагрузке системы${NC}"
    ;;

  "test")
    echo -e "${YELLOW}🧪 Тестирование подключения к API...${NC}"

    # Проверяем доступность API
    # Получаем URL из переменных окружения или используем localhost
    APP_URL="${NEXT_PUBLIC_APP_URL:-${APP_URL:-http://localhost:3000}}"
    echo -e "${BLUE}🔗 Используемый URL: ${APP_URL}${NC}"

    if curl -s -f "${APP_URL}/api/cron/init" > /dev/null; then
      echo -e "${GREEN}✅ API доступен${NC}"

      # Пробуем сделать тестовый запрос начислений
      echo -e "${YELLOW}📈 Тестовый запрос начислений...${NC}"
      curl -X POST "${APP_URL}/api/admin/accruals/auto-run" \
        -H "Content-Type: application/json" \
        -H "User-Agent: Internal-Test" \
        -w "\nHTTP Status: %{http_code}\n"
    else
      echo -e "${RED}❌ API недоступен по адресу ${APP_URL}${NC}"
      echo -e "${RED}   Убедитесь что основное TMA приложение запущено${NC}"
      echo -e "${YELLOW}💡 Для настройки другого URL установите переменную окружения:${NC}"
      echo -e "${YELLOW}   export NEXT_PUBLIC_APP_URL=https://quantumfintech.ai${NC}"
    fi
    ;;

  *)
    echo -e "${BLUE}📖 Использование:${NC}"
    echo "  ./manage-accruals-monitor.sh setup     - установка зависимостей"
    echo "  ./manage-accruals-monitor.sh start     - запуск мониторинга начислений"
    echo "  ./manage-accruals-monitor.sh stop      - остановка мониторинга"
    echo "  ./manage-accruals-monitor.sh restart   - перезапуск мониторинга"
    echo "  ./manage-accruals-monitor.sh status    - проверка статуса"
    echo "  ./manage-accruals-monitor.sh logs      - просмотр логов"
    echo "  ./manage-accruals-monitor.sh test      - тестирование API"
    echo "  ./manage-accruals-monitor.sh autostart - настройка автозапуска"
    echo ""
    echo -e "${YELLOW}💡 Для первого запуска выполните:${NC}"
    echo "  chmod +x manage-accruals-monitor.sh"
    echo "  ./manage-accruals-monitor.sh setup"
    echo "  ./manage-accruals-monitor.sh test"
    echo "  ./manage-accruals-monitor.sh start"
    echo ""
    echo -e "${BLUE}ℹ️ Этот скрипт управляет только автоматическими начислениями по планам${NC}"
    echo -e "${BLUE}   Для депозитов используйте manage-deposit-monitor.sh${NC}"
    ;;
esac
