import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';

// GET - получить количество непрочитанных сообщений для пользователя
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'user_id обязателен' },
        { status: 400 }
      );
    }

    const client = await pool.connect();

    try {
      // Сначала создадим таблицу для отслеживания последнего прочитанного сообщения, если её нет
      await client.query(`
        CREATE TABLE IF NOT EXISTS user_last_read (
          user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          room_id INTEGER NOT NULL REFERENCES chat_rooms(id) ON DELETE CASCADE,
          last_read_message_id INTEGER,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY (user_id, room_id)
        )
      `);

      // Получаем количество непрочитанных сообщений
      // Простая логика: считаем сообщения, которые появились после последнего прочитанного
      const result = await client.query(`
        SELECT
          COALESCE(SUM(
            CASE
              WHEN ulr.last_read_message_id IS NULL THEN
                (SELECT COUNT(*) FROM chat_messages WHERE room_id = cr.id AND user_id != $1)
              ELSE
                (SELECT COUNT(*) FROM chat_messages WHERE room_id = cr.id AND id > ulr.last_read_message_id AND user_id != $1)
            END
          ), 0) as total_unread
        FROM chat_rooms cr
        LEFT JOIN user_last_read ulr ON ulr.user_id = $1 AND ulr.room_id = cr.id
      `, [userId]);

      const unreadCount = Number.parseInt(result.rows[0]?.total_unread || '0');

      return NextResponse.json({
        success: true,
        data: {
          unreadCount,
          lastUpdated: new Date().toISOString()
        }
      });
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error fetching unread messages:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка получения непрочитанных сообщений' },
      { status: 500 }
    );
  }
}

// POST - отметить сообщения как прочитанные
export async function POST(request: NextRequest) {
  try {
    const { userId, roomId, lastReadMessageId } = await request.json();

    if (!userId || !roomId) {
      return NextResponse.json(
        { success: false, error: 'user_id и room_id обязательны' },
        { status: 400 }
      );
    }

    const client = await pool.connect();

    try {
      // Если lastReadMessageId не передан, берем последнее сообщение в комнате
      let messageId = lastReadMessageId;
      if (!messageId) {
        const lastMessage = await client.query(
          'SELECT id FROM chat_messages WHERE room_id = $1 ORDER BY created_at DESC LIMIT 1',
          [roomId]
        );
        messageId = lastMessage.rows[0]?.id;
      }

      if (messageId) {
        // Обновляем или создаем запись о последнем прочитанном сообщении
        await client.query(`
          INSERT INTO user_last_read (user_id, room_id, last_read_message_id, updated_at)
          VALUES ($1, $2, $3, CURRENT_TIMESTAMP)
          ON CONFLICT (user_id, room_id)
          DO UPDATE SET
            last_read_message_id = $3,
            updated_at = CURRENT_TIMESTAMP
        `, [userId, roomId, messageId]);
      }

      return NextResponse.json({
        success: true,
        message: 'Сообщения отмечены как прочитанные'
      });
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error marking messages as read:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка отметки сообщений как прочитанные' },
      { status: 500 }
    );
  }
}
