'use client';

import { useEffect, useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useVoiceAI } from '@/hooks/useVoiceAI';
import {
  Mic,
  MicOff,
  Trash2,
  Download,
  Filter,
  Play,
  Square,
  Eye,
  EyeOff,
  Globe,
  Wifi,
  AlertCircle
} from 'lucide-react';

interface LogEntry {
  id: string;
  timestamp: string;
  message: string;
  type: 'info' | 'success' | 'error' | 'event' | 'proxy-test' | 'proxy-error';
  data?: unknown;
}

interface ProxyTestResult {
  success: boolean;
  error?: string;
  responseTime: number;
  proxyUsed?: { id: number; ip: string; port: number };
}

export default function DebugPage() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isAutoScroll, setIsAutoScroll] = useState(true);
  const [filterType, setFilterType] = useState<string>('all');
  const [showRawData, setShowRawData] = useState(false);
  const [isTestingProxy, setIsTestingProxy] = useState(false);
  const [isTestingOpenAI, setIsTestingOpenAI] = useState(false);
  const [proxyText, setProxyText] = useState('');
  const [isAddingProxy, setIsAddingProxy] = useState(false);
  const logsEndRef = useRef<HTMLDivElement>(null);

  const { state, isConnected, connect, disconnect, error, logs: voiceLogs } = useVoiceAI();

  // Функция для добавления лога
  const addLog = (message: string, type: LogEntry['type'], data?: unknown) => {
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const timestamp = new Date().toLocaleTimeString('ru-RU', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      fractionalSecondDigits: 3
    });

    setLogs(prev => [...prev, {
      id,
      timestamp,
      message,
      type,
      data
    }]);
  };

  // Тестирование прокси подключения
  const testProxyConnection = async () => {
    setIsTestingProxy(true);
    addLog('🔍 Начинаем тестирование прокси подключения...', 'proxy-test');

    try {
      const response = await fetch('/api/admin/proxies/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ testUrl: 'https://httpbin.org/ip' })
      });

      const result = await response.json();

      if (result.success) {
        const proxyInfo = result.data?.proxyInfo;
        addLog(`✅ Прокси ${proxyInfo?.ip}:${proxyInfo?.port} работает! Время ответа: ${result.data?.responseTime}ms`, 'success', result);
      } else {
        addLog(`❌ Ошибка прокси подключения: ${result.error}`, 'proxy-error', result);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      addLog(`❌ Критическая ошибка тестирования прокси: ${errorMessage}`, 'proxy-error', { error: errorMessage, stack: error instanceof Error ? error.stack : undefined });
    } finally {
      setIsTestingProxy(false);
    }
  };

  // Тестирование OpenAI API через прокси
  const testOpenAIConnection = async () => {
    setIsTestingOpenAI(true);
    addLog('🤖 Начинаем тестирование OpenAI API через прокси...', 'proxy-test');

    try {
      const response = await fetch('/api/test-openai-proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ endpoint: '/v1/models' })
      });

      const result = await response.json();

      if (result.success) {
        addLog(`✅ OpenAI API доступен через прокси! Время ответа: ${result.responseTime}ms`, 'success', result);
      } else {
        addLog(`❌ Ошибка доступа к OpenAI API: ${result.error}`, 'proxy-error', result);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      addLog(`❌ Критическая ошибка тестирования OpenAI API: ${errorMessage}`, 'proxy-error', { error: errorMessage, stack: error instanceof Error ? error.stack : undefined });
    } finally {
      setIsTestingOpenAI(false);
    }
  };

  // Получение статистики прокси
  const getProxyStats = async () => {
    addLog('📊 Получаем статистику прокси...', 'info');

    try {
      const response = await fetch('/api/admin/proxies');
      const result = await response.json();

      if (result.success) {
        addLog(`📊 Статистика прокси получена: ${result.data?.proxies?.length || 0} прокси доступно`, 'success', result);
      } else {
        addLog(`❌ Ошибка получения статистики прокси: ${result.error}`, 'error', result);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      addLog(`❌ Критическая ошибка получения статистики: ${errorMessage}`, 'error', { error: errorMessage });
    }
  };

  // Добавление прокси
  const addProxy = async () => {
    if (!proxyText.trim()) {
      addLog('❌ Введите строку прокси для добавления', 'error');
      return;
    }

    setIsAddingProxy(true);
    addLog('➕ Добавляем прокси...', 'info', { proxyText });

    try {
      const response = await fetch('/api/admin/proxies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proxiesText: proxyText })
      });

      const result = await response.json();

      if (result.success) {
        addLog(`✅ Прокси успешно добавлен! ${result.message}`, 'success', result);
        setProxyText(''); // Очищаем поле
        // Автоматически получаем обновленную статистику
        await getProxyStats();
      } else {
        addLog(`❌ Ошибка добавления прокси: ${result.error}`, 'error', result);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      addLog(`❌ Критическая ошибка добавления прокси: ${errorMessage}`, 'error', { error: errorMessage });
    } finally {
      setIsAddingProxy(false);
    }
  };

  // Быстрое добавление тестового прокси
  const addTestProxy = () => {
    const testProxy = '143.20.172.60\t4598\t14598\tuser326029\tejdif4\tuser326029:ejdif4@143.20.172.60:4598';
    setProxyText(testProxy);
    addLog('📝 Тестовый прокси загружен в поле ввода', 'info', { testProxy });
  };

  // Синхронизируем логи из useVoiceAI
  useEffect(() => {
    if (voiceLogs.length > logs.length) {
      const newLogs = voiceLogs.slice(logs.length).map((log, index) => {
        const id = `voice-${Date.now()}-${index}`;
        const timestamp = new Date().toLocaleTimeString('ru-RU', {
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          fractionalSecondDigits: 3
        });

        let type: LogEntry['type'] = 'info';
        let data = undefined;

        // Определяем тип лога и извлекаем JSON данные
        if (log.includes('❌') || log.includes('Ошибка') || log.includes('failed to fetch')) {
          type = 'error';
        } else if (log.includes('✅') || log.includes('Сохранено')) {
          type = 'success';
        } else if (log.includes('🎯') || log.includes('Событие:')) {
          type = 'event';
        }

        // Пытаемся извлечь JSON из лога
        const jsonMatch = log.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          try {
            data = JSON.parse(jsonMatch[0]);
          } catch (e) {
            // Не JSON
          }
        }

        return {
          id,
          timestamp,
          message: log.replace(/^\[.*?\]\s*/, ''), // Убираем timestamp из сообщения
          type,
          data
        };
      });

      setLogs(prev => [...prev, ...newLogs]);
    }
  }, [voiceLogs, logs.length]);

  // Автопрокрутка
  useEffect(() => {
    if (isAutoScroll && logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, isAutoScroll]);

  const clearLogs = () => {
    setLogs([]);
  };

  const downloadLogs = () => {
    const logText = logs.map(log => `[${log.timestamp}] [${log.type.toUpperCase()}] ${log.message}${log.data ? '\nDATA: ' + JSON.stringify(log.data, null, 2) : ''}`).join('\n\n');
    const blob = new Blob([logText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `voice-ai-debug-logs-${new Date().toISOString().slice(0, 19)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleConnect = async () => {
    addLog('🔌 Начинаем подключение к Voice AI...', 'info');
    await connect(1); // Используем тестовый user_id = 1
  };

  const filteredLogs = logs.filter(log => {
    if (filterType === 'all') return true;
    return log.type === filterType;
  });

  const getLogBadgeColor = (type: LogEntry['type']) => {
    switch (type) {
      case 'error':
      case 'proxy-error':
        return 'bg-red-500 text-white';
      case 'success': return 'bg-green-500 text-white';
      case 'event': return 'bg-blue-500 text-white';
      case 'proxy-test': return 'bg-purple-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const formatJSON = (data: unknown) => {
    return JSON.stringify(data, null, 2);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Заголовок */}
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
            🐛 Voice AI Debug Console
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Детальная отладка событий, прокси подключений и ошибок
          </p>
        </div>

        {/* Управление */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6">
          {/* Подключение Voice AI */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mic className="w-5 h-5" />
                Voice AI
              </CardTitle>
              <CardDescription>
                Статус: {' '}
                <Badge className={isConnected ? 'bg-green-500' : 'bg-gray-500'}>
                  {isConnected ? 'Подключен' : 'Отключен'}
                </Badge>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {!isConnected ? (
                <Button
                  onClick={handleConnect}
                  disabled={state === 'connecting'}
                  className="w-full"
                >
                  {state === 'connecting' ? (
                    <>Подключение...</>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      Подключиться
                    </>
                  )}
                </Button>
              ) : (
                <Button
                  onClick={disconnect}
                  variant="outline"
                  className="w-full"
                >
                  <Square className="w-4 h-4 mr-2" />
                  Отключиться
                </Button>
              )}

              {error && (
                <div className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded">
                  <p className="text-red-800 dark:text-red-200 text-sm">{error}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Тестирование прокси */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                Прокси тесты
              </CardTitle>
              <CardDescription>
                Проверка подключений
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                onClick={testProxyConnection}
                disabled={isTestingProxy}
                className="w-full"
                variant="outline"
              >
                {isTestingProxy ? (
                  <>Тестируем...</>
                ) : (
                  <>
                    <Wifi className="w-4 h-4 mr-2" />
                    Тест прокси
                  </>
                )}
              </Button>

              <Button
                onClick={testOpenAIConnection}
                disabled={isTestingOpenAI}
                className="w-full"
                variant="outline"
              >
                {isTestingOpenAI ? (
                  <>Тестируем...</>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4 mr-2" />
                    Тест OpenAI API
                  </>
                )}
              </Button>

              <Button
                onClick={getProxyStats}
                className="w-full"
                variant="outline"
              >
                📊 Статистика прокси
              </Button>
            </CardContent>
          </Card>

          {/* Управление логами */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="w-5 h-5" />
                Логи
              </CardTitle>
              <CardDescription>
                Всего: {logs.length} | Показано: {filteredLogs.length}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="w-full px-3 py-2 border rounded bg-white dark:bg-gray-800"
              >
                <option value="all">Все события</option>
                <option value="info">Информация</option>
                <option value="event">События ИИ</option>
                <option value="success">Успешные</option>
                <option value="error">Ошибки</option>
                <option value="proxy-test">Прокси тесты</option>
                <option value="proxy-error">Прокси ошибки</option>
              </select>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowRawData(!showRawData)}
                  className="flex-1"
                >
                  {showRawData ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearLogs}
                  className="flex-1"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={downloadLogs}
                  className="flex-1"
                >
                  <Download className="w-4 h-4" />
                </Button>
              </div>

              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={isAutoScroll}
                  onChange={(e) => setIsAutoScroll(e.target.checked)}
                />
                Автопрокрутка
              </label>
            </CardContent>
          </Card>

          {/* Добавление прокси */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                ➕ Добавить прокси
              </CardTitle>
              <CardDescription>
                Формат: IP PORT AUTH_PORT USER PASS FULL_URL
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <textarea
                  value={proxyText}
                  onChange={(e) => setProxyText(e.target.value)}
                  placeholder="143.20.172.60	4598	14598	user326029	ejdif4	user326029:ejdif4@143.20.172.60:4598"
                  className="w-full px-3 py-2 border rounded bg-white dark:bg-gray-800 text-xs font-mono resize-none"
                  rows={3}
                />
              </div>

              <Button
                onClick={addTestProxy}
                variant="outline"
                size="sm"
                className="w-full"
              >
                📝 Загрузить тестовый прокси
              </Button>

              <Button
                onClick={addProxy}
                disabled={isAddingProxy || !proxyText.trim()}
                className="w-full"
              >
                {isAddingProxy ? (
                  <>Добавляем...</>
                ) : (
                  <>
                    ➕ Добавить прокси
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Логи */}
        <Card>
          <CardHeader>
            <CardTitle>События в реальном времени</CardTitle>
            <CardDescription>
              Детальная отладочная информация с полными данными об ошибках
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-96 overflow-y-auto bg-gray-900 text-green-400 p-4 rounded font-mono text-sm">
              {filteredLogs.length === 0 ? (
                <div className="text-gray-500 text-center py-8">
                  Нет событий для отображения
                </div>
              ) : (
                filteredLogs.map((log) => (
                  <div key={log.id} className="mb-3 border-b border-gray-800 pb-3">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-gray-400">[{log.timestamp}]</span>
                      <Badge className={`text-xs ${getLogBadgeColor(log.type)}`}>
                        {log.type}
                      </Badge>
                    </div>

                    <div className={`${log.type.includes('error') ? 'text-red-400' : 'text-gray-200'}`}>
                      {log.message}
                    </div>

                    {log.data !== undefined && (
                      <details className="mt-2">
                        <summary className="text-blue-400 cursor-pointer hover:text-blue-300 text-xs">
                          {showRawData ? 'Скрыть' : 'Показать'} данные
                        </summary>
                        {showRawData && (
                          <pre className="mt-2 p-2 bg-gray-800 rounded text-xs overflow-x-auto whitespace-pre-wrap">
                            {formatJSON(log.data)}
                          </pre>
                        )}
                      </details>
                    )}
                  </div>
                ))
              )}
              <div ref={logsEndRef} />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
