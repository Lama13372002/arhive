import { NextRequest, NextResponse } from 'next/server';
import { createDbConnection } from '@/lib/database';

const VALID_VOICES = [
  'alloy', 'ash', 'ballad', 'cedar', 'coral',
  'echo', 'marin', 'sage', 'shimmer', 'verse'
];

export async function POST(request: NextRequest) {
  try {
    const { user_id, voice } = await request.json();

    if (!user_id || !voice) {
      return NextResponse.json(
        { success: false, error: 'user_id и voice обязательны' },
        { status: 400 }
      );
    }

    if (!VALID_VOICES.includes(voice)) {
      return NextResponse.json(
        { success: false, error: 'Недопустимый голос' },
        { status: 400 }
      );
    }

    const client = createDbConnection();
    await client.connect();

    try {
      // Обновляем выбранный голос пользователя
      const updateResult = await client.query(
        'UPDATE users SET selected_voice = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [voice, user_id]
      );

      if ((updateResult.rowCount ?? 0) === 0) {
        return NextResponse.json(
          { success: false, error: 'Пользователь не найден' },
          { status: 404 }
        );
      }

      return NextResponse.json({
        success: true,
        message: 'Голос успешно обновлен',
        voice: voice
      });

    } finally {
      await client.end();
    }

  } catch (error) {
    console.error('Ошибка при обновлении голоса:', error);
    return NextResponse.json(
      { success: false, error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const user_id = searchParams.get('user_id');

    if (!user_id) {
      return NextResponse.json(
        { success: false, error: 'user_id обязателен' },
        { status: 400 }
      );
    }

    const client = createDbConnection();
    await client.connect();

    try {
      // Получаем текущий выбранный голос пользователя
      const result = await client.query(
        'SELECT selected_voice FROM users WHERE id = $1',
        [user_id]
      );

      if (result.rows.length === 0) {
        return NextResponse.json(
          { success: false, error: 'Пользователь не найден' },
          { status: 404 }
        );
      }

      return NextResponse.json({
        success: true,
        voice: result.rows[0].selected_voice || 'ash'
      });

    } finally {
      await client.end();
    }

  } catch (error) {
    console.error('Ошибка при получении голоса:', error);
    return NextResponse.json(
      { success: false, error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    );
  }
}
