import TMAApp from '@/components/TMAApp';

export default function Home() {
  return <TMAApp />;
}
