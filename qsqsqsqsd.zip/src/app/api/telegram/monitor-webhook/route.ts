import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL;

    if (!botToken || !appUrl) {
      return NextResponse.json({ error: 'Configuration missing' }, { status: 500 });
    }

    // Проверяем текущий статус webhook
    const infoResponse = await fetch(`https://api.telegram.org/bot${botToken}/getWebhookInfo`);
    const webhookInfo = await infoResponse.json();

    if (!webhookInfo.ok) {
      return NextResponse.json({
        error: 'Failed to get webhook info',
        details: webhookInfo.description
      }, { status: 500 });
    }

    const info = webhookInfo.result;
    const expectedUrl = `${appUrl}/api/telegram/webhook`;

    // Проверяем состояние webhook
    const isHealthy =
      info.url === expectedUrl &&
      info.has_custom_certificate === false &&
      info.pending_update_count < 10 && // Меньше 10 необработанных обновлений
      (!info.last_error_date || (Date.now() / 1000 - info.last_error_date) > 3600); // Нет ошибок за последний час

    const status: {
      healthy: boolean;
      url: string;
      expected_url: string;
      pending_updates: number;
      last_error_date?: number;
      last_error_message?: string;
      max_connections: number;
      allowed_updates: string[];
      restored?: boolean;
      restore_error?: string;
    } = {
      healthy: isHealthy,
      url: info.url,
      expected_url: expectedUrl,
      pending_updates: info.pending_update_count,
      last_error_date: info.last_error_date,
      last_error_message: info.last_error_message,
      max_connections: info.max_connections,
      allowed_updates: info.allowed_updates
    };

    // Если webhook нездоров, пытаемся его восстановить
    if (!isHealthy) {
      console.log('Webhook is unhealthy, attempting to restore...');

      try {
        const restoreResponse = await fetch(`https://api.telegram.org/bot${botToken}/setWebhook`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            url: expectedUrl,
            allowed_updates: ['pre_checkout_query', 'message'],
            max_connections: 40,
            drop_pending_updates: info.pending_update_count > 5 // Очищаем старые обновления если их много
          })
        });

        const restoreResult = await restoreResponse.json();

        if (restoreResult.ok) {
          console.log('Webhook restored successfully');
          status.healthy = true;
          status.restored = true;
        } else {
          console.error('Failed to restore webhook:', restoreResult.description);
          status.restore_error = restoreResult.description;
        }
      } catch (restoreError) {
        console.error('Error restoring webhook:', restoreError);
        status.restore_error = 'Exception during restore';
      }
    }

    return NextResponse.json({
      success: true,
      webhook_status: status,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Monitor webhook error:', error);
    return NextResponse.json({
      error: 'Failed to monitor webhook',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

// POST endpoint для принудительного восстановления webhook
export async function POST(request: NextRequest) {
  try {
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL;

    if (!botToken || !appUrl) {
      return NextResponse.json({ error: 'Configuration missing' }, { status: 500 });
    }

    const webhookUrl = `${appUrl}/api/telegram/webhook`;

    // Принудительно устанавливаем webhook
    const response = await fetch(`https://api.telegram.org/bot${botToken}/setWebhook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        url: webhookUrl,
        allowed_updates: ['pre_checkout_query', 'message'],
        max_connections: 40,
        drop_pending_updates: true // Очищаем все старые обновления
      })
    });

    const result = await response.json();

    if (!result.ok) {
      return NextResponse.json({
        error: 'Failed to force restore webhook',
        details: result.description
      }, { status: 500 });
    }

    // Проверяем результат
    const infoResponse = await fetch(`https://api.telegram.org/bot${botToken}/getWebhookInfo`);
    const webhookInfo = await infoResponse.json();

    return NextResponse.json({
      success: true,
      message: 'Webhook force restored successfully',
      webhook_info: webhookInfo.result
    });

  } catch (error) {
    console.error('Force restore webhook error:', error);
    return NextResponse.json({
      error: 'Failed to force restore webhook',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}
