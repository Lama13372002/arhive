import pool from '@/lib/database';
import { telegramBot, type NotificationData } from '@/lib/telegram-bot';

export interface NotificationRecord {
  id: number;
  user_id: number;
  bet_id: number | null;
  notification_type: string;
  title: string;
  message: string;
  is_read: boolean;
  sent_to_telegram: boolean;
  created_at: string;
}

export class NotificationService {
  /**
   * Создать уведомление в базе данных
   */
  async createNotification(
    userId: number,
    betId: number | null,
    type: string,
    title: string,
    message: string
  ): Promise<number | null> {
    try {
      const client = await pool.connect();

      try {
        const result = await client.query(`
          INSERT INTO notifications (user_id, bet_id, notification_type, title, message)
          VALUES ($1, $2, $3, $4, $5)
          RETURNING id
        `, [userId, betId, type, title, message]);

        return result.rows[0]?.id || null;
      } finally {
        client.release();
      }
    } catch (error) {
      console.error('Ошибка создания уведомления:', error);
      return null;
    }
  }

  /**
   * Отметить уведомление как отправленное в Telegram
   */
  async markAsSentToTelegram(notificationId: number): Promise<boolean> {
    try {
      const client = await pool.connect();

      try {
        await client.query(`
          UPDATE notifications
          SET sent_to_telegram = true
          WHERE id = $1
        `, [notificationId]);

        return true;
      } finally {
        client.release();
      }
    } catch (error) {
      console.error('Ошибка обновления статуса уведомления:', error);
      return false;
    }
  }

  /**
   * Получить информацию о пользователе для уведомления
   */
  async getUserInfo(userId: number): Promise<{ telegram_id: number; username: string; first_name: string } | null> {
    try {
      const client = await pool.connect();

      try {
        const result = await client.query(`
          SELECT telegram_id, username, first_name
          FROM users
          WHERE id = $1
        `, [userId]);

        return result.rows[0] || null;
      } finally {
        client.release();
      }
    } catch (error) {
      console.error('Ошибка получения информации о пользователе:', error);
      return null;
    }
  }

  /**
   * Получить информацию о споре и матче
   */
  async getBetMatchInfo(betId: number): Promise<{
    bet: {
      id: number;
      creator_id: number;
      match_id: number;
      prediction_type: string;
      prediction_text: string;
      amount: string;
      currency: string;
      status: string;
    };
    match: { home_team: string; away_team: string; league: string };
  } | null> {
    try {
      const client = await pool.connect();

      try {
        const result = await client.query(`
          SELECT
            b.*,
            m.home_team,
            m.away_team,
            m.league
          FROM bets b
          JOIN matches m ON b.match_id = m.id
          WHERE b.id = $1
        `, [betId]);

        if (result.rows.length === 0) return null;

        const row = result.rows[0];
        return {
          bet: row,
          match: {
            home_team: row.home_team,
            away_team: row.away_team,
            league: row.league
          }
        };
      } finally {
        client.release();
      }
    } catch (error) {
      console.error('Ошибка получения информации о ставке:', error);
      return null;
    }
  }

  /**
   * Универсальный метод отправки уведомлений
   */
  async sendNotification(data: NotificationData): Promise<boolean> {
    try {
      // Получаем информацию о пользователе, если telegram_id не передан
      let telegramId = data.telegram_id;
      if (!telegramId) {
        const userInfo = await this.getUserInfo(data.user_id);
        if (!userInfo) return false;
        telegramId = userInfo.telegram_id;
      }

      // Обновляем данные с telegram_id
      const notificationData = { ...data, telegram_id: telegramId };

      // Создаем уведомление в базе данных
      let notificationTitle = '';
      let notificationMessage = '';

      switch (data.type) {
        case 'bet_win':
          notificationTitle = 'Поздравляем! Вы выиграли!';
          notificationMessage = `Вы выиграли ${data.amount} ${data.currency}`;
          break;
        case 'bet_loss':
          notificationTitle = 'Вы проиграли спор';
          notificationMessage = `К сожалению, вы проиграли ${data.amount} ${data.currency}`;
          break;
        case 'bet_refund':
          notificationTitle = 'Возврат средств';
          notificationMessage = `Вам возвращено ${data.amount} ${data.currency}`;
          break;
        case 'bet_joined':
          notificationTitle = 'К спору присоединился игрок';
          notificationMessage = `К вашему спору присоединился новый игрок`;
          break;
        case 'bet_created':
          notificationTitle = 'Спор создан';
          notificationMessage = `Ваш спор на ${data.amount} ${data.currency} создан`;
          break;
        default:
          notificationTitle = 'Уведомление';
          notificationMessage = 'У вас новое уведомление';
      }

      const notificationId = await this.createNotification(
        data.user_id,
        data.bet_id,
        data.type,
        notificationTitle,
        notificationMessage
      );

      if (!notificationId) return false;

      // Отправляем уведомление в Telegram
      const sent = await telegramBot.sendNotification(notificationData);

      if (sent) {
        await this.markAsSentToTelegram(notificationId);
      }

      return sent;
    } catch (error) {
      console.error('Ошибка отправки уведомления:', error);
      return false;
    }
  }

  /**
   * Отправить уведомление о победе в ставке
   */
  async sendWinNotification(
    userId: number,
    betId: number,
    winAmount: number,
    currency: string,
    totalBank: number
  ): Promise<boolean> {
    try {
      console.log(`[WIN] Отправка уведомления о победе: userId=${userId}, betId=${betId}, amount=${winAmount}`);

      // Получаем информацию о пользователе
      const userInfo = await this.getUserInfo(userId);
      if (!userInfo) {
        console.error(`[WIN] Пользователь не найден: userId=${userId}`);
        return false;
      }
      console.log(`[WIN] Пользователь найден: telegram_id=${userInfo.telegram_id}`);

      // Получаем информацию о ставке и матче
      const betMatchInfo = await this.getBetMatchInfo(betId);
      if (!betMatchInfo) {
        console.error(`[WIN] Информация о ставке не найдена: betId=${betId}`);
        return false;
      }
      console.log(`[WIN] Информация о ставке найдена: ${betMatchInfo.match.home_team} vs ${betMatchInfo.match.away_team}`);

      // Создаем уведомление в базе данных
      const notificationId = await this.createNotification(
        userId,
        betId,
        'bet_completed',
        'Поздравляем! Вы выиграли!',
        `Вы выиграли ${winAmount} ${currency} в споре на матч ${betMatchInfo.match.home_team} vs ${betMatchInfo.match.away_team}`
      );

      if (!notificationId) return false;

      // Отправляем уведомление в Telegram
      const notificationData: NotificationData = {
        user_id: userId,
        telegram_id: userInfo.telegram_id,
        type: 'bet_win',
        bet_id: betId,
        amount: winAmount,
        currency,
        match_info: betMatchInfo.match,
        additional_info: { total_bank: totalBank }
      };

      const sent = await telegramBot.sendNotification(notificationData);
      console.log(`[WIN] Telegram сообщение отправлено: ${sent}`);

      if (sent) {
        await this.markAsSentToTelegram(notificationId);
        console.log(`[WIN] Уведомление помечено как отправленное в БД`);
      }

      return sent;
    } catch (error) {
      console.error('Ошибка отправки уведомления о победе:', error);
      return false;
    }
  }

  /**
   * Отправить уведомление о проигрыше в ставке
   */
  async sendLossNotification(
    userId: number,
    betId: number,
    lostAmount: number,
    currency: string
  ): Promise<boolean> {
    try {
      console.log(`[LOSS] Отправка уведомления о проигрыше: userId=${userId}, betId=${betId}, amount=${lostAmount}`);

      const userInfo = await this.getUserInfo(userId);
      if (!userInfo) {
        console.error(`[LOSS] Пользователь не найден: userId=${userId}`);
        return false;
      }
      console.log(`[LOSS] Пользователь найден: telegram_id=${userInfo.telegram_id}`);

      const betMatchInfo = await this.getBetMatchInfo(betId);
      if (!betMatchInfo) {
        console.error(`[LOSS] Информация о ставке не найдена: betId=${betId}`);
        return false;
      }
      console.log(`[LOSS] Информация о ставке найдена: ${betMatchInfo.match.home_team} vs ${betMatchInfo.match.away_team}`);

      const notificationId = await this.createNotification(
        userId,
        betId,
        'bet_completed',
        'Вы проиграли спор',
        `К сожалению, вы проиграли ${lostAmount} ${currency} в споре на матч ${betMatchInfo.match.home_team} vs ${betMatchInfo.match.away_team}`
      );

      if (!notificationId) return false;

      const notificationData: NotificationData = {
        user_id: userId,
        telegram_id: userInfo.telegram_id,
        type: 'bet_loss',
        bet_id: betId,
        amount: lostAmount,
        currency,
        match_info: betMatchInfo.match
      };

      const sent = await telegramBot.sendNotification(notificationData);
      console.log(`[LOSS] Telegram сообщение отправлено: ${sent}`);

      if (sent) {
        await this.markAsSentToTelegram(notificationId);
        console.log(`[LOSS] Уведомление помечено как отправленное в БД`);
      }

      return sent;
    } catch (error) {
      console.error('Ошибка отправки уведомления о проигрыше:', error);
      return false;
    }
  }

  /**
   * Отправить уведомление о возврате средств
   */
  async sendRefundNotification(
    userId: number,
    betId: number,
    refundAmount: number,
    currency: string,
    reason: string = 'К вашему спору никто не присоединился'
  ): Promise<boolean> {
    try {
      console.log(`[REFUND] Отправка уведомления о возврате: userId=${userId}, betId=${betId}, amount=${refundAmount}`);

      const userInfo = await this.getUserInfo(userId);
      if (!userInfo) {
        console.error(`[REFUND] Пользователь не найден: userId=${userId}`);
        return false;
      }
      console.log(`[REFUND] Пользователь найден: telegram_id=${userInfo.telegram_id}`);

      const betMatchInfo = await this.getBetMatchInfo(betId);
      if (!betMatchInfo) {
        console.error(`[REFUND] Информация о ставке не найдена: betId=${betId}`);
        return false;
      }
      console.log(`[REFUND] Информация о ставке найдена: ${betMatchInfo.match.home_team} vs ${betMatchInfo.match.away_team}`);

      const notificationId = await this.createNotification(
        userId,
        betId,
        'bet_cancelled',
        'Возврат средств',
        `Вам возвращено ${refundAmount} ${currency} из-за отмены спора на матч ${betMatchInfo.match.home_team} vs ${betMatchInfo.match.away_team}`
      );

      if (!notificationId) return false;

      const notificationData: NotificationData = {
        user_id: userId,
        telegram_id: userInfo.telegram_id,
        type: 'bet_refund',
        bet_id: betId,
        amount: refundAmount,
        currency,
        match_info: betMatchInfo.match,
        additional_info: { reason }
      };

      const sent = await telegramBot.sendNotification(notificationData);
      console.log(`[REFUND] Telegram сообщение отправлено: ${sent}`);

      if (sent) {
        await this.markAsSentToTelegram(notificationId);
        console.log(`[REFUND] Уведомление помечено как отправленное в БД`);
      }

      return sent;
    } catch (error) {
      console.error('Ошибка отправки уведомления о возврате:', error);
      return false;
    }
  }

  /**
   * Отправить уведомление о присоединении к ставке
   */
  async sendJoinedNotification(
    creatorUserId: number,
    betId: number,
    joinerUserId: number
  ): Promise<boolean> {
    try {
      const creatorInfo = await this.getUserInfo(creatorUserId);
      const joinerInfo = await this.getUserInfo(joinerUserId);
      if (!creatorInfo || !joinerInfo) return false;

      const betMatchInfo = await this.getBetMatchInfo(betId);
      if (!betMatchInfo) return false;

      const joinerName = joinerInfo.first_name || joinerInfo.username || 'Пользователь';

      const notificationId = await this.createNotification(
        creatorUserId,
        betId,
        'bet_joined',
        'К спору присоединился игрок',
        `${joinerName} присоединился к вашему спору на матч ${betMatchInfo.match.home_team} vs ${betMatchInfo.match.away_team}`
      );

      if (!notificationId) return false;

      const notificationData: NotificationData = {
        user_id: creatorUserId,
        telegram_id: creatorInfo.telegram_id,
        type: 'bet_joined',
        bet_id: betId,
        match_info: betMatchInfo.match,
        additional_info: { joiner_name: joinerName }
      };

      const sent = await telegramBot.sendNotification(notificationData);

      if (sent) {
        await this.markAsSentToTelegram(notificationId);
      }

      return sent;
    } catch (error) {
      console.error('Ошибка отправки уведомления о присоединении:', error);
      return false;
    }
  }
}

export const notificationService = new NotificationService();
