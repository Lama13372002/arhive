"use client";

import { useState, useEffect, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { WalletInput } from "@/components/ui/wallet-input";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import {
  Wallet,
  ArrowDownToLine,
  Clock,
  CheckCircle,
  XCircle,
  X,
  RefreshCw,
  History,
  Zap
} from "lucide-react";

import { useTelegram } from "@/components/providers/TelegramProvider";
import { TonWithdrawalI18nProvider, useTonWithdrawalI18n } from "@/components/providers/TonWithdrawalI18nProvider";
import { useIOSKeyboard } from "@/hooks/useIOSKeyboard";

interface TonWithdrawalModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentBalance: number;
}

interface WithdrawalRequest {
  id: number;
  amount: number | string;
  commission: number | string;
  net_amount: number | string;
  target_wallet: string;
  status: string;
  transaction_hash: string | null;
  created_at: string;
  auto_generated: boolean;
  error_message: string | null;
}

function TonWithdrawalModalContent({ isOpen, onClose, currentBalance }: TonWithdrawalModalProps) {
  const { t } = useTonWithdrawalI18n();
  const { user, isFullscreen } = useTelegram();
  const { inputRef: withdrawInputRef } = useIOSKeyboard({ enabled: true, delay: 200 });
  // Убрали useIOSKeyboard для walletInputRef - это решает проблему с контекстным меню на iOS
  const [activeTab, setActiveTab] = useState<'withdraw' | 'history'>('withdraw');
  const [loading, setLoading] = useState(false);

  // Manual withdrawal
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [targetWallet, setTargetWallet] = useState("");

  // Commission rate for withdrawal calculation
  const commissionRate = 0.01;

  // History
  const [withdrawalHistory, setWithdrawalHistory] = useState<WithdrawalRequest[]>([]);

  const loadWithdrawalHistory = useCallback(async (retryCount = 0) => {
    if (!user?.id) return;

    try {
      console.log('TMA: Loading withdrawal history for user:', user.id);

      // Для TMA добавляем заголовки и timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 секунд timeout

      const response = await fetch(`/api/ton/withdrawal/process?telegramId=${user.id}&limit=10`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
        },
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      console.log('TMA: Response status:', response.status);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      console.log('TMA: Received data:', data);

      if (data && data.requests && Array.isArray(data.requests)) {
        setWithdrawalHistory(data.requests);
        console.log('TMA: Successfully loaded', data.requests.length, 'withdrawal records');
      } else {
        console.warn('TMA: No withdrawal data received or invalid format');
        setWithdrawalHistory([]);
      }
    } catch (error) {
      console.error('TMA: Error loading withdrawal history:', error);

      // Retry logic для TMA - иногда первый запрос может не проходить
      if (retryCount < 2) {
        console.log(`TMA: Retrying request (attempt ${retryCount + 1})`);
        setTimeout(() => {
          loadWithdrawalHistory(retryCount + 1);
        }, 1000 * (retryCount + 1)); // Увеличиваем задержку с каждой попыткой
      } else {
        setWithdrawalHistory([]);
        console.error('TMA: Failed to load withdrawal history after 3 attempts');
      }
    }
  }, [user?.id]);

  useEffect(() => {
    if (isOpen && user?.id) {
      console.log('TMA: Modal opened, loading withdrawal history...');

      // Увеличиваем задержку для TMA и проверяем готовность
      const timeoutId = setTimeout(() => {
        // Проверяем, что окружение готово
        if (typeof window !== 'undefined') {
          console.log('TMA: Environment ready, starting history load');
          loadWithdrawalHistory();
        } else {
          console.warn('TMA: Window not available, retrying...');
          setTimeout(() => loadWithdrawalHistory(), 500);
        }
      }, 300); // Увеличиваем задержку для TMA

      return () => clearTimeout(timeoutId);
    }
  }, [isOpen, user?.id, loadWithdrawalHistory]);

  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  // Сброс состояния при закрытии модального окна
  useEffect(() => {
    if (!isOpen) {
      setWithdrawAmount("");
      setTargetWallet("");
      setSuccessMessage("");
      setErrorMessage("");
      setActiveTab('withdraw');
    }
  }, [isOpen]);

  const handleManualWithdraw = async () => {
    if (!user?.id || !withdrawAmount || !targetWallet) return;

    const amount = Number.parseFloat(withdrawAmount);
    if (amount <= 0 || amount > currentBalance) {
      setErrorMessage(t('error_invalid_amount'));
      return;
    }

    setLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    try {
      console.log('TMA: Creating withdrawal request for user:', user.id, 'amount:', amount);

      // Добавляем timeout и улучшенные заголовки для TMA
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);

      const response = await fetch('/api/ton/withdrawal/process', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
        },
        body: JSON.stringify({
          telegramId: user.id,
          amount,
          targetWallet,
          isManual: true
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      console.log('TMA: Withdrawal request response status:', response.status);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('TMA: Withdrawal request failed:', errorText);
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      console.log('TMA: Withdrawal request result:', data);

      if (data.success) {
        setSuccessMessage(t('success_created'));
        setWithdrawAmount("");
        // Обновляем историю с небольшой задержкой
        setTimeout(() => {
          loadWithdrawalHistory();
        }, 500);
      } else {
        setErrorMessage(data.error || t('error_create'));
      }
    } catch (error) {
      console.error('TMA: Error creating withdrawal request:', error);

      if (error instanceof Error && error.name === 'AbortError') {
        setErrorMessage(t('error_timeout'));
      } else {
        setErrorMessage(t('error_create'));
      }
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-500/20 text-green-400 border-green-500/30"><CheckCircle className="w-3 h-3 mr-1" />{t('status_completed')}</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30"><Clock className="w-3 h-3 mr-1" />{t('status_pending')}</Badge>;
      case 'processing':
        return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30"><RefreshCw className="w-3 h-3 mr-1" />{t('status_processing')}</Badge>;
      case 'failed':
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30"><XCircle className="w-3 h-3 mr-1" />{t('status_failed')}</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const calculateCommission = (amount: number) => {
    const commission = Math.max(amount * commissionRate, 0.01);
    return commission;
  };

  const handleMaxAmount = () => {
    setWithdrawAmount(currentBalance.toString());
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent
        className={`
          ${isFullscreen
            ? 'fixed left-0 right-0 bottom-0 top-24 w-full max-w-none max-h-none m-0 rounded-t-2xl border-none !transform-none [&>button]:hidden'
            : 'max-w-md mx-auto'
          }
          glass-modal border-none shadow-2xl
          ${isFullscreen ? '' : 'max-h-[90vh] overflow-y-auto'}
          ${isFullscreen ? 'pt-4 pb-[env(safe-area-inset-bottom)]' : ''}
          data-[state=open]:!animate-none data-[state=closed]:!animate-none
          data-[state=open]:!zoom-in-100 data-[state=closed]:!zoom-out-100
        `}
        onPointerDown={(e) => e.stopPropagation()}
        onPointerUp={(e) => e.stopPropagation()}
        onClick={(e) => e.stopPropagation()}
        style={{
          paddingBottom: isFullscreen ? 'max(1rem, env(safe-area-inset-bottom))' : undefined,
          top: !isFullscreen ? '50%' : undefined,
        }}
      >
        <div
          className={`
            ${isFullscreen
              ? 'h-full overflow-y-auto space-y-4 p-1'
              : 'flex flex-col max-h-[90vh] p-1'
            }
          `}
          onPointerDown={(e) => e.stopPropagation()}
          onPointerUp={(e) => e.stopPropagation()}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative w-10 h-10 bg-gradient-to-br from-blue-400 via-cyan-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/30">
                <img src="/images/ton.png" alt="TON" className="h-6 w-6" />
              </div>

              <div>
                <h2 className="text-lg font-bold bg-gradient-to-r from-blue-400 via-cyan-500 to-indigo-500 bg-clip-text text-transparent">{t('header_title')}</h2>
                <p className="text-slate-400 text-xs">
                  {t('header_sub')}
                </p>
              </div>
            </div>

            {/* Close button for fullscreen */}
            {isFullscreen && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="w-8 h-8 p-0 rounded-full hover:bg-white/10"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>

        {/* Tabs */}
        <div className="flex space-x-2 bg-white/5 backdrop-blur-sm rounded-xl p-1 mb-4">
          {[
            { id: 'withdraw', label: t('tab_withdraw'), icon: ArrowDownToLine },
            { id: 'history', label: t('tab_history'), icon: History }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as 'withdraw' | 'history')}
              className={`flex-1 flex items-center justify-center space-x-1 py-2 px-3 rounded-lg text-sm font-medium transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-blue-500 text-white shadow-lg'
                  : 'text-foreground/70 hover:text-foreground hover:bg-white/5'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

          {activeTab === 'withdraw' && (
            <div className="space-y-4">
              <Card className="glass-card border-none no-click-animation">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center space-x-2">
                    <Wallet className="w-5 h-5 text-blue-400" />
                    <span>{t('withdraw_title')}</span>
                  </CardTitle>
                  <p className="text-sm text-foreground/70 mt-2">
                    {t('withdraw_desc')}
                  </p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">{t('amount_label')}</label>
                    <div className="relative">
                      <Input
                        ref={withdrawInputRef}
                        type="number"
                        value={withdrawAmount}
                        onChange={(e) => setWithdrawAmount(e.target.value)}
                        placeholder="0.00"
                        className="bg-white/5 border-white/10 focus:border-blue-500/50 focus:bg-white/10 transition-all duration-200 text-center text-base h-12 rounded-lg pl-10 pr-16 ios-input"
                        step="0.01"
                        min="0.01"
                        max={currentBalance}
                        style={{
                          fontSize: '16px',
                          WebkitAppearance: 'none',
                          WebkitBorderRadius: '0.5rem',
                        }}
                      />
                      <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
                        <img src="/images/ton.png" alt="TON" className="h-4 w-4" />
                      </div>
                      <Button
                        type="button"
                        onClick={handleMaxAmount}
                        className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 px-2 text-xs bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 border border-blue-500/30 rounded-md"
                      >
                        MAX
                      </Button>
                    </div>
                    <div className="text-xs text-foreground/60 mt-1">
                      {t('available', { balance: currentBalance.toFixed(2) })}
                    </div>
                  </div>

                  <WalletInput
                    value={targetWallet}
                    onChange={setTargetWallet}
                    placeholder="UQ..."
                    label={t('wallet_label')}
                    hint={t('wallet_hint')}
                  />

                  {withdrawAmount && (
                    <div className="bg-white/5 rounded-lg p-3 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>{t('summary_amount')}</span>
                        <span>{Number.parseFloat(withdrawAmount || "0").toFixed(2)} TON</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>{t('summary_fee')}</span>
                        <span>{calculateCommission(Number.parseFloat(withdrawAmount || "0")).toFixed(2)} TON</span>
                      </div>
                      <Separator className="bg-white/10" />
                      <div className="flex justify-between text-sm font-medium">
                        <span>{t('summary_receive')}</span>
                        <span>{(Number.parseFloat(withdrawAmount || "0") - calculateCommission(Number.parseFloat(withdrawAmount || "0"))).toFixed(2)} TON</span>
                      </div>
                    </div>
                  )}

                  {successMessage && (
                    <div className="bg-green-500/20 border border-green-500/30 text-green-400 p-3 rounded-lg text-sm">
                      {successMessage}
                    </div>
                  )}

                  {errorMessage && (
                    <div className="bg-red-500/20 border border-red-500/30 text-red-400 p-3 rounded-lg text-sm">
                      {errorMessage}
                    </div>
                  )}

                  <Button
                    onClick={handleManualWithdraw}
                    disabled={loading || !withdrawAmount || !targetWallet}
                    className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white"
                  >
                    {loading ? (
                      <RefreshCw className="w-4 h-4 animate-spin mr-2" />
                    ) : (
                      <ArrowDownToLine className="w-4 h-4 mr-2" />
                    )}
                    {t('create_request')}
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-4">
              <Card className="glass-card border-none no-click-animation">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center space-x-2">
                    <History className="w-5 h-5 text-green-400" />
                    <span>{t('history_title')}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {withdrawalHistory.length === 0 ? (
                    <p className="text-center text-foreground/60 py-4">{t('history_empty')}</p>
                  ) : (
                    <div className="space-y-3">
                      {withdrawalHistory.map((request) => (
                        <div key={request.id} className="bg-white/5 rounded-lg p-3 space-y-2">
                          <div className="flex justify-between items-start">
                            <div className="space-y-1">
                              <p className="font-medium">{Number(request.net_amount || 0).toFixed(2)} TON</p>
                              <p className="text-xs text-foreground/60">{formatDate(request.created_at)}</p>
                              {request.auto_generated && (
                                <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 text-xs">
                                  <Zap className="w-3 h-3 mr-1" />{t('auto_withdraw')}
                                </Badge>
                              )}
                            </div>
                            <div className="text-right space-y-1">
                              {getStatusBadge(request.status)}
                              <p className="text-xs text-foreground/60">{t('fee_label', { fee: Number(request.commission || 0).toFixed(2) })}</p>
                            </div>
                          </div>
                          {request.transaction_hash && (
                            <p className="text-xs text-foreground/60 font-mono break-all">{t('hash_label', { hash: request.transaction_hash })}</p>
                          )}
                          {request.error_message && (
                            <p className="text-xs text-red-400">
                              {request.error_message}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function TonWithdrawalModal(props: TonWithdrawalModalProps) {
  return (
    <TonWithdrawalI18nProvider>
      <TonWithdrawalModalContent {...props} />
    </TonWithdrawalI18nProvider>
  );
}
