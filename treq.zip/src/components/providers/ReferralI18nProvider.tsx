"use client";
import React, { createContext, useCallback, useContext, useMemo } from "react";
import { useI18n } from "./I18nProvider";

type Dict = Record<string, string>;

const ru: Dict = {
  // Dialog title
  modal_title: "Реферальная программа",

  // Loading states
  loading: "Загрузка...",
  error_loading: "Ошибка при загрузке информации о рефералах",
  retry: "Попробовать снова",

  // Main stats
  stats_total_referrals: "Всего рефералов",
  stats_earned: "Заработано",

  // Pending earnings section
  pending_earnings_title: "Накопленные отчисления",
  ton_earnings: "TON отчисления",
  stars_earnings: "Stars отчисления",
  transfer_button: "Перевести",
  no_funds: "Нет средств",
  pending_hint: "💡 Отчисления накапливаются с каждого депозита ваших рефералов и могут быть переведены на основной баланс одной кнопкой",

  // Referral link section
  referral_link_title: "Ваша реферальная ссылка",
  copy_button: "Копировать",
  copied: "Скопировано!",
  share_button: "Поделиться",
  referral_code: "Код: {code}",

  // Tabs
  tab_referrals: "Рефералы",
  tab_earnings: "Доходы",

  // Referrals tab
  no_referrals_title: "У вас пока нет рефералов",
  no_referrals_desc: "Поделитесь своей реферальной ссылкой, чтобы начать зарабатывать!",
  referral_status_active: "Активен",
  referral_status_inactive: "Неактивен",
  referral_bet_amount: "Ставка: {amount}",

  // Earnings tab
  no_earnings_title: "Пока нет доходов",
  no_earnings_desc: "Доходы появятся, когда ваши рефералы начнут делать ставки",
  earnings_transactions: "{count} транзакций",

  // Earnings types
  deposit_commission_ton: "Комиссии с TON депозитов",
  deposit_commission_stars: "Комиссии с Stars депозитов",
  bet_commission: "Комиссии со ставок",
  deposit_bonus: "Бонусы с депозитов",
  activity_bonus: "Бонусы за активность",

  // Referred by section
  referred_by_title: "Вас пригласил",

  // How it works section
  how_it_works_title: "Как это работает",
  step_1: "Поделитесь своей реферальной ссылкой с друзьями",
  step_2: "Когда друг регистрируется, он получает приветственный бонус",
  step_3: "Вы получаете 5% с каждого депозита вашего реферала",
  step_4: "Накопленные отчисления можно перевести на основной баланс одной кнопкой",

  // Transfer success messages
  transfer_success: "Успешно переведено {amount} {currency} на основной баланс!",
  transfer_error: "Ошибка при переводе средств",
};

const en: Dict = {
  // Dialog title
  modal_title: "Referral Program",

  // Loading states
  loading: "Loading...",
  error_loading: "Error loading referral information",
  retry: "Try again",

  // Main stats
  stats_total_referrals: "Total referrals",
  stats_earned: "Earned",

  // Pending earnings section
  pending_earnings_title: "Pending Earnings",
  ton_earnings: "TON earnings",
  stars_earnings: "Stars earnings",
  transfer_button: "Transfer",
  no_funds: "No funds",
  pending_hint: "💡 Earnings accumulate from each deposit of your referrals and can be transferred to main balance with one click",

  // Referral link section
  referral_link_title: "Your referral link",
  copy_button: "Copy",
  copied: "Copied!",
  share_button: "Share",
  referral_code: "Code: {code}",

  // Tabs
  tab_referrals: "Referrals",
  tab_earnings: "Earnings",

  // Referrals tab
  no_referrals_title: "You don't have any referrals yet",
  no_referrals_desc: "Share your referral link to start earning!",
  referral_status_active: "Active",
  referral_status_inactive: "Inactive",
  referral_bet_amount: "Bet: {amount}",

  // Earnings tab
  no_earnings_title: "No earnings yet",
  no_earnings_desc: "Earnings will appear when your referrals start betting",
  earnings_transactions: "{count} transactions",

  // Earnings types
  deposit_commission_ton: "TON deposit commissions",
  deposit_commission_stars: "Stars deposit commissions",
  bet_commission: "Bet commissions",
  deposit_bonus: "Deposit bonuses",
  activity_bonus: "Activity bonuses",

  // Referred by section
  referred_by_title: "You were invited by",

  // How it works section
  how_it_works_title: "How it works",
  step_1: "Share your referral link with friends",
  step_2: "When a friend registers, they receive a welcome bonus",
  step_3: "You get 5% from each deposit of your referral",
  step_4: "Accumulated earnings can be transferred to main balance with one click",

  // Transfer success messages
  transfer_success: "Successfully transferred {amount} {currency} to main balance!",
  transfer_error: "Error transferring funds",
};

const dicts = { ru, en };

type Ctx = { t: (key: string, params?: Record<string, string | number>) => string };
const Ctx = createContext<Ctx | undefined>(undefined);

export const ReferralI18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useI18n();
  const t = useCallback((key: string, params?: Record<string, string | number>) => {
    const dict = dicts[lang] || en;
    let text = dict[key] ?? key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
      });
    }
    return text;
  }, [lang]);
  const value = useMemo(() => ({ t }), [t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export const useReferralI18n = () => {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useReferralI18n must be used within ReferralI18nProvider");
  return ctx;
};
