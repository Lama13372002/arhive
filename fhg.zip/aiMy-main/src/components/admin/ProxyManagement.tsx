'use client';

import { useState, useEffect, useCallback } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert } from '@/components/ui/alert';

interface ProxyStats {
  id: number;
  ip: string;
  port: number;
  status: string;
  success_rate: number;
  response_time: number;
  success_count: number;
  failure_count: number;
  last_check_at?: string;
  last_used?: string;
}

interface ProxyListResponse {
  success: boolean;
  data: {
    proxies: ProxyStats[];
    total: number;
  };
}

export default function ProxyManagement() {
  const [proxies, setProxies] = useState<ProxyStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [addingProxies, setAddingProxies] = useState(false);
  const [checkingProxy, setCheckingProxy] = useState<number | null>(null);
  const [proxiesText, setProxiesText] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [currentPage, setCurrentPage] = useState(0);
  const [total, setTotal] = useState(0);
  const [bestProxy, setBestProxy] = useState<{
    id: string;
    ip: string;
    port: number;
    status: string;
    responseTime: number;
    successRate: number;
  } | null>(null);

  const pageSize = 20;

  const loadProxies = useCallback(async () => {
    try {
      const params = new URLSearchParams({
        limit: pageSize.toString(),
        offset: (currentPage * pageSize).toString(),
      });

      if (statusFilter) {
        params.append('status', statusFilter);
      }

      const response = await fetch(`/api/admin/proxies?${params}`);
      const data: ProxyListResponse = await response.json();

      if (data.success) {
        setProxies(data.data.proxies);
        setTotal(data.data.total);
      }
    } catch (error) {
      console.error('Ошибка загрузки прокси:', error);
      setMessage({ type: 'error', text: 'Ошибка загрузки списка прокси' });
    } finally {
      setLoading(false);
    }
  }, [currentPage, statusFilter]);

  const loadBestProxy = useCallback(async () => {
    try {
      const response = await fetch('/api/admin/proxies/check');
      const data = await response.json();

      if (data.success) {
        setBestProxy(data.data);
      }
    } catch (error) {
      console.error('Ошибка загрузки лучшего прокси:', error);
    }
  }, []);

  useEffect(() => {
    loadProxies();
    loadBestProxy();
  }, [loadProxies, loadBestProxy]);

  const handleAddProxies = async () => {
    if (!proxiesText.trim()) {
      setMessage({ type: 'error', text: 'Введите данные прокси' });
      return;
    }

    setAddingProxies(true);
    try {
      const response = await fetch('/api/admin/proxies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proxiesText })
      });

      const data = await response.json();

      if (data.success) {
        setMessage({ type: 'success', text: data.message });
        setProxiesText('');
        loadProxies();
      } else {
        setMessage({ type: 'error', text: data.error });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Ошибка добавления прокси' });
    } finally {
      setAddingProxies(false);
    }
  };

  const handleCheckProxy = async (proxyId: number) => {
    setCheckingProxy(proxyId);
    try {
      const response = await fetch('/api/admin/proxies/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proxyId })
      });

      const data = await response.json();

      if (data.success) {
        const result = data.data;
        setMessage({
          type: result.working ? 'success' : 'error',
          text: result.working
            ? `Прокси работает (${result.responseTime}ms)`
            : `Прокси не работает: ${result.error}`
        });
        loadProxies();
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Ошибка проверки прокси' });
    } finally {
      setCheckingProxy(null);
    }
  };

  const handleDeleteProxy = async (proxyId: number) => {
    if (!confirm('Удалить этот прокси?')) return;

    try {
      const response = await fetch(`/api/admin/proxies?id=${proxyId}`, {
        method: 'DELETE'
      });

      const data = await response.json();

      if (data.success) {
        setMessage({ type: 'success', text: 'Прокси удален' });
        loadProxies();
      } else {
        setMessage({ type: 'error', text: data.error });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Ошибка удаления прокси' });
    }
  };

  const handleUpdateStatus = async (proxyId: number, status: string) => {
    try {
      const response = await fetch('/api/admin/proxies', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proxyId, status })
      });

      const data = await response.json();

      if (data.success) {
        setMessage({ type: 'success', text: 'Статус обновлен' });
        loadProxies();
      } else {
        setMessage({ type: 'error', text: data.error });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Ошибка обновления статуса' });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'inactive': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      case 'checking': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const totalPages = Math.ceil(total / pageSize);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Управление прокси</h2>
        {bestProxy && (
          <div className="text-sm">
            <Badge className="bg-green-100 text-green-800">
              Лучший прокси: {bestProxy.ip}:{bestProxy.port} ({bestProxy.responseTime}ms)
            </Badge>
          </div>
        )}
      </div>

      {message && (
        <Alert className={message.type === 'error' ? 'border-red-500 bg-red-50' : 'border-green-500 bg-green-50'}>
          <span className={message.type === 'error' ? 'text-red-700' : 'text-green-700'}>
            {message.text}
          </span>
        </Alert>
      )}

      {/* Добавление прокси */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Добавить прокси</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">
              Прокси (каждый с новой строки)
            </label>
            <textarea
              value={proxiesText}
              onChange={(e) => setProxiesText(e.target.value)}
              placeholder="143.20.172.60	4598	14598	user326029	ejdif4	user326029:ejdif4@143.20.172.60:4598"
              className="w-full h-32 p-3 border rounded-lg font-mono text-sm"
              disabled={addingProxies}
            />
          </div>
          <Button
            onClick={handleAddProxies}
            disabled={addingProxies || !proxiesText.trim()}
            className="w-full"
          >
            {addingProxies ? 'Добавляем...' : 'Добавить прокси'}
          </Button>
        </div>
      </Card>

      {/* Фильтры */}
      <Card className="p-4">
        <div className="flex gap-4 items-center">
          <label className="text-sm font-medium">Фильтр по статусу:</label>
          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setCurrentPage(0);
            }}
            className="border rounded px-3 py-1"
          >
            <option value="">Все</option>
            <option value="active">Активные</option>
            <option value="inactive">Неактивные</option>
            <option value="failed">Неработающие</option>
            <option value="checking">Проверяются</option>
          </select>
          <span className="text-sm text-gray-500">Всего: {total}</span>
        </div>
      </Card>

      {/* Список прокси */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Список прокси</h3>

        {loading ? (
          <div className="text-center py-8">Загрузка...</div>
        ) : proxies.length === 0 ? (
          <div className="text-center py-8 text-gray-500">Нет прокси</div>
        ) : (
          <div className="space-y-3">
            {proxies.map((proxy) => (
              <div key={proxy.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="font-mono font-medium">
                        {proxy.ip}:{proxy.port}
                      </span>
                      <Badge className={getStatusColor(proxy.status)}>
                        {proxy.status}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600">
                      <div>
                        <span className="font-medium">Успешность:</span> {proxy.success_rate.toFixed(1)}%
                      </div>
                      <div>
                        <span className="font-medium">Время ответа:</span> {proxy.response_time}ms
                      </div>
                      <div>
                        <span className="font-medium">Успешных:</span> {proxy.success_count}
                      </div>
                      <div>
                        <span className="font-medium">Неудачных:</span> {proxy.failure_count}
                      </div>
                    </div>

                    {(proxy.last_check_at || proxy.last_used) && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2 text-xs text-gray-500">
                        {proxy.last_check_at && (
                          <div>
                            Последняя проверка: {new Date(proxy.last_check_at).toLocaleString()}
                          </div>
                        )}
                        {proxy.last_used && (
                          <div>
                            Последнее использование: {new Date(proxy.last_used).toLocaleString()}
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleCheckProxy(proxy.id)}
                      disabled={checkingProxy === proxy.id}
                    >
                      {checkingProxy === proxy.id ? '...' : 'Проверить'}
                    </Button>

                    <select
                      value={proxy.status}
                      onChange={(e) => handleUpdateStatus(proxy.id, e.target.value)}
                      className="text-xs border rounded px-2 py-1"
                    >
                      <option value="active">Активный</option>
                      <option value="inactive">Неактивный</option>
                      <option value="failed">Неработающий</option>
                    </select>

                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDeleteProxy(proxy.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      Удалить
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Пагинация */}
        {totalPages > 1 && (
          <div className="flex justify-center gap-2 mt-6">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.max(0, prev - 1))}
              disabled={currentPage === 0}
            >
              Назад
            </Button>
            <span className="px-3 py-2 text-sm">
              Страница {currentPage + 1} из {totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.min(totalPages - 1, prev + 1))}
              disabled={currentPage === totalPages - 1}
            >
              Вперед
            </Button>
          </div>
        )}
      </Card>
    </div>
  );
}
