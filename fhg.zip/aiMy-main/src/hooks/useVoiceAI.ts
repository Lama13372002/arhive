import { useState, useRef, useCallback } from 'react';
import { useProximityDisabler } from './useProximityDisabler';
import { useWebRTCAudioForcer } from './useWebRTCAudioForcer';

type ConnectionState = 'idle' | 'connecting' | 'connected' | 'listening' | 'thinking' | 'speaking' | 'error';

interface UseVoiceAIReturn {
  state: ConnectionState;
  isConnected: boolean;
  logs: string[];
  connect: (userId?: number) => Promise<void>;
  disconnect: () => void;
  error: string | null;
}

interface VoiceMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface TokenUsage {
  total_tokens: number;
  input_tokens: number;
  output_tokens: number;
}

export function useVoiceAI(): UseVoiceAIReturn {
  const [state, setState] = useState<ConnectionState>('idle');
  const [logs, setLogs] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Инициализируем хук для отключения датчика приближения
  const { enforceMainSpeaker, initializeProximityDisabler } = useProximityDisabler({
    enabled: true
  });

  // Инициализируем хук для принудительного использования внешнего динамика в WebRTC
  const { configureRTCForSpeaker, forceAudioToSpeaker, createSpeakerAudioContext } = useWebRTCAudioForcer();

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const dcRef = useRef<RTCDataChannel | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const userIdRef = useRef<number | null>(null);
  const sessionIdRef = useRef<number | null>(null);
  const processedItemIds = useRef<Set<string>>(new Set()); // Для дедупликации

  const log = useCallback((message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = `[${timestamp}] ${message}`;
    setLogs(prev => [...prev, logEntry]);
    console.log(logEntry);
  }, []);

  // Функция для сохранения сообщения в базу данных
  const saveMessage = useCallback(async (role: 'user' | 'assistant', content: string) => {
    if (!userIdRef.current) {
      log('❌ User ID отсутствует, сохранение невозможно');
      return;
    }

    try {
      const response = await fetch('/api/conversation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userIdRef.current,
          session_id: sessionIdRef.current,
          message_type: role,
          content: content.trim(),
          audio_duration_seconds: 0
        }),
      });

      if (response.ok) {
        log(`✅ Сохранено: ${role} - "${content}"`);
      } else {
        const errorText = await response.text();
        log(`❌ Ошибка сохранения: ${response.status} - ${errorText}`);
      }

    } catch (error) {
      log(`❌ Ошибка сохранения: ${error instanceof Error ? error.message : 'Неизвестная ошибка'}`);
    }
  }, [log]);

  // Функция для списания токенов через новый PATCH endpoint
  const deductTokens = useCallback(async (usage: TokenUsage, sessionId: string) => {
    if (!userIdRef.current) {
      log('❌ User ID отсутствует, списание токенов невозможно');
      return;
    }

    try {
      log(`💳 Списываем токены: ${usage.total_tokens} (вход: ${usage.input_tokens}, выход: ${usage.output_tokens})`);

      const response = await fetch('/api/tokens', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userIdRef.current,
          session_id: sessionId,
          usage: usage
        }),
      });

      const result = await response.json();

      if (response.ok && result.success) {
        log(`✅ Токены списаны: ${result.tokens_used}, новый баланс: ${result.new_balance}`);
        log(`📊 Детали: текст входных: ${result.usage_breakdown.input.text}, аудио выходных: ${result.usage_breakdown.output.audio}`);
      } else {
        log(`❌ Ошибка списания токенов: ${result.error || 'Неизвестная ошибка'}`);
      }

    } catch (error) {
      log(`❌ Ошибка списания токенов: ${error instanceof Error ? error.message : 'Неизвестная ошибка'}`);
    }
  }, [log]);

  const connect = useCallback(async (userId?: number) => {
    if (state === 'connecting' || state === 'connected') return;

    setState('connecting');
    setError(null);
    userIdRef.current = userId || null;
    log(`Начинаем подключение для пользователя: ${userId || 'анонимный'}...`);

    try {
      // Получаем токен от нашего API с user_id для контекста
      log('Запрашиваем токен...');
      const tokenUrl = userId ? `/api/token?user_id=${userId}` : '/api/token';
      const tokenResp = await fetch(tokenUrl);
      if (!tokenResp.ok) throw new Error('Не удалось получить токен');

      const tokenData = await tokenResp.json();
      const ephemeralKey = tokenData.client_secret?.value || tokenData.value;

      if (!ephemeralKey) {
        throw new Error('Токен не найден в ответе сервера');
      }

      // Инициализируем отключение датчика приближения перед получением микрофона
      log('Инициализируем отключение датчика приближения...');
      await initializeProximityDisabler();

      // Создаем аудио контекст для принудительного использования внешнего динамика
      log('Создаем аудио контекст для внешнего динамика...');
      const speakerContext = await createSpeakerAudioContext();
      if (speakerContext) {
        log('✅ Аудио контекст для внешнего динамика создан');
      }

      // Получаем доступ к микрофону
      log('Получаем доступ к микрофону...');
      localStreamRef.current = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,      // Включаем для лучшего качества
          noiseSuppression: true,      // Включаем для чистого звука
          autoGainControl: true,       // Включаем для стабильной громкости
          // Дополнительные настройки для качественного звука
          sampleRate: 48000,
          channelCount: 1
        }
      });

      // Создаем RTCPeerConnection
      log('Создаем WebRTC соединение...');
      pcRef.current = new RTCPeerConnection();

      // Настраиваем RTCPeerConnection для принудительного использования внешнего динамика
      configureRTCForSpeaker(pcRef.current);

      // Обработчик для входящего аудио
      pcRef.current.ontrack = async (event) => {
        log('Получен удаленный аудио поток');
        if (!audioRef.current) {
          audioRef.current = new Audio();
          audioRef.current.autoplay = true;

          }

        audioRef.current.srcObject = event.streams[0];

        // Применяем комплексную настройку для принудительного использования внешнего динамика
        await forceAudioToSpeaker(audioRef.current);

        // Применяем настройки для отключения датчика приближения
        await enforceMainSpeaker();

        log('🔊 Аудио поток настроен на внешний динамик');
      };

      // Обработчик состояния соединения
      pcRef.current.onconnectionstatechange = () => {
        const connectionState = pcRef.current?.connectionState;
        log(`Состояние соединения: ${connectionState}`);

        if (connectionState === 'connected') {
          setState('connected');
        } else if (connectionState === 'failed' || connectionState === 'disconnected') {
          setState('error');
          setError('Соединение потеряно');
        }
      };

      // Обработчик для data channel (получение сообщений от ИИ)
      pcRef.current.ondatachannel = (event) => {
        const channel = event.channel;
        log(`Data channel создан: ${channel.label}`);

        channel.onopen = () => {
          log('Data channel открыт и готов к приему сообщений');
        };

        channel.onmessage = (message) => {
          log(`Входящее сообщение в pcRef channel: ${message.data}`);
        };

        channel.onerror = (error) => {
          log(`❌ Ошибка data channel: ${error}`);
        };

        channel.onclose = () => {
          log('🔒 Data channel закрыт');
        };
      };

      // Добавляем локальный аудио трек
      const audioTrack = localStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        pcRef.current.addTrack(audioTrack, localStreamRef.current);
      }

      // Создаем исходящий data channel
      dcRef.current = pcRef.current.createDataChannel('oai-events');

      dcRef.current.onopen = () => {
        log('Data channel открыт и готов к работе');

        // Настраиваем сессию (голос уже установлен в токене)
        if (dcRef.current && dcRef.current.readyState === 'open') {
          const sessionConfig = {
            type: 'session.update',
            session: {
              modalities: ['text', 'audio'],
              instructions: 'Инструкции будут получены от сервера через API token endpoint',
              // Убираем voice отсюда - он уже установлен в токене из БД
              input_audio_format: 'pcm16',
              output_audio_format: 'pcm16',
              input_audio_transcription: {
                model: 'whisper-1'
              },
              turn_detection: {
                type: 'server_vad',
                threshold: 0.5,
                prefix_padding_ms: 300,
                silence_duration_ms: 500
              },
              tools: [],
              tool_choice: 'auto',
              temperature: 0.8,
              max_response_output_tokens: 4096
            }
          };

          dcRef.current.send(JSON.stringify(sessionConfig));
          log(`🎯 Сессия настроена (голос берется из токена для пользователя ${userId})`);
        }
      };

      dcRef.current.onmessage = async (message) => {
        try {
          const eventData = JSON.parse(message.data);

          // Обрабатываем только важные события
          if (eventData.type) {

            // ✨ НОВОЕ: Обработка завершения ответа с данными о токенах
            if (eventData.type === 'response.done') {
              log('💰 Получены данные о токенах от AI');

              if (eventData.response?.usage) {
                const usage = eventData.response.usage;
                const responseId = eventData.response?.id || `session_${Date.now()}`;

                // Списываем токены через новый PATCH endpoint
                await deductTokens(usage, responseId);
              } else {
                log('⚠️ Данные о токенах отсутствуют в response.done');
              }
            }

            // Проверяем разные возможные события для сохранения сообщений
            else if (eventData.type === 'conversation.item.done') {
              log('📝 Обрабатываем завершенное сообщение');

              if (eventData.item && eventData.item.content && eventData.item.content.length > 0) {
                const item = eventData.item;
                const itemId = item.id || `${item.role}_${Date.now()}`;

                // Проверяем, не обрабатывали ли мы уже это сообщение
                if (processedItemIds.current.has(itemId)) {
                  log(`⚠️ Сообщение ${itemId} уже обработано, пропускаем`);
                  return;
                }

                // Добавляем ID в список обработанных
                processedItemIds.current.add(itemId);

                // Для пользователя - сохраняем сообщение
                if (item.role === 'user') {
                  if (item.content[0]?.type === 'input_audio') {
                    const userMessage = item.content[0]?.transcript || '[Голосовое сообщение]';
                    await saveMessage('user', userMessage);
                  }
                }

                // Для ассистента - сохраняем ответ
                else if (item.role === 'assistant') {
                  if (item.content[0]?.type === 'output_audio' && item.content[0]?.transcript) {
                    await saveMessage('assistant', item.content[0].transcript);
                  }
                }

                else {
                  log(`❓ Неизвестная роль: ${item.role}`);
                }
              } else {
                log('❌ Нет item или content в событии');
              }
            }

            // Убираем дублирование - сохраняем только в conversation.item.done
            else if (eventData.type === 'response.output_audio_transcript.done') {
              log('🎙️ Событие завершения транскрипции (не сохраняем - будет в conversation.item.done)');
            }

            else if (eventData.type === 'input_audio_buffer.speech_started') {
              log('🗣️ Пользователь начал говорить');
            }

            else if (eventData.type === 'input_audio_buffer.speech_stopped') {
              log('🤐 Пользователь закончил говорить');
            }

            // Игнорируем шумные события для чистоты логов
            else if (eventData.type.includes('delta') ||
                     eventData.type.includes('added') ||
                     eventData.type.includes('started') ||
                     eventData.type === 'session.created' ||
                     eventData.type === 'response.created' ||
                     eventData.type === 'rate_limits.updated') {
              // Не логируем эти события для чистоты
            }

            else {
              log(`❓ Неизвестное событие: ${eventData.type}`);
            }
          }
        } catch (e) {
          // Если не JSON, просто логируем
          const errorMessage = e instanceof Error ? e.message : 'Неизвестная ошибка';
          log(`❌ Ошибка парсинга JSON: ${errorMessage}`);
          log(`📄 Сообщение как текст: ${message.data}`);
        }
      };

      // Создаем offer
      log('Создаем offer...');
      const offer = await pcRef.current.createOffer();
      await pcRef.current.setLocalDescription(offer);

      // Отправляем SDP через наш прокси API
      log('Отправляем SDP через прокси...');
      const model = 'gpt-realtime';

      const sdpResp = await fetch(`/api/realtime?model=${encodeURIComponent(model)}`, {
        method: 'POST',
        body: offer.sdp,
        headers: {
          'Content-Type': 'application/sdp',
        },
      });

      if (!sdpResp.ok) {
        throw new Error(`OpenAI API вернул статус: ${sdpResp.status}`);
      }

      const answerSdp = await sdpResp.text();
      await pcRef.current.setRemoteDescription({ type: 'answer', sdp: answerSdp });

      log('Подключение успешно установлено!');
      setState('connected');

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Неизвестная ошибка';
      log(`Ошибка: ${errorMessage}`);
      setError(errorMessage);
      setState('error');

      // Очистка при ошибке
      if (pcRef.current) {
        try {
          pcRef.current.close();
        } catch (e) {
          console.error('Ошибка при закрытии peer connection:', e);
        }
        pcRef.current = null;
      }

      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach(track => track.stop());
        localStreamRef.current = null;
      }
    }
  }, [state, log, saveMessage, deductTokens, enforceMainSpeaker, initializeProximityDisabler, configureRTCForSpeaker, forceAudioToSpeaker, createSpeakerAudioContext]);

  const disconnect = useCallback(() => {
    log('Отключаемся...');

    if (pcRef.current) {
      try {
        pcRef.current.close();
      } catch (e) {
        console.error('Ошибка при закрытии peer connection:', e);
      }
      pcRef.current = null;
    }

    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => track.stop());
      localStreamRef.current = null;
    }

    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }

    dcRef.current = null;
    userIdRef.current = null;
    sessionIdRef.current = null;
    processedItemIds.current.clear(); // Очищаем список обработанных сообщений
    setState('idle');
    setError(null);
    log('Отключено');
  }, [log]);

  return {
    state,
    isConnected: state === 'connected',
    logs,
    connect,
    disconnect,
    error,
  };
}
