import { NextRequest, NextResponse } from 'next/server';

// Этот endpoint должен вызываться каждые 5 минут через внешний cron сервис
export async function GET(request: NextRequest) {
  // Проверяем секретный ключ для безопасности
  const cronSecret = process.env.CRON_SECRET;
  const authHeader = request.headers.get('authorization');

  if (!cronSecret || authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    console.log('Running webhook health check...');

    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL;
    if (!baseUrl) {
      throw new Error('App URL not configured');
    }

    // Вызываем наш monitor endpoint
    const monitorResponse = await fetch(`${baseUrl}/api/telegram/monitor-webhook`);
    const monitorResult = await monitorResponse.json();

    if (!monitorResult.success) {
      console.error('Webhook monitor failed:', monitorResult.error);
      return NextResponse.json({
        success: false,
        error: 'Monitor check failed',
        details: monitorResult.error
      });
    }

    const webhookStatus = monitorResult.webhook_status;

    // Логируем результаты
    console.log('Webhook health check result:', {
      healthy: webhookStatus.healthy,
      pending_updates: webhookStatus.pending_updates,
      last_error: webhookStatus.last_error_message,
      restored: webhookStatus.restored
    });

    // Если webhook был восстановлен, отправляем уведомление (опционально)
    if (webhookStatus.restored) {
      console.log('🔧 Webhook was automatically restored');

      // Здесь можно добавить отправку уведомления админу в Telegram
      // await notifyAdmin('Webhook был автоматически восстановлен');
    }

    return NextResponse.json({
      success: true,
      webhook_healthy: webhookStatus.healthy,
      details: webhookStatus,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Cron webhook monitor error:', error);

    // Попытка экстренного восстановления при критической ошибке
    try {
      const baseUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL;
      if (baseUrl) {
        console.log('Attempting emergency webhook restore...');
        await fetch(`${baseUrl}/api/telegram/monitor-webhook`, { method: 'POST' });
      }
    } catch (emergencyError) {
      console.error('Emergency restore failed:', emergencyError);
    }

    return NextResponse.json({
      success: false,
      error: 'Cron job failed',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

// Функция для отправки уведомлений админу (опционально)
async function notifyAdmin(message: string) {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const adminChatId = process.env.TELEGRAM_ADMIN_CHAT_ID;

  if (!botToken || !adminChatId) return;

  try {
    await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: adminChatId,
        text: `🤖 <b>Webhook Monitor</b>\n\n${message}`,
        parse_mode: 'HTML'
      })
    });
  } catch (error) {
    console.error('Failed to notify admin:', error);
  }
}
