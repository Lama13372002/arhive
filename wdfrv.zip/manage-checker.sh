#!/bin/bash

# Скрипт управления демоном автопроверки ставок

DAEMON_SCRIPT="auto-checker-daemon.cjs"
PID_FILE="auto-checker.pid"
LOG_FILE="auto-checker.log"
WATCHDOG_PID_FILE="auto-checker-watchdog.pid"
WATCHDOG_LOG_FILE="auto-checker-watchdog.log"

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_help() {
    echo -e "${BLUE}🤖 Управление демоном автопроверки ставок${NC}"
    echo ""
    echo "Использование: $0 {start|stop|restart|status|logs|watch|stopwatch|autostart|help}"
    echo ""
    echo "Команды:"
    echo "  start     - Запустить демон"
    echo "  stop      - Остановить демон и watchdog"
    echo "  restart   - Перезапустить демон"
    echo "  status    - Показать статус демона и watchdog"
    echo "  logs      - Показать логи демона и watchdog"
    echo "  watch     - Запустить watchdog для автоматического перезапуска"
    echo "  stopwatch - Остановить только watchdog"
    echo "  autostart - Запустить демон + watchdog (рекомендуется)"
    echo "  help      - Показать эту справку"
    echo ""
    echo -e "${YELLOW}💡 Рекомендация: используйте 'autostart' для максимальной надежности${NC}"
}

check_dependencies() {
    if ! command -v node &> /dev/null; then
        echo -e "${RED}❌ Node.js не установлен${NC}"
        exit 1
    fi

    if [ ! -f "$DAEMON_SCRIPT" ]; then
        echo -e "${RED}❌ Файл демона не найден: $DAEMON_SCRIPT${NC}"
        exit 1
    fi
}

get_pid() {
    if [ -f "$PID_FILE" ]; then
        cat "$PID_FILE"
    else
        echo ""
    fi
}

is_running() {
    local pid=$(get_pid)
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
        return 0
    else
        return 1
    fi
}

get_watchdog_pid() {
    if [ -f "$WATCHDOG_PID_FILE" ]; then
        cat "$WATCHDOG_PID_FILE"
    else
        echo ""
    fi
}

is_watchdog_running() {
    local pid=$(get_watchdog_pid)
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
        return 0
    else
        return 1
    fi
}

log_watchdog() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$WATCHDOG_LOG_FILE"
}

watchdog_loop() {
    local restart_count=0
    local max_restarts=5
    local last_restart_time=0

    log_watchdog "🐕 Watchdog запущен (PID: $)"

    while true; do
        if ! is_running; then
            log_watchdog "⚠️ Демон автопроверки не запущен, пытаюсь перезапустить..."

            current_time=$(date +%s)

            # Сбрасываем счетчик если прошло более часа
            if [ $((current_time - last_restart_time)) -gt 3600 ]; then
                restart_count=0
            fi

            if [ $restart_count -ge $max_restarts ]; then
                log_watchdog "❌ Превышен лимит перезапусков ($max_restarts). Останавливаю watchdog."
                break
            fi

            # Запускаем демон
            if start_daemon_silent; then
                restart_count=$((restart_count + 1))
                last_restart_time=$current_time
                log_watchdog "✅ Демон перезапущен (попытка #$restart_count)"
            else
                log_watchdog "❌ Не удалось перезапустить демон"
            fi

            sleep 30
        else
            sleep 30
        fi
    done

    log_watchdog "🛑 Watchdog остановлен"
}

start_daemon_silent() {
    if is_running; then
        return 0
    fi

    # Удаляем старый PID файл если он есть
    [ -f "$PID_FILE" ] && rm -f "$PID_FILE"

    # Запускаем демон в фоне
    nohup node "$DAEMON_SCRIPT" > /dev/null 2>&1 &

    # Ждем немного и проверяем запуск
    sleep 2

    if is_running; then
        return 0
    else
        return 1
    fi
}

start_daemon() {
    echo -e "${BLUE}🚀 Запуск демона автопроверки...${NC}"

    if is_running; then
        echo -e "${YELLOW}⚠️ Демон уже запущен (PID: $(get_pid))${NC}"
        return 1
    fi

    # Удаляем старый PID файл если он есть
    [ -f "$PID_FILE" ] && rm -f "$PID_FILE"

    # Устанавливаем node-fetch если не установлен
    if ! node -e "require('node-fetch')" 2>/dev/null; then
        echo -e "${YELLOW}📦 Устанавливаю node-fetch...${NC}"
        npm install node-fetch
    fi

    # Запускаем демон в фоне
    nohup node "$DAEMON_SCRIPT" > /dev/null 2>&1 &

    # Ждем немного и проверяем запуск
    sleep 2

    if is_running; then
        echo -e "${GREEN}✅ Демон успешно запущен (PID: $(get_pid))${NC}"
        echo -e "${BLUE}📄 Логи: tail -f $LOG_FILE${NC}"
    else
        echo -e "${RED}❌ Не удалось запустить демон${NC}"
        if [ -f "$LOG_FILE" ]; then
            echo -e "${YELLOW}Последние ошибки:${NC}"
            tail -n 10 "$LOG_FILE"
        fi
        return 1
    fi
}

stop_daemon() {
    echo -e "${BLUE}🛑 Остановка демона...${NC}"

    if ! is_running; then
        echo -e "${YELLOW}⚠️ Демон не запущен${NC}"
        # Удаляем старый PID файл
        [ -f "$PID_FILE" ] && rm -f "$PID_FILE"
        return 1
    fi

    local pid=$(get_pid)
    echo -e "${BLUE}Останавливаю процесс $pid...${NC}"

    # Отправляем SIGTERM
    kill "$pid"

    # Ждем корректного завершения
    local count=0
    while is_running && [ $count -lt 10 ]; do
        sleep 1
        count=$((count + 1))
    done

    if is_running; then
        echo -e "${YELLOW}⚠️ Принудительная остановка...${NC}"
        kill -9 "$pid"
        sleep 1
    fi

    # Удаляем PID файл
    [ -f "$PID_FILE" ] && rm -f "$PID_FILE"

    if is_running; then
        echo -e "${RED}❌ Не удалось остановить демон${NC}"
        return 1
    else
        echo -e "${GREEN}✅ Демон остановлен${NC}"
    fi
}

start_watchdog() {
    echo -e "${BLUE}🐕 Запуск watchdog для автоматического перезапуска...${NC}"

    if is_watchdog_running; then
        echo -e "${YELLOW}⚠️ Watchdog уже запущен (PID: $(get_watchdog_pid))${NC}"
        return 1
    fi

    # Удаляем старый PID файл если он есть
    [ -f "$WATCHDOG_PID_FILE" ] && rm -f "$WATCHDOG_PID_FILE"

    # Запускаем watchdog в фоне
    (
        echo $$ > "$WATCHDOG_PID_FILE"
        watchdog_loop
    ) &

    # Ждем немного и проверяем запуск
    sleep 2

    if is_watchdog_running; then
        echo -e "${GREEN}✅ Watchdog успешно запущен (PID: $(get_watchdog_pid))${NC}"
        echo -e "${BLUE}📄 Логи watchdog: tail -f $WATCHDOG_LOG_FILE${NC}"
    else
        echo -e "${RED}❌ Не удалось запустить watchdog${NC}"
        return 1
    fi
}

stop_watchdog() {
    echo -e "${BLUE}🛑 Остановка watchdog...${NC}"

    if ! is_watchdog_running; then
        echo -e "${YELLOW}⚠️ Watchdog не запущен${NC}"
        # Удаляем старый PID файл
        [ -f "$WATCHDOG_PID_FILE" ] && rm -f "$WATCHDOG_PID_FILE"
        return 1
    fi

    local pid=$(get_watchdog_pid)
    echo -e "${BLUE}Останавливаю watchdog $pid...${NC}"

    # Отправляем SIGTERM
    kill "$pid"

    # Ждем корректного завершения
    local count=0
    while is_watchdog_running && [ $count -lt 10 ]; do
        sleep 1
        count=$((count + 1))
    done

    if is_watchdog_running; then
        echo -e "${YELLOW}⚠️ Принудительная остановка watchdog...${NC}"
        kill -9 "$pid"
        sleep 1
    fi

    # Удаляем PID файл
    [ -f "$WATCHDOG_PID_FILE" ] && rm -f "$WATCHDOG_PID_FILE"

    if is_watchdog_running; then
        echo -e "${RED}❌ Не удалось остановить watchdog${NC}"
        return 1
    else
        echo -e "${GREEN}✅ Watchdog остановлен${NC}"
    fi
}

show_status() {
    echo -e "${BLUE}📊 Статус демона автопроверки${NC}"
    echo ""

    # Статус основного демона
    if is_running; then
        local pid=$(get_pid)
        echo -e "Демон: ${GREEN}🟢 Запущен${NC} (PID: $pid)"

        # Показываем информацию о процессе
        if command -v ps &> /dev/null; then
            echo "Процесс:"
            ps -p "$pid" -o pid,ppid,cmd,etime,pcpu,pmem 2>/dev/null || echo "  Информация недоступна"
        fi
    else
        echo -e "Демон: ${RED}🔴 Остановлен${NC}"

        if [ -f "$PID_FILE" ]; then
            echo -e "${YELLOW}⚠️ Найден старый PID файл (процесс завершился некорректно)${NC}"
        fi
    fi

    echo ""

    # Статус watchdog
    if is_watchdog_running; then
        local watchdog_pid=$(get_watchdog_pid)
        echo -e "Watchdog: ${GREEN}🟢 Запущен${NC} (PID: $watchdog_pid)"
    else
        echo -e "Watchdog: ${RED}🔴 Остановлен${NC}"
    fi

    # Показываем последние логи демона
    if [ -f "$LOG_FILE" ]; then
        echo ""
        echo -e "${BLUE}📄 Последние логи демона:${NC}"
        tail -n 3 "$LOG_FILE"
    fi

    # Показываем последние логи watchdog
    if [ -f "$WATCHDOG_LOG_FILE" ]; then
        echo ""
        echo -e "${BLUE}📄 Последние логи watchdog:${NC}"
        tail -n 3 "$WATCHDOG_LOG_FILE"
    fi

    echo ""
    echo -e "${BLUE}Файлы:${NC}"
    echo "  Демон: $DAEMON_SCRIPT $([ -f "$DAEMON_SCRIPT" ] && echo "✅" || echo "❌")"
    echo "  PID: $PID_FILE $([ -f "$PID_FILE" ] && echo "✅" || echo "❌")"
    echo "  Логи: $LOG_FILE $([ -f "$LOG_FILE" ] && echo "✅" || echo "❌")"
    echo "  Watchdog PID: $WATCHDOG_PID_FILE $([ -f "$WATCHDOG_PID_FILE" ] && echo "✅" || echo "❌")"
    echo "  Watchdog логи: $WATCHDOG_LOG_FILE $([ -f "$WATCHDOG_LOG_FILE" ] && echo "✅" || echo "❌")"
}

show_logs() {
    echo -e "${BLUE}📄 Логи автопроверки (последние 50 строк):${NC}"
    echo ""

    if [ ! -f "$LOG_FILE" ]; then
        echo -e "${YELLOW}⚠️ Лог файл демона не найден: $LOG_FILE${NC}"
    else
        tail -n 50 "$LOG_FILE"
    fi

    echo ""
    echo -e "${BLUE}📄 Логи watchdog (последние 20 строк):${NC}"
    echo ""

    if [ ! -f "$WATCHDOG_LOG_FILE" ]; then
        echo -e "${YELLOW}⚠️ Лог файл watchdog не найден: $WATCHDOG_LOG_FILE${NC}"
    else
        tail -n 20 "$WATCHDOG_LOG_FILE"
    fi
}

# Основная логика
case "$1" in
    start)
        check_dependencies
        start_daemon
        ;;
    stop)
        stop_watchdog
        stop_daemon
        ;;
    restart)
        check_dependencies
        stop_daemon
        sleep 1
        start_daemon
        ;;
    status)
        show_status
        ;;
    logs)
        show_logs
        ;;
    watch)
        check_dependencies
        start_watchdog
        ;;
    stopwatch)
        stop_watchdog
        ;;
    autostart)
        check_dependencies
        echo -e "${BLUE}🚀 Автозапуск: демон + watchdog${NC}"
        start_daemon
        if [ $? -eq 0 ]; then
            sleep 2
            start_watchdog
        fi
        ;;
    help|--help|-h)
        print_help
        ;;
    *)
        echo -e "${RED}❌ Неизвестная команда: $1${NC}"
        echo ""
        print_help
        exit 1
        ;;
esac
