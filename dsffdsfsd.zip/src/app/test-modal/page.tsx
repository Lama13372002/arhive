'use client';

import { useState, useEffect } from 'react';
import { JoinBetModal } from '@/components/modals/JoinBetModal';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TelegramProvider, useTelegram } from '@/components/providers/TelegramProvider';

// Тестовый пользователь для отладки
const testUser = {
  id: 123456789,
  first_name: 'Test',
  last_name: 'User',
  username: 'testuser',
  language_code: 'ru',
  is_premium: false,
  allows_write_to_pm: true
};

function TestModalContent() {
  const { user } = useTelegram();
  const [modalOpen, setModalOpen] = useState(false);
  const [betId, setBetId] = useState(1); // ID существующего спора

  const handleJoinSuccess = () => {
    console.log('Successfully joined bet!');
    setModalOpen(false);
  };

  useEffect(() => {
    console.log('Current user from TelegramProvider:', user);
  }, [user]);

  return (
    <div className="min-h-screen p-8 bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="max-w-2xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Тестирование модального окна присоединения к спору</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-yellow-100 p-3 rounded">
              <p className="text-sm font-medium">Текущий пользователь:</p>
              <p className="text-xs">ID: {user?.id || 'не загружен'}</p>
              <p className="text-xs">Имя: {user?.first_name} {user?.last_name}</p>
              <p className="text-xs">Username: {user?.username || 'не указан'}</p>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">ID спора для тестирования:</label>
              <input
                type="number"
                value={betId}
                onChange={(e) => setBetId(Number(e.target.value))}
                className="border rounded px-3 py-2 w-32"
              />
            </div>

            <Button
              onClick={() => setModalOpen(true)}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Открыть модальное окно (Bet ID: {betId})
            </Button>

            <div className="text-sm text-gray-600">
              <p>Открой консоль браузера (F12) чтобы увидеть логи и ошибки.</p>
              <p>Спор с ID=1 должен существовать в базе данных.</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <JoinBetModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        betId={betId}
        onJoinSuccess={handleJoinSuccess}
      />
    </div>
  );
}

export default function TestModalPage() {
  return (
    <TelegramProvider>
      <TestModalContent />
    </TelegramProvider>
  );
}
