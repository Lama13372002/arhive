/**
 * TON API Service для проверки транзакций
 * Использует tonapi.io для верификации блокчейн транзакций
 */

import { Address } from '@ton/core';

interface TonApiTransaction {
  hash: string;
  lt: string;
  account: {
    address: string;
  };
  in_msg?: {
    value: string;
    destination: {
      address: string;
    };
    source?: {
      address: string;
    };
  };
  out_msgs: Array<{
    value: string;
    destination: {
      address: string;
    };
  }>;
  success: boolean;
  total_fees: string;
  utime: number;
}

interface TonApiResponse<T> {
  ok: boolean;
  result?: T;
  error?: string;
}

class TonApiService {
  private baseUrl = 'https://tonapi.io/v2';
  private apiKey?: string;

  constructor(apiKey?: string) {
    this.apiKey = apiKey;
  }

  private async makeRequest<T>(endpoint: string): Promise<TonApiResponse<T>> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    // Добавляем API ключ если есть
    if (this.apiKey) {
      headers['Authorization'] = `Bearer ${this.apiKey}`;
    }

    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        headers,
      });

      if (!response.ok) {
        return {
          ok: false,
          error: `HTTP ${response.status}: ${response.statusText}`,
        };
      }

      const data = await response.json();
      return {
        ok: true,
        result: data,
      };
    } catch (error) {
      return {
        ok: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Получить информацию о транзакции по хешу
   */
  async getTransaction(txHash: string): Promise<TonApiResponse<TonApiTransaction>> {
    return this.makeRequest<TonApiTransaction>(`/blockchain/transactions/${txHash}`);
  }

  /**
   * Получить транзакции аккаунта
   */
  async getAccountTransactions(
    address: string,
    limit: number = 10,
    before_lt?: string
  ): Promise<TonApiResponse<{ transactions: TonApiTransaction[] }>> {
    let endpoint = `/blockchain/accounts/${address}/transactions?limit=${limit}`;
    if (before_lt) {
      endpoint += `&before_lt=${before_lt}`;
    }
    return this.makeRequest(`/blockchain/accounts/${address}/transactions?limit=${limit}`);
  }

  /**
   * Проверить, была ли отправлена транзакция с определенными параметрами
   * @param fromAddress - адрес отправителя (в любом формате)
   * @param toAddress - адрес получателя (в любом формате)
   * @param amount - сумма в наноTON
   * @param timeWindow - окно времени для поиска в секундах (по умолчанию 10 минут)
   */
  async verifyPayment(
    fromAddress: string,
    toAddress: string,
    amount: string,
    timeWindow: number = 600
  ): Promise<{
    verified: boolean;
    transaction?: TonApiTransaction;
    error?: string;
  }> {
    try {
      // Нормализуем адреса к user-friendly формату
      const normalizedFromAddress = this.normalizeToUserFriendly(fromAddress);
      const normalizedToAddress = this.normalizeToUserFriendly(toAddress);

      console.log('Normalized addresses:', {
        from: normalizedFromAddress,
        to: normalizedToAddress,
        originalFrom: fromAddress,
        originalTo: toAddress
      });

      // Получаем последние транзакции получателя
      const response = await this.getAccountTransactions(normalizedToAddress, 20);

      if (!response.ok || !response.result) {
        return {
          verified: false,
          error: response.error || 'Failed to fetch transactions',
        };
      }

      const transactions = response.result.transactions;
      const now = Math.floor(Date.now() / 1000);
      const timeThreshold = now - timeWindow;

      console.log(`Looking for transactions from ${timeThreshold} to ${now}, checking ${transactions.length} transactions`);

      // Ищем подходящую транзакцию
      for (const tx of transactions) {
        console.log('Checking transaction:', {
          hash: tx.hash,
          time: tx.utime,
          success: tx.success,
          hasInMsg: !!tx.in_msg
        });

        // Проверяем время
        if (tx.utime < timeThreshold) {
          console.log('Transaction too old, skipping');
          continue;
        }

        // Проверяем успешность
        if (!tx.success) {
          console.log('Transaction failed, skipping');
          continue;
        }

        // Проверяем входящее сообщение
        if (tx.in_msg) {
          const txFromAddress = this.normalizeToUserFriendly(tx.in_msg.source?.address || '');
          const txToAddress = this.normalizeToUserFriendly(tx.in_msg.destination.address);

          console.log('Transaction details:', {
            from: txFromAddress,
            to: txToAddress,
            value: tx.in_msg.value,
            expectedAmount: amount
          });

          const isFromCorrectSender = txFromAddress === normalizedFromAddress;
          const isCorrectAmount = tx.in_msg.value === amount;
          const isToCorrectRecipient = txToAddress === normalizedToAddress;

          console.log('Verification checks:', {
            isFromCorrectSender,
            isCorrectAmount,
            isToCorrectRecipient
          });

          if (isFromCorrectSender && isCorrectAmount && isToCorrectRecipient) {
            return {
              verified: true,
              transaction: tx,
            };
          }
        }
      }

      return {
        verified: false,
        error: 'No matching transaction found',
      };
    } catch (error) {
      console.error('Error in verifyPayment:', error);
      return {
        verified: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  /**
   * Конвертировать TON в наноTON
   */
  static tonToNano(ton: number): string {
    return Math.floor(ton * 1000000000).toString();
  }

  /**
   * Конвертировать наноTON в TON
   */
  static nanoToTon(nano: string): number {
    return parseInt(nano) / 1000000000;
  }

  /**
   * Нормализовать адрес TON (убрать флаги и конвертировать в user-friendly формат)
   */
  static normalizeAddress(address: string): string {
    // Убираем флаги если есть
    if (address.includes(':')) {
      const parts = address.split(':');
      if (parts.length === 2) {
        return `0:${parts[1]}`;
      }
    }
    return address;
  }

  /**
   * Конвертировать адрес в user-friendly формат
   */
  normalizeToUserFriendly(address: string): string {
    try {
      if (!address) return '';

      // Если адрес уже в user-friendly формате (начинается с EQ или UQ)
      if (address.startsWith('EQ') || address.startsWith('UQ')) {
        return address;
      }

      // Если адрес в raw формате (workchain:hash)
      if (address.includes(':')) {
        const [workchain, hash] = address.split(':');
        const parsedAddress = Address.parseRaw(`${workchain}:${hash}`);
        return parsedAddress.toString();
      }

      // Пытаемся распарсить как есть
      const parsedAddress = Address.parse(address);
      return parsedAddress.toString();
    } catch (error) {
      console.error('Failed to normalize address:', address, error);
      return address; // Возвращаем исходный адрес если не удалось конвертировать
    }
  }

  /**
   * Получить информацию об аккаунте
   */
  async getAccount(address: string): Promise<TonApiResponse<{
    address: string;
    balance: string;
    status: string;
  }>> {
    const normalizedAddress = this.normalizeToUserFriendly(address);
    return this.makeRequest(`/blockchain/accounts/${normalizedAddress}`);
  }
}

// Создаем экземпляр сервиса
export const tonApi = new TonApiService(process.env.TONAPI_KEY);

// Экспортируем класс для создания новых экземпляров при необходимости
export { TonApiService };

// Типы для использования в других частях приложения
export type { TonApiTransaction, TonApiResponse };
