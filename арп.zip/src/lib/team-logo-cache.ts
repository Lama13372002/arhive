import { query } from './database';

export interface TeamLogoCache {
  id: number;
  team_name: string;
  team_id?: number;
  logo_url: string;
  last_updated: Date;
}

// Инициализация таблицы для кеша логотипов команд
export const initTeamLogoCacheTable = async (): Promise<void> => {
  try {
    await query(`
      CREATE TABLE IF NOT EXISTS team_logo_cache (
        id SERIAL PRIMARY KEY,
        team_name VARCHAR(255) NOT NULL,
        team_id INTEGER,
        logo_url TEXT NOT NULL,
        last_updated TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(team_name)
      )
    `);

    // Создаем индекс для быстрого поиска по имени команды
    await query(`
      CREATE INDEX IF NOT EXISTS idx_team_logo_cache_name
      ON team_logo_cache(team_name)
    `);

    console.log('✅ Team logo cache table initialized successfully');
  } catch (error) {
    console.error('❌ Error initializing team logo cache table:', error);
  }
};

// Сохранить логотип команды в кеш
export const saveTeamLogo = async (
  teamName: string,
  logoUrl: string,
  teamId?: number
): Promise<void> => {
  if (!teamName || !logoUrl) return;

  try {
    await query(`
      INSERT INTO team_logo_cache (team_name, team_id, logo_url, last_updated)
      VALUES ($1, $2, $3, CURRENT_TIMESTAMP)
      ON CONFLICT (team_name)
      DO UPDATE SET
        logo_url = EXCLUDED.logo_url,
        team_id = COALESCE(EXCLUDED.team_id, team_logo_cache.team_id),
        last_updated = CURRENT_TIMESTAMP
    `, [teamName, teamId, logoUrl]);

  } catch (error) {
    console.error(`Error caching logo for team ${teamName}:`, error);
  }
};

// Получить логотип команды из кеша
export const getTeamLogo = async (teamName: string): Promise<string | null> => {
  if (!teamName) return null;

  try {
    const result = await query(`
      SELECT logo_url
      FROM team_logo_cache
      WHERE team_name = $1
    `, [teamName]);

    if (result.rows.length > 0) {
      return result.rows[0].logo_url;
    }

    return null;
  } catch (error) {
    console.error(`Error getting cached logo for team ${teamName}:`, error);
    return null;
  }
};

// Получить несколько логотипов команд за один запрос
export const getTeamLogos = async (teamNames: string[]): Promise<Record<string, string>> => {
  if (!teamNames.length) return {};

  try {
    const result = await query(`
      SELECT team_name, logo_url
      FROM team_logo_cache
      WHERE team_name = ANY($1)
    `, [teamNames]);

    const logos: Record<string, string> = {};
    result.rows.forEach(row => {
      logos[row.team_name] = row.logo_url;
    });

    return logos;
  } catch (error) {
    console.error('Error getting cached logos for teams:', error);
    return {};
  }
};

// Сохранить логотипы для нескольких команд безопасно
export const saveTeamLogos = async (teams: Array<{
  name: string;
  logo: string;
  id?: number;
}>): Promise<void> => {
  if (!teams.length) return;

  try {
    // Используем параметризованные запросы для безопасности
    for (const team of teams) {
      if (team.name && team.logo) {
        await saveTeamLogo(team.name, team.logo, team.id);
      }
    }
  } catch (error) {
    console.error('Error batch saving team logos:', error);
  }
};

// Функция для обогащения матчей кешированными логотипами
export const enrichMatchesWithCachedLogos = async <T extends {
  homeTeam: string;
  awayTeam: string;
  homeTeamLogo?: string;
  awayTeamLogo?: string;
}>(matches: T[]): Promise<T[]> => {
  if (!matches.length) return matches;

  try {
    // Собираем все уникальные имена команд
    const teamNames = Array.from(new Set(
      matches.flatMap(match => [match.homeTeam, match.awayTeam])
    ));

    // Получаем кешированные логотипы
    const cachedLogos = await getTeamLogos(teamNames);

    // Обогащаем матчи логотипами
    return matches.map(match => ({
      ...match,
      homeTeamLogo: match.homeTeamLogo || cachedLogos[match.homeTeam] || undefined,
      awayTeamLogo: match.awayTeamLogo || cachedLogos[match.awayTeam] || undefined,
    }));
  } catch (error) {
    console.error('Error enriching matches with cached logos:', error);
    return matches;
  }
};

// Функция для сохранения логотипов из матчей в кеш
export const cacheLogosFromMatches = async <T extends {
  homeTeam: string;
  awayTeam: string;
  homeTeamLogo?: string;
  awayTeamLogo?: string;
}>(matches: T[]): Promise<void> => {
  if (!matches.length) return;

  try {
    const teamsToCache: Array<{ name: string; logo: string; id?: number }> = [];

    matches.forEach(match => {
      if (match.homeTeam && match.homeTeamLogo) {
        teamsToCache.push({
          name: match.homeTeam,
          logo: match.homeTeamLogo
        });
      }
      if (match.awayTeam && match.awayTeamLogo) {
        teamsToCache.push({
          name: match.awayTeam,
          logo: match.awayTeamLogo
        });
      }
    });

    if (teamsToCache.length > 0) {
      await saveTeamLogos(teamsToCache);
    }
  } catch (error) {
    console.error('Error caching logos from matches:', error);
  }
};
