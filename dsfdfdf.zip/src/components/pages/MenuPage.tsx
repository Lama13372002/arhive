"use client";

import { useState, useEffect, useRef } from "react";
import { TonTopUpModal } from "@/components/ton/TonTopUpModal";
import { TonWithdrawalModal } from "@/components/ton/TonWithdrawalModal";
import { StarsTopUpModal } from "@/components/stars/StarsTopUpModal";
import { StarsToTonModal } from "@/components/stars/StarsToTonModal";
import { TonWalletButton } from "@/components/ton/TonWalletButton";
import { ReferralModal } from "@/components/referrals/ReferralModal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { UserAvatar } from "@/components/ui/user-avatar";
import { UserGuideModal } from "@/components/modals/UserGuideModal";
import { UserGuideI18nProvider } from "@/components/providers/UserGuideI18nProvider";
import { ReferralI18nProvider } from "@/components/providers/ReferralI18nProvider";
import {
  Wallet,
  Settings,
  HelpCircle,
  Plus,
  Minus,
  ArrowRight,
  Globe,
  Bell,
  Volume2,
  Vibrate,
  ChevronRight,
  ChevronDown,
  Coins,
  Star,
  TrendingUp,
  Shield,
  User,
  Users,
  Crown,
  Sparkles,
  DollarSign,
  History,
  Zap,
  Bookmark,
  Gift,
  BookOpen
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useTelegram } from "@/components/providers/TelegramProvider";
import { useBalance } from "@/hooks/useBalance";
import { useUserStats } from "@/hooks/useUserStats";
import { useTonWallet } from '@tonconnect/ui-react';
import { useI18n } from "@/components/providers/I18nProvider";
import { FEATURES } from "@/lib/features";

export const MenuPage = () => {
  const { user } = useTelegram();
  const wallet = useTonWallet();
  const { t, lang, setLanguage } = useI18n();
  const [expandedFaq, setExpandedFaq] = useState<string | null>(null);
  const walletSectionRef = useRef<HTMLDivElement>(null);
  const [settings, setSettings] = useState({
    language: "ru",
    notifications: true,
    sound: true,
    vibration: true
  });

  // User balance state - используем централизованный хук
  const { balance, exchangeRates, loading: loadingBalance, refreshBalance } = useBalance();

  // User stats - процент побед и другая статистика
  const { winRate, loading: loadingStats } = useUserStats(user?.id);

  // Modal states
  const [showTonTopUp, setShowTonTopUp] = useState(false);
  const [showTonWithdrawal, setShowTonWithdrawal] = useState(false);
  const [showStarsTopUp, setShowStarsTopUp] = useState(false);
  const [showStarsToTon, setShowStarsToTon] = useState(false);
  const [showReferralModal, setShowReferralModal] = useState(false);
  const [showUserGuide, setShowUserGuide] = useState(false);

  // Referral data
  const [referralCount, setReferralCount] = useState(0);

  const faqs = [
    { id: "1", question: t('faq_q1'), answer: t('faq_a1') },
    { id: "2", question: t('faq_q2'), answer: t('faq_a2') },
    { id: "3", question: t('faq_q3'), answer: t('faq_a3') },
    { id: "4", question: t('faq_q4'), answer: t('faq_a4') },
    { id: "5", question: t('faq_q5'), answer: t('faq_a5') },
  ];

  const handleDeposit = (currency: "TON" | "STARS") => {
    if (currency === "TON") {
      if (!wallet) {
        scrollToWalletSection();
      } else {
        setShowTonTopUp(true);
      }
    } else if (currency === "STARS") {
      setShowStarsTopUp(true);
    }
  };

  const handleWithdraw = (currency: "TON" | "STARS") => {
    if (currency === "TON") {
      setShowTonWithdrawal(true);
    } else if (currency === "STARS") {
      setShowStarsToTon(true);
    }
  };

  const handleLanguageChange = (language: "ru" | "en") => {
    setLanguage(language);
    alert(language === "ru" ? t('language_changed_ru') : t('language_changed_en'));
  };

  const handleNotificationsToggle = (checked: boolean) => {
    setSettings({ ...settings, notifications: checked });
    alert(checked ? t('notifications_on') : t('notifications_off'));
  };

  const handleSoundToggle = (checked: boolean) => {
    setSettings({ ...settings, sound: checked });
    alert(checked ? t('sound_on') : t('sound_off'));
  };

  const handleVibrationToggle = (checked: boolean) => {
    setSettings({ ...settings, vibration: checked });
    alert(checked ? t('vibration_on') : t('vibration_off'));
  };

  const handleViewTransactions = () => {
    alert(t('transactions_soon'));
  };

  const toggleFaq = (id: string) => {
    setExpandedFaq(expandedFaq === id ? null : id);
  };

  // Загружаем данные о рефералах
  useEffect(() => {
    const fetchReferralCount = async () => {
      if (user?.id) {
        try {
          const response = await fetch(`/api/referrals/info?telegram_id=${user.id}`);
          if (response.ok) {
            const data = await response.json();
            setReferralCount(data.user?.total_referrals || 0);
          }
        } catch (error) {
          console.log('Error fetching referral count:', error);
        }
      }
    };

    fetchReferralCount();
  }, [user?.id]);

  const scrollToWalletSection = () => {
    walletSectionRef.current?.scrollIntoView({
      behavior: 'smooth',
      block: 'center'
    });
  };

  return (
    <div className="p-4 space-y-6 pb-24">
      {/* User Profile */}
      <Card className="glass-card border-none overflow-hidden relative shadow-md">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 via-purple-500/10 to-pink-500/10 rounded-xl"></div>
        <CardContent className="p-5 relative z-10">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <UserAvatar
                telegramId={user?.id}
                userName={`${user?.first_name || ''} ${user?.last_name || ''}`.trim() || t('user')}
                size="menu"
                className="shadow-lg"
              />
              {user?.is_premium && (
                <div className="absolute -right-1 -top-1 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full p-1.5 flex items-center justify-center shadow-lg">
                  <Crown className="h-3 w-3 text-white" />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-xl bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text truncate">
                {user?.first_name} {user?.last_name}
              </h3>
              <p className="text-sm text-foreground/70 flex items-center space-x-1">
                <span className="truncate">
                  {user?.username ? `@${user.username}` : (user ? `ID: ${user.id}` : "Загрузка...")}
                </span>
              </p>
              {user?.is_premium && (
                <Badge className="mt-1 px-2 py-0.5 bg-gradient-to-r from-yellow-400 to-amber-500 text-white border-none font-medium">
                  <div className="flex items-center space-x-1">
                    <Sparkles className="h-3 w-3" />
                    <span>Premium</span>
                  </div>
                </Badge>
              )}
            </div>
            <div className="text-right min-w-0 flex-shrink-0 w-20">
              <p className="text-sm text-foreground/70">{t('stats')}</p>
              <div className="flex items-center justify-end space-x-1">
                <TrendingUp className="h-4 w-4 text-green-400" />
                <div className="text-right">
                  {loadingStats ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-green-400"></div>
                  ) : (
                    <div>
                      <p className="font-bold text-sm bg-gradient-to-r from-green-400 to-emerald-500 text-transparent bg-clip-text">{winRate}%</p>
                      <p className="text-xs text-foreground/60">{t('winrate')}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Balance */}
      <Card className="glass-card border-none overflow-hidden relative shadow-md">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-purple-500 rounded-t-xl"></div>
        <CardHeader className="pb-2 pt-4">
          <CardTitle className="flex items-center space-x-2">
            <Wallet className="h-5 w-5 text-blue-400" />
            <span>{t('balance_title')}</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* TON Balance */}
          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-white/5 backdrop-blur-sm flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center shadow-md relative overflow-hidden">
                  <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full animate-shimmer"></div>
                  <img src="/images/ton.png" alt="TON" className="h-6 w-6" />
                </div>
                <div>
                  <p className="font-bold text-lg">TON</p>
                  <p className="text-sm text-foreground/70">Toncoin</p>
                </div>
              </div>
              <div className="text-right">
                {loadingBalance ? (
                  <div className="flex items-center space-x-2">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-400"></div>
                    <span className="text-sm text-foreground/70">{t('loading')}</span>
                  </div>
                ) : (
                  <div>
                    <p className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-blue-600 text-transparent bg-clip-text">{balance.TON.toFixed(2)}</p>
                    <p className="text-sm text-foreground/70">≈ ${(balance.TON * exchangeRates.TON_TO_USD).toFixed(2)}</p>
                  </div>
                )}
              </div>
            </div>
            <div className="flex space-x-2">
              <Button
                size="sm"
                className="flex-1 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white border-none shadow-lg hover:shadow-[0_0_20px_rgba(59,130,246,0.4)] transition-all duration-300 relative overflow-hidden group"
                onClick={() => handleDeposit("TON")}
              >
                <div className="absolute inset-0 bg-white/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="flex items-center space-x-2 relative z-10">
                  <Plus className="h-4 w-4" />
                  <span>{t('deposit')}</span>
                </div>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="flex-1 rounded-xl bg-white/5 backdrop-blur-sm border-2 border-blue-500 hover:bg-white/10 hover:border-blue-400"
                onClick={() => handleWithdraw("TON")}
              >
                <div className="flex items-center space-x-2">
                  <Minus className="h-4 w-4" />
                  <span>{t('withdraw')}</span>
                </div>
              </Button>
            </div>
          </div>

          {FEATURES.SHOW_STARS && <Separator className="bg-white/10" />}

          {/* STARS Balance */}
          {FEATURES.SHOW_STARS && (
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-white/5 backdrop-blur-sm flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gradient-to-r from-yellow-500 to-amber-500 rounded-full flex items-center justify-center shadow-md relative overflow-hidden">
                    <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full animate-shimmer"></div>
                    <img src="/images/stars.png" alt="Stars" className="h-6 w-6" />
                  </div>
                  <div>
                    <p className="font-bold text-lg">STARS</p>
                    <p className="text-sm text-foreground/70">Telegram Stars</p>
                  </div>
                </div>
                <div className="text-right">
                  {loadingBalance ? (
                    <div className="flex items-center space-x-2">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-yellow-400"></div>
                      <span className="text-sm text-foreground/70">{t('loading')}</span>
                    </div>
                  ) : (
                    <div>
                      <p className="text-2xl font-bold bg-gradient-to-r from-yellow-400 to-amber-500 text-transparent bg-clip-text">{balance.STARS.toFixed(0)}</p>
                      <p className="text-sm text-foreground/70">≈ ${(balance.STARS * exchangeRates.STARS_TO_USD).toFixed(2)}</p>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex space-x-2">
                <Button
                  size="sm"
                  className="flex-1 rounded-xl bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-600 hover:to-amber-600 text-white border-none shadow-lg hover:shadow-[0_0_20px_rgba(245,158,11,0.4)] transition-all duration-300 relative overflow-hidden group"
                  onClick={() => handleDeposit("STARS")}
                >
                  <div className="absolute inset-0 bg-white/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="flex items-center space-x-2 relative z-10">
                    <Plus className="h-4 w-4" />
                    <span>{t('deposit')}</span>
                  </div>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1 rounded-xl bg-white/5 backdrop-blur-sm border-2 border-yellow-500 hover:bg-white/10 hover:border-yellow-400"
                  onClick={() => handleWithdraw("STARS")}
                >
                  <div className="flex items-center space-x-2">
                    <ArrowRight className="h-4 w-4" />
                    <span>{t('to_ton')}</span>
                  </div>
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Referral Program - СКРЫТО */}
      {false && (
      <Card className="glass-card border-none overflow-hidden relative shadow-md">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 to-pink-500 rounded-t-xl"></div>
        <CardHeader className="pb-2 pt-4">
          <CardTitle className="flex items-center space-x-2">
            <Users className="h-5 w-5 text-purple-400" />
            <span>{t('referral_program_title')}</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-3 rounded-xl bg-white/5 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center shadow-md">
                  <Gift className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="font-bold text-lg">{t('referral_invite_friends')}</p>
                  <p className="text-sm text-foreground/70">{t('referral_earn_commission')}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-foreground/70">{t('referral_count_label')}</p>
                <p className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 text-transparent bg-clip-text">
                  {referralCount}
                </p>
              </div>
            </div>
            <Button
              className="w-full rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white border-none shadow-lg hover:shadow-[0_0_20px_rgba(168,85,247,0.4)] transition-all duration-300"
              onClick={() => setShowReferralModal(true)}
            >
              <div className="flex items-center space-x-2">
                <Users className="h-4 w-4" />
                <span>{t('referral_my_program')}</span>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
      )}

      {/* Settings */}
      <Card className="glass-card border-none overflow-hidden relative shadow-md">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-purple-500 rounded-t-xl"></div>
        <CardHeader className="pb-2 pt-4">
          <CardTitle className="flex items-center space-x-2">
            <Settings className="h-5 w-5 text-blue-400" />
            <span>{t('settings')}</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Language */}
          <div className="p-3 rounded-xl bg-white/5 backdrop-blur-sm flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Globe className="h-5 w-5 text-blue-400" />
              <span>{t('language')}</span>
            </div>
            <div className="flex space-x-2">
              <Button
                variant={lang === "ru" ? "default" : "outline"}
                size="sm"
                onClick={() => handleLanguageChange("ru")}
                className={`rounded-full ${
                  lang === "ru"
                    ? "bg-gradient-to-r from-blue-400 to-purple-500 text-white border-none"
                    : "bg-white/5 backdrop-blur-sm border border-white/10"
                }`}
              >
                {t('lang_ru')}
              </Button>
              <Button
                variant={lang === "en" ? "default" : "outline"}
                size="sm"
                onClick={() => handleLanguageChange("en")}
                className={`rounded-full ${
                  lang === "en"
                    ? "bg-gradient-to-r from-blue-400 to-purple-500 text-white border-none"
                    : "bg-white/5 backdrop-blur-sm border border-white/10"
                }`}
              >
                {t('lang_en')}
              </Button>
            </div>
          </div>

          {/* Notifications and sound/vibration toggles removed as per request */}
        </CardContent>
      </Card>

      {/* FAQ */}
      <Card className="glass-card border-none overflow-hidden relative shadow-md">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-purple-500 rounded-t-xl"></div>
        <CardHeader className="pb-2 pt-4">
          <CardTitle className="flex items-center space-x-2">
            <HelpCircle className="h-5 w-5 text-blue-400" />
            <span>{t('faq_title')}</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* User Guide Button */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0 }}
          >
            <Button
              className="w-full p-4 rounded-xl bg-gradient-to-r from-blue-500/10 to-purple-500/10 hover:from-blue-500/20 hover:to-purple-500/20 border border-blue-500/20 hover:border-blue-500/30 transition-all duration-300 h-auto"
              variant="ghost"
              onClick={() => setShowUserGuide(true)}
            >
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl flex items-center justify-center">
                    <BookOpen className="h-5 w-5 text-white" />
                  </div>
                  <div className="text-left">
                    <h4 className="font-bold text-sm bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text">
                      {t('user_guide_title')}
                    </h4>
                    <p className="text-xs text-foreground/70">
                      {t('user_guide_description')}
                    </p>
                  </div>
                </div>
                <ArrowRight className="h-5 w-5 text-blue-400" />
              </div>
            </Button>
          </motion.div>

          <Separator className="bg-white/10" />

          {faqs.map((faq, index) => (
            <motion.div
              key={faq.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: (index + 1) * 0.05 }}
            >
              <div
                className="border border-white/10 bg-white/5 backdrop-blur-sm rounded-xl overflow-hidden cursor-pointer hover:bg-white/10 transition-colors"
                onClick={() => toggleFaq(faq.id)}
              >
                <div className="p-3 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Bookmark className="h-4 w-4 text-blue-400" />
                    <span className="font-medium text-sm">{faq.question}</span>
                  </div>
                  {expandedFaq === faq.id ? (
                    <ChevronDown className="h-4 w-4 text-foreground/70" />
                  ) : (
                    <ChevronRight className="h-4 w-4 text-foreground/70" />
                  )}
                </div>

                <AnimatePresence>
                  {expandedFaq === faq.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <div className="px-3 pb-3 pt-0">
                        <Separator className="mb-3 bg-white/10" />
                        <p className="text-sm text-foreground/70 leading-relaxed">
                          {faq.answer}
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          ))}
        </CardContent>
      </Card>

      {/* TON Wallet Connection */}
      <Card ref={walletSectionRef} className="glass-card border-none overflow-hidden relative shadow-md">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-purple-500 rounded-t-xl"></div>
        <CardHeader className="pb-2 pt-4">
          <CardTitle className="flex items-center space-x-2">
            <Wallet className="h-5 w-5 text-blue-400" />
            <span>{t('ton_wallet')}</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <TonWalletButton />
        </CardContent>
      </Card>

      {/* TON Top-up Modal */}
      <TonTopUpModal
        isOpen={showTonTopUp}
        onClose={() => {
          setShowTonTopUp(false);
          setTimeout(() => refreshBalance(), 1000);
        }}
        onConnectWallet={scrollToWalletSection}
      />

      {/* TON Withdrawal Modal */}
      <TonWithdrawalModal
        isOpen={showTonWithdrawal}
        onClose={() => {
          setShowTonWithdrawal(false);
          setTimeout(() => refreshBalance(), 1000);
        }}
        currentBalance={balance.TON}
      />

      {/* Stars Top-up Modal */}
      {FEATURES.SHOW_STARS && (
        <StarsTopUpModal
          isOpen={showStarsTopUp}
          onClose={() => {
            setShowStarsTopUp(false);
            setTimeout(() => refreshBalance(), 1000);
          }}
        />
      )}

      {/* Stars to TON Conversion Modal */}
      {FEATURES.SHOW_STARS && (
        <StarsToTonModal
          isOpen={showStarsToTon}
          onClose={() => {
            setShowStarsToTon(false);
            setTimeout(() => refreshBalance(), 1000);
          }}
          userBalance={balance.STARS}
        />
      )}

      {/* User Guide Modal */}
      <UserGuideI18nProvider>
        <UserGuideModal
          open={showUserGuide}
          onOpenChange={setShowUserGuide}
        />
      </UserGuideI18nProvider>

      {/* Referral Modal */}
      <ReferralI18nProvider>
        <ReferralModal
          open={showReferralModal}
          onOpenChange={setShowReferralModal}
        />
      </ReferralI18nProvider>
    </div>
  );
};
