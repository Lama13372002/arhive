import { Client } from 'pg';

export const createDbConnection = () => {
  return new Client({
    connectionString: process.env.DATABASE_URL,
  });
};

// Интерфейсы для сырых данных из PostgreSQL
export interface RawSubscriptionPlan {
  id: number;
  name: string;
  description: string | null;
  price: string; // numeric из PostgreSQL приходит как строка
  currency: string;
  token_amount: number; // Количество токенов в плане
  features: string[]; // jsonb массив строк
  is_active: boolean;
  created_at: string; // timestamp приходит как строка
}

export interface RawUser {
  id: number;
  telegram_id: string; // bigint из PostgreSQL приходит как строка
  username: string | null;
  first_name: string;
  last_name: string | null;
  language_code: string | null;
  is_premium: boolean;
  token_balance: number; // Новое поле для баланса токенов
  selected_model: string | null; // Выбранная модель (gpt-realtime или gpt-realtime-mini)
  created_at: string;
  updated_at: string;
  last_active: string;
}

// Интерфейсы для обработанных данных
export interface User {
  id: number;
  telegram_id: string;
  username?: string;
  first_name: string;
  last_name?: string;
  language_code?: string;
  is_premium: boolean;
  token_balance: number; // Баланс токенов
  selected_model?: string; // Выбранная модель (gpt-realtime или gpt-realtime-mini)
  created_at: Date;
  updated_at: Date;
  last_active: Date;
}

export interface SubscriptionPlan {
  id: number;
  name: string;
  description?: string;
  price: number;
  currency: string;
  token_amount: number; // Количество токенов в плане
  features: string[];
  is_active: boolean;
  created_at: Date;
}

export interface UserSubscription {
  id: number;
  user_id: number;
  plan_id: number;
  start_date: Date;
  end_date: Date;
  status: string;
  payment_id?: string;
  created_at: Date;
  updated_at: Date;
}

// Новый интерфейс для логирования использования токенов
export interface TokenUsage {
  id: number;
  user_id: number;
  session_id: string;
  input_tokens: number;
  output_tokens: number;
  total_tokens: number;
  cost_tokens: number; // Сколько токенов списано с баланса
  // Детализация входных токенов (GPT Realtime API)
  input_text_tokens: number;
  input_audio_tokens: number;
  input_image_tokens: number;
  cached_tokens: number;
  // Детализация выходных токенов (GPT Realtime API)
  output_text_tokens: number;
  output_audio_tokens: number;
  created_at: Date;
}
