<?php
session_start();

// Настройки безопасности
define('ADMIN_PASSWORD_HASH', '$2a$12$NUCzgF08t/9wZdWXx2d60e/EbTgVTKHq6T9/PQh/428lBYO2PUpoy'); // yuMQDm526khGQ7M
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_TIME', 1800); // 30 минут в секундах
define('SESSION_TIMEOUT', 3600); // 1 час
define('LOG_FILE', '../logs/admin_security.log');

class SecurityManager {

    /**
     * Проверка авторизации администратора
     */
    public static function checkAuth() {
        // Проверяем есть ли активная сессия
        if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
            return false;
        }

        // Проверяем время последней активности
        if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > SESSION_TIMEOUT) {
            self::logout();
            return false;
        }

        // Обновляем время последней активности
        $_SESSION['last_activity'] = time();

        return true;
    }

    /**
     * Авторизация администратора
     */
    public static function login($password) {
        $ip = self::getClientIP();

        // Проверяем блокировку IP
        if (self::isIPBlocked($ip)) {
            self::logSecurityEvent('Login attempt from blocked IP', $ip);
            return [
                'success' => false,
                'message' => 'IP адрес заблокирован. Попробуйте позже.',
                'blocked_until' => self::getBlockEndTime($ip)
            ];
        }

        // Проверяем пароль
        if (password_verify($password, ADMIN_PASSWORD_HASH)) {
            // Успешная авторизация
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['last_activity'] = time();
            $_SESSION['login_time'] = time();
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

            // Сбрасываем счетчик неудачных попыток
            self::resetLoginAttempts($ip);

            self::logSecurityEvent('Successful admin login', $ip);

            return ['success' => true, 'message' => 'Авторизация успешна'];
        } else {
            // Неудачная попытка
            self::incrementLoginAttempts($ip);
            $attempts = self::getLoginAttempts($ip);

            self::logSecurityEvent("Failed login attempt #{$attempts}", $ip);

            if ($attempts >= MAX_LOGIN_ATTEMPTS) {
                self::blockIP($ip);
                return [
                    'success' => false,
                    'message' => 'Превышено количество попыток. IP заблокирован.',
                    'blocked_until' => self::getBlockEndTime($ip)
                ];
            }

            $remaining = MAX_LOGIN_ATTEMPTS - $attempts;
            return [
                'success' => false,
                'message' => "Неверный пароль. Осталось попыток: {$remaining}"
            ];
        }
    }

    /**
     * Выход из системы
     */
    public static function logout() {
        $ip = self::getClientIP();
        self::logSecurityEvent('Admin logout', $ip);

        session_destroy();
        session_start();
    }

    /**
     * Проверка CSRF токена
     */
    public static function verifyCSRFToken($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }

    /**
     * Получение CSRF токена
     */
    public static function getCSRFToken() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    /**
     * Получение IP адреса клиента
     */
    private static function getClientIP() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            return $_SERVER['REMOTE_ADDR'];
        }
    }

    /**
     * Увеличение счетчика попыток входа
     */
    private static function incrementLoginAttempts($ip) {
        $file = '../logs/login_attempts.json';
        $attempts = self::getLoginAttemptsData();

        if (!isset($attempts[$ip])) {
            $attempts[$ip] = ['count' => 0, 'last_attempt' => time()];
        }

        $attempts[$ip]['count']++;
        $attempts[$ip]['last_attempt'] = time();

        self::saveLoginAttemptsData($attempts);
    }

    /**
     * Получение количества попыток входа
     */
    private static function getLoginAttempts($ip) {
        $attempts = self::getLoginAttemptsData();
        return isset($attempts[$ip]) ? $attempts[$ip]['count'] : 0;
    }

    /**
     * Сброс попыток входа
     */
    private static function resetLoginAttempts($ip) {
        $attempts = self::getLoginAttemptsData();
        unset($attempts[$ip]);
        self::saveLoginAttemptsData($attempts);
    }

    /**
     * Блокировка IP
     */
    private static function blockIP($ip) {
        $file = '../logs/blocked_ips.json';
        $blocked = self::getBlockedIPsData();

        $blocked[$ip] = time() + LOCKOUT_TIME;

        self::saveBlockedIPsData($blocked);
    }

    /**
     * Проверка блокировки IP
     */
    private static function isIPBlocked($ip) {
        $blocked = self::getBlockedIPsData();

        if (isset($blocked[$ip])) {
            if ($blocked[$ip] > time()) {
                return true;
            } else {
                // Время блокировки истекло
                unset($blocked[$ip]);
                self::saveBlockedIPsData($blocked);
            }
        }

        return false;
    }

    /**
     * Получение времени окончания блокировки
     */
    private static function getBlockEndTime($ip) {
        $blocked = self::getBlockedIPsData();
        return isset($blocked[$ip]) ? date('H:i:s', $blocked[$ip]) : null;
    }

    /**
     * Получение данных о попытках входа
     */
    private static function getLoginAttemptsData() {
        $file = '../logs/login_attempts.json';
        if (file_exists($file)) {
            $data = json_decode(file_get_contents($file), true);
            if ($data) {
                // Очищаем старые записи (старше 24 часов)
                $cutoff = time() - 86400;
                foreach ($data as $ip => $info) {
                    if ($info['last_attempt'] < $cutoff) {
                        unset($data[$ip]);
                    }
                }
                return $data;
            }
        }
        return [];
    }

    /**
     * Сохранение данных о попытках входа
     */
    private static function saveLoginAttemptsData($data) {
        $file = '../logs/login_attempts.json';
        $dir = dirname($file);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
    }

    /**
     * Получение данных о заблокированных IP
     */
    private static function getBlockedIPsData() {
        $file = '../logs/blocked_ips.json';
        if (file_exists($file)) {
            $data = json_decode(file_get_contents($file), true);
            return $data ?: [];
        }
        return [];
    }

    /**
     * Сохранение данных о заблокированных IP
     */
    private static function saveBlockedIPsData($data) {
        $file = '../logs/blocked_ips.json';
        $dir = dirname($file);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
    }

    /**
     * Логирование событий безопасности
     */
    public static function logSecurityEvent($event, $ip = null, $details = '') {
        $ip = $ip ?: self::getClientIP();
        $timestamp = date('Y-m-d H:i:s');
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

        $logEntry = "[{$timestamp}] IP: {$ip} | Event: {$event} | User-Agent: {$userAgent}";
        if ($details) {
            $logEntry .= " | Details: {$details}";
        }
        $logEntry .= PHP_EOL;

        $dir = dirname(LOG_FILE);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        file_put_contents(LOG_FILE, $logEntry, FILE_APPEND | LOCK_EX);
    }

    /**
     * Установка безопасных заголовков
     */
    public static function setSecurityHeaders() {
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('X-XSS-Protection: 1; mode=block');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Content-Security-Policy: default-src \'self\'; script-src \'self\' \'unsafe-inline\'; style-src \'self\' \'unsafe-inline\' https://fonts.googleapis.com; font-src \'self\' https://fonts.gstatic.com; img-src \'self\' data:');
    }

    /**
     * Очистка старых логов (оставляем только последние 30 дней)
     */
    public static function cleanupLogs() {
        $logFiles = [LOG_FILE, '../logs/login_attempts.json', '../logs/blocked_ips.json'];
        $cutoffTime = time() - (30 * 24 * 60 * 60); // 30 дней

        foreach ($logFiles as $file) {
            if (file_exists($file) && filemtime($file) < $cutoffTime) {
                // Для JSON файлов просто очищаем
                if (strpos($file, '.json') !== false) {
                    file_put_contents($file, '{}');
                }
                // Для лог файлов создаем архив или удаляем старые записи
                else {
                    $lines = file($file);
                    $newLines = [];
                    foreach ($lines as $line) {
                        if (preg_match('/\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]/', $line, $matches)) {
                            $lineTime = strtotime($matches[1]);
                            if ($lineTime > $cutoffTime) {
                                $newLines[] = $line;
                            }
                        }
                    }
                    file_put_contents($file, implode('', $newLines));
                }
            }
        }
    }
}

// Автоматическая очистка логов при загрузке (с вероятностью 1%)
if (rand(1, 100) === 1) {
    SecurityManager::cleanupLogs();
}
?>
