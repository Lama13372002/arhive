<?php
require_once __DIR__ . '/config/security.php';

// Устанавливаем безопасные заголовки
SecurityManager::setSecurityHeaders();

// Проверяем авторизацию
if (!SecurityManager::checkAuth()) {
    // Если это AJAX запрос, возвращаем JSON
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        header('Content-Type: application/json');
        http_response_code(401);
        echo json_encode([
            'error' => 'Не авторизован',
            'redirect' => 'login.php'
        ]);
        exit();
    }

    // Иначе перенаправляем на страницу входа
    header('Location: login.php');
    exit();
}

// Проверяем CSRF токен для POST/PUT запросов
if (in_array($_SERVER['REQUEST_METHOD'], ['POST', 'PUT', 'DELETE'])) {
    $csrf_token = null;

    // Получаем CSRF токен из заголовка или POST данных
    if (isset($_SERVER['HTTP_X_CSRF_TOKEN'])) {
        $csrf_token = $_SERVER['HTTP_X_CSRF_TOKEN'];
    } elseif (isset($_POST['csrf_token'])) {
        $csrf_token = $_POST['csrf_token'];
    } else {
        // Для JSON запросов
        $input = file_get_contents('php://input');
        $data = json_decode($input, true);
        if (isset($data['csrf_token'])) {
            $csrf_token = $data['csrf_token'];
        }
    }

    if (!SecurityManager::verifyCSRFToken($csrf_token)) {
        SecurityManager::logSecurityEvent('CSRF token verification failed', null, $_SERVER['REQUEST_URI']);

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            http_response_code(403);
            echo json_encode([
                'error' => 'CSRF токен неверен',
                'csrf_token' => SecurityManager::getCSRFToken()
            ]);
            exit();
        } else {
            header('HTTP/1.1 403 Forbidden');
            echo 'CSRF токен неверен';
            exit();
        }
    }
}

// Логируем доступ к админ панели
if (!isset($_SESSION['access_logged'])) {
    SecurityManager::logSecurityEvent('Admin panel access', null, $_SERVER['REQUEST_URI']);
    $_SESSION['access_logged'] = true;
}
?>
