/**
 * Класс для управления настройками корзины в админ панели
 */
class CartAdminPanel {
    constructor() {
        this.cartSettings = {
            cartVisible: true
        };
        this.init();
    }

    async init() {
        try {
            // Загружаем текущие настройки корзины
            await this.loadCartSettings();

            // Создаем форму
            this.createForm();

            // Привязываем события
            this.bindEvents();

            // Отображаем превью
            this.renderPreview();
        } catch (error) {
            console.error('Ошибка инициализации панели корзины:', error);
            this.showMessage('Ошибка загрузки настроек корзины', 'error');
        }
    }

    async loadCartSettings() {
        try {
            const response = await fetch('../api/cart-settings.php');
            const result = await response.json();

            if (result.success) {
                this.cartSettings = result.data;
            } else {
                throw new Error(result.error || 'Ошибка загрузки настроек');
            }
        } catch (error) {
            console.error('Ошибка загрузки настроек корзины:', error);
            throw error;
        }
    }

    createForm() {
        const container = document.getElementById('cartFormContainer');

        container.innerHTML = `
            <div class="card">
                <div class="card-header">
                    <h2>Настройки корзины</h2>
                    <p>Управление отображением корзины на странице меню</p>
                </div>

                <div class="card-body">
                    <div class="form-group">
                        <label class="switch-label">
                            <span class="switch-text">Отображение корзины</span>
                            <label class="switch">
                                <input type="checkbox" id="cartVisibleToggle" ${this.cartSettings.cartVisible ? 'checked' : ''}>
                                <span class="slider round"></span>
                            </label>
                        </label>
                        <div class="form-help">
                            При выключении корзины:
                            <ul>
                                <li>Круглая кнопка корзины в правом нижнем углу исчезнет</li>
                                <li>Кнопки "Добавить в корзину" в модальных окнах товаров исчезнут</li>
                                <li>Дизайн модальных окон адаптируется (круглая форма)</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    bindEvents() {
        const cartToggle = document.getElementById('cartVisibleToggle');
        if (cartToggle) {
            cartToggle.addEventListener('change', () => {
                this.cartSettings.cartVisible = cartToggle.checked;
                this.renderPreview();
            });
        }
    }

    async saveData() {
        try {
            const response = await fetch('../api/cart-settings.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(this.cartSettings)
            });

            const result = await response.json();

            if (result.success) {
                this.showMessage('Настройки корзины успешно сохранены!', 'success');

                // Обновляем данные из ответа сервера
                if (result.data) {
                    this.cartSettings = result.data;
                }

                return true;
            } else {
                throw new Error(result.error || 'Ошибка сохранения');
            }
        } catch (error) {
            console.error('Ошибка сохранения настроек корзины:', error);
            this.showMessage('Ошибка сохранения настроек: ' + error.message, 'error');
            return false;
        }
    }

    renderPreview() {
        const previewContent = document.getElementById('previewContent');

        const statusText = this.cartSettings.cartVisible ? 'включена' : 'отключена';
        const statusClass = this.cartSettings.cartVisible ? 'status-enabled' : 'status-disabled';

        previewContent.innerHTML = `
            <div class="cart-preview">
                <h4>Текущие настройки корзины</h4>

                <div class="preview-item">
                    <span class="preview-label">Корзина:</span>
                    <span class="preview-value ${statusClass}">${statusText}</span>
                </div>

                <div class="preview-features">
                    <h5>Что изменится на сайте:</h5>
                    ${this.cartSettings.cartVisible ? `
                        <div class="feature enabled">
                            <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
                            </svg>
                            Круглая кнопка корзины отображается
                        </div>
                        <div class="feature enabled">
                            <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
                            </svg>
                            Кнопки "Добавить в корзину" активны
                        </div>
                    ` : `
                        <div class="feature disabled">
                            <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                            </svg>
                            Круглая кнопка корзины скрыта
                        </div>
                        <div class="feature disabled">
                            <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                            </svg>
                            Кнопки "Добавить в корзину" скрыты
                        </div>
                        <div class="feature enabled">
                            <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z"/>
                            </svg>
                            Модальные окна адаптированы (круглая форма)
                        </div>
                    `}
                </div>

                <div class="preview-note">
                    <strong>Внимание:</strong> Изменения применятся после сохранения и обновления страницы меню.
                </div>
            </div>
        `;
    }

    showMessage(message, type = 'info') {
        const statusMessage = document.getElementById('statusMessage');
        statusMessage.textContent = message;
        statusMessage.className = `status-message ${type} show`;

        setTimeout(() => {
            statusMessage.classList.remove('show');
        }, 5000);
    }
}
