class WiFiAdminPanel {
    constructor() {
        this.settings = {};
        this.init();
    }

    init() {
        this.createWiFiInterface();
        this.loadSettings();
    }

    createWiFiInterface() {
        const container = document.getElementById('wifiFormContainer');
        if (!container) return;

        container.innerHTML = `
            <div class="wifi-admin-container">
                <!-- WiFi настройки -->
                <div class="card">
                    <div class="card-header">
                        <h2>📶 WiFi настройки</h2>
                        <p>Управление паролем WiFi для гостей ресторана</p>
                    </div>
                    <div class="card-body">
                        <!-- Текущие настройки WiFi -->
                        <div class="wifi-settings">
                            <div class="form-group">
                                <label for="wifiPassword">Пароль WiFi:</label>
                                <div class="input-group">
                                    <input type="password" id="wifiPassword" class="form-control"
                                           placeholder="Введите новый пароль WiFi" minlength="8">
                                    <button type="button" id="togglePasswordVisibility" class="btn btn-outline">
                                        👁️
                                    </button>
                                </div>
                                <small class="form-text">Минимум 8 символов. Пароль будет отображаться на страницах after-qr.</small>
                            </div>

                            <div class="form-group">
                                <label for="wifiName">Название сети WiFi (SSID):</label>
                                <input type="text" id="wifiName" class="form-control"
                                       placeholder="Например: CallianLounge_Guest">
                                <small class="form-text">Опционально: название сети для отображения гостям</small>
                            </div>

                            <div class="wifi-actions">
                                <button onclick="wifiAdmin.updateWiFiPassword()" class="btn btn-primary">
                                    🔐 Обновить пароль WiFi
                                </button>
                                <button onclick="wifiAdmin.generateRandomPassword()" class="btn btn-secondary">
                                    🎲 Сгенерировать случайный пароль
                                </button>
                            </div>
                        </div>

                        <!-- История изменений -->
                        <div class="wifi-history">
                            <h3>📋 Последние изменения</h3>
                            <div id="historyContainer" class="history-list">
                                <div class="loading">Загрузка истории...</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Предварительный просмотр -->
                <div class="card">
                    <div class="card-header">
                        <h3>👀 Предварительный просмотр</h3>
                        <p>Как будет отображаться пароль на страницах after-qr</p>
                    </div>
                    <div class="card-body">
                        <div id="wifiPreview" class="wifi-preview-block">
                            <!-- Предварительный просмотр будет здесь -->
                        </div>
                    </div>
                </div>
            </div>
        `;

        this.addWiFiStyles();
        this.setupEventListeners();
    }

    addWiFiStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .wifi-admin-container {
                gap: 20px;
                display: flex;
                flex-direction: column;
            }

            .wifi-settings {
                margin-bottom: 30px;
            }

            .input-group {
                display: flex;
                gap: 0;
                align-items: stretch;
            }

            .input-group input {
                border-top-right-radius: 0;
                border-bottom-right-radius: 0;
                border-right: none;
            }

            .input-group button {
                border-top-left-radius: 0;
                border-bottom-left-radius: 0;
                border-left: 1px solid #ddd;
                padding: 0 15px;
                min-width: 50px;
            }

            .wifi-actions {
                display: flex;
                gap: 15px;
                margin-top: 20px;
                flex-wrap: wrap;
            }

            .wifi-history {
                border-top: 1px solid #eee;
                padding-top: 20px;
            }

            .history-list {
                max-height: 200px;
                overflow-y: auto;
            }

            .history-item {
                padding: 10px;
                border-left: 3px solid #007bff;
                background: #f8f9fa;
                margin-bottom: 10px;
                border-radius: 0 6px 6px 0;
            }

            .history-item .time {
                font-size: 12px;
                color: #666;
                float: right;
            }

            .history-item .action {
                font-weight: bold;
                color: #007bff;
            }

            .wifi-preview-block {
                background: linear-gradient(145deg, rgba(239, 231, 210, 0.05), rgba(239, 231, 210, 0.02));
                border: 1px solid rgba(239, 231, 210, 0.2);
                border-radius: 14px;
                padding: 20px;
                color: #333;
            }

            .wifi-preview-block h3 {
                color: #333;
                font-size: 18px;
                margin-bottom: 15px;
                font-weight: 600;
                text-align: center;
            }

            .wifi-preview-block .wifi-password {
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
                font-size: 16px;
                color: #555;
            }

            .wifi-preview-block .wifi-password code {
                background: rgba(239, 231, 210, 0.1);
                padding: 8px 15px;
                border-radius: 8px;
                font-family: 'Courier New', monospace;
                color: #333;
                font-weight: bold;
                border: 1px solid rgba(239, 231, 210, 0.2);
            }

            .loading {
                text-align: center;
                padding: 20px;
                color: #666;
            }

            @media (max-width: 768px) {
                .wifi-actions {
                    flex-direction: column;
                }

                .wifi-actions button {
                    width: 100%;
                }
            }
        `;
        document.head.appendChild(style);
    }

    setupEventListeners() {
        // Переключатель видимости пароля
        document.getElementById('togglePasswordVisibility').addEventListener('click', () => {
            const passwordInput = document.getElementById('wifiPassword');
            const button = document.getElementById('togglePasswordVisibility');

            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                button.textContent = '🙈';
            } else {
                passwordInput.type = 'password';
                button.textContent = '👁️';
            }
        });

        // Обновление предварительного просмотра при вводе
        document.getElementById('wifiPassword').addEventListener('input', () => {
            this.updatePreview();
        });

        document.getElementById('wifiName').addEventListener('input', () => {
            this.updatePreview();
        });
    }

    async loadSettings() {
        try {
            const response = await fetch('../api/settings.php');
            const result = await response.json();

            if (result.success) {
                this.settings = result.data;

                // Заполняем поля
                if (this.settings.wifi_password) {
                    document.getElementById('wifiPassword').value = this.settings.wifi_password.value;
                }

                if (this.settings.wifi_name) {
                    document.getElementById('wifiName').value = this.settings.wifi_name.value;
                }

                this.updatePreview();
                this.loadHistory();
            }
        } catch (error) {
            console.error('Error loading WiFi settings:', error);
            this.showMessage('Ошибка загрузки настроек WiFi', 'error');
        }
    }

    async updateWiFiPassword() {
        const password = document.getElementById('wifiPassword').value.trim();
        const wifiName = document.getElementById('wifiName').value.trim();

        if (!password) {
            this.showMessage('Введите пароль WiFi', 'error');
            return;
        }

        if (password.length < 8) {
            this.showMessage('Пароль должен содержать минимум 8 символов', 'error');
            return;
        }

        try {
            // Обновляем пароль
            const passwordResponse = await fetch('../api/settings.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    key: 'wifi_password',
                    value: password
                })
            });

            const passwordResult = await passwordResponse.json();

            if (!passwordResult.success) {
                throw new Error(passwordResult.error || 'Ошибка обновления пароля');
            }

            // Обновляем название сети (если указано)
            if (wifiName) {
                const nameResponse = await fetch('../api/settings.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        key: 'wifi_name',
                        value: wifiName
                    })
                });

                const nameResult = await nameResponse.json();
                if (!nameResult.success) {
                    console.warn('Warning: Could not update WiFi name:', nameResult.error);
                }
            }

            this.showMessage('Пароль WiFi успешно обновлен!', 'success');
            this.updatePreview();
            this.loadHistory();

        } catch (error) {
            console.error('Error updating WiFi password:', error);
            this.showMessage('Ошибка обновления пароля: ' + error.message, 'error');
        }
    }

    generateRandomPassword() {
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
        let password = '';

        for (let i = 0; i < 12; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
        }

        document.getElementById('wifiPassword').value = password;
        document.getElementById('wifiPassword').type = 'text';
        document.getElementById('togglePasswordVisibility').textContent = '🙈';

        this.updatePreview();
        this.showMessage('Случайный пароль сгенерирован', 'success');
    }

    updatePreview() {
        const password = document.getElementById('wifiPassword').value || 'Loading...';
        const wifiName = document.getElementById('wifiName').value || 'WiFi';

        const previewContainer = document.getElementById('wifiPreview');
        previewContainer.innerHTML = `
            <h3>
                <img src="../images/wifi.svg" alt="WiFi" style="height: 20px; width: auto; margin-right: 8px; vertical-align: middle; filter: brightness(0);">
                ${wifiName} Access
            </h3>
            <div class="wifi-password">
                <span>Password: </span>
                <code>${password}</code>
            </div>
        `;
    }

    async loadHistory() {
        try {
            // Заглушка для истории - можно добавить отдельную таблицу для логов
            const historyContainer = document.getElementById('historyContainer');

            if (this.settings.wifi_password && this.settings.wifi_password.updated_at) {
                historyContainer.innerHTML = `
                    <div class="history-item">
                        <span class="time">${new Date(this.settings.wifi_password.updated_at).toLocaleString('ru')}</span>
                        <div class="action">Пароль WiFi обновлен</div>
                    </div>
                `;
            } else {
                historyContainer.innerHTML = '<div class="loading">История пуста</div>';
            }
        } catch (error) {
            console.error('Error loading history:', error);
        }
    }

    showMessage(message, type = 'info') {
        const statusDiv = document.getElementById('statusMessage');
        if (statusDiv) {
            statusDiv.textContent = message;
            statusDiv.className = `status-message ${type}`;
            statusDiv.style.display = 'block';

            setTimeout(() => {
                statusDiv.style.display = 'none';
            }, 5000);
        }
    }

    renderPreview() {
        this.updatePreview();
    }

    // Метод saveData для совместимости с главной админ панелью
    async saveData() {
        await this.updateWiFiPassword();
    }
}

// Глобальная переменная для доступа из HTML
let wifiAdmin = null;
