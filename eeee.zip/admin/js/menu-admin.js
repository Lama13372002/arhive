class MenuAdminPanel {
    constructor() {
        this.menuData = null;
        this.currentEditingItem = null;
        this.currentEditingCategory = null;
        this.currentLanguage = 'en'; // по умолчанию английский
        this.init();
    }

    async init() {
        await this.loadData();
        this.renderMenuForm();
        this.renderPreview();
        this.bindEvents();
    }

    async loadData() {
        try {
            const timestamp = Date.now();
            const response = await fetch(`../data/menu-data.json?v=${timestamp}&_cache=no`, {
                method: 'GET',
                headers: {
                    'Cache-Control': 'no-cache, no-store, must-revalidate',
                    'Pragma': 'no-cache',
                    'Expires': '0'
                },
                cache: 'no-cache',
                mode: 'cors',
                credentials: 'same-origin'
            });

            if (!response.ok) {
                throw new Error(`Ошибка загрузки данных: ${response.status}`);
            }
            this.menuData = await response.json();
            console.log('📡 Данные меню загружены с сервера');
        } catch (error) {
            console.error('Ошибка загрузки данных меню:', error);

            // Fallback к localStorage
            const localData = localStorage.getItem('menuData');
            if (localData) {
                this.menuData = JSON.parse(localData);
                console.log('⚠️ Данные меню загружены из localStorage');
                this.showMessage('Данные загружены из кэша (сервер недоступен)', 'warning');
                return;
            }

            // Дефолтные данные
            this.showMessage('Ошибка загрузки данных меню', 'error');
            this.menuData = this.getDefaultData();
        }
    }

    getDefaultData() {
        return {
            pageTitle: "Menu",
            hero: {
                backgroundImage: "",
                title: "Menu"
            },
            categories: [
                {
                    id: "maki",
                    name: "Maki",
                    items: []
                }
            ],
            currency: '€' // по умолчанию Евро
        };
    }

    renderMenuForm() {
        const container = document.getElementById('menuFormContainer');
        container.innerHTML = `
            <div class="card">
                <div class="card-header">
                    <h2>Настройка меню</h2>
                    <p>Управление категориями и блюдами ресторана</p>
                    <div class="card-actions">
                        <div class="language-switcher" style="display: inline-block; margin-right: 10px;">
                            <label>Язык редактирования:</label>
                            <button type="button" class="btn ${this.currentLanguage === 'en' ? 'btn-primary' : 'btn-secondary'}" id="langEnBtn">EN</button>
                            <button type="button" class="btn ${this.currentLanguage === 'ru' ? 'btn-primary' : 'btn-secondary'}" id="langRuBtn">RU</button>
                            <button type="button" class="btn ${this.currentLanguage === 'lv' ? 'btn-primary' : 'btn-secondary'}" id="langLvBtn">LV</button>
                        </div>
                        <button type="button" class="btn btn-warning" id="forceUpdateMenuBtn">Принудительно обновить страницу меню</button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="menuPageTitle">Заголовок страницы (EN):</label>
                        <input type="text" id="menuPageTitle" value="${this.menuData.pageTitle}" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="menuPageTitleRu">Заголовок страницы (RU):</label>
                        <input type="text" id="menuPageTitleRu" value="${this.menuData.pageTitleRu || ''}" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="menuPageTitleLv">Заголовок страницы (LV):</label>
                        <input type="text" id="menuPageTitleLv" value="${this.menuData.pageTitleLv || ''}" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="menuHeroTitle">Заголовок героя (EN):</label>
                        <input type="text" id="menuHeroTitle" value="${this.menuData.hero.title}" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="menuHeroTitleRu">Заголовок героя (RU):</label>
                        <input type="text" id="menuHeroTitleRu" value="${this.menuData.hero.titleRu || ''}" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="menuHeroTitleLv">Заголовок героя (LV):</label>
                        <input type="text" id="menuHeroTitleLv" value="${this.menuData.hero.titleLv || ''}" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="menuHeroImage">Фоновое изображение героя (URL):</label>
                        <input type="url" id="menuHeroImage" value="${this.menuData.hero.backgroundImage}" class="form-control" placeholder="https://example.com/image.jpg">
                    </div>

                    <div class="form-group">
                        <label for="menuCurrency">Валюта меню:</label>
                        <select id="menuCurrency" class="form-control">
                            <option value="€" ${(this.menuData.currency || '€') === '€' ? 'selected' : ''}>€ (Евро)</option>
                        </select>
                    </div>

                    <div class="categories-section">
                        <div class="section-header">
                            <h3>Категории меню</h3>
                            <button type="button" class="btn btn-success" id="addCategoryBtn">+ Добавить категорию</button>
                        </div>
                        <div id="categoriesContainer">
                            <!-- Категории будут добавлены динамически -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- Модальное окно для редактирования блюда с двумя ценами -->
            <div id="dualPriceItemModal" class="modal" style="display: none;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 id="dualPriceModalTitle">Добавить блюдо с двумя ценами</h3>
                        <span class="modal-close-dual">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="dualPriceItemName">Название блюда (EN):</label>
                            <input type="text" id="dualPriceItemName" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="dualPriceItemNameRu">Название блюда (RU):</label>
                            <input type="text" id="dualPriceItemNameRu" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="dualPriceItemNameLv">Название блюда (LV):</label>
                            <input type="text" id="dualPriceItemNameLv" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="dualPriceItemDescription">Описание (EN):</label>
                            <textarea id="dualPriceItemDescription" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="dualPriceItemDescriptionRu">Описание (RU):</label>
                            <textarea id="dualPriceItemDescriptionRu" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="dualPriceItemDescriptionLv">Описание (LV):</label>
                            <textarea id="dualPriceItemDescriptionLv" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="dualPriceItemImage">Изображение (URL):</label>
                            <input type="url" id="dualPriceItemImage" class="form-control" placeholder="https://example.com/image.jpg">
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="dualPriceItemSpicy"> Острое блюдо
                            </label>
                        </div>

                        <div style="border-top: 2px solid #ddd; margin: 20px 0; padding-top: 20px;">
                            <h4>Цены</h4>
                            <div class="form-row" style="display: flex; gap: 15px;">
                                <div class="form-group" style="flex: 1;">
                                    <label for="dualPriceItemPrice1">Цена 1:</label>
                                    <input type="text" id="dualPriceItemPrice1" class="form-control" placeholder="$12">
                                </div>
                                <div class="form-group" style="flex: 1;">
                                    <label for="dualPriceItemPrice1Desc">Описание цены 1 (например, "8 шт"):</label>
                                    <input type="text" id="dualPriceItemPrice1Desc" class="form-control" placeholder="8 шт">
                                </div>
                            </div>
                            <div class="form-row" style="display: flex; gap: 15px;">
                                <div class="form-group" style="flex: 1;">
                                    <label for="dualPriceItemPrice2">Цена 2:</label>
                                    <input type="text" id="dualPriceItemPrice2" class="form-control" placeholder="$20">
                                </div>
                                <div class="form-group" style="flex: 1;">
                                    <label for="dualPriceItemPrice2Desc">Описание цены 2 (например, "16 шт"):</label>
                                    <input type="text" id="dualPriceItemPrice2Desc" class="form-control" placeholder="16 шт">
                                </div>
                            </div>

                            <!-- Переводы для описаний цен -->
                            <div class="form-row" style="display: flex; gap: 15px; margin-top: 15px;">
                                <div class="form-group" style="flex: 1;">
                                    <label for="dualPriceItemPrice1DescRu">Описание цены 1 (RU):</label>
                                    <input type="text" id="dualPriceItemPrice1DescRu" class="form-control" placeholder="8 шт">
                                </div>
                                <div class="form-group" style="flex: 1;">
                                    <label for="dualPriceItemPrice2DescRu">Описание цены 2 (RU):</label>
                                    <input type="text" id="dualPriceItemPrice2DescRu" class="form-control" placeholder="16 шт">
                                </div>
                            </div>
                            <div class="form-row" style="display: flex; gap: 15px;">
                                <div class="form-group" style="flex: 1;">
                                    <label for="dualPriceItemPrice1DescLv">Описание цены 1 (LV):</label>
                                    <input type="text" id="dualPriceItemPrice1DescLv" class="form-control" placeholder="8 gab">
                                </div>
                                <div class="form-group" style="flex: 1;">
                                    <label for="dualPriceItemPrice2DescLv">Описание цены 2 (LV):</label>
                                    <input type="text" id="dualPriceItemPrice2DescLv" class="form-control" placeholder="16 gab">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" id="cancelDualPriceItemBtn">Отмена</button>
                        <button type="button" class="btn btn-primary" id="saveDualPriceItemBtn">Сохранить</button>
                    </div>
                </div>
            </div>

            <!-- Модальное окно для редактирования алкогольной карточки -->
            <div id="alcoholItemModal" class="modal" style="display: none;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 id="alcoholModalTitle">Добавить алкогольную карточку</h3>
                        <span class="modal-close-alcohol">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="alcoholItemName">Название напитка (EN):</label>
                            <input type="text" id="alcoholItemName" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="alcoholItemNameRu">Название напитка (RU):</label>
                            <input type="text" id="alcoholItemNameRu" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="alcoholItemNameLv">Название напитка (LV):</label>
                            <input type="text" id="alcoholItemNameLv" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="alcoholItemPrice">Цена (в евро):</label>
                            <input type="text" id="alcoholItemPrice" class="form-control" placeholder="12">
                        </div>
                        <div class="form-group">
                            <label for="alcoholItemVolume">Объем (оставьте пустым, если не нужно указывать):</label>
                            <input type="text" id="alcoholItemVolume" class="form-control" placeholder="40ml">
                            <small class="form-text text-muted">Если объем указан, цена будет слева, объем справа. Если пусто - цена по центру.</small>
                        </div>
                        <div class="form-group">
                            <label for="alcoholItemVolumeRu">Объем (RU):</label>
                            <input type="text" id="alcoholItemVolumeRu" class="form-control" placeholder="40мл">
                        </div>
                        <div class="form-group">
                            <label for="alcoholItemVolumeLv">Объем (LV):</label>
                            <input type="text" id="alcoholItemVolumeLv" class="form-control" placeholder="40ml">
                        </div>
                        <div class="form-group">
                            <label for="alcoholItemDescription">Описание (EN):</label>
                            <textarea id="alcoholItemDescription" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="alcoholItemDescriptionRu">Описание (RU):</label>
                            <textarea id="alcoholItemDescriptionRu" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="alcoholItemDescriptionLv">Описание (LV):</label>
                            <textarea id="alcoholItemDescriptionLv" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="alcoholItemImage">Изображение (URL):</label>
                            <input type="url" id="alcoholItemImage" class="form-control" placeholder="https://example.com/image.jpg">
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="alcoholItemSpicy"> Острый напиток
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" id="cancelAlcoholItemBtn">Отмена</button>
                        <button type="button" class="btn btn-primary" id="saveAlcoholItemBtn">Сохранить</button>
                    </div>
                </div>
            </div>

            <!-- Модальное окно для редактирования блюда -->
            <div id="itemModal" class="modal" style="display: none;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 id="modalTitle">Добавить блюдо</h3>
                        <span class="modal-close">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="itemName">Название блюда (EN):</label>
                            <input type="text" id="itemName" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="itemNameRu">Название блюда (RU):</label>
                            <input type="text" id="itemNameRu" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="itemNameLv">Название блюда (LV):</label>
                            <input type="text" id="itemNameLv" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="itemPrice">Цена:</label>
                            <input type="text" id="itemPrice" class="form-control" placeholder="$12">
                        </div>
                        <div class="form-group">
                            <label for="itemDescription">Описание (EN):</label>
                            <textarea id="itemDescription" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="itemDescriptionRu">Описание (RU):</label>
                            <textarea id="itemDescriptionRu" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="itemDescriptionLv">Описание (LV):</label>
                            <textarea id="itemDescriptionLv" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="itemImage">Изображение (URL):</label>
                            <input type="url" id="itemImage" class="form-control" placeholder="https://example.com/image.jpg">
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="itemSpicy"> Острое блюдо
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" id="cancelItemBtn">Отмена</button>
                        <button type="button" class="btn btn-primary" id="saveItemBtn">Сохранить</button>
                    </div>
                </div>
            </div>
        `;

        this.renderCategories();

        // Добавляем обработчик для кнопки принудительного обновления
        document.getElementById('forceUpdateMenuBtn').addEventListener('click', () => {
            this.forceUpdateMenuPage();
        });
    }

    renderCategories() {
        const container = document.getElementById('categoriesContainer');
        container.innerHTML = '';

        this.menuData.categories.forEach((category, categoryIndex) => {
            const categoryElement = this.createCategoryElement(category, categoryIndex);
            container.appendChild(categoryElement);
        });
    }

    createCategoryElement(category, categoryIndex) {
        const categoryDiv = document.createElement('div');
        categoryDiv.className = 'category-item';
        categoryDiv.innerHTML = `
            <div class="category-header">
                <div class="category-title">
                    <div class="form-group">
                        <label>Название категории (EN):</label>
                        <input type="text" value="${category.name}" class="category-name-input" data-category-index="${categoryIndex}">
                    </div>
                    <div class="form-group">
                        <label>Название категории (RU):</label>
                        <input type="text" value="${category.nameRu || ''}" class="category-name-ru-input" data-category-index="${categoryIndex}">
                    </div>
                    <div class="form-group">
                        <label>Название категории (LV):</label>
                        <input type="text" value="${category.nameLv || ''}" class="category-name-lv-input" data-category-index="${categoryIndex}">
                    </div>
                    <label>
                        <input type="checkbox" class="category-spicy-input" data-category-index="${categoryIndex}" ${category.spicy ? 'checked' : ''}>
                        Острая категория
                    </label>
                </div>
                <div class="category-actions">
                    <button type="button" class="btn btn-sm btn-success add-item-btn" data-category-index="${categoryIndex}">+ Карточка с одной ценой</button>
                    <button type="button" class="btn btn-sm btn-info add-dual-price-item-btn" data-category-index="${categoryIndex}">+ Карточка с двумя ценами</button>
                    <button type="button" class="btn btn-sm btn-warning add-alcohol-item-btn" data-category-index="${categoryIndex}">🍸 Алкогольная карточка</button>
                    <button type="button" class="btn btn-sm btn-danger delete-category-btn" data-category-index="${categoryIndex}">Удалить категорию</button>
                </div>
            </div>
            <div class="items-container" data-category-index="${categoryIndex}">
                ${this.renderItems(category.items, categoryIndex)}
            </div>
        `;

        return categoryDiv;
    }

    renderItems(items, categoryIndex) {
        return items.map((item, itemIndex) => {
            const isDualPrice = item.type === 'dual_price';
            const isAlcohol = item.type === 'alcohol';

            return `
                <div class="item-card ${isDualPrice ? 'dual-price-card' : ''} ${isAlcohol ? 'alcohol-card' : ''}" data-category-index="${categoryIndex}" data-item-index="${itemIndex}">
                    <div class="item-image">
                        <img src="${item.image}" alt="${item.name}" onerror="this.src='data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"100\" height=\"100\"><rect width=\"100\" height=\"100\" fill=\"%23ddd\"/><text x=\"50\" y=\"55\" text-anchor=\"middle\" fill=\"%23999\">No Image</text></svg>'">
                        ${isDualPrice ? '<div class="dual-price-badge">Двойная цена</div>' : ''}
                        ${isAlcohol ? '<div class="alcohol-badge">🍸 Алкоголь</div>' : ''}
                    </div>
                    <div class="item-content">
                        <div class="item-header">
                            <h4>${item.name} ${item.spicy ? '🌶️' : ''}</h4>
                            ${isDualPrice ?
                                `<div class="dual-prices">
                                    <span class="price-1">${this.formatPrice(item.price1)} (${item.price1Desc})</span>
                                    <span class="price-separator">|</span>
                                    <span class="price-2">${this.formatPrice(item.price2)} (${item.price2Desc})</span>
                                </div>` :
                                isAlcohol ?
                                    `<div class="alcohol-price">
                                        <span class="price">${this.formatPrice(item.price)}</span>
                                        ${item.volume ? `<span class="volume">${item.volume}</span>` : ''}
                                    </div>` :
                                    `<span class="item-price">${this.formatPrice(item.price)}</span>`
                            }
                        </div>
                        <p class="item-description">${item.description}</p>
                        <div class="item-actions">
                            <button type="button" class="btn btn-sm btn-primary ${isDualPrice ? 'edit-dual-price-item-btn' : isAlcohol ? 'edit-alcohol-item-btn' : 'edit-item-btn'}" data-category-index="${categoryIndex}" data-item-index="${itemIndex}">Редактировать</button>
                            <button type="button" class="btn btn-sm btn-danger delete-item-btn" data-category-index="${categoryIndex}" data-item-index="${itemIndex}">Удалить</button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    bindEvents() {
        // Переключатели языков
        document.getElementById('langEnBtn').addEventListener('click', () => this.switchLanguage('en'));
        document.getElementById('langRuBtn').addEventListener('click', () => this.switchLanguage('ru'));
        document.getElementById('langLvBtn').addEventListener('click', () => this.switchLanguage('lv'));

        // Основные поля формы
        document.getElementById('menuPageTitle').addEventListener('input', () => this.updateData());
        document.getElementById('menuPageTitleRu').addEventListener('input', () => this.updateData());
        document.getElementById('menuPageTitleLv').addEventListener('input', () => this.updateData());
        document.getElementById('menuHeroTitle').addEventListener('input', () => this.updateData());
        document.getElementById('menuHeroTitleRu').addEventListener('input', () => this.updateData());
        document.getElementById('menuHeroTitleLv').addEventListener('input', () => this.updateData());
        document.getElementById('menuHeroImage').addEventListener('input', () => this.updateData());
        document.getElementById('menuCurrency').addEventListener('change', () => this.updateData());

        // Добавление категории
        document.getElementById('addCategoryBtn').addEventListener('click', () => this.addCategory());

        // Делегирование событий для динамических элементов
        document.getElementById('categoriesContainer').addEventListener('click', (e) => {
            const categoryIndex = e.target.dataset.categoryIndex;
            const itemIndex = e.target.dataset.itemIndex;

            if (e.target.classList.contains('add-item-btn')) {
                this.openItemModal(parseInt(categoryIndex));
            } else if (e.target.classList.contains('add-dual-price-item-btn')) {
                this.openDualPriceItemModal(parseInt(categoryIndex));
            } else if (e.target.classList.contains('add-alcohol-item-btn')) {
                this.openAlcoholItemModal(parseInt(categoryIndex));
            } else if (e.target.classList.contains('edit-item-btn')) {
                this.openItemModal(parseInt(categoryIndex), parseInt(itemIndex));
            } else if (e.target.classList.contains('edit-dual-price-item-btn')) {
                this.openDualPriceItemModal(parseInt(categoryIndex), parseInt(itemIndex));
            } else if (e.target.classList.contains('edit-alcohol-item-btn')) {
                this.openAlcoholItemModal(parseInt(categoryIndex), parseInt(itemIndex));
            } else if (e.target.classList.contains('delete-item-btn')) {
                this.deleteItem(parseInt(categoryIndex), parseInt(itemIndex));
            } else if (e.target.classList.contains('delete-category-btn')) {
                this.deleteCategory(parseInt(categoryIndex));
            }
        });

        // События для изменения названий категорий
        document.getElementById('categoriesContainer').addEventListener('input', (e) => {
            if (e.target.classList.contains('category-name-input')) {
                const categoryIndex = parseInt(e.target.dataset.categoryIndex);
                this.menuData.categories[categoryIndex].name = e.target.value;
                this.renderPreview();
            } else if (e.target.classList.contains('category-name-ru-input')) {
                const categoryIndex = parseInt(e.target.dataset.categoryIndex);
                this.menuData.categories[categoryIndex].nameRu = e.target.value;
                this.renderPreview();
            } else if (e.target.classList.contains('category-name-lv-input')) {
                const categoryIndex = parseInt(e.target.dataset.categoryIndex);
                this.menuData.categories[categoryIndex].nameLv = e.target.value;
                this.renderPreview();
            } else if (e.target.classList.contains('category-spicy-input')) {
                const categoryIndex = parseInt(e.target.dataset.categoryIndex);
                this.menuData.categories[categoryIndex].spicy = e.target.checked;
                this.renderPreview();
            }
        });

        // Модальное окно
        document.getElementById('cancelItemBtn').addEventListener('click', () => this.closeItemModal());
        document.getElementById('saveItemBtn').addEventListener('click', () => this.saveItem());
        document.querySelector('.modal-close').addEventListener('click', () => this.closeItemModal());

        // Модальное окно для двойных цен
        document.getElementById('cancelDualPriceItemBtn').addEventListener('click', () => this.closeDualPriceItemModal());
        document.getElementById('saveDualPriceItemBtn').addEventListener('click', () => this.saveDualPriceItem());
        document.querySelector('.modal-close-dual').addEventListener('click', () => this.closeDualPriceItemModal());

        // Модальное окно для алкогольных карточек
        document.getElementById('cancelAlcoholItemBtn').addEventListener('click', () => this.closeAlcoholItemModal());
        document.getElementById('saveAlcoholItemBtn').addEventListener('click', () => this.saveAlcoholItem());
        document.querySelector('.modal-close-alcohol').addEventListener('click', () => this.closeAlcoholItemModal());

        // Закрытие модального окна по клику вне его
        document.getElementById('itemModal').addEventListener('click', (e) => {
            if (e.target.id === 'itemModal') {
                this.closeItemModal();
            }
        });

        // Закрытие модального окна для двойных цен по клику вне его
        document.getElementById('dualPriceItemModal').addEventListener('click', (e) => {
            if (e.target.id === 'dualPriceItemModal') {
                this.closeDualPriceItemModal();
            }
        });

        // Закрытие модального окна для алкогольных карточек по клику вне его
        document.getElementById('alcoholItemModal').addEventListener('click', (e) => {
            if (e.target.id === 'alcoholItemModal') {
                this.closeAlcoholItemModal();
            }
        });
    }

    updateData() {
        this.menuData.pageTitle = document.getElementById('menuPageTitle').value;
        this.menuData.pageTitleRu = document.getElementById('menuPageTitleRu').value;
        this.menuData.pageTitleLv = document.getElementById('menuPageTitleLv').value;
        this.menuData.hero.title = document.getElementById('menuHeroTitle').value;
        this.menuData.hero.titleRu = document.getElementById('menuHeroTitleRu').value;
        this.menuData.hero.titleLv = document.getElementById('menuHeroTitleLv').value;
        this.menuData.hero.backgroundImage = document.getElementById('menuHeroImage').value;
        this.menuData.currency = document.getElementById('menuCurrency').value;
        this.renderPreview();
    }

    addCategory() {
        // Генерируем уникальный ID, основанный на текущем времени и случайности
        const timestamp = Date.now();
        const randomPart = Math.floor(Math.random() * 10000);
        const uniqueId = `category-${timestamp}-${randomPart}`;

        // Создаем базовое название категории на основе количества существующих категорий
        let categoryNumber = this.menuData.categories.length + 1;
        let categoryName = `Новая категория ${categoryNumber}`;

        // Проверяем, не существует ли уже категория с таким названием
        while (this.menuData.categories.some(cat => cat.name === categoryName)) {
            categoryNumber++;
            categoryName = `Новая категория ${categoryNumber}`;
        }

        const newCategory = {
            id: uniqueId,
            name: categoryName,
            nameRu: `Новая категория ${categoryNumber}`,
            nameLv: `Jauna kategorija ${categoryNumber}`,
            items: []
        };

        this.menuData.categories.push(newCategory);
        this.renderCategories();
        this.renderPreview();

        // Показываем уведомление об успешном добавлении категории
        this.showMessage(`Категория "${categoryName}" успешно добавлена`, 'success');

        // Автоматически раскрываем новую категорию для редактирования
        setTimeout(() => {
            const newCategoryElement = document.querySelector(`.category-item[data-category-index="${this.menuData.categories.length - 1}"]`);
            if (newCategoryElement) {
                newCategoryElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                const categoryNameInput = newCategoryElement.querySelector('.category-name-input');
                if (categoryNameInput) {
                    categoryNameInput.focus();
                    categoryNameInput.select();
                }
            }
        }, 100);
    }

    deleteCategory(categoryIndex) {
        // Получаем название категории для подтверждения
        const categoryName = this.menuData.categories[categoryIndex]?.name || `Категория ${categoryIndex + 1}`;

        if (confirm(`Вы уверены, что хотите удалить категорию "${categoryName}" и все блюда в ней?`)) {
            // Удаляем категорию из массива
            this.menuData.categories.splice(categoryIndex, 1);

            // Обновляем интерфейс
            this.renderCategories();
            this.renderPreview();

            // Если все категории удалены, показываем сообщение
            if (this.menuData.categories.length === 0) {
                this.showMessage('Все категории удалены. Для добавления новой категории нажмите "Добавить категорию"', 'info');

                // Обновляем превью с пустым содержимым
                const previewContent = document.getElementById('previewContent');
                if (previewContent) {
                    previewContent.innerHTML = `
                        <div class="preview-empty">
                            <p>В меню нет категорий. Добавьте новую категорию.</p>
                        </div>
                    `;
                }
            } else {
                // Показываем сообщение об успешном удалении
                this.showMessage(`Категория "${categoryName}" успешно удалена`, 'success');
            }

            // Автоматически сохраняем данные после удаления категории
            this.saveData();
        }
    }

    openItemModal(categoryIndex, itemIndex = null) {
        this.currentEditingCategory = categoryIndex;
        this.currentEditingItem = itemIndex;

        const modal = document.getElementById('itemModal');
        const title = document.getElementById('modalTitle');

        if (itemIndex !== null) {
            // Редактирование существующего блюда
            const item = this.menuData.categories[categoryIndex].items[itemIndex];
            title.textContent = 'Редактировать блюдо';
            document.getElementById('itemName').value = item.name;
            document.getElementById('itemNameRu').value = item.nameRu || '';
            document.getElementById('itemNameLv').value = item.nameLv || '';
            document.getElementById('itemPrice').value = item.price;
            document.getElementById('itemDescription').value = item.description;
            document.getElementById('itemDescriptionRu').value = item.descriptionRu || '';
            document.getElementById('itemDescriptionLv').value = item.descriptionLv || '';
            document.getElementById('itemImage').value = item.image;
            document.getElementById('itemSpicy').checked = item.spicy || false;
        } else {
            // Добавление нового блюда
            title.textContent = 'Добавить блюдо';
            document.getElementById('itemName').value = '';
            document.getElementById('itemNameRu').value = '';
            document.getElementById('itemNameLv').value = '';
            document.getElementById('itemPrice').value = '';
            document.getElementById('itemDescription').value = '';
            document.getElementById('itemDescriptionRu').value = '';
            document.getElementById('itemDescriptionLv').value = '';
            document.getElementById('itemImage').value = '';
            document.getElementById('itemSpicy').checked = false;
        }

        modal.style.display = 'block';
    }

    closeItemModal() {
        document.getElementById('itemModal').style.display = 'none';
        this.currentEditingCategory = null;
        this.currentEditingItem = null;
    }

    saveItem() {
        const name = document.getElementById('itemName').value.trim();
        const nameRu = document.getElementById('itemNameRu').value.trim();
        const nameLv = document.getElementById('itemNameLv').value.trim();
        const price = document.getElementById('itemPrice').value.trim();
        const description = document.getElementById('itemDescription').value.trim();
        const descriptionRu = document.getElementById('itemDescriptionRu').value.trim();
        const descriptionLv = document.getElementById('itemDescriptionLv').value.trim();
        const image = document.getElementById('itemImage').value.trim();
        const spicy = document.getElementById('itemSpicy').checked;

        if (!name || !price) {
            alert('Пожалуйста, заполните обязательные поля: название и цену');
            return;
        }

        const itemData = {
            id: this.currentEditingItem !== null ?
                this.menuData.categories[this.currentEditingCategory].items[this.currentEditingItem].id :
                `item-${Date.now()}`,
            name,
            nameRu,
            nameLv,
            price,
            description,
            descriptionRu,
            descriptionLv,
            image: image,
            spicy
        };

        if (this.currentEditingItem !== null) {
            // Обновление существующего блюда
            this.menuData.categories[this.currentEditingCategory].items[this.currentEditingItem] = itemData;
        } else {
            // Добавление нового блюда
            this.menuData.categories[this.currentEditingCategory].items.push(itemData);
        }

        this.closeItemModal();
        this.renderCategories();
        this.renderPreview();
    }

    deleteItem(categoryIndex, itemIndex) {
        if (confirm('Вы уверены, что хотите удалить это блюдо?')) {
            this.menuData.categories[categoryIndex].items.splice(itemIndex, 1);
            this.renderCategories();
            this.renderPreview();
        }
    }

    openDualPriceItemModal(categoryIndex, itemIndex = null) {
        this.currentEditingCategory = categoryIndex;
        this.currentEditingItem = itemIndex;

        const modal = document.getElementById('dualPriceItemModal');
        const title = document.getElementById('dualPriceModalTitle');

        if (itemIndex !== null) {
            // Редактирование существующего блюда с двумя ценами
            const item = this.menuData.categories[categoryIndex].items[itemIndex];
            title.textContent = 'Редактировать блюдо с двумя ценами';
            document.getElementById('dualPriceItemName').value = item.name;
            document.getElementById('dualPriceItemNameRu').value = item.nameRu || '';
            document.getElementById('dualPriceItemNameLv').value = item.nameLv || '';
            document.getElementById('dualPriceItemDescription').value = item.description;
            document.getElementById('dualPriceItemDescriptionRu').value = item.descriptionRu || '';
            document.getElementById('dualPriceItemDescriptionLv').value = item.descriptionLv || '';
            document.getElementById('dualPriceItemImage').value = item.image;
            document.getElementById('dualPriceItemSpicy').checked = item.spicy || false;
            document.getElementById('dualPriceItemPrice1').value = item.price1 || '';
            document.getElementById('dualPriceItemPrice1Desc').value = item.price1Desc || '';
            document.getElementById('dualPriceItemPrice2').value = item.price2 || '';
            document.getElementById('dualPriceItemPrice2Desc').value = item.price2Desc || '';
            document.getElementById('dualPriceItemPrice1DescRu').value = item.price1DescRu || '';
            document.getElementById('dualPriceItemPrice2DescRu').value = item.price2DescRu || '';
            document.getElementById('dualPriceItemPrice1DescLv').value = item.price1DescLv || '';
            document.getElementById('dualPriceItemPrice2DescLv').value = item.price2DescLv || '';
        } else {
            // Добавление нового блюда с двумя ценами
            title.textContent = 'Добавить блюдо с двумя ценами';
            document.getElementById('dualPriceItemName').value = '';
            document.getElementById('dualPriceItemNameRu').value = '';
            document.getElementById('dualPriceItemNameLv').value = '';
            document.getElementById('dualPriceItemDescription').value = '';
            document.getElementById('dualPriceItemDescriptionRu').value = '';
            document.getElementById('dualPriceItemDescriptionLv').value = '';
            document.getElementById('dualPriceItemImage').value = '';
            document.getElementById('dualPriceItemSpicy').checked = false;
            document.getElementById('dualPriceItemPrice1').value = '';
            document.getElementById('dualPriceItemPrice1Desc').value = '';
            document.getElementById('dualPriceItemPrice2').value = '';
            document.getElementById('dualPriceItemPrice2Desc').value = '';
            document.getElementById('dualPriceItemPrice1DescRu').value = '';
            document.getElementById('dualPriceItemPrice2DescRu').value = '';
            document.getElementById('dualPriceItemPrice1DescLv').value = '';
            document.getElementById('dualPriceItemPrice2DescLv').value = '';
        }

        modal.style.display = 'block';
    }

    closeDualPriceItemModal() {
        document.getElementById('dualPriceItemModal').style.display = 'none';
        this.currentEditingCategory = null;
        this.currentEditingItem = null;
    }

    saveDualPriceItem() {
        const name = document.getElementById('dualPriceItemName').value.trim();
        const nameRu = document.getElementById('dualPriceItemNameRu').value.trim();
        const nameLv = document.getElementById('dualPriceItemNameLv').value.trim();
        const description = document.getElementById('dualPriceItemDescription').value.trim();
        const descriptionRu = document.getElementById('dualPriceItemDescriptionRu').value.trim();
        const descriptionLv = document.getElementById('dualPriceItemDescriptionLv').value.trim();
        const image = document.getElementById('dualPriceItemImage').value.trim();
        const spicy = document.getElementById('dualPriceItemSpicy').checked;
        const price1 = document.getElementById('dualPriceItemPrice1').value.trim();
        const price1Desc = document.getElementById('dualPriceItemPrice1Desc').value.trim();
        const price2 = document.getElementById('dualPriceItemPrice2').value.trim();
        const price2Desc = document.getElementById('dualPriceItemPrice2Desc').value.trim();
        const price1DescRu = document.getElementById('dualPriceItemPrice1DescRu').value.trim();
        const price2DescRu = document.getElementById('dualPriceItemPrice2DescRu').value.trim();
        const price1DescLv = document.getElementById('dualPriceItemPrice1DescLv').value.trim();
        const price2DescLv = document.getElementById('dualPriceItemPrice2DescLv').value.trim();

        if (!name || !price1 || !price2 || !price1Desc || !price2Desc) {
            alert('Пожалуйста, заполните все обязательные поля (название и цены)');
            return;
        }

        const itemData = {
            id: this.currentEditingItem !== null ?
                this.menuData.categories[this.currentEditingCategory].items[this.currentEditingItem].id :
                `dual-item-${Date.now()}`,
            type: 'dual_price',
            name,
            nameRu,
            nameLv,
            description,
            descriptionRu,
            descriptionLv,
            image: image,
            spicy,
            price1,
            price1Desc,
            price2,
            price2Desc,
            price1DescRu,
            price2DescRu,
            price1DescLv,
            price2DescLv
        };

        if (this.currentEditingItem !== null) {
            // Обновление существующего блюда
            this.menuData.categories[this.currentEditingCategory].items[this.currentEditingItem] = itemData;
        } else {
            // Добавление нового блюда
            this.menuData.categories[this.currentEditingCategory].items.push(itemData);
        }

        this.closeDualPriceItemModal();
        this.renderCategories();
        this.renderPreview();
    }

    openAlcoholItemModal(categoryIndex, itemIndex = null) {
        this.currentEditingCategory = categoryIndex;
        this.currentEditingItem = itemIndex;

        const modal = document.getElementById('alcoholItemModal');
        const title = document.getElementById('alcoholModalTitle');

        if (itemIndex !== null) {
            // Редактирование существующей алкогольной карточки
            const item = this.menuData.categories[categoryIndex].items[itemIndex];
            title.textContent = 'Редактировать алкогольную карточку';
            document.getElementById('alcoholItemName').value = item.name;
            document.getElementById('alcoholItemNameRu').value = item.nameRu || '';
            document.getElementById('alcoholItemNameLv').value = item.nameLv || '';
            document.getElementById('alcoholItemPrice').value = item.price;
            document.getElementById('alcoholItemVolume').value = item.volume || '';
            document.getElementById('alcoholItemVolumeRu').value = item.volumeRu || '';
            document.getElementById('alcoholItemVolumeLv').value = item.volumeLv || '';
            document.getElementById('alcoholItemDescription').value = item.description;
            document.getElementById('alcoholItemDescriptionRu').value = item.descriptionRu || '';
            document.getElementById('alcoholItemDescriptionLv').value = item.descriptionLv || '';
            document.getElementById('alcoholItemImage').value = item.image;
            document.getElementById('alcoholItemSpicy').checked = item.spicy || false;
        } else {
            // Добавление новой алкогольной карточки
            title.textContent = 'Добавить алкогольную карточку';
            document.getElementById('alcoholItemName').value = '';
            document.getElementById('alcoholItemNameRu').value = '';
            document.getElementById('alcoholItemNameLv').value = '';
            document.getElementById('alcoholItemPrice').value = '';
            document.getElementById('alcoholItemVolume').value = '';
            document.getElementById('alcoholItemVolumeRu').value = '';
            document.getElementById('alcoholItemVolumeLv').value = '';
            document.getElementById('alcoholItemDescription').value = '';
            document.getElementById('alcoholItemDescriptionRu').value = '';
            document.getElementById('alcoholItemDescriptionLv').value = '';
            document.getElementById('alcoholItemImage').value = '';
            document.getElementById('alcoholItemSpicy').checked = false;
        }

        modal.style.display = 'block';
    }

    closeAlcoholItemModal() {
        document.getElementById('alcoholItemModal').style.display = 'none';
        this.currentEditingCategory = null;
        this.currentEditingItem = null;
    }

    saveAlcoholItem() {
        const name = document.getElementById('alcoholItemName').value.trim();
        const nameRu = document.getElementById('alcoholItemNameRu').value.trim();
        const nameLv = document.getElementById('alcoholItemNameLv').value.trim();
        const price = document.getElementById('alcoholItemPrice').value.trim();
        const volume = document.getElementById('alcoholItemVolume').value.trim();
        const volumeRu = document.getElementById('alcoholItemVolumeRu').value.trim();
        const volumeLv = document.getElementById('alcoholItemVolumeLv').value.trim();
        const description = document.getElementById('alcoholItemDescription').value.trim();
        const descriptionRu = document.getElementById('alcoholItemDescriptionRu').value.trim();
        const descriptionLv = document.getElementById('alcoholItemDescriptionLv').value.trim();
        const image = document.getElementById('alcoholItemImage').value.trim();
        const spicy = document.getElementById('alcoholItemSpicy').checked;

        if (!name || !price) {
            alert('Пожалуйста, заполните обязательные поля: название и цену');
            return;
        }

        const itemData = {
            id: this.currentEditingItem !== null ?
                this.menuData.categories[this.currentEditingCategory].items[this.currentEditingItem].id :
                `alcohol-item-${Date.now()}`,
            type: 'alcohol',
            name,
            nameRu,
            nameLv,
            price,
            volume,
            volumeRu,
            volumeLv,
            description,
            descriptionRu,
            descriptionLv,
            image: image,
            spicy
        };

        if (this.currentEditingItem !== null) {
            // Обновление существующей алкогольной карточки
            this.menuData.categories[this.currentEditingCategory].items[this.currentEditingItem] = itemData;
        } else {
            // Добавление новой алкогольной карточки
            this.menuData.categories[this.currentEditingCategory].items.push(itemData);
        }

        this.closeAlcoholItemModal();
        this.renderCategories();
        this.renderPreview();
    }

    renderPreview() {
        const previewContent = document.getElementById('previewContent');
        let previewHTML = `
            <div class="menu-preview">
                <div class="preview-hero">
                    <h2>${this.menuData.hero.title}</h2>
                    ${this.menuData.hero.backgroundImage ? `<img src="${this.menuData.hero.backgroundImage}" alt="Hero" style="max-width: 200px;">` : ''}
                </div>
        `;

        this.menuData.categories.forEach(category => {
            previewHTML += `
                <div class="preview-category">
                    <h3>${category.name} ${category.spicy ? '🌶️' : ''}</h3>
                    <div class="preview-items">
            `;

            category.items.forEach(item => {
                const isDualPrice = item.type === 'dual_price';
                const isAlcohol = item.type === 'alcohol';
                previewHTML += `
                    <div class="preview-item ${isDualPrice ? 'dual-price-preview' : ''} ${isAlcohol ? 'alcohol-preview' : ''}">
                        <div class="preview-item-image">
                            <img src="${item.image}" alt="${item.name}" style="width: 60px; height: 60px; object-fit: cover; border-radius: 4px;">
                            ${isDualPrice ? '<span style="position: absolute; top: 2px; right: 2px; background: #3b82f6; color: white; font-size: 8px; padding: 1px 3px; border-radius: 3px;">2️⃣</span>' : ''}
                            ${isAlcohol ? '<span style="position: absolute; top: 2px; right: 2px; background: #d4af37; color: #1a1a1a; font-size: 8px; padding: 1px 3px; border-radius: 3px;">🍸</span>' : ''}
                        </div>
                        <div class="preview-item-content">
                            <div class="preview-item-header">
                                <span class="preview-item-name">${item.name} ${item.spicy ? '🌶️' : ''}</span>
                                ${isDualPrice ?
                                    `<span class="preview-item-price">${this.formatPrice(item.price1)} (${item.price1Desc}) | ${this.formatPrice(item.price2)} (${item.price2Desc})</span>` :
                                    isAlcohol ?
                                        `<span class="preview-item-price">${this.formatPrice(item.price)}${item.volume ? ` | ${item.volume}` : ''}</span>` :
                                        `<span class="preview-item-price">${this.formatPrice(item.price)}</span>`
                                }
                            </div>
                            <p class="preview-item-description">${item.description}</p>
                        </div>
                    </div>
                `;
            });

            previewHTML += `
                    </div>
                </div>
            `;
        });

        previewHTML += '</div>';
        previewContent.innerHTML = previewHTML;
    }

    async saveData() {
        try {
            let serverSaved = false;
            let errorMessage = '';

            // Добавляем CSRF токен в данные (выносим наверх)
            const dataWithToken = {
                ...this.menuData,
                csrf_token: window.csrfToken
            };

            // ПРИОРИТЕТ: пытаемся сохранить на сервере с улучшенными настройками
            try {

                const response = await fetch('save-menu-data.php', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Cache-Control': 'no-cache',
                        'X-CSRF-Token': window.csrfToken
                    },
                    body: JSON.stringify(dataWithToken, null, 2),
                    cache: 'no-cache',
                    credentials: 'same-origin'
                });

                if (response.ok) {
                    const result = await response.json();
                    serverSaved = true;
                    console.log('✅ Данные меню сохранены на сервере:', result);
                } else {
                    const errorData = await response.text();
                    errorMessage = `Ошибка сервера: ${response.status}`;
                    console.log('❌ Ошибка сохранения на сервере:', errorData);
                }
            } catch (error) {
                errorMessage = 'Сервер недоступен или проблемы с подключением';
                console.log('⚠️ Ошибка подключения:', error);

                // Дополнительная попытка с другими настройками
                try {
                    console.log('🔄 Пытаемся повторить запрос...');
                    const retryResponse = await fetch('save-menu-data.php', {
                        method: 'POST', // Пробуем POST вместо PUT
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-Token': window.csrfToken
                        },
                        body: JSON.stringify(dataWithToken, null, 2)
                    });

                    if (retryResponse.ok) {
                        const result = await retryResponse.json();
                        serverSaved = true;
                        console.log('✅ Данные меню сохранены на сервере (повторная попытка):', result);
                    }
                } catch (retryError) {
                    console.log('❌ Повторная попытка не удалась:', retryError);
                }
            }

            if (serverSaved) {
                // Если успешно сохранили на сервере, также сохраняем в localStorage как кэш
                localStorage.setItem('menuData', JSON.stringify(this.menuData));
                this.notifyAllChannels();
                this.showMessage('✅ Данные меню успешно сохранены на сервере!', 'success');
                console.log('🔄 Данные меню отправлены на страницу (все методы)');
            } else {
                // Если сервер недоступен, сохраняем локально как резерв
                localStorage.setItem('menuData', JSON.stringify(this.menuData));
                this.notifyAllChannels();
                this.showMessage(`⚠️ ${errorMessage}. Данные сохранены локально.`, 'warning');
                console.log('📁 Файл menu-data.json скачан');
            }

            // Обновляем предпросмотр
            this.renderPreview();
            return serverSaved;

        } catch (error) {
            console.error('Ошибка сохранения:', error);

            // В крайнем случае сохраняем хотя бы локально
            localStorage.setItem('menuData', JSON.stringify(this.menuData));
            this.notifyAllChannels();
            this.showMessage('❌ Ошибка сохранения. Данные сохранены локально.', 'error');
            this.renderPreview();
            return false;
        }
    }

    notifyAllChannels() {
        try {
            // 1. Используем localStorage для передачи данных между вкладками
            const timestamp = Date.now();
            localStorage.setItem('menuDataTimestamp', timestamp.toString());

            // 2. Используем postMessage для всех открытых фреймов с меню
            this.notifyViaPostMessage();

            // 3. Используем BroadcastChannel API если доступен
            this.notifyViaBroadcastChannel();

            // 4. Вызываем специальное событие для страниц в том же окне
            this.notifyViaCustomEvent();

            console.log('🔄 Отправлены уведомления об изменениях по всем каналам');
        } catch (error) {
            console.error('Ошибка при отправке уведомлений:', error);
        }
    }

    notifyViaPostMessage() {
        try {
            // Находим все фреймы на странице
            const iframes = document.querySelectorAll('iframe');
            iframes.forEach(iframe => {
                try {
                    iframe.contentWindow.postMessage({
                        type: 'menuDataUpdate',
                        data: this.menuData,
                        source: 'admin-panel',
                        timestamp: Date.now()
                    }, '*');
                } catch (frameError) {
                    console.log('Не удалось отправить сообщение фрейму:', frameError);
                }
            });

            // Также отправляем сообщение родительскому окну, если мы во фрейме
            if (window.parent !== window) {
                window.parent.postMessage({
                    type: 'menuDataUpdate',
                    data: this.menuData,
                    source: 'admin-panel',
                    timestamp: Date.now()
                }, '*');
            }

            // И всем открытым окнам меню
            if (window.opener) {
                window.opener.postMessage({
                    type: 'menuDataUpdate',
                    data: this.menuData,
                    source: 'admin-panel',
                    timestamp: Date.now()
                }, '*');
            }
        } catch (error) {
            console.error('Ошибка при отправке postMessage:', error);
        }
    }

    notifyViaBroadcastChannel() {
        try {
            if (typeof BroadcastChannel !== 'undefined') {
                const channel = new BroadcastChannel('menuUpdates');
                channel.postMessage({
                    type: 'menuDataUpdate',
                    data: this.menuData,
                    source: 'admin-panel',
                    timestamp: Date.now()
                });

                // Закрываем канал после отправки сообщения
                setTimeout(() => {
                    channel.close();
                }, 1000);
            }
        } catch (error) {
            console.log('BroadcastChannel не поддерживается в этом браузере:', error);
        }
    }

    notifyViaCustomEvent() {
        try {
            // Создаем и диспатчим кастомное событие
            const event = new CustomEvent('menuDataForceUpdate', {
                detail: {
                    data: this.menuData,
                    source: 'admin-panel',
                    timestamp: Date.now()
                }
            });
            window.dispatchEvent(event);

            // Если есть доступная страница меню в этом же документе
            document.querySelectorAll('[data-menu-container]').forEach(container => {
                container.dispatchEvent(event);
            });
        } catch (error) {
            console.error('Ошибка при отправке CustomEvent:', error);
        }
    }

    showMessage(text, type) {
        const messageEl = document.getElementById('statusMessage');
        messageEl.textContent = text;
        messageEl.className = `status-message ${type}`;
        messageEl.style.display = 'block';

        setTimeout(() => {
            messageEl.style.display = 'none';
        }, 3000);
    }

    // Метод для принудительного обновления страницы меню
    forceUpdateMenuPage() {
        try {
            // Создаем событие для всех открытых окон/вкладок
            const timestamp = Date.now();

            // 1. Обновляем метку времени в localStorage для триггера событий storage
            localStorage.removeItem('menuData');
            localStorage.setItem('menuData', JSON.stringify(this.menuData));
            localStorage.setItem('menuDataTimestamp', timestamp.toString());

            // 2. Добавляем special флаг для принудительного обновления
            localStorage.setItem('menuForceReload', 'true');

            // 3. Используем BroadcastChannel если доступен
            this.notifyViaBroadcastChannel();

            // 4. Используем postMessage для всех открытых фреймов
            this.notifyViaPostMessage();

            // 5. Используем кастомные события
            this.notifyViaCustomEvent();

            // Показываем сообщение
            this.showMessage('Отправлен сигнал принудительного обновления страницы меню', 'success');

            console.log('🔄 Отправлен сигнал принудительного обновления');

            // Через 2 секунды удаляем флаг
            setTimeout(() => {
                localStorage.removeItem('menuForceReload');
            }, 2000);

            return true;
        } catch (error) {
            console.error('Ошибка при принудительном обновлении:', error);
            this.showMessage('Ошибка при отправке сигнала обновления: ' + error.message, 'error');
            return false;
        }
    }

    switchLanguage(lang) {
        this.currentLanguage = lang;

        // Обновляем кнопки
        document.getElementById('langEnBtn').className = `btn ${lang === 'en' ? 'btn-primary' : 'btn-secondary'}`;
        document.getElementById('langRuBtn').className = `btn ${lang === 'ru' ? 'btn-primary' : 'btn-secondary'}`;
        document.getElementById('langLvBtn').className = `btn ${lang === 'lv' ? 'btn-primary' : 'btn-secondary'}`;

        // Сохраняем выбранный язык
        localStorage.setItem('adminLanguage', lang);

        // Показываем сообщение
        const langNames = { 'en': 'Английский', 'ru': 'Русский', 'lv': 'Латышский' };
        this.showMessage(`Выбран язык редактирования: ${langNames[lang]}`, 'info');
    }

    formatPrice(price) {
        const currency = this.menuData?.currency || '€';
        const numericPrice = price.replace(/[^\d.,]/g, '');
        return `${numericPrice}${currency}`;
    }
}
