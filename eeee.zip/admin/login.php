<?php
require_once 'config/security.php';

SecurityManager::setSecurityHeaders();

// Если уже авторизован, перенаправляем в админ панель
if (SecurityManager::checkAuth()) {
    header('Location: index.php');
    exit();
}

$error = '';
$blocked_until = '';

// Обработка формы входа
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';

    // Проверка CSRF токена
    if (!SecurityManager::verifyCSRFToken($csrf_token)) {
        $error = 'Ошибка безопасности. Обновите страницу.';
        SecurityManager::logSecurityEvent('CSRF token mismatch on login');
    } else {
        $result = SecurityManager::login($password);

        if ($result['success']) {
            header('Location: index.php');
            exit();
        } else {
            $error = $result['message'];
            $blocked_until = $result['blocked_until'] ?? '';
        }
    }
}

$csrf_token = SecurityManager::getCSRFToken();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход в админ панель</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-container {
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        .login-header {
            margin-bottom: 30px;
        }

        .login-header h1 {
            color: #333;
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .login-header p {
            color: #666;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
        }

        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e1e5e9;
            border-radius: 10px;
            font-size: 16px;
            transition: border-color 0.3s ease;
            background: #f8f9fa;
        }

        .form-control:focus {
            outline: none;
            border-color: #667eea;
            background: white;
        }

        .btn {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: transform 0.2s ease;
        }

        .btn:hover {
            transform: translateY(-2px);
        }

        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        .error-message {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #c33;
        }

        .security-info {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e1e5e9;
            font-size: 12px;
            color: #666;
            line-height: 1.5;
        }

        .security-info ul {
            text-align: left;
            margin-top: 10px;
        }

        .security-info li {
            margin-bottom: 5px;
        }

        .blocked-info {
            background: #fff3cd;
            color: #856404;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #ffc107;
        }

        .attempts-counter {
            font-size: 12px;
            color: #666;
            margin-top: 10px;
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 30px 20px;
            }

            .login-header h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>🔐 Админ панель</h1>
            <p>Введите пароль для доступа</p>
        </div>

        <?php if ($error): ?>
            <div class="error-message">
                <?php echo htmlspecialchars($error); ?>
                <?php if ($blocked_until): ?>
                    <br><small>Разблокировка в: <?php echo $blocked_until; ?></small>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <form method="POST" id="loginForm">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">

            <div class="form-group">
                <label for="password">Пароль:</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>

            <button type="submit" class="btn" id="loginBtn">Войти</button>
        </form>

        <div class="security-info">
            <strong>Меры безопасности:</strong>
            <ul>
                <li>Максимум 5 попыток входа</li>
                <li>Блокировка IP на 30 минут при превышении</li>
                <li>Все действия логируются</li>
                <li>Автоматический выход через 1 час</li>
                <li>CSRF защита</li>
            </ul>
        </div>
    </div>

    <script>
        // Защита от перебора паролей
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const btn = document.getElementById('loginBtn');
            btn.disabled = true;
            btn.textContent = 'Проверка...';

            // Небольшая задержка для предотвращения автоматических атак
            setTimeout(() => {
                if (btn.disabled) {
                    btn.disabled = false;
                    btn.textContent = 'Войти';
                }
            }, 2000);
        });

        // Автофокус на поле пароля
        document.getElementById('password').focus();

        // Предотвращение копирования/вставки в поле пароля для дополнительной безопасности
        document.getElementById('password').addEventListener('paste', function(e) {
            e.preventDefault();
        });
    </script>
</body>
</html>
