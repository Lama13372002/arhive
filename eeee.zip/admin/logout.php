<?php
require_once 'config/security.php';

// Проверяем, что пользователь авторизован
if (SecurityManager::checkAuth()) {
    SecurityManager::logout();
}

// Перенаправляем на страницу входа
header('Location: login.php');
exit();
?>
