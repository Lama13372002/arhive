<?php
session_start();

// Простая аутентификация (можешь изменить пароль)
$admin_password = 'admin123'; // Измени этот пароль!

if (isset($_POST['login'])) {
    if ($_POST['password'] === $admin_password) {
        $_SESSION['admin_logged_in'] = true;
    } else {
        $error = 'Неверный пароль!';
    }
}

if (isset($_POST['logout'])) {
    unset($_SESSION['admin_logged_in']);
}

// Обработка обновления кэша
if (isset($_POST['update_cache']) && isset($_SESSION['admin_logged_in'])) {
    $config_file = '../config/css_version.json';

    if (file_exists($config_file)) {
        $config = json_decode(file_get_contents($config_file), true);

        // Увеличиваем версию
        $version_parts = explode('.', $config['version']);
        $version_parts[2] = (int)$version_parts[2] + 1;
        $config['version'] = implode('.', $version_parts);
        $config['last_updated'] = date('c');

        file_put_contents($config_file, json_encode($config, JSON_PRETTY_PRINT));
        $success = 'Кэш CSS успешно обновлен! Новая версия: ' . $config['version'];
    } else {
        $error = 'Файл конфигурации не найден!';
    }
}

// Получаем текущую версию
$config_file = '../config/css_version.json';
$current_version = '1.0.0';
$last_updated = 'Неизвестно';

if (file_exists($config_file)) {
    $config = json_decode(file_get_contents($config_file), true);
    $current_version = $config['version'];
    $last_updated = date('d.m.Y H:i', strtotime($config['last_updated']));
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление кэшем CSS - Calliano Lounge</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
            color: #fff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.2);
            max-width: 500px;
            width: 100%;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            color: #ff6b35;
            font-size: 2em;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }

        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            font-size: 16px;
        }

        input[type="password"]:focus {
            outline: none;
            border-color: #ff6b35;
            box-shadow: 0 0 10px rgba(255, 107, 53, 0.3);
        }

        .btn {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 10px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(255, 107, 53, 0.3);
        }

        .btn-danger {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
        }

        .btn-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-success {
            background: rgba(40, 167, 69, 0.2);
            border: 1px solid #28a745;
            color: #28a745;
        }

        .alert-error {
            background: rgba(220, 53, 69, 0.2);
            border: 1px solid #dc3545;
            color: #dc3545;
        }

        .version-info {
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
        }

        .version-number {
            font-size: 1.5em;
            font-weight: 600;
            color: #ff6b35;
            margin-bottom: 5px;
        }

        .last-updated {
            font-size: 0.9em;
            color: rgba(255, 255, 255, 0.7);
        }

        .warning {
            background: rgba(255, 193, 7, 0.2);
            border: 1px solid #ffc107;
            color: #ffc107;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Управление кэшем CSS</h1>

        <?php if (!isset($_SESSION['admin_logged_in'])): ?>
            <!-- Форма входа -->
            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label for="password">Пароль администратора:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" name="login" class="btn btn-primary">Войти</button>
            </form>

        <?php else: ?>
            <!-- Панель управления -->
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?= $error ?></div>
            <?php endif; ?>

            <div class="version-info">
                <div class="version-number">v<?= $current_version ?></div>
                <div class="last-updated">Обновлено: <?= $last_updated ?></div>
            </div>

            <div class="warning">
                ⚠️ Внимание! После нажатия кнопки "Обновить кэш" все пользователи получат новую версию CSS файлов при следующем посещении сайта.
            </div>

            <form method="POST">
                <button type="submit" name="update_cache" class="btn btn-success"
                        onclick="return confirm('Вы уверены, что хотите обновить кэш CSS для всех пользователей?')">
                    🔄 Обновить кэш CSS
                </button>
            </form>

            <form method="POST">
                <button type="submit" name="logout" class="btn btn-secondary">Выйти</button>
            </form>

            <div style="margin-top: 30px; text-align: center; font-size: 14px; color: rgba(255, 255, 255, 0.6);">
                <p>Система автоматического управления кэшем CSS</p>
                <p>Calliano Lounge Admin Panel</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
