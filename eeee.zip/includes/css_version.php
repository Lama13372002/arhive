<?php
function getCSSVersion() {
    $config_file = __DIR__ . '/../config/css_version.json';

    if (file_exists($config_file)) {
        $config = json_decode(file_get_contents($config_file), true);
        return $config['version'];
    }

    return '1.0.0';
}

function cssLink($href) {
    $version = getCSSVersion();
    $separator = strpos($href, '?') !== false ? '&' : '?';
    return $href . $separator . 'v=' . $version;
}

function getCSSVersionInfo() {
    $config_file = __DIR__ . '/../config/css_version.json';

    if (file_exists($config_file)) {
        return json_decode(file_get_contents($config_file), true);
    }

    return [
        'version' => '1.0.0',
        'last_updated' => date('c')
    ];
}
?>
