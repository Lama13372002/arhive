/**
 * CSS Version Manager
 * Автоматически добавляет актуальную версию к CSS файлам
 */

class CSSVersionManager {
    constructor() {
        this.configUrl = '../config/css_version.json';
        this.init();
    }

    async init() {
        try {
            const version = await this.getCurrentVersion();
            this.updateCSSLinks(version);
        } catch (error) {
            console.warn('CSS Version Manager: Не удалось загрузить версию CSS, используется кэшированная версия');
        }
    }

    async getCurrentVersion() {
        try {
            const response = await fetch(this.configUrl + '?nocache=' + Date.now());
            const config = await response.json();
            return config.version;
        } catch (error) {
            // Если не удалось загрузить версию, используем текущее время как версию
            return Date.now().toString();
        }
    }

    updateCSSLinks(version) {
        const cssLinks = document.querySelectorAll('link[rel="stylesheet"]');

        cssLinks.forEach(link => {
            const href = link.getAttribute('href');

            // Проверяем, что это локальный CSS файл
            if (href && (href.includes('.css') && !href.startsWith('http'))) {
                // Удаляем старый параметр версии, если есть
                const cleanHref = href.split('?')[0];

                // Добавляем новую версию
                const newHref = cleanHref + '?v=' + version;

                link.setAttribute('href', newHref);

                console.log(`CSS Version Manager: Обновлен ${cleanHref} -> v${version}`);
            }
        });
    }

    // Метод для принудительного обновления CSS
    async forceRefresh() {
        const version = await this.getCurrentVersion();
        this.updateCSSLinks(version);

        // Дополнительно перезагружаем все CSS файлы
        const cssLinks = document.querySelectorAll('link[rel="stylesheet"]');
        cssLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href && href.includes('.css') && !href.startsWith('http')) {
                // Создаем новый элемент link
                const newLink = document.createElement('link');
                newLink.rel = 'stylesheet';
                newLink.href = href;

                // Заменяем старый на новый
                link.parentNode.insertBefore(newLink, link.nextSibling);
                link.remove();
            }
        });

        console.log('CSS Version Manager: Принудительно обновлены все CSS файлы');
    }
}

// Автоматически инициализируем при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    window.cssVersionManager = new CSSVersionManager();
});

// Экспортируем для использования в других скриптах
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CSSVersionManager;
}
