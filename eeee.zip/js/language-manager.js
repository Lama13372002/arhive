/**
 * Центральный менеджер языков для синхронизации между страницами
 * Обеспечивает сохранение выбранного языка при переходах между after-qr и menu.html
 * Работает с отдельными HTML файлами для after-qr и JSON переводами для menu.html
 */
class LanguageManager {
    constructor() {
        this.storageKey = 'qitchen_selected_language';
        this.defaultLanguage = 'en';
        this.supportedLanguages = ['en', 'ru', 'lv'];

        // Определяем текущую страницу
        this.currentPage = this.detectCurrentPage();

        this.init();
    }

    /**
     * Определяет текущую страницу
     */
    detectCurrentPage() {
        const path = window.location.pathname;
        if (path.includes('after-qr')) {
            return 'after-qr';
        } else if (path.includes('menu.html')) {
            return 'menu';
        }
        return 'unknown';
    }

    init() {
        // Проверяем URL параметры при загрузке
        this.checkUrlParams();

        // Определяем язык из текущей страницы для after-qr
        const currentLanguage = this.getCurrentLanguage();
        this.applyLanguage(currentLanguage);

        // Устанавливаем обработчики событий
        this.setupEventListeners();

        console.log(`🌐 Language Manager: Инициализирован с языком ${currentLanguage} на странице ${this.currentPage}`);
    }

    /**
     * Устанавливает обработчики событий для переключателей
     */
    setupEventListeners() {
        // Обработчики для after-qr страниц
        if (this.currentPage === 'after-qr') {
            // Функции для глобального использования
            window.switchToLanguagePage = (lang) => this.switchToLanguagePage(lang);
            window.switchToOriginalPage = (lang) => this.switchToLanguagePage(lang);
        }

        // Обработчики для menu.html страницы
        if (this.currentPage === 'menu') {
            const setupMenuHandlers = () => {
                const langEnBtn = document.getElementById('langEnBtn');
                const langRuBtn = document.getElementById('langRuBtn');
                const langLvBtn = document.getElementById('langLvBtn');

                console.log('🌐 Language Manager: Настройка обработчиков для menu.html', {
                    langEnBtn: !!langEnBtn,
                    langRuBtn: !!langRuBtn,
                    langLvBtn: !!langLvBtn
                });

                if (langEnBtn) {
                    langEnBtn.addEventListener('click', (e) => {
                        e.preventDefault();
                        console.log('🌐 EN button clicked');
                        this.switchLanguage('en');
                    });
                }
                if (langRuBtn) {
                    langRuBtn.addEventListener('click', (e) => {
                        e.preventDefault();
                        console.log('🌐 RU button clicked');
                        this.switchLanguage('ru');
                    });
                }
                if (langLvBtn) {
                    langLvBtn.addEventListener('click', (e) => {
                        e.preventDefault();
                        console.log('🌐 LV button clicked');
                        this.switchLanguage('lv');
                    });
                }
            };

            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', setupMenuHandlers);
            } else {
                setupMenuHandlers();
            }
        }
    }

    /**
     * Проверяет URL параметры на наличие языка
     */
    checkUrlParams() {
        const urlParams = new URLSearchParams(window.location.search);
        const langFromUrl = urlParams.get('lang');

        if (langFromUrl && this.supportedLanguages.includes(langFromUrl)) {
            this.setLanguage(langFromUrl);
            console.log(`🌐 Language Manager: Язык установлен из URL: ${langFromUrl}`);
        }
    }

    /**
     * Получает текущий язык из localStorage, URL или пути страницы
     */
    getCurrentLanguage() {
        // Для after-qr страниц определяем язык по пути
        if (this.currentPage === 'after-qr') {
            const path = window.location.pathname;
            if (path.includes('/ru/')) {
                return 'ru';
            } else if (path.includes('/lv/')) {
                return 'lv';
            } else if (path.includes('/after-qr/')) {
                return 'en';
            }
        }

        // Сначала проверяем URL параметры
        const urlParams = new URLSearchParams(window.location.search);
        const langFromUrl = urlParams.get('lang');

        if (langFromUrl && this.supportedLanguages.includes(langFromUrl)) {
            return langFromUrl;
        }

        // Затем проверяем localStorage
        const savedLanguage = localStorage.getItem(this.storageKey);
        if (savedLanguage && this.supportedLanguages.includes(savedLanguage)) {
            return savedLanguage;
        }

        return this.defaultLanguage;
    }

    /**
     * Устанавливает язык и сохраняет в localStorage
     */
    setLanguage(language) {
        if (!this.supportedLanguages.includes(language)) {
            console.warn(`🌐 Language Manager: Неподдерживаемый язык ${language}`);
            return;
        }

        localStorage.setItem(this.storageKey, language);
        console.log(`🌐 Language Manager: Язык сохранен: ${language}`);
    }

    /**
     * Переключает язык и обновляет интерфейс
     */
    switchLanguage(language) {
        if (!this.supportedLanguages.includes(language)) {
            console.warn(`🌐 Language Manager: Неподдерживаемый язык ${language}`);
            return;
        }

        this.setLanguage(language);

        // Для after-qr страниц используем переход между файлами
        if (this.currentPage === 'after-qr') {
            this.switchToLanguagePage(language);
            return;
        }

        // Для menu.html применяем переводы
        this.applyLanguage(language);

        // Уведомляем другие компоненты об изменении языка
        this.notifyLanguageChange(language);

        console.log(`🌐 Language Manager: Язык переключен на ${language}`);
    }

    /**
     * Применяет язык к интерфейсу
     */
    applyLanguage(language) {
        // Обновляем кнопки переключения языков
        this.updateLanguageButtons(language);

        // Для menu.html уведомляем multilingualManager напрямую, без вызова switchLanguage
        if (this.currentPage === 'menu' && window.multilingualManager) {
            window.multilingualManager.currentLanguage = language;
            window.multilingualManager.updateLanguageButtons();
            window.multilingualManager.applyLanguage(language);
        }
    }

    /**
     * Обновляет состояние кнопок языков
     */
    updateLanguageButtons(language) {
        if (this.currentPage === 'after-qr') {
            // Для страниц after-qr кнопки уже настроены в HTML
            const buttons = document.querySelectorAll('.language-btn');
            buttons.forEach(button => {
                button.classList.remove('language__img_active');
                const buttonLang = button.textContent.toLowerCase();
                if (buttonLang === language) {
                    button.classList.add('language__img_active');
                }
            });
        } else if (this.currentPage === 'menu') {
            // Для menu.html
            const langEnBtn = document.getElementById('langEnBtn');
            const langRuBtn = document.getElementById('langRuBtn');
            const langLvBtn = document.getElementById('langLvBtn');

            if (langEnBtn && langRuBtn && langLvBtn) {
                langEnBtn.classList.toggle('active', language === 'en');
                langRuBtn.classList.toggle('active', language === 'ru');
                langLvBtn.classList.toggle('active', language === 'lv');
            }
        }
    }

    /**
     * Создает URL с языковым параметром
     */
    createUrlWithLanguage(baseUrl, language = null) {
        const lang = language || this.getCurrentLanguage();
        const url = new URL(baseUrl, window.location.origin);

        // Добавляем параметр языка
        url.searchParams.set('lang', lang);

        // Сохраняем параметры сессии если они есть
        const currentParams = new URLSearchParams(window.location.search);
        if (currentParams.has('session')) {
            url.searchParams.set('session', currentParams.get('session'));
        }
        if (currentParams.has('table')) {
            url.searchParams.set('table', currentParams.get('table'));
        }

        return url.toString();
    }

    /**
     * Переключается на нужную языковую версию страницы after-qr
     */
    switchToLanguagePage(language) {
        let targetPath;
        const currentPath = window.location.pathname;

        // Сохраняем язык перед переходом
        this.setLanguage(language);

        // Определяем целевой путь в зависимости от текущего местоположения
        if (currentPath.includes('/after-qr/')) {
            // Находимся в английской версии
            switch (language) {
                case 'ru':
                    targetPath = '../ru/after-qr.html';
                    break;
                case 'lv':
                    targetPath = '../lv/after-qr.html';
                    break;
                case 'en':
                default:
                    return; // Уже на английской странице
            }
        } else if (currentPath.includes('/ru/')) {
            // Находимся в русской версии
            switch (language) {
                case 'en':
                    targetPath = '../after-qr/after-qr.html';
                    break;
                case 'lv':
                    targetPath = '../lv/after-qr.html';
                    break;
                case 'ru':
                default:
                    return; // Уже на русской странице
            }
        } else if (currentPath.includes('/lv/')) {
            // Находимся в латышской версии
            switch (language) {
                case 'en':
                    targetPath = '../after-qr/after-qr.html';
                    break;
                case 'ru':
                    targetPath = '../ru/after-qr.html';
                    break;
                case 'lv':
                default:
                    return; // Уже на латышской странице
            }
        } else if (currentPath.includes('/menu/')) {
            // Находимся на странице меню, переходим на after-qr
            switch (language) {
                case 'ru':
                    targetPath = '../ru/after-qr.html';
                    break;
                case 'lv':
                    targetPath = '../lv/after-qr.html';
                    break;
                case 'en':
                default:
                    targetPath = '../after-qr/after-qr.html';
                    break;
            }
        }

        if (targetPath) {
            // Создаем URL с сохранением сессии
            const targetUrl = this.createUrlWithLanguage(targetPath, language);
            window.location.href = targetUrl;
        }
    }

    /**
     * Перенаправляет на нужную языковую версию страницы after-qr (устаревший метод для совместимости)
     */
    redirectToLanguagePage(language) {
        this.switchToLanguagePage(language);
    }

    /**
     * Обновляет ссылки на странице для сохранения языка
     */
    updateLinksWithLanguage() {
        const currentLanguage = this.getCurrentLanguage();

        if (this.currentPage === 'after-qr') {
            // Обновляем ссылку на меню с языковым параметром
            const menuLinks = document.querySelectorAll('a[href*="menu.html"], a[href*="menu/"]');
            menuLinks.forEach(link => {
                const href = link.getAttribute('href');
                if (href) {
                    const newUrl = this.createUrlWithLanguage(href, currentLanguage);
                    link.setAttribute('href', newUrl);
                }
            });
        } else if (this.currentPage === 'menu') {
            // Обновляем ссылки Back на правильную языковую версию after-qr
            const backLinks = document.querySelectorAll('a[href*="after-qr"]');
            backLinks.forEach(link => {
                let targetPath;
                switch (currentLanguage) {
                    case 'ru':
                        targetPath = '../ru/after-qr.html';
                        break;
                    case 'lv':
                        targetPath = '../lv/after-qr.html';
                        break;
                    case 'en':
                    default:
                        targetPath = '../after-qr/after-qr.html';
                        break;
                }

                const newUrl = this.createUrlWithLanguage(targetPath, currentLanguage);
                link.setAttribute('href', newUrl);
            });
        }
    }

    /**
     * Уведомляет другие компоненты об изменении языка
     */
    notifyLanguageChange(language) {
        // Создаем кастомное событие
        const event = new CustomEvent('languageChanged', {
            detail: { language: language }
        });

        document.dispatchEvent(event);
    }

    /**
     * Получает переведенный текст для текущего языка
     */
    getTranslatedText(translations) {
        const currentLanguage = this.getCurrentLanguage();
        return translations[currentLanguage] || translations['en'] || '';
    }
}

// Создаем глобальный экземпляр
window.languageManager = new LanguageManager();

// Экспортируем для совместимости
if (typeof module !== 'undefined' && module.exports) {
    module.exports = LanguageManager;
}
