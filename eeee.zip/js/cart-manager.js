/**
 * Менеджер корзины для ресторана
 * Управляет добавлением, удалением товаров и отправкой заказов
 */

class CartManager {
    constructor() {
        this.cart = [];
        this.cartIcon = null;
        this.cartModal = null;
        this.init();
    }

    async init() {
        // Проверяем настройки видимости корзины
        await this.checkCartVisibility();

        // Загружаем корзину из localStorage
        this.loadCartFromStorage();

        // Создаем иконку корзины
        this.createCartIcon();

        // Создаем модальное окно корзины
        this.createCartModal();

        // Привязываем события
        this.bindEvents();

        // Настраиваем слушатель изменений языка
        this.setupLanguageListener();

        // Обновляем отображение
        this.updateCartDisplay();
    }

    async checkCartVisibility() {
        try {
            const response = await fetch('/api/cart-settings.php');
            const result = await response.json();

            if (result.success && result.data) {
                this.isCartVisible = result.data.cartVisible;
            } else {
                this.isCartVisible = true; // По умолчанию корзина видна
            }
        } catch (error) {
            console.log('Использование настроек корзины по умолчанию');
            this.isCartVisible = true;
        }
    }

    loadCartFromStorage() {
        try {
            const savedCart = localStorage.getItem('restaurant_cart');
            if (savedCart) {
                this.cart = JSON.parse(savedCart);
            }
        } catch (error) {
            console.error('Error loading cart from storage:', error);
            this.cart = [];
        }
    }

    saveCartToStorage() {
        try {
            localStorage.setItem('restaurant_cart', JSON.stringify(this.cart));
        } catch (error) {
            console.error('Error saving cart to storage:', error);
        }
    }

    createCartIcon() {
        // Если корзина скрыта, не создаем иконку
        if (!this.isCartVisible) {
            return;
        }

        // Создаем HTML для иконки корзины
        const cartIconHTML = `
            <div class="cart-icon-container" id="cartIcon">
                <div class="cart-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path d="M3 3H5L5.4 5M7 13H17L21 5H5.4M7 13L5.4 5M7 13L4.7 15.3C4.3 15.7 4.6 16.5 5.1 16.5H17M17 13V19C17 20.1 16.1 21 15 21H9C7.9 21 7 20.1 7 19V13M17 13H7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <span class="cart-count" id="cartCount">0</span>
                </div>
            </div>
        `;

        // Добавляем иконку в body
        document.body.insertAdjacentHTML('beforeend', cartIconHTML);
        this.cartIcon = document.getElementById('cartIcon');
    }

    createCartModal() {
        // Если корзина скрыта, не создаем модальное окно
        if (!this.isCartVisible) {
            return;
        }

        // Получаем текущий язык и переводы
        let currentLang = 'en';
        let translations = {
            yourOrder: 'Your Order',
            cartEmpty: 'Your cart is empty',
            addItemsFromMenu: 'Add items from menu',
            totalAmount: 'Total:',
            orderBtn: 'Order'
        };

        if (window.multilingualManager) {
            currentLang = window.multilingualManager.getCurrentLanguage();
            translations = window.multilingualManager.translations[currentLang] || translations;
        }

        // Создаем HTML для модального окна корзины
        const cartModalHTML = `
            <div class="cart-modal-overlay" id="cartModal">
                <div class="cart-modal-container">
                    <div class="cart-modal-header">
                        <h2>${translations.yourOrder}</h2>
                        <button class="cart-modal-close" id="cartModalClose">×</button>
                    </div>
                    <div class="cart-modal-content">
                        <div class="cart-items" id="cartItems">
                            <!-- Товары корзины будут добавлены здесь -->
                        </div>
                        <div class="cart-empty-message" id="cartEmptyMessage" style="display: none;">
                            <svg width="64" height="64" viewBox="0 0 24 24" fill="none">
                                <path d="M3 3H5L5.4 5M7 13H17L21 5H5.4M7 13L5.4 5M7 13L4.7 15.3C4.3 15.7 4.6 16.5 5.1 16.5H17M17 13V19C17 20.1 16.1 21 15 21H9C7.9 21 7 20.1 7 19V13M17 13H7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <p>${translations.cartEmpty}</p>
                            <small>${translations.addItemsFromMenu}</small>
                        </div>
                    </div>
                    <div class="cart-modal-footer" id="cartModalFooter">
                        <div class="cart-total" id="cartTotal">
                            <span class="total-label">${translations.totalAmount}</span>
                            <span class="total-amount">€0</span>
                        </div>
                        <button class="order-btn" id="orderBtn">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                                <path d="M22 2L11 13M22 2L15 22L11 13M22 2L2 9L11 13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <span>${translations.orderBtn}</span>
                        </button>
                    </div>
                </div>
            </div>
        `;

        // Добавляем модальное окно в body
        document.body.insertAdjacentHTML('beforeend', cartModalHTML);
        this.cartModal = document.getElementById('cartModal');
    }

    bindEvents() {
        // Клик по иконке корзины
        if (this.cartIcon) {
            this.cartIcon.addEventListener('click', () => {
                this.openCartModal();
            });
        }

        // Закрытие модального окна корзины
        const closeBtn = document.getElementById('cartModalClose');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                this.closeCartModal();
            });
        }

        // Закрытие по клику на оверлей
        if (this.cartModal) {
            this.cartModal.addEventListener('click', (e) => {
                if (e.target === this.cartModal) {
                    this.closeCartModal();
                }
            });
        }

        // Кнопка заказать
        const orderBtn = document.getElementById('orderBtn');
        if (orderBtn) {
            orderBtn.addEventListener('click', () => {
                this.processOrder();
            });
        }

        // Делегирование событий для кнопок удаления товаров
        document.addEventListener('click', (e) => {
            if (e.target.closest('.remove-item-btn')) {
                const itemId = e.target.closest('.remove-item-btn').dataset.itemId;
                this.removeFromCart(itemId);
            }
        });
    }

    setupLanguageListener() {
        // Слушаем изменения языка
        document.addEventListener('languageChanged', (event) => {
            this.updateCartLanguage(event.detail.language);
        });
    }

    updateCartLanguage(lang) {
        // Получаем переводы из multilingualManager
        if (!window.multilingualManager || !window.multilingualManager.translations[lang]) {
            return;
        }

        const translations = window.multilingualManager.translations[lang];

        // Обновляем заголовок корзины
        const cartModalHeader = document.querySelector('.cart-modal-header h2');
        if (cartModalHeader) {
            cartModalHeader.textContent = translations.yourOrder;
        }

        // Обновляем сообщение о пустой корзине
        const cartEmptyMessage = document.querySelector('.cart-empty-message p');
        if (cartEmptyMessage) {
            cartEmptyMessage.textContent = translations.cartEmpty;
        }

        const cartEmptySmall = document.querySelector('.cart-empty-message small');
        if (cartEmptySmall) {
            cartEmptySmall.textContent = translations.addItemsFromMenu;
        }

        // Обновляем кнопку "Заказать"
        const orderBtn = document.getElementById('orderBtn');
        if (orderBtn) {
            const span = orderBtn.querySelector('span');
            if (span) {
                span.textContent = translations.orderBtn;
            }
        }

        // Обновляем "Общая сумма"
        const totalLabel = document.querySelector('.total-label');
        if (totalLabel) {
            totalLabel.textContent = translations.totalAmount;
        }

        // Обновляем содержимое корзины для нового языка
        this.updateCartModalContent();
    }

    addToCart(item) {
        // Проверяем, есть ли уже такой товар в корзине
        const existingItemIndex = this.cart.findIndex(cartItem =>
            cartItem.name === item.name &&
            cartItem.price === item.price &&
            cartItem.priceDescription === item.priceDescription
        );

        if (existingItemIndex > -1) {
            // Увеличиваем количество
            this.cart[existingItemIndex].quantity += 1;
        } else {
            // Добавляем новый товар
            this.cart.push(item);
        }

        this.saveCartToStorage();
        this.updateCartDisplay();

        console.log('Item added to cart:', item);
    }

    removeFromCart(itemId) {
        this.cart = this.cart.filter(item => item.id != itemId);
        this.saveCartToStorage();
        this.updateCartDisplay();
        this.updateCartModalContent();
    }

    updateCartDisplay() {
        const cartCount = document.getElementById('cartCount');
        if (cartCount) {
            const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
            cartCount.textContent = totalItems;

            // Показываем/скрываем иконку в зависимости от количества товаров
            if (this.cartIcon) {
                if (totalItems > 0) {
                    this.cartIcon.classList.add('has-items');
                } else {
                    this.cartIcon.classList.remove('has-items');
                }
            }
        }
    }

    openCartModal() {
        if (this.cartModal) {
            this.updateCartModalContent();
            this.cartModal.classList.add('active');
            document.body.classList.add('cart-modal-open');
        }
    }

    closeCartModal() {
        if (this.cartModal) {
            this.cartModal.classList.remove('active');
            document.body.classList.remove('cart-modal-open');
        }
    }

    updateCartModalContent() {
        const cartItems = document.getElementById('cartItems');
        const cartEmptyMessage = document.getElementById('cartEmptyMessage');
        const cartModalFooter = document.getElementById('cartModalFooter');
        const cartTotal = document.getElementById('cartTotal');

        if (!cartItems) return;

        if (this.cart.length === 0) {
            // Пустая корзина
            cartItems.style.display = 'none';
            cartEmptyMessage.style.display = 'flex';
            cartModalFooter.style.display = 'none';
        } else {
            // Заполненная корзина
            cartItems.style.display = 'block';
            cartEmptyMessage.style.display = 'none';
            cartModalFooter.style.display = 'block';

            // Генерируем HTML для товаров
            cartItems.innerHTML = this.cart.map(item => `
                <div class="cart-item">
                    <div class="cart-item-image">
                        ${item.image && !item.image.includes('placeholder') ?
                            `<img src="${item.image}" alt="${item.name}">` :
                            `<div class="cart-item-placeholder">
                                <svg width="32" height="32" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M21 19V5C21 3.9 20.1 3 19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 19 20.1 21 19ZM8.5 13.5L11 16.51L14.5 12L19 18H5L8.5 13.5Z"/>
                                </svg>
                            </div>`
                        }
                    </div>
                    <div class="cart-item-details">
                        <h4 class="cart-item-name">${item.name}</h4>
                        ${item.priceDescription ? `<p class="cart-item-description">${item.priceDescription}</p>` : ''}
                        <div class="cart-item-price-qty">
                            <span class="cart-item-price">${item.price}</span>
                            <span class="cart-item-quantity">x${item.quantity}</span>
                        </div>
                        ${item.isSpicy ? this.getSpicyBadgeHtml() : ''}
                        ${item.isAlcohol ? this.getAlcoholBadgeHtml() : ''}
                    </div>
                    <button class="remove-item-btn" data-item-id="${item.id}" title="${this.getRemoveItemTitle()}">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                            <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                </div>
            `).join('');

            // Обновляем общую сумму
            this.updateCartTotal();
        }
    }

    updateCartTotal() {
        const cartTotal = document.querySelector('.total-amount');
        if (!cartTotal) return;

        // Подсчитываем общую сумму (пока без парсинга цен, просто показываем количество товаров)
        const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);

        // Используем правильное склонение через multilingualManager
        if (window.multilingualManager && typeof window.multilingualManager.getItemCountText === 'function') {
            cartTotal.textContent = window.multilingualManager.getItemCountText(totalItems);
        } else {
            // Fallback если multilingualManager недоступен
            cartTotal.textContent = `${totalItems} items`;
        }
    }

    async processOrder() {
        if (this.cart.length === 0) {
            alert(this.getCartEmptyAlert());
            return;
        }

        // Получаем данные сессии
        const session = sessionManager ? sessionManager.getSession() : null;
        if (!session || !session.tableNumber) {
            alert(this.getTableNumberError());
            return;
        }

        try {
            // Формируем данные заказа
            const orderData = {
                type: 'заказ',
                tableNumber: session.tableNumber,
                orderTime: new Date().toLocaleString('ru-RU', {
                    timeZone: 'Europe/Riga',
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit'
                }),
                items: this.cart.map(item => ({
                    name: item.name,
                    description: item.description || '',
                    price: item.price,
                    priceDescription: item.priceDescription || '',
                    quantity: item.quantity,
                    isSpicy: item.isSpicy,
                    isAlcohol: item.isAlcohol
                })),
                totalItems: this.cart.reduce((sum, item) => sum + item.quantity, 0)
            };

            // Отправляем заказ через существующую систему уведомлений
            const response = await fetch('/api/notifications.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'create',
                    session_id: session.sessionId,
                    table_number: session.tableNumber,
                    type: 'order',
                    message: JSON.stringify(orderData)
                })
            });

            if (response.ok) {
                // Заказ успешно отправлен
                alert(this.getOrderSuccess());

                // Очищаем корзину
                this.clearCart();

                // Закрываем модальное окно
                this.closeCartModal();
            } else {
                throw new Error('Order sending error');
            }
        } catch (error) {
            console.error('Error processing order:', error);
            alert(this.getOrderError());
        }
    }

    clearCart() {
        this.cart = [];
        this.saveCartToStorage();
        this.updateCartDisplay();
        this.updateCartModalContent();
    }

    // Вспомогательные методы для получения переводов
    getSpicyBadgeHtml() {
        const text = this.getTranslation('spicy', 'Spicy');
        return `<span class="cart-item-badge spicy">🌶️ ${text}</span>`;
    }

    getAlcoholBadgeHtml() {
        const text = this.getTranslation('alcohol', 'Alcohol');
        return `<span class="cart-item-badge alcohol">🍺 ${text}</span>`;
    }

    getRemoveItemTitle() {
        return this.getTranslation('removeItem', 'Remove item');
    }

    getCartEmptyAlert() {
        return this.getTranslation('cartEmptyAlert', 'Cart is empty');
    }

    getTableNumberError() {
        return this.getTranslation('tableNumberError', 'Error: table number not found');
    }

    getOrderSuccess() {
        return this.getTranslation('orderSuccess', 'Order sent successfully! Please wait for confirmation.');
    }

    getOrderError() {
        return this.getTranslation('orderError', 'Error sending order. Please try again.');
    }

    getTranslation(key, fallback) {
        if (window.multilingualManager && window.multilingualManager.translations) {
            const currentLang = window.multilingualManager.getCurrentLanguage();
            const translations = window.multilingualManager.translations[currentLang];
            return translations && translations[key] ? translations[key] : fallback;
        }
        return fallback;
    }

    // Публичные методы
    getCart() {
        return [...this.cart];
    }

    getCartCount() {
        return this.cart.reduce((sum, item) => sum + item.quantity, 0);
    }

    isCartHidden() {
        return !this.isCartVisible;
    }
}

// Инициализация менеджера корзины
let cartManager = null;

document.addEventListener('DOMContentLoaded', function() {
    cartManager = new CartManager();

    // Делаем доступным глобально
    window.cartManager = cartManager;

    console.log('Cart Manager initialized');
});
