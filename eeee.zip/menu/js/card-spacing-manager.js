/**
 * Универсальный менеджер отступов между карточками меню
 * Позволяет легко изменять отступы между карточками для всех устройств
 */

class CardSpacingManager {
    constructor() {
        this.styleId = 'card-spacing-override';
        this.init();
    }

    /**
     * Инициализация менеджера отступов
     */
    init() {
        // Создаем элемент style если его нет
        if (!document.getElementById(this.styleId)) {
            const style = document.createElement('style');
            style.id = this.styleId;
            document.head.appendChild(style);
        }
    }

    /**
     * Устанавливает отступы между карточками
     * @param {Object} spacing - Объект с отступами для разных устройств
     * @param {string} spacing.desktop - Отступ для десктопа (например: '1rem', '20px')
     * @param {string} spacing.tablet - Отступ для планшетов
     * @param {string} spacing.mobile - Отступ для мобильных
     * @param {string} spacing.small - Отступ для маленьких мобильных экранов
     */
    setSpacing(spacing) {
        const defaultSpacing = {
            desktop: '0.2rem',
            tablet: '0.15rem',
            mobile: '0.1rem',
            small: '0.15rem'
        };

        // Объединяем переданные значения с дефолтными
        const finalSpacing = { ...defaultSpacing, ...spacing };

        const css = `
            /* Основные отступы между карточками */
            .modern-card-container {
                margin-bottom: ${finalSpacing.desktop} !important;
            }

            /* Планшеты */
            @media (max-width: 1024px) {
                .modern-card-container {
                    margin-bottom: ${finalSpacing.tablet} !important;
                }
            }

            /* Мобильные устройства */
            @media (max-width: 768px) {
                .modern-card-container {
                    margin-bottom: ${finalSpacing.mobile} !important;
                }
            }

            /* Маленькие мобильные экраны */
            @media (max-width: 480px) {
                .modern-card-container {
                    margin-bottom: ${finalSpacing.small} !important;
                }
            }

            /* Дополнительные отступы для секций меню */
            @media (max-width: 1024px) {
                .menu-category {
                    margin-bottom: 2.5rem !important;
                }
            }

            @media (max-width: 768px) {
                .menu-category {
                    margin-bottom: 2rem !important;
                }
                .cards-grid {
                    gap: 1rem !important;
                }
            }

            @media (max-width: 480px) {
                .menu-category {
                    margin-bottom: 1.5rem !important;
                }
                .cards-grid {
                    gap: 0.75rem !important;
                }
            }
        `;

        // Применяем стили
        document.getElementById(this.styleId).textContent = css;

        console.log('Отступы между карточками обновлены:', finalSpacing);
    }

    /**
     * Устанавливает одинаковый отступ для всех устройств
     * @param {string} spacing - Отступ (например: '5px', '0.5rem')
     */
    setUniformSpacing(spacing) {
        this.setSpacing({
            desktop: spacing,
            tablet: spacing,
            mobile: spacing,
            small: spacing
        });
    }

    /**
     * Сбрасывает отступы к дефолтным значениям
     */
    resetToDefault() {
        this.setSpacing({});
    }

    /**
     * Устанавливает минимальные отступы
     */
    setMinimalSpacing() {
        this.setSpacing({
            desktop: '0.1rem',
            tablet: '0.05rem',
            mobile: '0.05rem',
            small: '0.05rem'
        });
    }

    /**
     * Устанавливает супер минимальные отступы (почти нулевые)
     */
    setSuperMinimalSpacing() {
        this.setSpacing({
            desktop: '0.05rem',
            tablet: '0.03rem',
            mobile: '0.02rem',
            small: '0.02rem'
        });
    }

    /**
     * Устанавливает нулевые отступы (карточки вплотную друг к другу)
     */
    setZeroSpacing() {
        this.setUniformSpacing('0');
    }

    /**
     * Устанавливает большие отступы
     */
    setLargeSpacing() {
        this.setSpacing({
            desktop: '1rem',
            tablet: '0.8rem',
            mobile: '0.6rem',
            small: '0.5rem'
        });
    }

    /**
     * Удаляет все кастомные стили отступов
     */
    removeSpacing() {
        const styleElement = document.getElementById(this.styleId);
        if (styleElement) {
            styleElement.textContent = '';
        }
    }

    /**
     * Получает текущие установленные отступы
     */
    getCurrentSpacing() {
        const styleElement = document.getElementById(this.styleId);
        return styleElement ? styleElement.textContent : '';
    }
}

// Создаем глобальный экземпляр менеджера
window.cardSpacingManager = new CardSpacingManager();

// Экспортируем класс для использования в модулях
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CardSpacingManager;
}

// Добавляем функции в глобальную область для удобства
window.setCardSpacing = function(spacing) {
    window.cardSpacingManager.setSpacing(spacing);
};

window.setUniformCardSpacing = function(spacing) {
    window.cardSpacingManager.setUniformSpacing(spacing);
};

window.setMinimalCardSpacing = function() {
    window.cardSpacingManager.setMinimalSpacing();
};

window.setSuperMinimalCardSpacing = function() {
    window.cardSpacingManager.setSuperMinimalSpacing();
};

window.setZeroCardSpacing = function() {
    window.cardSpacingManager.setZeroSpacing();
};

window.resetCardSpacing = function() {
    window.cardSpacingManager.resetToDefault();
};

// Автоматически применяем супер минимальные отступы при загрузке
document.addEventListener('DOMContentLoaded', function() {
    // Применяем супер минимальные отступы по умолчанию
    window.cardSpacingManager.setSpacing({
        desktop: '0.05rem',  // Очень маленький отступ для десктопа
        tablet: '0.03rem',   // Еще меньше для планшетов
        mobile: '0.02rem',   // Минимальный для мобильных
        small: '0.02rem'     // Минимальный для маленьких экранов
    });

    console.log('Card Spacing Manager инициализирован');
    console.log('Доступные функции:');
    console.log('- setUniformCardSpacing("5px") - одинаковый отступ для всех устройств');
    console.log('- setMinimalCardSpacing() - минимальные отступы');
    console.log('- setZeroCardSpacing() - нулевые отступы');
    console.log('- resetCardSpacing() - сброс к дефолтным');
    console.log('- setCardSpacing({desktop: "10px", mobile: "5px"}) - разные отступы для устройств');
});
