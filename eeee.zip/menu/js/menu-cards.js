/**
 * Оптимизированный скрипт для карточек меню с ленивой загрузкой
 * Улучшает производительность за счет постепенной загрузки контента
 */
class MenuCards {
    constructor() {
        this.menuData = null;
        this.initialized = false;
        this.loadedCategories = new Set();
        this.itemsPerBatch = 6; // Загружаем по 6 карточек за раз
        this.isLoading = false;
        this.intersectionObserver = null;

        // Свойства для стабильной навигации
        this.categoryHeights = new Map(); // Для сохранения высот категорий

        console.log('🍽️ MenuCards: Инициализация с ленивой загрузкой...');

        // Сохраняем экземпляр для доступа из карусели
        window.menuCardsInstance = this;

        this.init();
    }

    async init() {
        try {
            console.log('📋 MenuCards: Начинаем инициализацию');

            // Показываем скелетоны сразу
            this.showInitialSkeletons();

            // Загружаем данные в фоне
            await this.loadMenuData();

            // Рендерим меню с ленивой загрузкой
            this.setupLazyLoading();
            this.renderMenuLazy();

            // Настраиваем обновления
            this.setupUpdateListeners();

            // Добавляем слушатель скролла для дополнительной проверки
            this.setupScrollListener();

            this.initialized = true;
            console.log('✅ MenuCards: Инициализация завершена успешно');

            // Принудительная проверка видимых элементов через небольшую задержку
            setTimeout(() => {
                this.forceCheckVisibleCategories();
            }, 500);

        } catch (error) {
            console.error('❌ MenuCards: Ошибка инициализации:', error);
            this.renderErrorMessage();
        }
    }

    showInitialSkeletons() {
        let container = document.getElementById('dynamic-menu-container');
        if (!container) {
            // Если контейнер не найден, создаем его
            container = document.createElement('div');
            container.id = 'dynamic-menu-container';
            document.body.appendChild(container);
        }

        container.innerHTML = `
            <div class="loading-indicator">
                <div class="loading-spinner"></div>
                Загрузка меню...
            </div>
            ${this.generateSkeletonCategories(3)}
        `;
    }

    generateSkeletonCategories(count) {
        let skeletonHTML = '';
        for (let i = 0; i < count; i++) {
            skeletonHTML += `
                <div class="skeleton-category">
                    <div class="skeleton-category-header">
                        <div class="skeleton-category-title skeleton-loader"></div>
                    </div>
                    ${this.generateSkeletonCards(4)}
                </div>
            `;
        }
        return skeletonHTML;
    }

    generateSkeletonCards(count) {
        let skeletonHTML = '';
        for (let i = 0; i < count; i++) {
            skeletonHTML += `
                <div class="skeleton-card">
                    <div class="skeleton-image skeleton-loader"></div>
                    <div class="skeleton-content">
                        <div class="skeleton-title skeleton-loader"></div>
                        <div class="skeleton-description skeleton-loader"></div>
                        <div class="skeleton-description skeleton-loader"></div>
                        <div class="skeleton-price skeleton-loader"></div>
                    </div>
                </div>
            `;
        }
        return skeletonHTML;
    }

    setupLazyLoading() {
        // Настраиваем Intersection Observer для ленивой загрузки
        if ('IntersectionObserver' in window) {
            this.intersectionObserver = new IntersectionObserver(
                this.debounce((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting && !this.isLoading) {
                            const categoryId = entry.target.dataset.categoryId;
                            if (categoryId && !this.loadedCategories.has(categoryId)) {
                                this.loadCategoryItems(categoryId);
                            }
                        }
                    });
                }, 100), // Добавляем debouncing на 100ms
                {
                    rootMargin: '200px', // Увеличиваем до 200px для более раннего срабатывания
                    threshold: 0.1
                }
            );
        }
    }

    // Добавляем debouncing функцию
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // НОВЫЙ МЕТОД: Безопасная навигация к категории
    navigateToCategory(categoryId) {
        console.log(`🧭 Начинаем навигацию к категории: ${categoryId}`);

        // Проверяем, загружена ли категория и загружаем только её
        if (!this.loadedCategories.has(categoryId)) {
            console.log(`📦 Загружаем только целевую категорию: ${categoryId}`);
            this.loadSingleCategory(categoryId);
        }

        // Выполняем скролл с небольшой задержкой
        setTimeout(() => {
            this.performSafeScroll(categoryId);
        }, 150);
    }

    // Загрузка только одной конкретной категории при навигации
    async loadSingleCategory(categoryId) {
        console.log(`🎯 Загружаем только категорию: ${categoryId}`);

        // Блокируем intersection observer на время загрузки конкретной категории
        const originalObserver = this.intersectionObserver;
        this.intersectionObserver = null;

        try {
            await this.loadCategoryItems(categoryId);
        } catch (error) {
            console.error(`❌ Ошибка загрузки категории ${categoryId}:`, error);
        } finally {
            // Восстанавливаем observer через короткую задержку
            setTimeout(() => {
                this.intersectionObserver = originalObserver;
                console.log('🔄 Intersection Observer восстановлен');
            }, 500);
        }
    }

    // Скролл к категории
    performSafeScroll(categoryId) {
        const categoryElement = document.getElementById(categoryId);
        if (!categoryElement) {
            console.warn(`⚠️ Элемент категории ${categoryId} не найден`);
            return;
        }

        const offsetTop = categoryElement.offsetTop - 100; // Учитываем высоту карусели

        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });

        console.log(`✈️ Скролл к категории ${categoryId}`);
    }

    // Принудительная проверка видимых категорий
    forceCheckVisibleCategories() {
        if (!this.menuData?.categories) return;

        console.log('🔍 Принудительная проверка видимых категорий...');

        const viewportHeight = window.innerHeight;
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

        this.menuData.categories.forEach(category => {
            if (this.loadedCategories.has(category.id)) return;

            const categoryElement = document.getElementById(category.id);
            if (!categoryElement) return;

            const rect = categoryElement.getBoundingClientRect();
            const elementTop = rect.top + scrollTop;
            const elementBottom = elementTop + rect.height;

            // Проверяем, виден ли элемент в области видимости (с запасом 300px)
            if (elementTop < scrollTop + viewportHeight + 300 && elementBottom > scrollTop - 300) {
                console.log(`👁️ Категория ${category.id} видна - загружаем принудительно`);
                this.loadCategoryItems(category.id);
            }
        });
    }

    // Настройка слушателя скролла
    setupScrollListener() {
        const scrollHandler = this.debounce(() => {
            this.forceCheckVisibleCategories();
        }, 100);

        window.addEventListener('scroll', scrollHandler, { passive: true });

        // Также проверяем при изменении размера окна
        window.addEventListener('resize', this.debounce(() => {
            this.forceCheckVisibleCategories();
        }, 300), { passive: true });
    }

    async renderMenuLazy() {
        const container = document.getElementById('dynamic-menu-container');
        if (!container || !this.menuData?.categories) {
            this.renderErrorMessage();
            return;
        }

        try {
            // Очищаем контейнер от скелетонов
            container.innerHTML = '';

            // Рендерим структуру категорий сначала (без товаров)
            this.menuData.categories.forEach((category, index) => {
                const categoryElement = this.createCategoryStructure(category, index);
                container.appendChild(categoryElement);

                // Загружаем первые 5-6 категорий сразу для лучшего UX
                if (index < 6) {
                    setTimeout(() => this.loadCategoryItems(category.id), 100 * (index + 1));
                }
            });

            console.log('✅ MenuCards: Структура меню создана');

            // Автоматически загружаем все остальные категории через 2 секунды
            setTimeout(() => {
                console.log('🚀 Начинаем автоматическую загрузку остальных категорий...');
                this.menuData.categories.forEach((category, index) => {
                    // Загружаем категории начиная с 6-й
                    if (index >= 6 && !this.loadedCategories.has(category.id)) {
                        // Добавляем небольшую задержку между категориями для плавности
                        setTimeout(() => {
                            this.loadCategoryItems(category.id);
                        }, 100 * (index - 5)); // Начинаем с задержки для 6-й категории
                    }
                });
            }, 2000); // 2 секунды задержки

        } catch (error) {
            console.error('❌ MenuCards: Ошибка рендеринга:', error);
            this.renderErrorMessage();
        }
    }

    createCategoryStructure(category, index) {
        const categoryDiv = document.createElement('div');
        categoryDiv.className = 'menu-category';
        categoryDiv.id = category.id;
        categoryDiv.dataset.categoryId = category.id;

        // Заголовок категории
        const headerHTML = this.createCategoryHeader(category);

        // Контейнер для товаров (пока пустой)
        const itemsContainer = document.createElement('div');
        itemsContainer.className = 'menu-items-container';
        itemsContainer.id = `items-${category.id}`;

        categoryDiv.innerHTML = headerHTML;
        categoryDiv.appendChild(itemsContainer);

        // Добавляем отступ между категориями
        categoryDiv.style.marginBottom = '3rem';

        return categoryDiv;
    }

    createCategoryHeader(category) {
        const currentLang = this.getCurrentLanguage();
        const categoryName = this.getCategoryName(category, currentLang);

        return `
            <div style="max-width: 1200px; margin: 0 auto; padding: 0 1rem;">
                <div class="framer-ctytay">
                    <div class="framer-14yj1y1">
                        <div class="framer-ip9mw5" data-border="true" data-framer-name="Icon" style="transform:rotate(-45deg); background-color: var(--token-68c05b50-ca7b-4173-82aa-ed42aea1a9b4, rgb(232, 232, 232)); width: 8px; height: 8px; border: 1px solid var(--token-68c05b50-ca7b-4173-82aa-ed42aea1a9b4, rgb(232, 232, 232));"></div>
                        <div class="framer-bnmzg6" data-framer-name="Line" style="background-color: var(--token-68c05b50-ca7b-4173-82aa-ed42aea1a9b4, rgb(232, 232, 232)); height: 1px; flex: 1;"></div>
                    </div>
                    <div class="framer-om33u4" data-framer-component-type="RichTextContainer" style="outline:none;display:flex;flex-direction:column;justify-content:flex-start;flex-shrink:0;transform:none; margin: 0 1rem;">
                        <h2 class="framer-text framer-styles-preset-12lj5ox category-title" data-styles-preset="YckFIlg3V" style="color: var(--token-b0d5b115-8d5e-4849-a7e4-d3bb5b253c70, rgb(239, 230, 210)); font-size: 2rem; font-weight: 600; margin: 0;">${categoryName}${category.spicy ? ' 🌶️' : ''}</h2>
                    </div>
                    <div class="framer-1h4if96">
                        <div class="framer-194wd46" data-framer-name="Line" style="background-color: var(--token-68c05b50-ca7b-4173-82aa-ed42aea1a9b4, rgb(232, 232, 232)); height: 1px; flex: 1;"></div>
                        <div class="framer-pxgvsy" data-border="true" data-framer-name="Icon" style="transform:rotate(-45deg); background-color: var(--token-68c05b50-ca7b-4173-82aa-ed42aea1a9b4, rgb(232, 232, 232)); width: 8px; height: 8px; border: 1px solid var(--token-68c05b50-ca7b-4173-82aa-ed42aea1a9b4, rgb(232, 232, 232));"></div>
                    </div>
                </div>
            </div>
        `;
    }



    async loadCategoryItems(categoryId) {
        // Проверка на дублирование с улучшенной защитой
        if (this.isLoading || this.loadedCategories.has(categoryId)) {
            console.log(`⏭️ Пропускаем загрузку ${categoryId} - уже загружается или загружена`);
            return;
        }

        // Добавляем блокировку сразу
        this.loadedCategories.add(categoryId);
        this.isLoading = true;

        console.log(`🔄 Загружаем товары для категории: ${categoryId}`);

        try {
            const category = this.menuData.categories.find(cat => cat.id === categoryId);
            if (!category || !category.items) {
                console.warn(`⚠️ Категория ${categoryId} не найдена или пуста`);
                return;
            }

            const container = document.getElementById(`items-${categoryId}`);
            if (!container) {
                console.warn(`⚠️ Контейнер для категории ${categoryId} не найден`);
                return;
            }

            // Проверяем, не загружены ли уже товары
            if (container.children.length > 0 && !container.querySelector('.loading-indicator')) {
                console.log(`✅ Товары для ${categoryId} уже загружены`);
                return;
            }

            // НОВОЕ: Устанавливаем минимальную высоту для стабильности
            const estimatedHeight = category.items.length * 180; // Примерная высота карточки
            container.style.minHeight = `${estimatedHeight}px`;

            // Очищаем контейнер перед загрузкой
            container.innerHTML = '';

            // Показываем индикатор загрузки
            const loadingIndicator = document.createElement('div');
            loadingIndicator.className = 'loading-indicator';
            loadingIndicator.innerHTML = `
                <div class="loading-spinner"></div>
                Загрузка товаров...
            `;
            container.appendChild(loadingIndicator);

            // Имитируем небольшую задержку для плавности
            await new Promise(resolve => setTimeout(resolve, 50));

            // Загружаем товары пакетами
            await this.loadItemsInBatches(category, container);

            // Убираем индикатор загрузки и минимальную высоту
            if (container.contains(loadingIndicator)) {
                container.removeChild(loadingIndicator);
            }
            container.style.minHeight = '';

            console.log(`✅ Товары загружены для категории: ${categoryId}`);

            // Инициализируем lazy loading для изображений с небольшой задержкой
            setTimeout(() => {
                this.initLazyLoading(container);
            }, 100);

        } catch (error) {
            console.error(`❌ Ошибка загрузки категории ${categoryId}:`, error);
            // Убираем из загруженных при ошибке, чтобы можно было попробовать снова
            this.loadedCategories.delete(categoryId);
        } finally {
            this.isLoading = false;
        }
    }

    async loadItemsInBatches(category, container) {
        const items = category.items || [];
        const batches = [];

        // Разделяем товары на пакеты
        for (let i = 0; i < items.length; i += this.itemsPerBatch) {
            batches.push(items.slice(i, i + this.itemsPerBatch));
        }

        // Загружаем пакеты по очереди
        for (let i = 0; i < batches.length; i++) {
            const batch = batches[i];
            const batchElements = batch.map((item, index) => {
                const element = this.createItemCard(item, index);
                element.classList.add('card-fade-in');
                return element;
            });

            // Добавляем пакет в DOM
            batchElements.forEach(element => container.appendChild(element));

            // Небольшая пауза между пакетами для плавности
            if (i < batches.length - 1) {
                await new Promise(resolve => setTimeout(resolve, 20));
            }
        }
    }

    createItemCard(item, itemIndex) {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'ssr-variant hidden-1td9vov hidden-okrmbe menu-item-card';
        itemDiv.dataset.itemId = item.id;

        // Получаем текущий язык для правильного отображения
        const currentLang = this.getCurrentLanguage();

        const itemContainer = document.createElement('div');
        itemContainer.className = 'framer-rto2k8-container modern-card-container';

        const isDualPrice = item.type === 'dual_price';
        const isAlcohol = item.type === 'alcohol';

        // Проверяем наличие изображения и описания
        const hasImage = item.image && item.image.trim() !== '' && item.image !== 'undefined' && item.image !== 'null' && !item.image.includes('placeholder');
        const hasDescription = item.description && item.description.trim() !== '' && item.description !== 'undefined' && item.description !== 'null';

        // Создаем HTML с новым современным дизайном
        itemContainer.innerHTML = `
            <div class="modern-menu-card ${isDualPrice ? 'dual-price-card' : ''} ${isAlcohol ? 'alcohol-card' : ''} ${!hasImage ? 'no-image' : ''}"
                 data-framer-name="Desktop"
                 data-full-description="${hasDescription ? this.getItemDescription(item, currentLang).replace(/"/g, '&quot;') : ''}"
                 data-item-name="${this.getItemName(item, currentLang).replace(/"/g, '&quot;')}"
                 style="width: 100%; opacity: 1;">
                ${hasImage ? `
                <div class="card-image-container">
                    <div class="card-image-wrapper">
                        <img alt="${item.name}"
                             decoding="async"
                             src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzIyMjIyMiIvPgogIDx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTRweCIgZmlsbD0iIzY2NjY2NiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkxvYWRpbmcuLi48L3RleHQ+Cjwvc3ZnPg=="
                             data-src="${item.image}"
                             class="card-image lazy-loading"
                             onerror="this.src='https://via.placeholder.com/300x200?text=No+Image'"/>
                        ${item.spicy ? '<div class="spicy-badge">🌶️</div>' : ''}
                    </div>
                </div>
                ` : ''}
                <div class="card-content">
                    <div class="card-header">
                        <h3 class="item-name">${this.getItemName(item, currentLang)}</h3>
                    </div>
                    ${hasDescription ? `<p class="item-description">${this.truncateDescription(this.getItemDescription(item, currentLang))}</p>` : ''}
                    ${isDualPrice ?
                        `<div class="dual-price-section">
                            <div class="price-divider"></div>
                            <div class="dual-prices">
                                <div class="price-option">
                                    <div class="price-container">
                                        <span class="price">${this.formatPrice(item.price1)}</span>
                                        <span class="description">${this.getCurrentPriceDescription(item, 'price1Desc')}</span>
                                    </div>
                                </div>
                                <div class="price-option">
                                    <div class="price-container">
                                        <span class="price">${this.formatPrice(item.price2)}</span>
                                        <span class="description">${this.getCurrentPriceDescription(item, 'price2Desc')}</span>
                                    </div>
                                </div>
                            </div>
                        </div>` :
                        isAlcohol ?
                            item.volume ?
                                `<div class="dual-price-section">
                                    <div class="price-divider"></div>
                                    <div class="dual-prices">
                                        <div class="price-option alcohol-option">
                                            <div class="alcohol-price-row">
                                                <span class="price">${this.formatPrice(item.price)}</span>
                                                <span class="description">${this.getCurrentVolume(item)}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>` :
                                `<div class="single-price-section">
                                    <div class="price-divider"></div>
                                    <div class="single-price-container">
                                        <div class="price-tag">${this.formatPrice(item.price)}</div>
                                    </div>
                                </div>` :
                            `<div class="single-price-section">
                                <div class="price-divider"></div>
                                <div class="single-price-container">
                                    <div class="price-tag">${this.formatPrice(item.price)}</div>
                                </div>
                            </div>`
                    }
                </div>
            </div>
        `;

        itemDiv.appendChild(itemContainer);

        // Добавляем анимацию загрузки
        itemDiv.classList.add('loading');
        setTimeout(() => {
            itemDiv.classList.remove('loading');
            itemDiv.classList.add('loaded');
        }, 100 + itemIndex * 50);

        // Добавляем улучшенные hover эффекты
        itemDiv.addEventListener('mouseenter', () => {
            const card = itemContainer.querySelector('.modern-menu-card');
            card.style.transform = 'translateY(-5px)';
            card.style.boxShadow = '0 15px 35px rgba(0,0,0,0.3)';
        });

        itemDiv.addEventListener('mouseleave', () => {
            const card = itemContainer.querySelector('.modern-menu-card');
            card.style.transform = 'translateY(0)';
            card.style.boxShadow = '0 8px 25px rgba(0,0,0,0.15)';
        });

        return itemDiv;
    }

    // Получение текущего языка
    getCurrentLanguage() {
        if (window.languageManager) {
            return window.languageManager.getCurrentLanguage();
        }
        return localStorage.getItem('selectedLanguage') || 'en';
    }

    // Получение названия товара с учетом языка
    getItemName(item, lang) {
        if (lang === 'ru' && item.nameRu) {
            return item.nameRu;
        } else if (lang === 'lv' && item.nameLv) {
            return item.nameLv;
        }
        return item.name || '';
    }

    // Получение описания товара с учетом языка
    getItemDescription(item, lang) {
        if (lang === 'ru' && item.descriptionRu) {
            return item.descriptionRu;
        } else if (lang === 'lv' && item.descriptionLv) {
            return item.descriptionLv;
        }
        return item.description || '';
    }

    // Получение названия категории с учетом языка
    getCategoryName(category, lang) {
        if (lang === 'ru' && category.nameRu) {
            return category.nameRu;
        } else if (lang === 'lv' && category.nameLv) {
            return category.nameLv;
        }
        return category.name || '';
    }

    // Получение описания цены с учетом языка
    getCurrentPriceDescription(item, field) {
        const lang = this.getCurrentLanguage();

        if (lang === 'ru') {
            const ruField = field.replace('Desc', 'DescRu');
            if (item[ruField]) return item[ruField];
        } else if (lang === 'lv') {
            const lvField = field.replace('Desc', 'DescLv');
            if (item[lvField]) return item[lvField];
        }

        return item[field] || '';
    }

    // Функция для обрезки описания до 70 символов с разбивкой длинных слов
    truncateDescription(description) {
        if (!description || description.length <= 70) {
            return description;
        }

        // Разбиваем длинные слова для лучшего отображения на мобильных
        const processedDescription = this.breakLongWords(description);

        // Обрезаем до 70 символов
        let truncated = processedDescription.substring(0, 70);

        // Находим последний пробел, чтобы не обрезать слово посередине
        const lastSpaceIndex = truncated.lastIndexOf(' ');
        if (lastSpaceIndex > 50) { // Если пробел достаточно близко к концу
            truncated = truncated.substring(0, lastSpaceIndex);
        }

        return truncated + '...';
    }

    // Функция для разбивки длинных слов
    breakLongWords(text) {
        if (!text) return '';

        return text.split(' ').map(word => {
            // Если слово длиннее 12 символов, добавляем мягкие переносы
            if (word.length > 12) {
                return word.replace(/(.{8})/g, '$1\u00AD'); // Добавляем мягкий перенос каждые 8 символов
            }
            return word;
        }).join(' ');
    }

    getDefaultMenuData() {
        return {
            pageTitle: "Меню",
            hero: {
                title: "Меню",
                backgroundImage: ""
            },
            categories: [
                {
                    id: "maki",
                    name: "Maki",
                    items: [
                        {
                            id: "spicy-tuna-maki",
                            name: "Spicy Tuna Maki",
                            price: "$5",
                            description: "A tantalizing blend of spicy tuna, cucumber, and avocado, harmoniously rolled in nori and seasoned rice.",
                            image: "https://via.placeholder.com/300x200?text=Spicy+Tuna+Maki",
                            spicy: true
                        },
                        {
                            id: "salmon-maki",
                            name: "Salmon Maki",
                            price: "$5",
                            description: "Fresh salmon wrapped in perfectly seasoned rice and nori seaweed.",
                            image: "https://via.placeholder.com/300x200?text=Salmon+Maki",
                            spicy: false
                        }
                    ]
                },
                {
                    id: "urmaki",
                    name: "Uramaki",
                    items: [
                        {
                            id: "volcano-delight",
                            name: "Volcano Delight",
                            price: "$12",
                            description: "Creamy crab salad, avocado, and cucumber rolled inside, topped with spicy tuna and drizzled with fiery sriracha sauce.",
                            image: "https://via.placeholder.com/300x200?text=Volcano+Delight",
                            spicy: true
                        }
                    ]
                },
                {
                    id: "special",
                    name: "Special Rolls",
                    items: [
                        {
                            id: "sunrise-bliss",
                            name: "Sunrise Bliss",
                            price: "$16",
                            description: "A delicate combination of fresh salmon, cream cheese, and asparagus, rolled in orange-hued tobiko for a burst of sunrise-inspired flavors.",
                            image: "https://via.placeholder.com/300x200?text=Sunrise+Bliss",
                            spicy: false
                        }
                    ]
                }
            ]
        };
    }

    async loadMenuData() {
        try {
            // Пытаемся загрузить с сервера
            const timestamp = Date.now();
            const response = await fetch(`../data/menu-data.json?t=${timestamp}&r=${Math.random()}`, {
                method: 'GET',
                headers: {
                    'Cache-Control': 'no-cache, no-store, must-revalidate',
                    'Pragma': 'no-cache',
                    'Expires': '0'
                },
                cache: 'no-cache'
            });

            if (response.ok) {
                const data = await response.json();
                this.menuData = data;
                console.log('📡 MenuCards: Данные загружены с сервера', data);

                // Сохраняем в localStorage как бэкап
                localStorage.setItem('menuData', JSON.stringify(data));
                return;
            }
        } catch (error) {
            console.log('⚠️ MenuCards: Ошибка загрузки с сервера:', error);
        }

        // Fallback к localStorage
        try {
            const localData = localStorage.getItem('menuData');
            if (localData) {
                this.menuData = JSON.parse(localData);
                console.log('💾 MenuCards: Данные загружены из localStorage');
                return;
            }
        } catch (error) {
            console.log('⚠️ MenuCards: Ошибка загрузки из localStorage:', error);
        }

        // Последний fallback - дефолтные данные с примерами
        this.menuData = this.getDefaultMenuData();
        console.log('🔄 MenuCards: Используем дефолтные данные');
    }

    renderErrorMessage() {
        let container = document.getElementById('dynamic-menu-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'dynamic-menu-container';
            document.body.appendChild(container);
        }

        container.innerHTML = `
            <div class="menu-error-state" style="
                padding: 3rem 2rem;
                text-align: center;
                background: var(--token-cd2934a7-4e35-4347-a32c-9650fca4db23, rgba(24, 24, 24, 0.7));
                border-radius: 12px;
                border: 2px solid #ff6b6b;
                margin: 2rem 0;
            ">
                <div style="font-size: 3rem; margin-bottom: 1rem;">⚠️</div>
                <h3 style="color: #ff6b6b; margin-bottom: 1rem;">Ошибка загрузки меню</h3>
                <p style="color: var(--token-797a2fb4-2d14-46eb-9fb6-f38c1a9a545e, rgb(245, 242, 234)); opacity: 0.8; line-height: 1.6; margin-bottom: 1.5rem;">
                    Произошла ошибка при загрузке меню. Попробуйте обновить страницу.
                </p>
                <button onclick="window.location.reload()" style="
                    background: #ff6b6b;
                    color: white;
                    border: none;
                    padding: 0.75rem 1.5rem;
                    border-radius: 6px;
                    cursor: pointer;
                    font-size: 1rem;
                ">Обновить страницу</button>
            </div>
        `;
    }

    setupUpdateListeners() {
        console.log('📡 MenuCards: Настраиваем слушатели обновлений');

        // Слушаем сообщения от админ панели
        window.addEventListener('message', (event) => {
            if (event.data.type === 'menuDataUpdate') {
                console.log('🔄 MenuCards: Получено обновление через postMessage');
                this.handleDataUpdate(event.data.data);
            }
        });

        // Слушаем изменения в localStorage
        window.addEventListener('storage', (event) => {
            if (event.key === 'menuData' && event.newValue) {
                console.log('🔄 MenuCards: Получено обновление через storage');
                this.handleDataUpdate(JSON.parse(event.newValue));
            }

            if (event.key === 'menuForceReload' && event.newValue === 'true') {
                console.log('🔄 MenuCards: Принудительная перезагрузка');
                setTimeout(() => {
                    window.location.reload();
                }, 500);
            }
        });

        // Слушаем кастомные события
        window.addEventListener('menuDataForceUpdate', (event) => {
            if (event.detail && event.detail.data) {
                console.log('🔄 MenuCards: Получено обновление через CustomEvent');
                this.handleDataUpdate(event.detail.data);
            }
        });

        // Слушаем изменения языка
        window.addEventListener('languageChanged', (event) => {
            console.log('🌐 MenuCards: Язык изменен, обновляем отображение');
            const newLang = event.detail.language;

            // Обновляем уже загруженный контент
            this.updateContentWithLanguage(newLang);

            // НЕ перерендериваем все меню, чтобы не потерять состояние загрузки
        });

        // BroadcastChannel если поддерживается
        try {
            if (typeof BroadcastChannel !== 'undefined') {
                this.broadcastChannel = new BroadcastChannel('menuUpdates');
                this.broadcastChannel.addEventListener('message', (event) => {
                    if (event.data.type === 'menuDataUpdate') {
                        console.log('🔄 MenuCards: Получено обновление через BroadcastChannel');
                        this.handleDataUpdate(event.data.data);
                    }
                });
            }
        } catch (error) {
            console.log('BroadcastChannel не поддерживается');
        }

        // Периодическая проверка обновлений каждые 30 секунд
        setInterval(() => {
            this.checkForUpdates();
        }, 30000);

        // Проверка при фокусе на странице
        window.addEventListener('focus', () => {
            this.checkForUpdates();
        });
    }

    handleDataUpdate(newData) {
        if (!newData) return;

        console.log('🔄 MenuCards: Обрабатываем обновление данных');

        // Сравниваем с текущими данными
        const currentDataStr = JSON.stringify(this.menuData);
        const newDataStr = JSON.stringify(newData);

        if (currentDataStr !== newDataStr) {
            this.menuData = newData;

            // Сохраняем в localStorage
            localStorage.setItem('menuData', newDataStr);

            // Перерендериваем меню
            this.loadedCategories.clear();
            this.renderMenuLazy();

            // Показываем уведомление
            // this.showUpdateNotification();

            console.log('✅ MenuCards: Данные обновлены и меню перерендерено');
        }
    }

    async checkForUpdates() {
        try {
            // Проверяем флаг принудительного обновления
            if (localStorage.getItem('menuForceReload') === 'true') {
                console.log('🔄 MenuCards: Принудительная перезагрузка');
                localStorage.removeItem('menuForceReload');
                window.location.reload();
                return;
            }

            const timestamp = Date.now();
            const response = await fetch(`../data/menu-data.json?t=${timestamp}&r=${Math.random()}`, {
                method: 'GET',
                headers: {
                    'Cache-Control': 'no-cache, no-store, must-revalidate',
                    'Pragma': 'no-cache',
                    'Expires': '0'
                },
                cache: 'no-cache'
            });

            if (response.ok) {
                const newData = await response.json();
                this.handleDataUpdate(newData);
            }
        } catch (error) {
            // Тихо игнорируем ошибки периодической проверки
            console.log('Периодическая проверка не удалась:', error);
        }
    }

    showUpdateNotification() {
        // Создаем уведомление
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            box-shadow: 0 4px 12px rgba(34, 197, 94, 0.3);
            z-index: 10000;
            transform: translateX(400px);
            transition: all 0.3s ease;
        `;
        notification.textContent = '🍽️ Меню обновлено!';

        document.body.appendChild(notification);

        // Показываем
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);

        // Убираем через 3 секунды
        setTimeout(() => {
            notification.style.transform = 'translateX(400px)';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    // Метод для принудительного обновления (может быть вызван извне)
    async forceReload() {
        console.log('🔄 MenuCards: Принудительное обновление');
        await this.loadMenuData();
        this.loadedCategories.clear();
        this.renderMenuLazy();
    }

    // Инициализируем lazy loading для изображений
    initLazyLoading(container) {
        if (!window.lazyLoader) {
            console.warn('⚠️ MenuCards: Lazy Loader не найден');
            return;
        }

        // Находим все изображения с data-src
        const lazyImages = container.querySelectorAll('img[data-src]');
        console.log(`🖼️ MenuCards: Настраиваем lazy loading для ${lazyImages.length} изображений`);

        // Немедленно загружаем первые несколько изображений
        const immediateLoadCount = Math.min(3, lazyImages.length);

        lazyImages.forEach((img, index) => {
            const actualSrc = img.dataset.src;
            // Проверяем что src не пустой и не placeholder значения
            if (actualSrc &&
                actualSrc.trim() !== '' &&
                actualSrc !== 'undefined' &&
                actualSrc !== 'null' &&
                !actualSrc.includes('placeholder')) {

                // Загружаем первые изображения немедленно
                if (index < immediateLoadCount) {
                    window.lazyLoader.loadImage(img, actualSrc);
                } else {
                    window.lazyLoader.setupLazyImage(img, actualSrc);
                }
            } else {
                // Если изображения нет, скрываем контейнер
                const imageContainer = img.closest('.card-image-container');
                if (imageContainer) {
                    imageContainer.style.display = 'none';
                    // Добавляем класс no-image к карточке
                    const card = img.closest('.modern-menu-card');
                    if (card) {
                        card.classList.add('no-image');
                    }
                }
            }
        });
    }

    getCurrentPriceDescription(item, field) {
        let currentLang = 'en';

        // Получаем язык от MultilingualManager если доступен
        if (window.multilingualManager) {
            currentLang = window.multilingualManager.currentLanguage;
        } else if (window.languageManager) {
            currentLang = window.languageManager.getCurrentLanguage();
        } else {
            // Fallback
            currentLang = localStorage.getItem('selectedLanguage') || document.documentElement.lang || 'en';
        }

        if (currentLang === 'ru' && item[field + 'Ru']) {
            return item[field + 'Ru'];
        } else if (currentLang === 'lv' && item[field + 'Lv']) {
            return item[field + 'Lv'];
        } else {
            return item[field] || '';
        }
    }

    getCurrentVolume(item) {
        let currentLang = 'en';

        // Получаем язык от MultilingualManager если доступен
        if (window.multilingualManager) {
            currentLang = window.multilingualManager.currentLanguage;
        } else if (window.languageManager) {
            currentLang = window.languageManager.getCurrentLanguage();
        } else {
            // Fallback
            currentLang = localStorage.getItem('selectedLanguage') || document.documentElement.lang || 'en';
        }

        if (currentLang === 'ru' && item.volumeRu) {
            return item.volumeRu;
        } else if (currentLang === 'lv' && item.volumeLv) {
            return item.volumeLv;
        } else {
            return item.volume || '';
        }
    }

    formatPrice(price) {
        const currency = this.menuData?.currency || '€';
        if (!price) return '';
        const numericPrice = price.replace(/[^\d.,]/g, '');
        return `${numericPrice}${currency}`;
    }

    // Метод для обновления контента с учетом языка
    updateContentWithLanguage(lang) {
        console.log(`🍽️ MenuCards: Обновление контента для языка ${lang}`);

        if (!this.menuData?.categories) return;

        // Обновляем все загруженные категории
        this.menuData.categories.forEach(category => {
            // Обновляем заголовок категории
            const categoryElement = document.getElementById(category.id);
            if (categoryElement) {
                const categoryTitle = categoryElement.querySelector('.category-title');
                if (categoryTitle) {
                    const categoryName = this.getCategoryName(category, lang);
                    categoryTitle.textContent = categoryName + (category.spicy ? ' 🌶️' : '');
                }
            }

            // Если категория загружена, обновляем ее элементы
            if (this.loadedCategories.has(category.id)) {
                category.items.forEach(item => {
                    this.updateItemTranslations(item, lang);
                });
            }
        });
    }

    // Метод для обновления переводов отдельного элемента
    updateItemTranslations(item, lang) {
        const itemElement = document.querySelector(`[data-item-id="${item.id}"]`);
        if (!itemElement) return;

        // Обновляем название
        const itemName = itemElement.querySelector('.item-name');
        if (itemName) {
            itemName.textContent = this.getItemName(item, lang);
        }

        // Обновляем описание
        const itemDescription = itemElement.querySelector('.item-description');
        if (itemDescription) {
            const description = this.getItemDescription(item, lang);
            itemDescription.textContent = this.truncateDescription(description);
        }

        // Обновляем описания цен для dual-price карточек
        if (item.type === 'dual_price') {
            const price1Desc = itemElement.querySelector('.price-option:first-child .description');
            if (price1Desc) {
                price1Desc.textContent = this.getCurrentPriceDescription(item, 'price1Desc');
            }

            const price2Desc = itemElement.querySelector('.price-option:last-child .description');
            if (price2Desc) {
                price2Desc.textContent = this.getCurrentPriceDescription(item, 'price2Desc');
            }
        }

        // Обновляем объем для алкогольных карточек
        if (item.type === 'alcohol' && item.volume) {
            const volumeElement = itemElement.querySelector('.alcohol-option .description');
            if (volumeElement) {
                volumeElement.textContent = this.getCurrentVolume(item);
            }
        }
    }

    // Принудительная загрузка всех категорий (вызывается из multilingual.js)
    async forceLoadAllCategories() {
        if (!this.menuData?.categories) return;

        console.log('🔄 MenuCards: Принудительная загрузка всех категорий');

        const loadPromises = this.menuData.categories.map(category => {
            if (!this.loadedCategories.has(category.id)) {
                return this.loadCategoryItems(category.id);
            }
            return Promise.resolve();
        });

        await Promise.all(loadPromises);
        console.log('✅ MenuCards: Все категории загружены');
    }

    // Очистка при выгрузке страницы
    cleanup() {
        if (this.broadcastChannel) {
            this.broadcastChannel.close();
        }
        if (this.intersectionObserver) {
            this.intersectionObserver.disconnect();
        }
    }
}

// Инициализируем при загрузке DOM
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 MenuCards: DOM загружен, инициализируем...');
    window.menuCards = new MenuCards();
});

// Очистка при выгрузке
window.addEventListener('beforeunload', () => {
    if (window.menuCards) {
        window.menuCards.cleanup();
    }
});

/* --- Минималистичные стили для скелетонов и ленивой загрузки (можно вынести в CSS) --- */
const style = document.createElement('style');
style.innerHTML = `
.skeleton-loader {
    background: linear-gradient(90deg, #e0e0e0 25%, #f5f5f5 50%, #e0e0e0 75%);
    background-size: 200% 100%;
    animation: skeleton-loading 1.2s infinite linear;
    border-radius: 4px;
}
@keyframes skeleton-loading {
    0% { background-position: 200% 0; }
    100% { background-position: -200% 0; }
}
.skeleton-category { margin-bottom: 2rem; }
.skeleton-category-title { width: 180px; height: 32px; margin: 0 auto 1.5rem auto; }
.skeleton-card { display: flex; gap: 1rem; margin-bottom: 1rem; background: #232323; border-radius: 10px; padding: 1rem; }
.skeleton-image { width: 120px; height: 80px; border-radius: 8px; }
.skeleton-content { flex: 1; display: flex; flex-direction: column; gap: 0.5rem; }
.skeleton-title { width: 60%; height: 20px; }
.skeleton-description { width: 90%; height: 14px; }
.skeleton-price { width: 40%; height: 18px; margin-top: 0.5rem; }
.loading-indicator { display: flex; align-items: center; gap: 1rem; justify-content: center; margin: 2rem 0; color: #ccc; font-size: 1.1rem; }
.loading-spinner {
    width: 28px; height: 28px; border: 4px solid #e0e0e0; border-top: 4px solid #bdbdbd;
    border-radius: 50%; animation: spin 1s linear infinite;
}
@keyframes spin { 100% { transform: rotate(360deg); } }
.card-fade-in { animation: fadeInCard 0.4s; }
@keyframes fadeInCard { from { opacity: 0; transform: translateY(20px);} to { opacity: 1; transform: none; } }
.load-more-sentinel { height: 1px; }
`;
document.head.appendChild(style);
