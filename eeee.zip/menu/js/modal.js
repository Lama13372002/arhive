/**
 * Модальные окна для товаров меню
 * Поддерживает карточки с одной ценой, двумя ценами и алкогольные карточки
 * Адаптивный дизайн для всех устройств
 */

class MenuModal {
    constructor() {
        this.modalOverlay = null;
        this.modalContainer = null;
        this.isOpen = false;
        this.currentItem = null;
        this.selectedPrice = null;
        this.init();
    }

    init() {
        this.createModal();
        this.bindEvents();
        this.setupLanguageListener();
    }

    setupLanguageListener() {
        // Слушаем изменения языка
        document.addEventListener('languageChanged', (event) => {
            this.updateModalLanguage(event.detail.language);
        });
    }

    updateModalLanguage(lang) {
        // Обновляем кнопку "Добавить в корзину"
        const addToCartBtn = document.getElementById('addToCartBtn');
        if (addToCartBtn && window.multilingualManager && window.multilingualManager.translations[lang]) {
            const span = addToCartBtn.querySelector('span');
            if (span) {
                span.textContent = window.multilingualManager.translations[lang].addToCart;
            }
        }

        // КРИТИЧНО: Обновляем содержимое модального окна, если оно открыто
        if (this.isOpen && this.currentItem) {
            console.log('🔄 Modal: Обновление содержимого модального окна для языка', lang);
            this.updateModalContent(lang);
        }
    }

    // Новый метод для обновления содержимого модального окна при смене языка
    updateModalContent(lang) {
        if (!this.currentItem || !window.multilingualManager) return;

        // Используем сохраненные оригинальные данные или ищем в menuData
        let foundItem = this.currentItem.originalData;

        if (!foundItem) {
            const menuData = window.multilingualManager.menuData;
            if (!menuData) return;

            // Ищем текущий элемент в данных меню для получения переводов
            for (const category of menuData.categories) {
                foundItem = category.items.find(item => item.name === this.currentItem.name || item.id === this.currentItem.id);
                if (foundItem) break;
            }
        }

        if (!foundItem) {
            console.warn('Modal: Элемент не найден в данных меню для перевода');
            return;
        }

        // Обновляем название
        const titleElement = document.getElementById('modalTitle');
        if (titleElement) {
            let name = foundItem.name;
            if (lang === 'ru' && foundItem.nameRu) {
                name = foundItem.nameRu;
            } else if (lang === 'lv' && foundItem.nameLv) {
                name = foundItem.nameLv;
            }
            titleElement.textContent = name;
            console.log(`✅ Modal: Обновлено название на ${name}`);
        }

        // Обновляем описание
        const descriptionElement = document.getElementById('modalDescription');
        if (descriptionElement) {
            let description = foundItem.description;
            if (lang === 'ru' && foundItem.descriptionRu) {
                description = foundItem.descriptionRu;
            } else if (lang === 'lv' && foundItem.descriptionLv) {
                description = foundItem.descriptionLv;
            }

            if (description) {
                descriptionElement.textContent = description;
                descriptionElement.style.display = 'block';
                console.log(`✅ Modal: Обновлено описание`);
            } else {
                descriptionElement.style.display = 'none';
            }
        }

        // Обновляем бейджи
        this.updateModalBadges(lang);

        // Обновляем описания цен для товаров с несколькими ценами
        this.updateModalPriceDescriptions(foundItem, lang);
    }

    // Обновление бейджей с учетом языка
    updateModalBadges(lang) {
        const badgesContainer = document.getElementById('modalBadges');
        if (!badgesContainer || !this.currentItem) return;

        badgesContainer.innerHTML = '';

        const translations = window.multilingualManager?.translations[lang];
        if (!translations) return;

        if (this.currentItem.isSpicy) {
            const spicyBadge = document.createElement('div');
            spicyBadge.className = 'modal-spicy-badge';
            spicyBadge.textContent = `🌶️ ${translations.spicy}`;
            badgesContainer.appendChild(spicyBadge);
        }

        if (this.currentItem.isAlcohol) {
            const alcoholBadge = document.createElement('div');
            alcoholBadge.className = 'modal-alcohol-badge';
            alcoholBadge.textContent = `🍺 ${translations.alcohol}`;
            badgesContainer.appendChild(alcoholBadge);
        }
    }

    // Обновление описаний цен для товаров с несколькими ценами
    updateModalPriceDescriptions(item, lang) {
        if (!item) return;

        // Обработка товаров с двумя ценами
        if (item.type === 'dual_price') {
            const price1DescElements = document.querySelectorAll('.modal-price-description');
            if (price1DescElements.length >= 1) {
                let price1Desc = item.price1Desc;
                if (lang === 'ru' && item.price1DescRu) {
                    price1Desc = item.price1DescRu;
                } else if (lang === 'lv' && item.price1DescLv) {
                    price1Desc = item.price1DescLv;
                }
                if (price1Desc) price1DescElements[0].textContent = price1Desc;
            }

            // Обновляем описания для второй цены
            if (price1DescElements.length >= 2) {
                let price2Desc = item.price2Desc;
                if (lang === 'ru' && item.price2DescRu) {
                    price2Desc = item.price2DescRu;
                } else if (lang === 'lv' && item.price2DescLv) {
                    price2Desc = item.price2DescLv;
                }
                if (price2Desc) price1DescElements[1].textContent = price2Desc;
            }
        }

        // Обработка алкогольных товаров с объемом
        if (item.type === 'alcohol' && item.volume) {
            const volumeElements = document.querySelectorAll('.modal-price-description');
            volumeElements.forEach(vol => {
                let volume = item.volume;
                if (lang === 'ru' && item.volumeRu) {
                    volume = item.volumeRu;
                } else if (lang === 'lv' && item.volumeLv) {
                    volume = item.volumeLv;
                }
                if (volume) vol.textContent = volume;
            });
        }
    }

    createModal() {
        // Получаем текущий язык и переводы
        let addToCartText = 'Add to Cart';
        if (window.multilingualManager) {
            const currentLang = window.multilingualManager.getCurrentLanguage();
            const translations = window.multilingualManager.translations[currentLang];
            if (translations) {
                addToCartText = translations.addToCart;
            }
        }

        // Создаем HTML структуру модального окна
        const modalHTML = `
            <div class="modal-overlay" id="menuModal">
                <div class="modal-container">
                    <button class="modal-close" id="modalClose" aria-label="Закрыть модальное окно">
                        ×
                    </button>
                    <div class="modal-image-container">
                        <img class="modal-image" id="modalImage" alt="" style="display: none;">
                        <div class="modal-image-placeholder" id="modalImagePlaceholder" style="display: none;">
                            <svg width="48" height="48" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M21 19V5C21 3.9 20.1 3 19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 19 20.1 21 19ZM8.5 13.5L11 16.51L14.5 12L19 18H5L8.5 13.5Z"/>
                            </svg>
                        </div>
                        <div class="modal-badges" id="modalBadges"></div>
                    </div>
                    <div class="modal-content">
                        <h1 class="modal-title" id="modalTitle"></h1>
                        <p class="modal-description" id="modalDescription"></p>
                        <div class="modal-prices" id="modalPrices"></div>
                    </div>
                    <div class="modal-actions" id="modalActions">
                        <button class="add-to-cart-btn" id="addToCartBtn">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                                <path d="M3 3H5L5.4 5M7 13H17L21 5H5.4M7 13L5.4 5M7 13L4.7 15.3C4.3 15.7 4.6 16.5 5.1 16.5H17M17 13V19C17 20.1 16.1 21 15 21H9C7.9 21 7 20.1 7 19V13M17 13H7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <span>${addToCartText}</span>
                        </button>
                    </div>
                </div>
            </div>
        `;

        // Вставляем модальное окно в body
        document.body.insertAdjacentHTML('beforeend', modalHTML);

        // Сохраняем ссылки на элементы
        this.modalOverlay = document.getElementById('menuModal');
        this.modalContainer = this.modalOverlay.querySelector('.modal-container');
    }

    bindEvents() {
        // Закрытие модального окна
        const closeBtn = document.getElementById('modalClose');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.closeModal());
        }

        // Закрытие по клику на оверлей
        this.modalOverlay.addEventListener('click', (e) => {
            if (e.target === this.modalOverlay) {
                this.closeModal();
            }
        });

        // Закрытие по ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isOpen) {
                this.closeModal();
            }
        });

        // Обработка кликов на карточки товаров
        this.bindCardClicks();

        // Обработка кнопки добавления в корзину
        this.bindAddToCartButton();
    }

    bindCardClicks() {
        // Используем делегирование событий для динамически создаваемых карточек
        document.addEventListener('click', (e) => {
            // Ищем ближайшую карточку товара
            const card = e.target.closest('.modern-menu-card');
            if (!card) return;

            // Проверяем, что клик не был по ссылке или другому интерактивному элементу
            if (e.target.closest('a, button, input, select, textarea')) return;

            e.preventDefault();
            e.stopPropagation();

            this.openModalFromCard(card);
        });
    }

    openModalFromCard(card) {
        try {
            // Извлекаем данные из карточки
            const itemData = this.extractItemDataFromCard(card);
            if (!itemData) {
                console.warn('Не удалось извлечь данные товара из карточки');
                return;
            }

            // Пытаемся найти полные данные элемента в menuData для переводов
            this.findOriginalItemData(itemData);

            this.openModal(itemData);
        } catch (error) {
            console.error('Ошибка при открытии модального окна:', error);
        }
    }

    // Метод для поиска оригинальных данных элемента в menuData
    findOriginalItemData(itemData) {
        if (!window.multilingualManager || !window.multilingualManager.menuData) return;

        const menuData = window.multilingualManager.menuData;

        // Ищем товар по названию или ID
        for (const category of menuData.categories) {
            const foundItem = category.items.find(item =>
                item.name === itemData.name ||
                item.id === itemData.name || // иногда ID может совпадать с именем
                (item.nameRu && item.nameRu === itemData.name) ||
                (item.nameLv && item.nameLv === itemData.name)
            );

            if (foundItem) {
                // Сохраняем ссылку на оригинальные данные для переводов
                itemData.originalData = foundItem;
                itemData.id = foundItem.id; // убеждаемся что ID установлен
                console.log('✅ Modal: Найдены оригинальные данные для товара:', foundItem.name);
                break;
            }
        }
    }

    extractItemDataFromCard(card) {
        try {
            // Используем полное описание из data-атрибута, если доступно
            const itemName = card.dataset.itemName || card.querySelector('.item-name')?.textContent?.trim() || '';
            const itemDescription = card.dataset.fullDescription || card.querySelector('.item-description')?.textContent?.trim() || '';
            const cardImage = card.querySelector('.card-image');
            const imageSrc = cardImage?.src || '';
            const isSpicy = card.querySelector('.spicy-badge') !== null;
            const isAlcohol = card.classList.contains('alcohol-card');
            const isDualPrice = card.classList.contains('dual-price-card');

            // Определяем тип товара и извлекаем цены
            let prices = [];

            if (isDualPrice) {
                // Товар с двумя ценами
                const priceOptions = card.querySelectorAll('.price-option');
                priceOptions.forEach(option => {
                    const priceElement = option.querySelector('.price');
                    const descriptionElement = option.querySelector('.description');

                    if (priceElement) {
                        prices.push({
                            price: priceElement.textContent.trim(),
                            description: descriptionElement?.textContent?.trim() || ''
                        });
                    }
                });
            } else if (isAlcohol) {
                // Алкогольный товар (может быть с volume или без)
                const alcoholPriceRow = card.querySelector('.alcohol-price-row');
                if (alcoholPriceRow) {
                    const priceElement = alcoholPriceRow.querySelector('.price');
                    const descriptionElement = alcoholPriceRow.querySelector('.description');

                    if (priceElement) {
                        prices.push({
                            price: priceElement.textContent.trim(),
                            description: descriptionElement?.textContent?.trim() || ''
                        });
                    }
                } else {
                    // Алкоголь без volume (одна цена)
                    const priceTag = card.querySelector('.price-tag');
                    if (priceTag) {
                        prices.push({
                            price: priceTag.textContent.trim(),
                            description: ''
                        });
                    }
                }
            } else {
                // Обычный товар с одной ценой
                const priceTag = card.querySelector('.price-tag');
                if (priceTag) {
                    prices.push({
                        price: priceTag.textContent.trim(),
                        description: ''
                    });
                }
            }

            return {
                name: itemName,
                description: itemDescription,
                image: imageSrc,
                prices: prices,
                isSpicy: isSpicy,
                isAlcohol: isAlcohol,
                isDualPrice: isDualPrice
            };
        } catch (error) {
            console.error('Ошибка при извлечении данных из карточки:', error);
            return null;
        }
    }

    openModal(itemData) {
        if (!itemData) return;

        // Сохраняем текущий товар
        this.currentItem = itemData;
        this.selectedPrice = null;

        // Заполняем контент модального окна
        this.populateModal(itemData);

        // Показываем модальное окно
        this.showModal();
    }

    populateModal(itemData) {
        // Название товара
        const titleElement = document.getElementById('modalTitle');
        if (titleElement) {
            titleElement.textContent = itemData.name;
        }

        // Описание товара
        const descriptionElement = document.getElementById('modalDescription');
        if (descriptionElement) {
            if (itemData.description) {
                descriptionElement.textContent = itemData.description;
                descriptionElement.style.display = 'block';
            } else {
                descriptionElement.style.display = 'none';
            }
        }

        // Изображение товара
        this.setupModalImage(itemData.image);

        // Бейджи
        this.setupModalBadges(itemData);

        // Цены
        this.setupModalPrices(itemData);

        // Проверяем видимость корзины и обновляем кнопку
        this.checkCartVisibility();

        // Обновляем состояние кнопки добавления в корзину
        this.updateAddToCartButton();
    }

    setupModalImage(imageSrc) {
        const imageElement = document.getElementById('modalImage');
        const placeholderElement = document.getElementById('modalImagePlaceholder');

        if (imageSrc && imageSrc !== '' && !imageSrc.includes('placeholder')) {
            // Есть изображение
            if (imageElement) {
                imageElement.src = imageSrc;
                imageElement.style.display = 'block';

                // Обработка ошибки загрузки изображения
                imageElement.onerror = () => {
                    imageElement.style.display = 'none';
                    if (placeholderElement) {
                        placeholderElement.style.display = 'flex';
                    }
                };
            }
            if (placeholderElement) {
                placeholderElement.style.display = 'none';
            }
        } else {
            // Нет изображения - показываем плейсхолдер
            if (imageElement) {
                imageElement.style.display = 'none';
            }
            if (placeholderElement) {
                placeholderElement.style.display = 'flex';
            }
        }
    }

    setupModalBadges(itemData) {
        const badgesContainer = document.getElementById('modalBadges');
        if (!badgesContainer) return;

        badgesContainer.innerHTML = '';

        // Получаем текущий язык и переводы
        const currentLang = window.multilingualManager ? window.multilingualManager.getCurrentLanguage() : 'en';
        const translations = window.multilingualManager?.translations[currentLang];

        if (itemData.isSpicy) {
            const spicyBadge = document.createElement('div');
            spicyBadge.className = 'modal-spicy-badge';
            const spicyText = translations?.spicy || 'Spicy';
            spicyBadge.textContent = `🌶️ ${spicyText}`;
            badgesContainer.appendChild(spicyBadge);
        }

        if (itemData.isAlcohol) {
            const alcoholBadge = document.createElement('div');
            alcoholBadge.className = 'modal-alcohol-badge';
            const alcoholText = translations?.alcohol || 'Alcohol';
            alcoholBadge.textContent = `🍺 ${alcoholText}`;
            badgesContainer.appendChild(alcoholBadge);
        }
    }

    setupModalPrices(itemData) {
        const pricesContainer = document.getElementById('modalPrices');
        if (!pricesContainer) return;

        pricesContainer.innerHTML = '';
        this.selectedPrice = null;

        if (!itemData.prices || itemData.prices.length === 0) {
            return;
        }

        if (itemData.prices.length === 1 && !itemData.prices[0].description) {
            // Одна цена без описания
            const singlePrice = document.createElement('div');
            singlePrice.className = 'modal-single-price';
            singlePrice.textContent = itemData.prices[0].price;
            pricesContainer.appendChild(singlePrice);

            // Автоматически выбираем единственную цену
            this.selectedPrice = itemData.prices[0];
        } else if (itemData.isDualPrice || itemData.prices.length > 1) {
            // Несколько вариантов цен - делаем их кликабельными
            const dualPricesContainer = document.createElement('div');
            dualPricesContainer.className = 'modal-dual-prices';

            itemData.prices.forEach((priceData, index) => {
                const priceOption = document.createElement('div');
                priceOption.className = itemData.isAlcohol ? 'modal-alcohol-price selectable-price' : 'modal-price-option selectable-price';
                priceOption.dataset.priceIndex = index;

                const priceValue = document.createElement('div');
                priceValue.className = 'modal-price-value';
                priceValue.textContent = priceData.price;
                priceOption.appendChild(priceValue);

                if (priceData.description) {
                    const priceDescription = document.createElement('div');
                    priceDescription.className = 'modal-price-description';
                    priceDescription.textContent = priceData.description;
                    priceOption.appendChild(priceDescription);
                }

                // Добавляем обработчик клика
                priceOption.addEventListener('click', () => {
                    this.selectPrice(priceData, priceOption);
                });

                dualPricesContainer.appendChild(priceOption);
            });

            pricesContainer.appendChild(dualPricesContainer);
        } else {
            // Одна цена с описанием (алкоголь с объемом)
            const alcoholPrice = document.createElement('div');
            alcoholPrice.className = 'modal-alcohol-price';

            const priceValue = document.createElement('div');
            priceValue.className = 'modal-price-value';
            priceValue.textContent = itemData.prices[0].price;
            alcoholPrice.appendChild(priceValue);

            if (itemData.prices[0].description) {
                const priceDescription = document.createElement('div');
                priceDescription.className = 'modal-price-description';
                priceDescription.textContent = itemData.prices[0].description;
                alcoholPrice.appendChild(priceDescription);
            }

            pricesContainer.appendChild(alcoholPrice);

            // Автоматически выбираем единственную цену
            this.selectedPrice = itemData.prices[0];
        }
    }

    showModal() {
        if (!this.modalOverlay) return;

        // Блокируем скролл body
        document.body.classList.add('modal-open');

        // Показываем модальное окно
        this.modalOverlay.classList.add('active');
        this.isOpen = true;

        // Фокус на кнопке закрытия для доступности
        setTimeout(() => {
            const closeBtn = document.getElementById('modalClose');
            if (closeBtn) {
                closeBtn.focus();
            }
        }, 300);
    }

    closeModal() {
        if (!this.modalOverlay) return;

        // Убираем блокировку скролла body
        document.body.classList.remove('modal-open');

        // Скрываем модальное окно
        this.modalOverlay.classList.remove('active');
        this.isOpen = false;

        // Очищаем контент модального окна
        setTimeout(() => {
            this.clearModalContent();
        }, 300);
    }

    selectPrice(priceData, priceElement) {
        // Убираем выделение с всех опций
        const allPriceOptions = document.querySelectorAll('.selectable-price');
        allPriceOptions.forEach(option => option.classList.remove('selected'));

        // Выделяем выбранную опцию
        priceElement.classList.add('selected');

        // Сохраняем выбранную цену
        this.selectedPrice = priceData;

        // Обновляем состояние кнопки добавления в корзину
        this.updateAddToCartButton();
    }

    bindAddToCartButton() {
        document.addEventListener('click', (e) => {
            if (e.target.closest('#addToCartBtn')) {
                e.preventDefault();
                this.handleAddToCart();
            }
        });
    }

    updateAddToCartButton() {
        const addToCartBtn = document.getElementById('addToCartBtn');
        if (!addToCartBtn) return;

        if (this.currentItem && this.selectedPrice) {
            addToCartBtn.disabled = false;
            addToCartBtn.classList.remove('disabled');
        } else if (this.currentItem && (this.currentItem.prices.length === 1 || !this.currentItem.isDualPrice)) {
            // Если только одна цена, кнопка всегда активна
            addToCartBtn.disabled = false;
            addToCartBtn.classList.remove('disabled');
        } else {
            addToCartBtn.disabled = true;
            addToCartBtn.classList.add('disabled');
        }
    }

    handleAddToCart() {
        if (!this.currentItem) return;

        // Определяем цену для добавления
        let priceToAdd = this.selectedPrice;
        if (!priceToAdd && this.currentItem.prices.length === 1) {
            priceToAdd = this.currentItem.prices[0];
        }

        if (!priceToAdd) {
            alert('Пожалуйста, выберите вариант цены');
            return;
        }

        // Создаем объект товара для корзины
        const cartItem = {
            id: Date.now() + Math.random(), // Уникальный ID
            name: this.currentItem.name,
            description: this.currentItem.description,
            image: this.currentItem.image,
            price: priceToAdd.price,
            priceDescription: priceToAdd.description || '',
            isSpicy: this.currentItem.isSpicy,
            isAlcohol: this.currentItem.isAlcohol,
            quantity: 1,
            addedAt: new Date().toISOString()
        };

        // Добавляем в корзину
        if (window.cartManager) {
            window.cartManager.addToCart(cartItem);

            // Показываем уведомление
            this.showAddToCartNotification();

            // Закрываем модальное окно
            setTimeout(() => {
                this.closeModal();
            }, 800);
        } else {
            console.error('Cart manager not found');
        }
    }

    showAddToCartNotification() {
        const addToCartBtn = document.getElementById('addToCartBtn');
        if (!addToCartBtn) return;

        const originalText = addToCartBtn.innerHTML;

        // Получаем текст уведомления на текущем языке
        let addedText = 'Added!';
        if (window.multilingualManager && window.multilingualManager.translations) {
            const currentLang = window.multilingualManager.getCurrentLanguage();
            addedText = window.multilingualManager.translations[currentLang]?.added || 'Added!';
        }

        addToCartBtn.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <span>${addedText}</span>
        `;
        addToCartBtn.classList.add('success');

        setTimeout(() => {
            addToCartBtn.innerHTML = originalText;
            addToCartBtn.classList.remove('success');
        }, 1500);
    }

    clearModalContent() {
        const titleElement = document.getElementById('modalTitle');
        const descriptionElement = document.getElementById('modalDescription');
        const imageElement = document.getElementById('modalImage');
        const placeholderElement = document.getElementById('modalImagePlaceholder');
        const badgesContainer = document.getElementById('modalBadges');
        const pricesContainer = document.getElementById('modalPrices');

        if (titleElement) titleElement.textContent = '';
        if (descriptionElement) {
            descriptionElement.textContent = '';
            descriptionElement.style.display = 'none';
        }
        if (imageElement) {
            imageElement.src = '';
            imageElement.style.display = 'none';
        }
        if (placeholderElement) placeholderElement.style.display = 'none';
        if (badgesContainer) badgesContainer.innerHTML = '';
        if (pricesContainer) pricesContainer.innerHTML = '';

        // Сбрасываем состояние
        this.currentItem = null;
        this.selectedPrice = null;
    }

    // Публичные методы для внешнего использования
    checkCartVisibility() {
        const addToCartBtn = document.getElementById('addToCartBtn');
        const modalActions = document.getElementById('modalActions');
        const modalContainer = this.modalOverlay?.querySelector('.modal-container');

        if (!addToCartBtn || !modalActions || !modalContainer) return;

        // Проверяем, скрыта ли корзина
        const isCartHidden = window.cartManager && window.cartManager.isCartHidden();

        if (isCartHidden) {
            // Скрываем кнопку и контейнер действий
            modalActions.style.display = 'none';

            // Добавляем класс для изменения дизайна модального окна (полный круг)
            modalContainer.classList.add('cart-hidden');
        } else {
            // Показываем кнопку и контейнер действий
            modalActions.style.display = 'block';

            // Убираем класс для возврата к обычному дизайну
            modalContainer.classList.remove('cart-hidden');
        }
    }

    destroy() {
        if (this.modalOverlay) {
            this.modalOverlay.remove();
        }
        document.body.classList.remove('modal-open');
        this.isOpen = false;
    }

    isModalOpen() {
        return this.isOpen;
    }
}

// Инициализация модальных окон после загрузки DOM
let menuModal = null;

document.addEventListener('DOMContentLoaded', function() {
    // Создаем экземпляр модального окна
    menuModal = new MenuModal();

    console.log('Menu Modal System initialized');
});

// Экспортируем для возможного использования в других скриптах
window.MenuModal = MenuModal;
window.menuModal = menuModal;
