/**
 * Lazy Loading System для изображений меню
 * Загружает изображения только когда они становятся видимыми
 */
class LazyImageLoader {
    constructor() {
        this.observer = null;
        this.loadingPlaceholder = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iIzIyMjIyMiIvPgogIDx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTRweCIgZmlsbD0iIzY2NjY2NiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkxvYWRpbmcuLi48L3RleHQ+CiAgPGNpcmNsZSBjeD0iMTUwIiBjeT0iMTAwIiByPSIyMCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjNDQ0NDQ0IiBzdHJva2Utd2lkdGg9IjIiPgogICAgPGFuaW1hdGUgYXR0cmlidXRlTmFtZT0ic3Ryb2tlLWRhc2hvZmZzZXQiIGR1cj0iMnMiIHJlcGVhdENvdW50PSJpbmRlZmluaXRlIiB2YWx1ZXM9IjA7MTI1Ii8+CiAgICA8YW5pbWF0ZSBhdHRyaWJ1dGVOYW1lPSJzdHJva2UtZGFzaGFycmF5IiBkdXI9IjJzIiByZXBlYXRDb3VudD0iaW5kZWZpbml0ZSIgdmFsdWVzPSIwIDEyNTsxMjUgMTI1OzAgMTI1Ii8+CiAgPC9jaXJjbGU+Cjwvc3ZnPg==';
        this.init();
    }

    init() {
        // Проверяем поддержку Intersection Observer
        if ('IntersectionObserver' in window) {
            this.observer = new IntersectionObserver(
                this.handleIntersection.bind(this),
                {
                    root: null,
                    rootMargin: '300px', // Увеличиваем до 300px для более ранней загрузки
                    threshold: 0.01 // Уменьшаем порог для более раннего срабатывания
                }
            );
            console.log('🖼️ LazyImageLoader: Intersection Observer инициализирован');
        } else {
            // Fallback для старых браузеров
            console.warn('⚠️ LazyImageLoader: Intersection Observer не поддерживается, используем fallback');
            this.fallbackLoadImages();
        }
    }

    /**
     * Обрабатывает пересечение элементов с областью видимости
     */
    handleIntersection(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                // Проверяем, что изображение еще не загружено
                if (img.dataset.src && img.classList.contains('lazy-loading')) {
                    this.loadImage(img);
                    this.observer.unobserve(img); // Прекращаем наблюдение за загруженным изображением
                }
            }
        });
    }

    /**
     * Загружает изображение
     */
    loadImage(img, srcOverride = null) {
        const src = srcOverride || img.dataset.src;
        if (!src) return;

        // Проверяем, не загружается ли уже
        if (img.dataset.loading === 'true') return;
        img.dataset.loading = 'true';

        // Создаем новый объект Image для предзагрузки
        const imageLoader = new Image();

        imageLoader.onload = () => {
            // Изображение загружено успешно
            img.src = src;
            img.classList.remove('lazy-loading');
            img.classList.add('lazy-loaded');
            img.dataset.loading = 'false';
            console.log(`✅ Изображение загружено: ${src.substring(0, 50)}...`);
        };

        imageLoader.onerror = () => {
            // Ошибка загрузки - показываем placeholder
            img.src = 'https://via.placeholder.com/300x200?text=Image+Not+Found';
            img.classList.remove('lazy-loading');
            img.classList.add('lazy-error');
            img.dataset.loading = 'false';
            console.warn(`❌ Ошибка загрузки изображения: ${src}`);
        };

        // Начинаем загрузку
        imageLoader.src = src;
    }

    /**
     * Подготавливает изображение для lazy loading
     */
    setupLazyImage(img, actualSrc) {
        // Сразу проверяем - если изображение в области видимости, загружаем немедленно
        const rect = img.getBoundingClientRect();
        const isVisible = rect.top < window.innerHeight + 100 && rect.bottom > -100;

        if (isVisible) {
            // Немедленная загрузка для видимых изображений
            this.loadImage(img, actualSrc);
            return img;
        }

        // Устанавливаем placeholder
        img.src = this.loadingPlaceholder;

        // Сохраняем реальный URL в data-src
        img.dataset.src = actualSrc;

        // Добавляем CSS класс
        img.classList.add('lazy-loading');

        // Добавляем элемент в наблюдение
        if (this.observer) {
            this.observer.observe(img);
        }

        return img;
    }

    /**
     * Fallback для браузеров без поддержки Intersection Observer
     */
    fallbackLoadImages() {
        const lazyImages = document.querySelectorAll('img[data-src]');
        lazyImages.forEach(img => {
            this.loadImage(img);
        });
    }

    /**
     * Принудительная загрузка всех изображений (для отладки)
     */
    loadAllImages() {
        const lazyImages = document.querySelectorAll('img[data-src]');
        console.log(`🔄 Принудительная загрузка ${lazyImages.length} изображений`);
        lazyImages.forEach(img => {
            this.loadImage(img);
        });
    }

    /**
     * Уничтожает observer при необходимости
     */
    destroy() {
        if (this.observer) {
            this.observer.disconnect();
            console.log('🗑️ LazyImageLoader: Observer отключен');
        }
    }
}

// Создаем глобальный экземпляр
window.lazyLoader = new LazyImageLoader();

// Экспортируем для использования в других модулях
if (typeof module !== 'undefined' && module.exports) {
    module.exports = LazyImageLoader;
}
