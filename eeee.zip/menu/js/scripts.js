/* Inline JS Block 1 */
(() => {
  function u() {
    function n(t, e, i) {
      let r = document.createElement("a");
      r.href = t, r.target = i, r.rel = e, document.body.appendChild(r), r.click(), r.remove()
    }

    function o(t) {
      if (this.dataset.hydrated) {
        this.removeEventListener("click", o);
        return
      }
      t.preventDefault(), t.stopPropagation();
      let e = this.getAttribute("href");
      if (!e) return;
      if (/Mac|iPod|iPhone|iPad/u.test(navigator.userAgent) ? t.metaKey : t.ctrlKey) return n(e, "", "_blank");
      let r = this.getAttribute("rel") ?? "",
        c = this.getAttribute("target") ?? "";
      n(e, r, c)
    }

    function a(t) {
      if (this.dataset.hydrated) {
        this.removeEventListener("auxclick", o);
        return
      }
      t.preventDefault(), t.stopPropagation();
      let e = this.getAttribute("href");
      e && n(e, "", "_blank")
    }

    function s(t) {
      if (this.dataset.hydrated) {
        this.removeEventListener("keydown", s);
        return
      }
      if (t.key !== "Enter") return;
      t.preventDefault(), t.stopPropagation();
      let e = this.getAttribute("href");
      if (!e) return;
      let i = this.getAttribute("rel") ?? "",
        r = this.getAttribute("target") ?? "";
      n(e, i, r)
    }
    document.querySelectorAll("[data-nested-link]")
      .forEach(t => {
        t instanceof HTMLElement && (t.addEventListener("click", o), t.addEventListener("auxclick", a), t.addEventListener("keydown", s))
      })
  }
  return u
})()()

/* Inline JS Block 2 */
(() => {
  function i() {
    for (let e of document.querySelectorAll("[data-framer-original-sizes]")) {
      let t = e.getAttribute("data-framer-original-sizes");
      t === "" ? e.removeAttribute("sizes") : e.setAttribute("sizes", t), e.removeAttribute("data-framer-original-sizes")
    }
  }

  function a() {
    window.__framer_onRewriteBreakpoints = i
  }
  return a
})()()

/* Inline JS Block 3 */
! function() {
  function c(t, r) {
    let e = r.indexOf("#"),
      n = e === -1 ? r : r.substring(0, e),
      o = e === -1 ? "" : r.substring(e),
      a = n.indexOf("?");
    if (a === -1) return n + t + o;
    let d = new URLSearchParams(t),
      h = n.substring(a + 1),
      s = new URLSearchParams(h);
    for (let [i, m] of d) s.has(i) || s.append(i, m);
    return n.substring(0, a + 1) + s.toString() + o
  }
  var l = 'div#main a[href^="#"],div#main a[href^="/"],div#main a[href^="."]',
    u = "div#main a[data-framer-preserve-params]",
    f, g = (f = document.currentScript) == null ? void 0 : f.hasAttribute("data-preserve-internal-params");
  if (window.location.search && !/bot|-google|google-|yandex|ia_archiver|crawl|spider/iu.test(navigator.userAgent)) {
    let t = document.querySelectorAll(g ? `${l},${u}` : u);
    for (let r of t) {
      let e = c(window.location.search, r.href);
      r.setAttribute("href", e)
    }
  }
}()

/* Inline JS Block 4 */
var animator = (() => {
  var k = (e, t, r) => r > t ? t : r < e ? e : r;
  var F = () => {};

  function W(e) {
    let t;
    return () => (t === void 0 && (t = e()), t)
  }
  var j = e => e;
  var w = e => e * 1e3,
    v = e => e / 1e3;

  function X(e, t) {
    return t ? e * (1e3 / t) : 0
  }
  var Y = e => Array.isArray(e) && typeof e[0] == "number";
  var q = {
    value: null,
    addProjectionMetrics: null
  };
  var Z = {
    layout: 0,
    mainThread: 0,
    waapi: 0
  };
  var G = (e, t, r = 10) => {
    let o = "",
      s = Math.max(Math.round(t / r), 2);
    for (let n = 0; n < s; n++) o += e(n / (s - 1)) + ", ";
    return `linear(${o.substring(0,o.length-2)})`
  };

  function $(e) {
    let t = 0,
      r = 50,
      o = e.next(t);
    for (; !o.done && t < 2e4;) t += r, o = e.next(t);
    return t >= 2e4 ? 1 / 0 : t
  }

  function pe(e, t = 100, r) {
    let o = r({
        ...e,
        keyframes: [0, t]
      }),
      s = Math.min($(o), 2e4);
    return {
      type: "keyframes",
      ease: n => o.next(s * n)
        .value / t,
      duration: v(s)
    }
  }
  var Ee = 5;

  function me(e, t, r) {
    let o = Math.max(t - Ee, 0);
    return X(r - e(o), t - o)
  }
  var l = {
    stiffness: 100,
    damping: 10,
    mass: 1,
    velocity: 0,
    duration: 800,
    bounce: .3,
    visualDuration: .3,
    restSpeed: {
      granular: .01,
      default: 2
    },
    restDelta: {
      granular: .005,
      default: .5
    },
    minDuration: .01,
    maxDuration: 10,
    minDamping: .05,
    maxDamping: 1
  };
  var H = .001;

  function fe({
    duration: e = l.duration,
    bounce: t = l.bounce,
    velocity: r = l.velocity,
    mass: o = l.mass
  }) {
    let s, n;
    F(e <= w(l.maxDuration), "Spring duration must be 10 seconds or less");
    let i = 1 - t;
    i = k(l.minDamping, l.maxDamping, i), e = k(l.minDuration, l.maxDuration, v(e)), i < 1 ? (s = m => {
      let p = m * i,
        c = p * e,
        u = p - r,
        d = L(m, i),
        g = Math.exp(-c);
      return H - u / d * g
    }, n = m => {
      let c = m * i * e,
        u = c * r + r,
        d = Math.pow(i, 2) * Math.pow(m, 2) * e,
        g = Math.exp(-c),
        y = L(Math.pow(m, 2), i);
      return (-s(m) + H > 0 ? -1 : 1) * ((u - d) * g) / y
    }) : (s = m => {
      let p = Math.exp(-m * e),
        c = (m - r) * e + 1;
      return -H + p * c
    }, n = m => {
      let p = Math.exp(-m * e),
        c = (r - m) * (e * e);
      return p * c
    });
    let f = 5 / e,
      a = Ce(s, n, f);
    if (e = w(e), isNaN(a)) return {
      stiffness: l.stiffness,
      damping: l.damping,
      duration: e
    };
    {
      let m = Math.pow(a, 2) * o;
      return {
        stiffness: m,
        damping: i * 2 * Math.sqrt(o * m),
        duration: e
      }
    }
  }
  var Pe = 12;

  function Ce(e, t, r) {
    let o = r;
    for (let s = 1; s < Pe; s++) o = o - e(o) / t(o);
    return o
  }

  function L(e, t) {
    return e * Math.sqrt(1 - t * t)
  }
  var Ie = ["duration", "bounce"],
    Ke = ["stiffness", "damping", "mass"];

  function ce(e, t) {
    return t.some(r => e[r] !== void 0)
  }

  function Be(e) {
    let t = {
      velocity: l.velocity,
      stiffness: l.stiffness,
      damping: l.damping,
      mass: l.mass,
      isResolvedFromDuration: !1,
      ...e
    };
    if (!ce(e, Ke) && ce(e, Ie))
      if (e.visualDuration) {
        let r = e.visualDuration,
          o = 2 * Math.PI / (r * 1.2),
          s = o * o,
          n = 2 * k(.05, 1, 1 - (e.bounce || 0)) * Math.sqrt(s);
        t = {
          ...t,
          mass: l.mass,
          stiffness: s,
          damping: n
        }
      } else {
        let r = fe(e);
        t = {
          ...t,
          ...r,
          mass: l.mass
        }, t.isResolvedFromDuration = !0
      } return t
  }

  function D(e = l.visualDuration, t = l.bounce) {
    let r = typeof e != "object" ? {
        visualDuration: e,
        keyframes: [0, 1],
        bounce: t
      } : e,
      {
        restSpeed: o,
        restDelta: s
      } = r,
      n = r.keyframes[0],
      i = r.keyframes[r.keyframes.length - 1],
      f = {
        done: !1,
        value: n
      },
      {
        stiffness: a,
        damping: m,
        mass: p,
        duration: c,
        velocity: u,
        isResolvedFromDuration: d
      } = Be({
        ...r,
        velocity: -v(r.velocity || 0)
      }),
      g = u || 0,
      y = m / (2 * Math.sqrt(a * p)),
      h = i - n,
      T = v(Math.sqrt(a / p)),
      B = Math.abs(h) < 5;
    o || (o = B ? l.restSpeed.granular : l.restSpeed.default), s || (s = B ? l.restDelta.granular : l.restDelta.default);
    let S;
    if (y < 1) {
      let x = L(T, y);
      S = A => {
        let M = Math.exp(-y * T * A);
        return i - M * ((g + y * T * h) / x * Math.sin(x * A) + h * Math.cos(x * A))
      }
    } else if (y === 1) S = x => i - Math.exp(-T * x) * (h + (g + T * h) * x);
    else {
      let x = T * Math.sqrt(y * y - 1);
      S = A => {
        let M = Math.exp(-y * T * A),
          z = Math.min(x * A, 300);
        return i - M * ((g + y * T * h) * Math.sinh(z) + x * h * Math.cosh(z)) / x
      }
    }
    let V = {
      calculatedDuration: d && c || null,
      next: x => {
        let A = S(x);
        if (d) f.done = x >= c;
        else {
          let M = x === 0 ? g : 0;
          y < 1 && (M = x === 0 ? w(g) : me(S, x, A));
          let z = Math.abs(M) <= o,
            ke = Math.abs(i - A) <= s;
          f.done = z && ke
        }
        return f.value = f.done ? i : A, f
      },
      toString: () => {
        let x = Math.min($(V), 2e4),
          A = G(M => V.next(x * M)
            .value, x, 30);
        return x + "ms " + A
      },
      toTransition: () => {}
    };
    return V
  }
  D.applyToOptions = e => {
    let t = pe(e, 100, D);
    return e.ease = t.ease, e.duration = w(t.duration), e.type = "keyframes", e
  };
  var ue = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
    _ = new Set(ue);
  var le = {};

  function de(e, t) {
    let r = W(e);
    return () => le[t] ?? r()
  }
  var xe = de(() => {
    try {
      document.createElement("div")
        .animate({
          opacity: 0
        }, {
          easing: "linear(0, 1)"
        })
    } catch {
      return !1
    }
    return !0
  }, "linearEasing");
  var O = ([e, t, r, o]) => `cubic-bezier(${e}, ${t}, ${r}, ${o})`;
  var Q = {
    linear: "linear",
    ease: "ease",
    easeIn: "ease-in",
    easeOut: "ease-out",
    easeInOut: "ease-in-out",
    circIn: O([0, .65, .55, 1]),
    circOut: O([.55, 0, 1, .45]),
    backIn: O([.31, .01, .66, -.59]),
    backOut: O([.33, 1.53, .69, .99])
  };

  function J(e, t) {
    if (e) return typeof e == "function" ? xe() ? G(e, t) : "ease-out" : Y(e) ? O(e) : Array.isArray(e) ? e.map(r => J(r, t) || Q.easeOut) : Q[e]
  }

  function R(e, t, r, {
    delay: o = 0,
    duration: s = 300,
    repeat: n = 0,
    repeatType: i = "loop",
    ease: f = "easeOut",
    times: a
  } = {}, m = void 0) {
    let p = {
      [t]: r
    };
    a && (p.offset = a);
    let c = J(f, s);
    Array.isArray(c) && (p.easing = c), q.value && Z.waapi++;
    let u = {
      delay: o,
      duration: s,
      easing: Array.isArray(c) ? "linear" : c,
      fill: "both",
      iterations: n + 1,
      direction: i === "reverse" ? "alternate" : "normal"
    };
    m && (u.pseudoElement = m);
    let d = e.animate(p, u);
    return q.value && d.finished.finally(() => {
      Z.waapi--
    }), d
  }
  var ge = e => e.replace(/([a-z])([A-Z])/gu, "$1-$2")
    .toLowerCase();
  var ee = "framerAppearId",
    ye = "data-" + ge(ee);

  function Ae(e) {
    return e.props[ye]
  }
  var b = new Map,
    E = new Map;
  var P = (e, t) => {
    let r = _.has(t) ? "transform" : t;
    return `${e}: ${r}`
  };

  function te(e, t, r) {
    let o = P(e, t),
      s = b.get(o);
    if (!s) return null;
    let {
      animation: n,
      startTime: i
    } = s;

    function f() {
      window.MotionCancelOptimisedAnimation?.(e, t, r)
    }
    return n.onfinish = f, i === null || window.MotionHandoffIsComplete?.(e) ? (f(), null) : i
  }
  var N, C, re = new Set;

  function ze() {
    re.forEach(e => {
      e.animation.play(), e.animation.startTime = e.startTime
    }), re.clear()
  }

  function oe(e, t, r, o, s) {
    if (window.MotionIsMounted) return;
    let n = e.dataset[ee];
    if (!n) return;
    window.MotionHandoffAnimation = te;
    let i = P(n, t);
    C || (C = R(e, t, [r[0], r[0]], {
      duration: 1e4,
      ease: "linear"
    }), b.set(i, {
      animation: C,
      startTime: null
    }), window.MotionHandoffAnimation = te, window.MotionHasOptimisedAnimation = (a, m) => {
      if (!a) return !1;
      if (!m) return E.has(a);
      let p = P(a, m);
      return !!b.get(p)
    }, window.MotionHandoffMarkAsComplete = a => {
      E.has(a) && E.set(a, !0)
    }, window.MotionHandoffIsComplete = a => E.get(a) === !0, window.MotionCancelOptimisedAnimation = (a, m, p, c) => {
      let u = P(a, m),
        d = b.get(u);
      d && (p && c === void 0 ? p.postRender(() => {
        p.postRender(() => {
          d.animation.cancel()
        })
      }) : d.animation.cancel(), p && c ? (re.add(d), p.render(ze)) : (b.delete(u), b.size || (window.MotionCancelOptimisedAnimation = void 0)))
    }, window.MotionCheckAppearSync = (a, m, p) => {
      let c = Ae(a);
      if (!c) return;
      let u = window.MotionHasOptimisedAnimation?.(c, m),
        d = a.props.values?.[m];
      if (!u || !d) return;
      let g = p.on("change", y => {
        d.get() !== y && (window.MotionCancelOptimisedAnimation?.(c, m), g())
      });
      return g
    });
    let f = () => {
      C.cancel();
      let a = R(e, t, r, o);
      N === void 0 && (N = performance.now()), a.startTime = N, b.set(i, {
        animation: a,
        startTime: N
      }), s && s(a)
    };
    E.set(n, !1), C.ready ? C.ready.then(f)
      .catch(j) : f()
  }
  var ne = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
    Ge = {
      x: "translateX",
      y: "translateY",
      z: "translateZ",
      transformPerspective: "perspective"
    },
    $e = {
      translateX: "px",
      translateY: "px",
      translateZ: "px",
      x: "px",
      y: "px",
      z: "px",
      perspective: "px",
      transformPerspective: "px",
      rotate: "deg",
      rotateX: "deg",
      rotateY: "deg"
    };

  function he(e, t) {
    let r = $e[e];
    return !r || typeof t == "string" && t.endsWith(r) ? t : `${t}${r}`
  }

  function ie(e) {
    return ne.includes(e)
  }
  var Le = (e, t) => ne.indexOf(e) - ne.indexOf(t);

  function Te({
    transform: e,
    transformKeys: t
  }, r) {
    let o = {},
      s = !0,
      n = "";
    t.sort(Le);
    for (let i of t) {
      let f = e[i],
        a = !0;
      typeof f == "number" ? a = f === (i.startsWith("scale") ? 1 : 0) : a = parseFloat(f) === 0, a || (s = !1, n += `${Ge[i]||i}(${e[i]}) `), r && (o[i] = e[i])
    }
    return n = n.trim(), r ? n = r(o, n) : s && (n = "none"), n
  }

  function ae(e, t) {
    let r = new Set(Object.keys(e));
    for (let o in t) r.add(o);
    return Array.from(r)
  }

  function se(e, t) {
    let r = t - e.length;
    if (r <= 0) return e;
    let o = new Array(r)
      .fill(e[e.length - 1]);
    return e.concat(o)
  }

  function I(e) {
    return e * 1e3
  }
  var Me = {
      duration: .001
    },
    K = {
      opacity: 1,
      scale: 1,
      translateX: 0,
      translateY: 0,
      translateZ: 0,
      x: 0,
      y: 0,
      z: 0,
      rotate: 0,
      rotateX: 0,
      rotateY: 0
    };

  function ve(e, t, r, o, s) {
    return r.delay && (r.delay = I(r.delay)), r.type === "spring" ? Ne(e, t, r, o, s) : We(e, t, r, o, s)
  }

  function Re(e, t, r) {
    let o = {},
      s = 0,
      n = 0;
    for (let i of ae(e, t)) {
      let f = e[i] ?? K[i],
        a = t[i] ?? K[i];
      if (f === void 0 || a === void 0 || i !== "transformPerspective" && f === a && f === K[i]) continue;
      i === "transformPerspective" && (o[i] = [f, a]);
      let m = Ze(f, a, r),
        {
          duration: p,
          keyframes: c
        } = m;
      p === void 0 || c === void 0 || (p > s && (s = p, n = c.length), o[i] = c)
    }
    return {
      keyframeValuesByProps: o,
      longestDuration: s,
      longestLength: n
    }
  }

  function Ne(e, t, r, o, s) {
    let n = {},
      {
        keyframeValuesByProps: i,
        longestDuration: f,
        longestLength: a
      } = Re(e, t, r);
    if (!a) return n;
    let m = {
        ease: "linear",
        duration: f,
        delay: r.delay
      },
      p = s ? Me : m,
      c = {};
    for (let [d, g] of Object.entries(i)) ie(d) ? c[d] = se(g, a) : n[d] = {
      keyframes: se(g, a),
      options: d === "opacity" ? m : p
    };
    let u = De(c, o);
    return u && (n.transform = {
      keyframes: u,
      options: p
    }), n
  }

  function Fe(e) {
    let {
      type: t,
      duration: r,
      ...o
    } = e;
    return {
      duration: I(r),
      ...o
    }
  }

  function We(e, t, r, o, s) {
    let n = Fe(r);
    if (!n) return;
    let i = {},
      f = s ? Me : n,
      a = {};
    for (let p of ae(e, t)) {
      let c = e[p] ?? K[p],
        u = t[p] ?? K[p];
      c === void 0 || u === void 0 || p !== "transformPerspective" && c === u || (ie(p) ? a[p] = [c, u] : i[p] = {
        keyframes: [c, u],
        options: p === "opacity" ? n : f
      })
    }
    let m = De(a, o);
    return m && (i.transform = {
      keyframes: m,
      options: f
    }), i
  }
  var je = ["duration", "bounce"],
    Xe = ["stiffness", "damping", "mass"];

  function we(e) {
    return Xe.some(t => t in e) ? !1 : je.some(t => t in e)
  }

  function Ye(e, t, r) {
    return we(r) ? `${e}-${t}-${r.duration}-${r.bounce}` : `${e}-${t}-${r.damping}-${r.stiffness}-${r.mass}`
  }

  function qe(e) {
    return we(e) ? {
      ...e,
      duration: I(e.duration)
    } : e
  }
  var be = new Map,
    Se = 10;

  function Ze(e, t, r) {
    let o = Ye(e, t, r),
      s = be.get(o);
    if (s) return s;
    let n = [e, t],
      i = D({
        ...qe(r),
        keyframes: n
      }),
      f = {
        done: !1,
        value: n[0]
      },
      a = [],
      m = 0;
    for (; !f.done && m < I(10);) f = i.next(m), a.push(f.value), m += Se;
    n = a;
    let p = m - Se,
      u = {
        keyframes: n,
        duration: p,
        ease: "linear"
      };
    return be.set(o, u), u
  }

  function De(e, t) {
    let r = [],
      o = Object.values(e)[0]?.length;
    if (!o) return;
    let s = Object.keys(e);
    for (let n = 0; n < o; n++) {
      let i = {};
      for (let [a, m] of Object.entries(e)) {
        let p = m[n];
        p !== void 0 && (i[a] = he(a, p))
      }
      let f = Te({
        transform: i,
        transformKeys: s
      }, t);
      r.push(f)
    }
    return r
  }

  function Ue(e, t) {
    if (!t)
      for (let r in e) {
        let o = e[r];
        return o?.legacy === !0 ? o : void 0
      }
  }

  function Oe(e, t, r, o, s, n) {
    for (let [i, f] of Object.entries(e)) {
      let a = n ? f[n] : void 0;
      if (a === null || !a && f.default === null) continue;
      let m = a ?? f.default ?? Ue(f, n);
      if (!m) continue;
      let {
        initial: p,
        animate: c,
        transformTemplate: u
      } = m;
      if (!p || !c) continue;
      let {
        transition: d,
        ...g
      } = c, y = ve(p, g, d, He(u, o), s);
      if (!y) continue;
      let h = {},
        T = {};
      for (let [S, V] of Object.entries(y)) h[S] = V.keyframes, T[S] = V.options;
      let B = n ? `:not(.hidden-${n}) ` : "";
      t(`${B}[${r}="${i}"]`, h, T)
    }
  }

  function He(e, t) {
    if (!(!e || !t)) return (r, o) => e.replace(t, o)
  }

  function Ve(e) {
    return e ? e.find(r => r.mediaQuery ? window.matchMedia(r.mediaQuery)
        .matches === !0 : !1)
      ?.hash : void 0
  }
  var Lr = {
    animateAppearEffects: Oe,
    getActiveVariantHash: Ve,
    spring: D,
    startOptimizedAppearAnimation: oe
  };
  return Lr
})()

/* Inline JS Block 5 */
{
  "5klz8i": {
    "default": {
      "initial": {
        "opacity": 0.001,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "x": 0,
        "y": 0
      },
      "animate": {
        "opacity": 1,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "transition": {
          "delay": 0,
          "duration": 0.5,
          "ease": [0.5, 0, 0.88, 0.77],
          "type": "tween"
        },
        "x": 0,
        "y": 0
      }
    }
  },
  "bqgz5j": {
    "default": {
      "initial": {
        "opacity": 0.001,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "x": 0,
        "y": 0
      },
      "animate": {
        "opacity": 1,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "transition": {
          "delay": 0.5,
          "duration": 1,
          "ease": [0.5, 1, 0.89, 1],
          "type": "tween"
        },
        "x": 0,
        "y": 0
      }
    },
    "g1i4v9": {
      "initial": {
        "opacity": 0.001,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "x": 0,
        "y": 0
      },
      "animate": {
        "opacity": 1,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "transition": {
          "delay": 0.5,
          "duration": 1,
          "ease": [0.5, 1, 0.89, 1],
          "type": "tween"
        },
        "x": 0,
        "y": 0
      }
    },
    "okrmbe": {
      "initial": {
        "opacity": 0.001,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "x": 0,
        "y": 0
      },
      "animate": {
        "opacity": 1,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "transition": {
          "delay": 0.5,
          "duration": 1,
          "ease": [0.5, 1, 0.89, 1],
          "type": "tween"
        },
        "x": 0,
        "y": 0
      }
    }
  },
  "1irorrg": {
    "default": {
      "initial": {
        "opacity": 0.001,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "x": 0,
        "y": 0
      },
      "animate": {
        "opacity": 1,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "transition": {
          "delay": 0,
          "duration": 0.5,
          "ease": [0.5, 0, 0.88, 0.77],
          "type": "tween"
        },
        "x": 0,
        "y": 0
      }
    }
  },
  "d48kb": {
    "default": {
      "initial": {
        "opacity": 0.001,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "x": 0,
        "y": 0
      },
      "animate": {
        "opacity": 1,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "transition": {
          "delay": 0,
          "duration": 0.5,
          "ease": [0.5, 0, 0.88, 0.77],
          "type": "tween"
        },
        "x": 0,
        "y": 0
      }
    }
  },
  "1lcp6bd": {
    "default": {
      "initial": {
        "opacity": 0.001,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "x": 0,
        "y": 0
      },
      "animate": {
        "opacity": 1,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "transition": {
          "delay": 0,
          "duration": 0.5,
          "ease": [0.5, 0, 0.88, 0.77],
          "type": "tween"
        },
        "x": 0,
        "y": 0
      }
    },
    "1r1q3e1": {
      "initial": {
        "opacity": 0.001,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "x": 0,
        "y": 0
      },
      "animate": {
        "opacity": 1,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "transition": {
          "delay": 0,
          "duration": 0.5,
          "ease": [0.5, 0, 0.88, 0.77],
          "type": "tween"
        },
        "x": 0,
        "y": 0
      }
    },
    "1auuoho": {
      "initial": {
        "opacity": 0.001,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "x": 0,
        "y": 0
      },
      "animate": {
        "opacity": 1,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transformPerspective": 1200,
        "transition": {
          "delay": 0,
          "duration": 0.5,
          "ease": [0.5, 0, 0.88, 0.77],
          "type": "tween"
        },
        "x": 0,
        "y": 0
      }
    }
  },
  "gqopxx": {
    "default": {
      "initial": {
        "opacity": 0.001,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "x": 0,
        "y": 10
      },
      "animate": {
        "opacity": 1,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transition": {
          "delay": 1.2,
          "duration": 0.4,
          "ease": [0.44, 0, 0.56, 1],
          "type": "tween"
        },
        "x": 0,
        "y": 0
      }
    }
  },
  "1wwcyo4": {
    "default": {
      "initial": {
        "opacity": 0.001,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "x": 0,
        "y": 10
      },
      "animate": {
        "opacity": 1,
        "rotate": 0,
        "rotateX": 0,
        "rotateY": 0,
        "scale": 1,
        "skewX": 0,
        "skewY": 0,
        "transition": {
          "delay": 1,
          "duration": 0.4,
          "ease": [0.44, 0, 0.56, 1],
          "type": "tween"
        },
        "x": 0,
        "y": 0
      }
    }
  }
}

/* Inline JS Block 6 */
[{
  "hash": "1td9vov",
  "mediaQuery": "(min-width: 1400px)"
}, {
  "hash": "g1i4v9",
  "mediaQuery": "(min-width: 810px) and (max-width: 1399px)"
}, {
  "hash": "okrmbe",
  "mediaQuery": "(max-width: 809px)"
}, {
  "hash": "zclkw6",
  "mediaQuery": "(min-width: 1200px)"
}, {
  "hash": "1r1q3e1",
  "mediaQuery": "(min-width: 810px) and (max-width: 1199px)"
}, {
  "hash": "1auuoho",
  "mediaQuery": "(max-width: 809px)"
}]

/* Inline JS Block 7 */
(() => {
  function c(i, o, m) {
    if (window.__framer_disable_appear_effects_optimization__ || typeof animator > "u") return;
    let e = {
      detail: {
        bg: document.hidden
      }
    };
    requestAnimationFrame(() => {
      let a = "framer-appear-start";
      performance.mark(a, e), animator.animateAppearEffects(JSON.parse(window.__framer__appearAnimationsContent.text), (s, p, d) => {
          let t = document.querySelector(s);
          if (t)
            for (let [r, f] of Object.entries(p)) animator.startOptimizedAppearAnimation(t, r, f, d[r])
        }, i, o, m && window.matchMedia("(prefers-reduced-motion:reduce)")
        .matches === !0, animator.getActiveVariantHash(JSON.parse(window.__framer__breakpoints.text)));
      let n = "framer-appear-end";
      performance.mark(n, e), performance.measure("framer-appear", {
        start: a,
        end: n,
        detail: e.detail
      })
    })
  }
  return c
})()("data-framer-appear-id", "__Appear_Animation_Transform__", false)