class MultilingualManager {
    constructor() {
        this.currentLanguage = 'en'; // по умолчанию английский
        this.menuData = null;
        this.translations = {
            en: {
                back: 'Back',
                categories: 'Categories',
                addToCart: 'Add to Cart',
                added: 'Added!',
                yourOrder: 'Your Order',
                cartEmpty: 'Your cart is empty',
                addItemsFromMenu: 'Add items from menu',
                orderBtn: 'Order',
                totalAmount: 'Total:',
                // Склонения для товаров
                itemSingular: 'item',
                itemPlural: 'items',
                // Дополнительные переводы
                spicy: 'Spicy',
                alcohol: 'Alcohol',
                removeItem: 'Remove item',
                cartEmptyAlert: 'Cart is empty',
                tableNumberError: 'Error: table number not found',
                orderSuccess: 'Order sent successfully! Please wait for confirmation.',
                orderError: 'Error sending order. Please try again.'
            },
            ru: {
                back: 'Назад',
                categories: 'Категории',
                addToCart: 'Добавить в корзину',
                added: 'Добавлено!',
                yourOrder: 'Ваш заказ',
                cartEmpty: 'Ваша корзина пуста',
                addItemsFromMenu: 'Добавьте товары из меню',
                orderBtn: 'Заказать',
                totalAmount: 'Общая сумма:',
                // Склонения для товаров
                itemSingular: 'товар',
                itemGenitive2to4: 'товара',
                itemGenitivePlural: 'товаров',
                // Дополнительные переводы
                spicy: 'Острое',
                alcohol: 'Алкоголь',
                removeItem: 'Удалить товар',
                cartEmptyAlert: 'Корзина пуста',
                tableNumberError: 'Ошибка: не найден номер столика',
                orderSuccess: 'Заказ успешно отправлен! Ожидайте подтверждения.',
                orderError: 'Ошибка при отправке заказа. Попробуйте еще раз.'
            },
            lv: {
                back: 'Atpakaļ',
                categories: 'Kategorijas',
                addToCart: 'Pievienot grozam',
                added: 'Pievienots!',
                yourOrder: 'Jūsu pasūtījums',
                cartEmpty: 'Jūsu grozs ir tukšs',
                addItemsFromMenu: 'Pievienojiet preces no ēdienkartes',
                orderBtn: 'Pasūtīt',
                totalAmount: 'Kopā:',
                // Склонения для товаров
                itemSingular: 'prece',
                itemPlural: 'preces',
                // Дополнительные переводы
                spicy: 'Aso',
                alcohol: 'Alkohols',
                removeItem: 'Noņemt preci',
                cartEmptyAlert: 'Grozs ir tukšs',
                tableNumberError: 'Kļūda: galda numurs nav atrasts',
                orderSuccess: 'Pasūtījums veiksmīgi nosūtīts! Gaidiet apstiprinājumu.',
                orderError: 'Kļūda nosūtot pasūtījumu. Lūdzu mēģiniet vēlreiz.'
            }
        };

        this.init();
    }

    async init() {
        // Получаем язык от центрального менеджера языков
        if (window.languageManager) {
            this.currentLanguage = window.languageManager.getCurrentLanguage();
        } else {
            // Fallback на localStorage если менеджер недоступен
            const savedLang = localStorage.getItem('selectedLanguage') || 'en';
            this.currentLanguage = savedLang;
        }

        // Устанавливаем обработчики
        this.bindEvents();

        // Слушаем изменения языка от центрального менеджера
        this.setupLanguageListener();

        // Ждем загрузки MenuCards и получаем данные от них
        this.waitForMenuCards(() => {
            this.menuData = window.menuCards.menuData;
            console.log('🌐 Multilingual: Получены данные от MenuCards');
            this.applyLanguage(this.currentLanguage);

            // Обновляем URL с текущим языком при загрузке
            this.updateUrlWithLanguage(this.currentLanguage);
        });

        // Слушаем обновления данных от MenuCards
        this.setupMenuDataListener();
    }

    setupLanguageListener() {
        // Слушаем изменения языка от центрального менеджера
        document.addEventListener('languageChanged', (event) => {
            console.log('🌐 Multilingual: Язык изменен на', event.detail.language);
            this.currentLanguage = event.detail.language;
            this.updateLanguageButtons();
            this.applyLanguage(this.currentLanguage);
        });
    }

    setupMenuDataListener() {
        // Слушаем обновления данных от MenuCards
        document.addEventListener('menuDataUpdated', (event) => {
            console.log('🌐 Multilingual: Данные меню обновлены');
            this.menuData = event.detail;
            this.applyLanguage(this.currentLanguage);
        });
    }

    bindEvents() {
        // Обработчики для переключения языков
        const langEnBtn = document.getElementById('langEnBtn');
        const langRuBtn = document.getElementById('langRuBtn');
        const langLvBtn = document.getElementById('langLvBtn');

        if (langEnBtn) {
            langEnBtn.addEventListener('click', () => this.switchLanguage('en'));
        }

        if (langRuBtn) {
            langRuBtn.addEventListener('click', () => this.switchLanguage('ru'));
        }

        if (langLvBtn) {
            langLvBtn.addEventListener('click', () => this.switchLanguage('lv'));
        }
    }

    switchLanguage(lang) {
        console.log(`🌐 Multilingual: Переключение языка на ${lang}`);

        // Обновляем локальный язык
        this.currentLanguage = lang;
        localStorage.setItem('selectedLanguage', lang);

        // Используем центральный менеджер языков если доступен
        if (window.languageManager) {
            window.languageManager.setLanguage(lang);
            window.languageManager.updateLanguageButtons(lang);
        }

        // Обновляем кнопки и применяем переводы
        this.updateLanguageButtons();

        // Немедленно обновляем переводы модального окна и корзины
        this.updateModalTranslations(lang);
        this.updateCartTranslations(lang);

        // КРИТИЧНО: Принудительная загрузка всех карточек перед применением переводов
        this.forceLoadAllCategoriesAndTranslate(lang);

        // ВАЖНО: Обновляем URL с новым языковым параметром
        this.updateUrlWithLanguage(lang);
    }

    updateLanguageButtons() {
        const langEnBtn = document.getElementById('langEnBtn');
        const langRuBtn = document.getElementById('langRuBtn');
        const langLvBtn = document.getElementById('langLvBtn');

        if (langEnBtn && langRuBtn && langLvBtn) {
            langEnBtn.classList.toggle('active', this.currentLanguage === 'en');
            langRuBtn.classList.toggle('active', this.currentLanguage === 'ru');
            langLvBtn.classList.toggle('active', this.currentLanguage === 'lv');
        }
    }

    applyLanguage(lang) {
        console.log(`🌐 Multilingual: Применение языка ${lang}`);

        // Обновляем элементы интерфейса
        this.updateInterfaceElements(lang);

        // Если данные меню доступны, обновляем контент
        if (this.menuData) {
            this.applyLanguageToAllElements(lang);
        } else {
            // Ждем загрузки menu-cards.js и обновляем контент
            this.waitForMenuCards(() => {
                this.updateMenuContent(lang);
            });
        }
    }

    waitForMenuCards(callback, attempts = 0) {
        if (window.menuCards && window.menuCards.menuData) {
            callback();
        } else if (attempts < 50) { // Ждем до 5 секунд
            setTimeout(() => this.waitForMenuCards(callback, attempts + 1), 100);
        } else {
            console.warn('MenuCards not found, content will not be translated');
        }
    }

    updateMenuContent(lang) {
        if (!window.menuCards || !this.menuData) return;

        // Обновляем данные в MenuCards
        window.menuCards.menuData = this.menuData;

        // Если есть метод для обновления контента с языком
        if (typeof window.menuCards.updateContentWithLanguage === 'function') {
            window.menuCards.updateContentWithLanguage(lang);
        } else {
            // Обновляем контент напрямую
            this.updateMenuCardsContent(lang);
        }
    }

    updateMenuCardsContent(lang) {
        // Обновляем заголовок героя
        const heroTitle = document.querySelector('.hero-title, h1');
        if (heroTitle && this.menuData.hero) {
            let title = this.menuData.hero.title;
            if (lang === 'ru' && this.menuData.hero.titleRu) {
                title = this.menuData.hero.titleRu;
            } else if (lang === 'lv' && this.menuData.hero.titleLv) {
                title = this.menuData.hero.titleLv;
            }
            heroTitle.textContent = title;
        }

        // Обновляем категории
        this.menuData.categories.forEach((category, categoryIndex) => {
            // Обновляем название категории
            const categoryElement = document.querySelector(`[data-category-id="${category.id}"]`);
            if (categoryElement) {
                const categoryTitle = categoryElement.querySelector('.category-title, h2, h3');
                if (categoryTitle) {
                    let title = category.name;
                    if (lang === 'ru' && category.nameRu) {
                        title = category.nameRu;
                    } else if (lang === 'lv' && category.nameLv) {
                        title = category.nameLv;
                    }
                    categoryTitle.textContent = title;
                }
            }

            // Обновляем элементы меню
            category.items.forEach((item, itemIndex) => {
                const itemElement = document.querySelector(`[data-item-id="${item.id}"]`);
                if (itemElement) {
                    // Обновляем название блюда
                    const itemName = itemElement.querySelector('.item-name, .menu-item-name, h4');
                    if (itemName) {
                        let name = item.name;
                        if (lang === 'ru' && item.nameRu) {
                            name = item.nameRu;
                        } else if (lang === 'lv' && item.nameLv) {
                            name = item.nameLv;
                        }
                        itemName.textContent = name;
                    }

                    // Обновляем описание блюда
                    const itemDescription = itemElement.querySelector('.item-description, .menu-item-description, p');
                    if (itemDescription) {
                        let description = item.description;
                        if (lang === 'ru' && item.descriptionRu) {
                            description = item.descriptionRu;
                        } else if (lang === 'lv' && item.descriptionLv) {
                            description = item.descriptionLv;
                        }
                        itemDescription.textContent = description;
                    }
                }
            });
        });
    }

    // Метод для внешнего использования
    getCurrentLanguage() {
        return this.currentLanguage;
    }

    // Метод для получения текста на текущем языке
    getText(enText, ruText, lvText) {
        if (this.currentLanguage === 'ru' && ruText) {
            return ruText;
        } else if (this.currentLanguage === 'lv' && lvText) {
            return lvText;
        }
        return enText;
    }

    // Метод для обновления URL с языковым параметром
    updateUrlWithLanguage(lang) {
        const url = new URL(window.location);
        url.searchParams.set('lang', lang);

        // Обновляем URL без перезагрузки страницы
        window.history.replaceState({}, '', url.toString());

        console.log(`🌐 URL updated with language: ${lang}`);
    }

    // Метод для обновления ссылок "Back" с правильным языком
    updateBackLinks(lang) {
        const backLinks = document.querySelectorAll('a[href*="after-qr"]');
        backLinks.forEach(link => {
            let targetPath;
            switch (lang) {
                case 'ru':
                    targetPath = '../ru/after-qr.html';
                    break;
                case 'lv':
                    targetPath = '../lv/after-qr.html';
                    break;
                case 'en':
                default:
                    targetPath = '../after-qr/after-qr.html';
                    break;
            }

            // Создаем URL с языковым параметром и сессией
            const url = new URL(targetPath, window.location.origin);
            url.searchParams.set('lang', lang);

            // Сохраняем параметры сессии если они есть
            const currentParams = new URLSearchParams(window.location.search);
            if (currentParams.has('session')) {
                url.searchParams.set('session', currentParams.get('session'));
            }
            if (currentParams.has('table')) {
                url.searchParams.set('table', currentParams.get('table'));
            }

            link.setAttribute('href', url.toString());
        });

        console.log(`🌐 Back links updated for language: ${lang}`);
    }

    // Принудительная загрузка всех категорий и применение переводов
    async forceLoadAllCategoriesAndTranslate(lang) {
        console.log(`🌐 Multilingual: Принудительная загрузка всех категорий для перевода на ${lang}`);

        // Обновляем данные в текущем объекте
        if (window.menuCards && window.menuCards.menuData) {
            this.menuData = window.menuCards.menuData;
            console.log(`📋 Multilingual: Обновлены данные меню, категорий: ${this.menuData.categories?.length || 0}`);
        }

        // Сначала принудительно загружаем все категории через MenuCards
        if (window.menuCards && window.menuCards.menuData && window.menuCards.menuData.categories) {
            const categories = window.menuCards.menuData.categories;

            // Загружаем все категории параллельно
            const loadPromises = categories.map(category => {
                if (!window.menuCards.loadedCategories.has(category.id)) {
                    console.log(`🔄 Принудительная загрузка категории: ${category.id}`);
                    return window.menuCards.loadCategoryItems(category.id);
                }
                return Promise.resolve();
            });

            // Ждем загрузки всех категорий
            await Promise.all(loadPromises);

            // Небольшая пауза для завершения рендеринга
            await new Promise(resolve => setTimeout(resolve, 300));
        }

        // Применяем переводы ко всем элементам (включая категории)
        this.applyLanguageToAllElements(lang);

        // Дополнительная проверка через небольшую задержку
        setTimeout(() => {
            console.log(`🔄 Multilingual: Дополнительная проверка переводов через 500мс`);
            this.applyLanguageToAllElements(lang);

            // Еще одна попытка специально для категорий
            if (window.menuCards && typeof window.menuCards.updateContentWithLanguage === 'function') {
                window.menuCards.updateContentWithLanguage(lang);
            }
        }, 500);
    }

    // Применение переводов ко всем элементам (в том числе новозагруженным)
    applyLanguageToAllElements(lang) {
        console.log(`🌐 Multilingual: Применение переводов ко всем элементам (${lang})`);

        if (!this.menuData) return;

        // Обновляем все категории
        this.menuData.categories.forEach((category) => {
            console.log(`🔍 Ищем категорию для перевода: ${category.id}`);

            // Расширенный список селекторов для поиска заголовков категорий
            const selectors = [
                `#${category.id} .category-title`,
                `[data-category-id="${category.id}"] .category-title`,
                `#${category.id} h2.category-title`,
                `#${category.id} h2`,
                `#${category.id} h3`,
                `.menu-category[id="${category.id}"] .category-title`,
                `.menu-category[data-category-id="${category.id}"] .category-title`,
                `[id="${category.id}"] .framer-text.category-title`,
                `[id="${category.id}"] .framer-styles-preset-12lj5ox`,
                `#${category.id} .framer-text`
            ];

            let foundElement = null;
            let usedSelector = '';

            // Пробуем каждый селектор по очереди
            for (const selector of selectors) {
                const elements = document.querySelectorAll(selector);
                console.log(`   Селектор "${selector}" найдено: ${elements.length} элементов`);

                if (elements.length > 0) {
                    foundElement = elements[0]; // Берем первый найденный
                    usedSelector = selector;
                    break;
                }
            }

            if (foundElement) {
                let title = category.name;
                if (lang === 'ru' && category.nameRu) {
                    title = category.nameRu;
                } else if (lang === 'lv' && category.nameLv) {
                    title = category.nameLv;
                }

                const oldText = foundElement.textContent;
                foundElement.textContent = title + (category.spicy ? ' 🌶️' : '');
                console.log(`✅ Переведена категория: ${category.id} -> "${oldText}" стал "${title}" (селектор: ${usedSelector})`);
            } else {
                console.warn(`❌ Не найден элемент категории: ${category.id}`);

                // Отладочная информация - покажем все элементы с id категории
                const categoryContainer = document.getElementById(category.id);
                if (categoryContainer) {
                    console.log(`📍 Контейнер категории найден:`, categoryContainer);
                    console.log(`📍 HTML контейнера:`, categoryContainer.innerHTML.substring(0, 200) + '...');
                } else {
                    console.log(`📍 Контейнер категории с id="${category.id}" не найден`);
                }
            }

            // Обновляем все элементы меню в категории
            category.items.forEach((item) => {
                this.translateMenuItem(item, lang);
            });
        });

        // Обновляем статические элементы интерфейса
        this.updateInterfaceElements(lang);
    }

    // Перевод отдельного элемента меню
    translateMenuItem(item, lang) {
        // Ищем элемент по разным селекторам
        const itemSelectors = [
            `[data-item-id="${item.id}"]`,
            `#${item.id}`,
            `.menu-item-card[data-item-id="${item.id}"]`
        ];

        let itemElement = null;
        for (const selector of itemSelectors) {
            itemElement = document.querySelector(selector);
            if (itemElement) break;
        }

        if (itemElement) {
            // Обновляем название блюда
            const nameSelectors = [
                '.item-name',
                '.menu-item-name',
                'h3',
                'h4',
                '.card-header h3'
            ];

            for (const selector of nameSelectors) {
                const itemName = itemElement.querySelector(selector);
                if (itemName) {
                    let name = item.name;
                    if (lang === 'ru' && item.nameRu) {
                        name = item.nameRu;
                    } else if (lang === 'lv' && item.nameLv) {
                        name = item.nameLv;
                    }
                    itemName.textContent = name;
                    console.log(`✅ Переведено название: ${item.id} -> ${name}`);
                    break;
                }
            }

            // Обновляем описание блюда
            const descSelectors = [
                '.item-description',
                '.menu-item-description',
                'p',
                '.card-content p'
            ];

            for (const selector of descSelectors) {
                const itemDescription = itemElement.querySelector(selector);
                if (itemDescription && itemDescription.textContent.length > 10) {
                    let description = item.description;
                    if (lang === 'ru' && item.descriptionRu) {
                        description = item.descriptionRu;
                    } else if (lang === 'lv' && item.descriptionLv) {
                        description = item.descriptionLv;
                    }

                    // Обрезаем описание если нужно
                    if (description && description.length > 70) {
                        description = description.substring(0, 70) + '...';
                    }

                    if (description) {
                        itemDescription.textContent = description;
                        console.log(`✅ Переведено описание: ${item.id}`);
                    }
                    break;
                }
            }

            // Обновляем описания цен для dual-price карточек
            if (item.type === 'dual_price') {
                const price1DescElements = itemElement.querySelectorAll('.price-option:first-child .description');
                price1DescElements.forEach(desc => {
                    let price1Desc = item.price1Desc;
                    if (lang === 'ru' && item.price1DescRu) {
                        price1Desc = item.price1DescRu;
                    } else if (lang === 'lv' && item.price1DescLv) {
                        price1Desc = item.price1DescLv;
                    }
                    if (price1Desc) desc.textContent = price1Desc;
                });

                const price2DescElements = itemElement.querySelectorAll('.price-option:last-child .description');
                price2DescElements.forEach(desc => {
                    let price2Desc = item.price2Desc;
                    if (lang === 'ru' && item.price2DescRu) {
                        price2Desc = item.price2DescRu;
                    } else if (lang === 'lv' && item.price2DescLv) {
                        price2Desc = item.price2DescLv;
                    }
                    if (price2Desc) desc.textContent = price2Desc;
                });
            }

            // Обновляем объем для алкогольных карточек
            if (item.type === 'alcohol' && item.volume) {
                const volumeElements = itemElement.querySelectorAll('.alcohol-option .description');
                volumeElements.forEach(vol => {
                    let volume = item.volume;
                    if (lang === 'ru' && item.volumeRu) {
                        volume = item.volumeRu;
                    } else if (lang === 'lv' && item.volumeLv) {
                        volume = item.volumeLv;
                    }
                    if (volume) vol.textContent = volume;
                });
            }
        }
    }

    // Обновление элементов интерфейса
    updateInterfaceElements(lang) {
        // Обновляем кнопку "Назад"
        const backBtnText = document.getElementById('backBtnText');
        if (backBtnText && this.translations[lang]) {
            backBtnText.textContent = this.translations[lang].back;
        }

        // Обновляем заголовок "Категории" в выпадающем меню
        const categoriesHeader = document.querySelector('.category-dropdown-header h3');
        if (categoriesHeader && this.translations[lang]) {
            categoriesHeader.textContent = this.translations[lang].categories;
        }

        // Обновляем заголовок страницы
        if (this.menuData) {
            let title = this.menuData.pageTitle;
            if (lang === 'ru' && this.menuData.pageTitleRu) {
                title = this.menuData.pageTitleRu;
            } else if (lang === 'lv' && this.menuData.pageTitleLv) {
                title = this.menuData.pageTitleLv;
            }
            document.title = title;
        }

        // Обновляем ссылки "Back" с правильным языковым параметром
        this.updateBackLinks(lang);

        // Обновляем переводы модального окна и корзины
        this.updateModalTranslations(lang);
        this.updateCartTranslations(lang);
    }

    // Обновление переводов модального окна
    updateModalTranslations(lang) {
        // Обновляем кнопку "Добавить в корзину" в модальном окне
        const addToCartBtn = document.getElementById('addToCartBtn');
        if (addToCartBtn && this.translations[lang]) {
            const span = addToCartBtn.querySelector('span');
            if (span) {
                span.textContent = this.translations[lang].addToCart;
            }
        }

        // Обновляем все кнопки "Добавить в корзину" на странице
        const allAddToCartBtns = document.querySelectorAll('.add-to-cart-btn span');
        allAddToCartBtns.forEach(span => {
            if (this.translations[lang]) {
                span.textContent = this.translations[lang].addToCart;
            }
        });
    }

    // Обновление переводов корзины
    updateCartTranslations(lang) {
        if (!this.translations[lang]) return;

        // Обновляем заголовок корзины "Ваш заказ"
        const cartModalHeader = document.querySelector('.cart-modal-header h2');
        if (cartModalHeader) {
            cartModalHeader.textContent = this.translations[lang].yourOrder;
        }

        // Обновляем сообщение о пустой корзине
        const cartEmptyMessage = document.querySelector('.cart-empty-message p');
        if (cartEmptyMessage) {
            cartEmptyMessage.textContent = this.translations[lang].cartEmpty;
        }

        const cartEmptySmall = document.querySelector('.cart-empty-message small');
        if (cartEmptySmall) {
            cartEmptySmall.textContent = this.translations[lang].addItemsFromMenu;
        }

        // Обновляем кнопку "Заказать"
        const orderBtn = document.getElementById('orderBtn');
        if (orderBtn) {
            const span = orderBtn.querySelector('span');
            if (span) {
                span.textContent = this.translations[lang].orderBtn;
            }
        }

        // Обновляем "Общая сумма"
        const totalLabel = document.querySelector('.total-label');
        if (totalLabel) {
            totalLabel.textContent = this.translations[lang].totalAmount;
        }
    }

    getCurrentLanguage() {
        return this.currentLanguage;
    }

    // Функция для правильного склонения слова "товар" в зависимости от количества
    getItemCountText(count, lang = null) {
        if (!lang) lang = this.currentLanguage;

        const translations = this.translations[lang];
        if (!translations) return `${count} items`;

        if (lang === 'ru') {
            // Русское склонение
            if (count === 1) {
                return `${count} ${translations.itemSingular}`;
            } else if (count >= 2 && count <= 4) {
                return `${count} ${translations.itemGenitive2to4}`;
            } else {
                return `${count} ${translations.itemGenitivePlural}`;
            }
        } else if (lang === 'en') {
            // Английское склонение
            return count === 1
                ? `${count} ${translations.itemSingular}`
                : `${count} ${translations.itemPlural}`;
        } else if (lang === 'lv') {
            // Латышское склонение
            return count === 1
                ? `${count} ${translations.itemSingular}`
                : `${count} ${translations.itemPlural}`;
        }

        // Fallback
        return `${count} items`;
    }
}

// Инициализируем менеджер многоязычности
const multilingualManager = new MultilingualManager();

// Экспортируем для использования другими скриптами
window.multilingualManager = multilingualManager;
