// Category Dropdown Menu JavaScript

let categoryDropdownOpen = false;

// Функция для открытия выпадающего меню категорий
function openCategoryDropdown() {
  const dropdown = document.getElementById('categoryDropdown');
  const menuButton = document.getElementById('categoryMenuBtn');

  if (dropdown) dropdown.classList.add('active');
  if (menuButton) menuButton.classList.add('active');

  categoryDropdownOpen = true;
  document.body.classList.add('menu-open');

  console.log('📂 Category Dropdown: Opened');
}

// Функция для закрытия выпадающего меню категорий
function closeCategoryDropdown() {
  const dropdown = document.getElementById('categoryDropdown');
  const menuButton = document.getElementById('categoryMenuBtn');

  if (dropdown) dropdown.classList.remove('active');
  if (menuButton) menuButton.classList.remove('active');

  categoryDropdownOpen = false;
  document.body.classList.remove('menu-open');

  console.log('📂 Category Dropdown: Closed');
}

// Функция для переключения состояния меню
function toggleCategoryDropdown() {
  if (categoryDropdownOpen) {
    closeCategoryDropdown();
  } else {
    openCategoryDropdown();
  }
}

// Функция для плавного скролла к категории
function scrollToCategory(categoryId) {
  const targetElement = document.getElementById(categoryId);

  if (targetElement) {
    // Закрываем меню перед скроллом
    closeCategoryDropdown();

    console.log(`📂 Category Dropdown: Navigating to ${categoryId}`);

    // НОВОЕ: Используем безопасную навигацию если доступна
    if (window.menuCardsInstance && window.menuCardsInstance.navigateToCategory) {
      window.menuCardsInstance.navigateToCategory(categoryId);
    } else {
      // Fallback к обычному скроллу
      const header = document.querySelector('.custom-header');
      const headerHeight = header ? header.offsetHeight : 80;
      const elementPosition = targetElement.offsetTop;
      const offsetPosition = elementPosition - headerHeight - 20;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  }
}

// Функция для получения названия категории с учетом языка
function getCategoryName(category) {
  if (!category) {
    console.warn('📂 Category Dropdown: Категория не найдена');
    return 'Loading...';
  }

  let categoryName = '';

  if (window.multilingualManager) {
    const currentLang = window.multilingualManager.getCurrentLanguage();
    if (currentLang === 'ru' && category.nameRu) {
      categoryName = category.nameRu;
    } else if (currentLang === 'lv' && category.nameLv) {
      categoryName = category.nameLv;
    } else {
      categoryName = category.name;
    }
  } else {
    categoryName = category.name;
  }

  // Защита от пустых названий или ID категорий
  if (!categoryName || categoryName.trim() === '' || categoryName.includes('category-')) {
    console.warn('📂 Category Dropdown: Некорректное название категории', category);
    return 'Loading...';
  }

  return categoryName;
}

// Функция для заполнения dropdown категориями
function populateDropdownWithCategories(categories) {
  const dropdownItems = document.getElementById('categoryDropdownItems');
  if (!dropdownItems) return;

  // Очищаем существующие элементы
  dropdownItems.innerHTML = '';

  // Создаем элементы меню для каждой категории
  categories.forEach(category => {
    const item = document.createElement('div');
    item.className = 'category-dropdown-item';

    // Получаем название с учетом языка
    const categoryName = getCategoryName(category);
    item.textContent = categoryName;
    item.setAttribute('data-category', category.id);

    // Добавляем обработчик клика
    item.addEventListener('click', function(e) {
      e.preventDefault();
      scrollToCategory(category.id);
    });

    dropdownItems.appendChild(item);
  });

  console.log('✅ Category Dropdown: Loaded categories:', categories.length);
}

// Функция для поиска категорий в DOM (запасной вариант)
function loadCategoriesFromDOM() {
  const dropdownItems = document.getElementById('categoryDropdownItems');
  if (!dropdownItems) return;

  // Очищаем существующие элементы
  dropdownItems.innerHTML = '';

  // Получаем все категории из DOM
  const categories = [];

  // Проверяем carousel items
  const carouselItems = document.querySelectorAll('#carousel-items .carousel-item');
  carouselItems.forEach(item => {
    const categoryId = item.getAttribute('data-category-id') || item.getAttribute('href')?.replace('#', '');
    const categoryName = item.textContent.trim();

    if (categoryId && categoryName) {
      categories.push({
        id: categoryId,
        name: categoryName
      });
    }
  });

  // Если carousel пустой, ищем категории по ID
  if (categories.length === 0) {
    const categoryElements = document.querySelectorAll('[id^="category-"], .framer-cr81gk[id], .framer-1mbvkdt[id], .framer-txxmxk[id]');

    categoryElements.forEach(element => {
      const categoryId = element.id;

      if (categoryId) {
        // Находим заголовок категории
        const titleElement = element.querySelector('h2, h3, .framer-text');
        const categoryName = titleElement ? titleElement.textContent.trim() : categoryId;

        if (categoryName && !categories.some(cat => cat.id === categoryId)) {
          categories.push({
            id: categoryId,
            name: categoryName
          });
        }
      }
    });
  }

  // Статические категории как запасной вариант
  if (categories.length === 0) {
    const defaultCategories = [
      { id: 'maki', name: 'Maki' },
      { id: 'urmaki', name: 'Uramaki' },
      { id: 'special', name: 'Special Rolls' }
    ];

    categories.push(...defaultCategories);
  }

  // Создаем элементы меню
  categories.forEach(category => {
    const item = document.createElement('div');
    item.className = 'category-dropdown-item';
    item.textContent = category.name;
    item.setAttribute('data-category', category.id);

    item.addEventListener('click', function(e) {
      e.preventDefault();
      scrollToCategory(category.id);
    });

    dropdownItems.appendChild(item);
  });

  console.log('📋 Category Dropdown: Loaded from DOM:', categories.length);
}

// Функция для загрузки категорий в выпадающее меню
function loadCategoriesIntoDropdown() {
  // Функция для загрузки из существующей системы
  const loadFromCarouselInstance = () => {
    if (window.categoryCarouselInstance && window.categoryCarouselInstance.categories.length > 0) {
      const categories = window.categoryCarouselInstance.categories;
      populateDropdownWithCategories(categories);
      return true;
    }
    return false;
  };

  // Функция для загрузки из menu-cards
  const loadFromMenuCards = () => {
    if (window.menuCardsInstance && window.menuCardsInstance.menuData && window.menuCardsInstance.menuData.categories) {
      const categories = window.menuCardsInstance.menuData.categories;
      populateDropdownWithCategories(categories);
      return true;
    }
    return false;
  };

  // Пытаемся загрузить сразу
  if (loadFromCarouselInstance() || loadFromMenuCards()) {
    return;
  }

  // Если не удалось загрузить сразу, ждем
  const checkForData = () => {
    if (loadFromCarouselInstance() || loadFromMenuCards()) {
      return;
    }

    // Попытка поиска в DOM
    setTimeout(() => {
      loadCategoriesFromDOM();
    }, 500);
  };

  // Ждем немного и пытаемся снова
  setTimeout(checkForData, 1000);
}

// Функция для обновления названий категорий при смене языка
function updateCategoryNames() {
  const dropdownItems = document.getElementById('categoryDropdownItems');
  if (!dropdownItems) return;

  const items = dropdownItems.querySelectorAll('.category-dropdown-item');

  if (window.categoryCarouselInstance && window.categoryCarouselInstance.categories) {
    const categories = window.categoryCarouselInstance.categories;

    items.forEach((item, index) => {
      if (categories[index]) {
        const categoryName = getCategoryName(categories[index]);
        item.textContent = categoryName;
      }
    });

    console.log('🌐 Category Dropdown: Updated language');
  }

  // Также обновляем заголовок "Категории"
  const categoriesHeader = document.querySelector('.category-dropdown-header h3');
  if (categoriesHeader && window.multilingualManager && window.multilingualManager.translations) {
    const currentLang = window.multilingualManager.getCurrentLanguage();
    const translations = window.multilingualManager.translations;
    if (translations[currentLang] && translations[currentLang].categories) {
      categoriesHeader.textContent = translations[currentLang].categories;
    }
  }
}

// Автообновление dropdown меню, если категории не загрузились
function setupDropdownAutoRefresh() {
  const refreshInterval = 3000; // Проверяем каждые 3 секунды
  let refreshAttempts = 0;
  const maxRefreshAttempts = 10; // Максимум 10 попыток (30 секунд)

  const checkAndRefresh = () => {
    const dropdownItems = document.getElementById('categoryDropdownItems');
    if (!dropdownItems) return;

    const items = dropdownItems.querySelectorAll('.category-dropdown-item');

    // Если нет элементов в dropdown
    if (items.length === 0) {
      console.log('🔄 Category Dropdown: Нет элементов, пытаемся загрузить...');
      loadCategoriesIntoDropdown();

      // Планируем следующую проверку
      refreshAttempts++;
      if (refreshAttempts < maxRefreshAttempts) {
        setTimeout(checkAndRefresh, refreshInterval);
      }
      return;
    }

    // Проверяем, есть ли проблемы с названиями категорий
    let hasInvalidNames = false;
    items.forEach(item => {
      const text = item.textContent.trim();
      if (text === '' || text === 'Loading...' || text.toLowerCase().includes('category-') || text.includes('carousel')) {
        hasInvalidNames = true;
      }
    });

    // Если есть проблемы с названиями и данные доступны
    if (hasInvalidNames) {
      console.log('🔄 Category Dropdown: Обнаружены некорректные названия, обновляем dropdown...');

      // Пытаемся загрузить из разных источников
      const loadFromMenuCards = () => {
        if (window.menuCardsInstance && window.menuCardsInstance.menuData && window.menuCardsInstance.menuData.categories) {
          const categories = window.menuCardsInstance.menuData.categories;
          const validCategories = categories.filter(cat => cat.name || cat.nameRu || cat.nameLv);

          if (validCategories.length > 0) {
            populateDropdownWithCategories(validCategories);
            console.log('✅ Category Dropdown: Обновлен с корректными данными из MenuCards');
            return true;
          }
        }
        return false;
      };

      const loadFromCarousel = () => {
        if (window.categoryCarouselInstance && window.categoryCarouselInstance.categories.length > 0) {
          const categories = window.categoryCarouselInstance.categories;
          const validCategories = categories.filter(cat => cat.name || cat.nameRu || cat.nameLv);

          if (validCategories.length > 0) {
            populateDropdownWithCategories(validCategories);
            console.log('✅ Category Dropdown: Обновлен с корректными данными из Carousel');
            return true;
          }
        }
        return false;
      };

      // Пытаемся загрузить из доступных источников
      if (loadFromMenuCards() || loadFromCarousel()) {
        console.log('✅ Category Dropdown: Dropdown успешно обновлен');
        return; // Выходим, больше не планируем обновления
      }
    } else if (items.length > 0) {
      // Все в порядке, останавливаем автообновление
      console.log('✅ Category Dropdown: Все категории загружены корректно, автообновление остановлено');
      return; // Выходим из функции, больше не планируем обновления
    }

    // Планируем следующую проверку, если еще не достигли лимита
    refreshAttempts++;
    if (refreshAttempts < maxRefreshAttempts) {
      setTimeout(checkAndRefresh, refreshInterval);
    } else {
      console.warn('⚠️ Category Dropdown: Достигнут максимум попыток автообновления');
    }
  };

  // Запускаем первую проверку через 3 секунды после инициализации
  setTimeout(checkAndRefresh, refreshInterval);
  console.log('🔄 Category Dropdown: Автообновление настроено');
}

// Инициализация при загрузке DOM
document.addEventListener('DOMContentLoaded', function() {
  // Обработчик клика на кнопку Menu
  const menuButton = document.getElementById('categoryMenuBtn');
  if (menuButton) {
    menuButton.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      toggleCategoryDropdown();
    });
  }

  // Обработчик клика на кнопку закрытия
  const closeButton = document.getElementById('categoryDropdownClose');
  if (closeButton) {
    closeButton.addEventListener('click', function(e) {
      e.preventDefault();
      closeCategoryDropdown();
    });
  }

  // Закрытие по ESC
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && categoryDropdownOpen) {
      closeCategoryDropdown();
    }
  });

  // Закрытие при клике вне меню
  document.addEventListener('click', function(e) {
    const dropdown = document.getElementById('categoryDropdown');
    const menuButton = document.getElementById('categoryMenuBtn');

    if (categoryDropdownOpen && dropdown && menuButton) {
      // Проверяем, что клик был не по меню и не по кнопке
      if (!dropdown.contains(e.target) && !menuButton.contains(e.target)) {
        closeCategoryDropdown();
      }
    }
  });

  // Загружаем категории в выпадающее меню
  loadCategoriesIntoDropdown();

  // Слушаем обновления меню
  document.addEventListener('menuDataUpdated', (event) => {
    if (event.detail && event.detail.categories) {
      populateDropdownWithCategories(event.detail.categories);
    }
  });

  // Слушаем смену языка
  document.addEventListener('languageChanged', (event) => {
    updateCategoryNames();
  });

  // Перезагружаем категории при изменении контента
  const observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        // Проверяем, добавились ли элементы карусели или меню
        const addedElements = Array.from(mutation.addedNodes);
        const hasMenuContent = addedElements.some(node =>
          node.nodeType === 1 && (
            node.id === 'carousel-items' ||
            node.querySelector && node.querySelector('#carousel-items, .dynamic-menu-content')
          )
        );

        if (hasMenuContent) {
          setTimeout(loadCategoriesIntoDropdown, 500);
        }
      }
    });
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  // Запускаем автообновление dropdown меню
  setupDropdownAutoRefresh();
});

// Автообновление dropdown меню, если категории не загрузились
function setupDropdownAutoRefresh() {
  const refreshInterval = 3000; // Проверяем каждые 3 секунды
  let refreshAttempts = 0;
  const maxRefreshAttempts = 10; // Максимум 10 попыток

  const checkAndRefresh = () => {
    const dropdownItems = document.getElementById('categoryDropdownItems');
    if (!dropdownItems) return;

    const items = dropdownItems.querySelectorAll('.category-dropdown-item');

    // Если нет элементов в dropdown
    if (items.length === 0) {
      console.log('🔄 Category Dropdown: Нет элементов, пытаемся загрузить...');
      loadCategoriesIntoDropdown();
    } else {
      // Проверяем, есть ли проблемы с названиями категорий
      let hasInvalidNames = false;
      items.forEach(item => {
        const text = item.textContent.trim();
        if (text === '' || text === 'Loading...' || text.toLowerCase().includes('category-') || text.includes('carousel')) {
          hasInvalidNames = true;
        }
      });

      // Если есть проблемы с названиями и данные доступны
      if (hasInvalidNames && window.menuCardsInstance && window.menuCardsInstance.menuData) {
        console.log('🔄 Category Dropdown: Обнаружены некорректные названия, обновляем dropdown...');
        const categories = window.menuCardsInstance.menuData.categories;
        if (categories && categories.length > 0) {
          populateDropdownWithCategories(categories);
          console.log('✅ Category Dropdown: Обновлен с корректными данными');
          return; // Останавливаем автообновление
        }
      } else if (!hasInvalidNames && items.length > 0) {
        console.log('✅ Category Dropdown: Все категории корректны, автообновление остановлено');
        return; // Останавливаем автообновление
      }
    }

    // Планируем следующую проверку
    refreshAttempts++;
    if (refreshAttempts < maxRefreshAttempts) {
      setTimeout(checkAndRefresh, refreshInterval);
    } else {
      console.warn('⚠️ Category Dropdown: Достигнут максимум попыток автообновления');
    }
  };

  // Запускаем первую проверку через 3 секунды
  setTimeout(checkAndRefresh, refreshInterval);
  console.log('🔄 Category Dropdown: Автообновление настроено');
}

// Экспортируем функции для использования в других скриптах
window.categoryDropdown = {
  open: openCategoryDropdown,
  close: closeCategoryDropdown,
  toggle: toggleCategoryDropdown,
  scrollToCategory: scrollToCategory,
  loadCategories: loadCategoriesIntoDropdown,
  updateLanguage: updateCategoryNames,
  setupAutoRefresh: setupDropdownAutoRefresh
};
