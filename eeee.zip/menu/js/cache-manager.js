// Упрощенный менеджер кеша для menu.html (без изменения CSS)
class CacheManager {
    constructor() {
        this.init();
    }

    // Инициализация менеджера кеша
    init() {
        console.log('Cache manager initialized for menu.html - HTML cache only');
    }

    // Сохранение данных сессии
    preserveSessionData() {
        const sessionData = {};
        const preserveKeys = ['session_id', 'table_number', 'qr_data', 'user_session', 'menu_cache_cleared'];

        preserveKeys.forEach(key => {
            const value = sessionStorage.getItem(key);
            if (value) {
                sessionData[key] = value;
            }
        });

        return sessionData;
    }

    // Восстановление данных сессии
    restoreSessionData(sessionData) {
        Object.keys(sessionData).forEach(key => {
            sessionStorage.setItem(key, sessionData[key]);
        });
    }

    // Принудительное обновление страницы с очисткой кеша
    forceRefresh() {
        // Сохраняем сессию
        const sessionData = this.preserveSessionData();

        // Очищаем флаг кеша, чтобы при следующей загрузке произошло обновление
        sessionStorage.removeItem('menu_cache_cleared');

        // Перезагружаем страницу с очисткой кеша
        window.location.reload(true);

        // Восстанавливаем сессию после перезагрузки
        setTimeout(() => {
            this.restoreSessionData(sessionData);
        }, 100);
    }
}

// Инициализируем менеджер кеша только для menu.html
if (window.location.pathname.includes('menu.html')) {
    window.cacheManager = new CacheManager();
}
