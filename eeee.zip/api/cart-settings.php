<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Обработка OPTIONS запроса
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$cartSettingsFile = '../data/cart-settings.json';

// Функция для чтения настроек корзины
function getCartSettings() {
    global $cartSettingsFile;

    if (!file_exists($cartSettingsFile)) {
        // Создаем файл с настройками по умолчанию
        $defaultSettings = [
            'cartVisible' => true,
            'lastUpdated' => date('Y-m-d H:i:s')
        ];
        file_put_contents($cartSettingsFile, json_encode($defaultSettings, JSON_PRETTY_PRINT));
        return $defaultSettings;
    }

    $content = file_get_contents($cartSettingsFile);
    return json_decode($content, true) ?: ['cartVisible' => true, 'lastUpdated' => date('Y-m-d H:i:s')];
}

// Функция для сохранения настроек корзины
function saveCartSettings($settings) {
    global $cartSettingsFile;

    $settings['lastUpdated'] = date('Y-m-d H:i:s');

    if (file_put_contents($cartSettingsFile, json_encode($settings, JSON_PRETTY_PRINT))) {
        return true;
    }
    return false;
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Возвращаем текущие настройки
        $settings = getCartSettings();
        echo json_encode([
            'success' => true,
            'data' => $settings
        ]);

    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Получаем данные из запроса
        $input = json_decode(file_get_contents('php://input'), true);

        if (!$input) {
            throw new Exception('Неверные данные запроса');
        }

        // Валидация данных
        $cartVisible = isset($input['cartVisible']) ? (bool)$input['cartVisible'] : true;

        $settings = [
            'cartVisible' => $cartVisible
        ];

        if (saveCartSettings($settings)) {
            echo json_encode([
                'success' => true,
                'message' => 'Настройки корзины успешно сохранены',
                'data' => $settings
            ]);
        } else {
            throw new Exception('Ошибка при сохранении настроек');
        }

    } else {
        throw new Exception('Метод не поддерживается');
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
