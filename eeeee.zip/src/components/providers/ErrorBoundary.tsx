"use client";

import React from 'react';

interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
  errorInfo?: React.ErrorInfo;
}

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('TMA: React Error Boundary caught an error:', error, errorInfo);

    this.setState({
      error,
      errorInfo
    });

    // Показываем ошибку пользователю
    this.showErrorToUser(error, errorInfo);
  }

  showErrorToUser(error: Error, errorInfo: React.ErrorInfo) {
    const errorDiv = document.createElement('div');
    errorDiv.style.cssText = `
      position: fixed;
      top: 20px;
      left: 20px;
      right: 20px;
      background: #cc4444;
      color: white;
      padding: 15px;
      border-radius: 8px;
      z-index: 10000;
      font-family: monospace;
      font-size: 12px;
      max-height: 300px;
      overflow-y: auto;
      border: 2px solid #aa0000;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    `;

    errorDiv.innerHTML = `
      <div style="font-weight: bold; margin-bottom: 10px;">🔥 React компонент сломался:</div>
      <div style="margin-bottom: 5px;"><strong>Ошибка:</strong> ${error.message}</div>
      <details style="margin-top: 10px;">
        <summary style="cursor: pointer;">Stack trace</summary>
        <div style="font-size: 10px; opacity: 0.8; margin-top: 5px; white-space: pre-wrap;">${error.stack || 'Стек недоступен'}</div>
      </details>
      <details style="margin-top: 10px;">
        <summary style="cursor: pointer;">Component stack</summary>
        <div style="font-size: 10px; opacity: 0.8; margin-top: 5px; white-space: pre-wrap;">${errorInfo.componentStack}</div>
      </details>
      <button onclick="this.parentElement.remove()" style="
        position: absolute;
        top: 5px;
        right: 5px;
        background: none;
        border: none;
        color: white;
        cursor: pointer;
        font-size: 18px;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
      ">×</button>
      <button onclick="window.location.reload()" style="
        background: #aa0000;
        color: white;
        border: none;
        padding: 5px 10px;
        border-radius: 4px;
        cursor: pointer;
        margin-top: 10px;
        font-size: 11px;
      ">Перезагрузить страницу</button>
    `;

    document.body.appendChild(errorDiv);

    setTimeout(() => {
      if (errorDiv.parentElement) {
        errorDiv.remove();
      }
    }, 20000);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          padding: '20px',
          textAlign: 'center',
          backgroundColor: '#ff4444',
          color: 'white',
          borderRadius: '8px',
          margin: '20px'
        }}>
          <h2>🔥 Что-то сломалось!</h2>
          <p>Компонент столкнулся с ошибкой и не может отобразиться.</p>
          <details style={{ marginTop: '10px', textAlign: 'left' }}>
            <summary style={{ cursor: 'pointer' }}>Подробности ошибки</summary>
            <div style={{
              backgroundColor: 'rgba(0,0,0,0.2)',
              padding: '10px',
              borderRadius: '4px',
              marginTop: '10px',
              fontSize: '12px',
              fontFamily: 'monospace'
            }}>
              <div><strong>Ошибка:</strong> {this.state.error?.message}</div>
              <div style={{ marginTop: '5px' }}><strong>Stack:</strong></div>
              <pre style={{ whiteSpace: 'pre-wrap', fontSize: '10px' }}>
                {this.state.error?.stack}
              </pre>
            </div>
          </details>
          <button
            onClick={() => window.location.reload()}
            style={{
              backgroundColor: '#aa0000',
              color: 'white',
              border: 'none',
              padding: '10px 20px',
              borderRadius: '4px',
              cursor: 'pointer',
              marginTop: '15px'
            }}
          >
            Перезагрузить страницу
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
