/**
 * Withdrawal Daemon
 * Автоматически обрабатывает запросы на вывод TON
 */

import { query } from './database';
import { tonWithdrawalService } from './ton-withdrawal-service';

interface PendingWithdrawal {
  id: number;
  telegram_id: number;
  amount: number;
  commission: number;
  net_amount: number;
  target_wallet: string;
  priority: number;
  created_at: string;
  status: string;
}

class WithdrawalDaemon {
  private isProcessing = false;
  private intervalId: NodeJS.Timeout | null = null;
  private readonly PROCESS_INTERVAL = 60000; // 60 секунд (увеличено для избежания rate limiting)
  private readonly MAX_CONCURRENT_WITHDRAWALS = 3;

  constructor() {
    console.log('Withdrawal Daemon initialized');
  }

  start() {
    if (this.intervalId) {
      console.log('Withdrawal Daemon is already running');
      return;
    }

    console.log('Starting Withdrawal Daemon...');
    this.intervalId = setInterval(() => {
      this.processWithdrawals();
    }, this.PROCESS_INTERVAL);

    // Запускаем первую обработку сразу
    this.processWithdrawals();
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
      console.log('Withdrawal Daemon stopped');
    }
  }

  async processWithdrawals() {
    if (this.isProcessing) {
      console.log('Withdrawal processing already in progress, skipping...');
      return;
    }

    this.isProcessing = true;

    try {
      console.log('Processing pending withdrawals...');

      // Получаем ожидающие запросы на вывод
      const pendingResult = await query(`
        SELECT id, telegram_id, amount, commission, net_amount, target_wallet, priority, created_at, status
        FROM withdrawal_requests
        WHERE status = 'pending'
        ORDER BY priority DESC, created_at ASC
        LIMIT $1
      `, [this.MAX_CONCURRENT_WITHDRAWALS]);

      const pendingWithdrawals: PendingWithdrawal[] = pendingResult.rows;

      if (pendingWithdrawals.length === 0) {
        console.log('No pending withdrawals found');
        return;
      }

      console.log(`Found ${pendingWithdrawals.length} pending withdrawals`);

      // Обрабатываем каждый запрос
      for (const withdrawal of pendingWithdrawals) {
        await this.processSingleWithdrawal(withdrawal);
      }

    } catch (error) {
      console.error('Error in withdrawal daemon:', error);
    } finally {
      this.isProcessing = false;
    }
  }

  private async processSingleWithdrawal(withdrawal: PendingWithdrawal) {
    try {
      console.log(`Processing withdrawal ${withdrawal.id} for user ${withdrawal.telegram_id}`);

      // Обновляем статус на "processing"
      await query(`
        UPDATE withdrawal_requests
        SET status = 'processing', processed_at = CURRENT_TIMESTAMP
        WHERE id = $1
      `, [withdrawal.id]);

      // Проверяем валидность адреса кошелька
      const isValidAddress = await tonWithdrawalService.validateWalletAddress(withdrawal.target_wallet);
      if (!isValidAddress) {
        await this.markWithdrawalFailed(withdrawal.id, 'Invalid wallet address');
        return;
      }

      // Проверяем баланс сервисного кошелька
      const serviceBalance = await tonWithdrawalService.getWalletBalance();
      if (serviceBalance < withdrawal.net_amount + 0.1) { // +0.1 TON для комиссий
        await this.markWithdrawalFailed(withdrawal.id, 'Insufficient service wallet balance');
        console.error(`Insufficient service wallet balance: ${serviceBalance} TON, required: ${withdrawal.net_amount + 0.1} TON`);
        return;
      }

      // Выполняем вывод
      const result = await tonWithdrawalService.processWithdrawal(withdrawal);

      if (result.success && result.txHash) {
        // Успешно обработано
        await query(`
          UPDATE withdrawal_requests
          SET status = 'completed', transaction_hash = $2, processed_at = CURRENT_TIMESTAMP
          WHERE id = $1
        `, [withdrawal.id, result.txHash]);

        // Добавляем запись в историю
        await query(`
          INSERT INTO withdrawal_history
          (telegram_id, amount, commission, net_amount, target_wallet, transaction_hash, status, withdrawal_type, processing_time_seconds, created_at, completed_at)
          VALUES ($1, $2, $3, $4, $5, $6, 'completed', 'automatic',
                  EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - $7))::INTEGER, $7, CURRENT_TIMESTAMP)
        `, [
          withdrawal.telegram_id,
          withdrawal.amount,
          withdrawal.commission,
          withdrawal.net_amount,
          withdrawal.target_wallet,
          result.txHash,
          withdrawal.created_at
        ]);

        console.log(`Withdrawal ${withdrawal.id} completed successfully. TX: ${result.txHash}`);

        // Отправляем уведомление пользователю (если есть Telegram Bot)
        await this.sendNotificationToUser(withdrawal.telegram_id, {
          type: 'withdrawal_completed',
          amount: withdrawal.net_amount,
          txHash: result.txHash
        });

      } else {
        // Ошибка при обработке
        await this.markWithdrawalFailed(withdrawal.id, result.error || 'Unknown error');
      }

    } catch (error) {
      console.error(`Error processing withdrawal ${withdrawal.id}:`, error);
      await this.markWithdrawalFailed(withdrawal.id, error instanceof Error ? error.message : 'Processing error');
    }
  }

  private async markWithdrawalFailed(withdrawalId: number, errorMessage: string) {
    try {
      await query(`
        UPDATE withdrawal_requests
        SET status = 'failed', error_message = $2, processed_at = CURRENT_TIMESTAMP
        WHERE id = $1
      `, [withdrawalId, errorMessage]);

      // Возвращаем средства пользователю
      const withdrawalData = await query(`
        SELECT telegram_id, amount FROM withdrawal_requests WHERE id = $1
      `, [withdrawalId]);

      if (withdrawalData.rows.length > 0) {
        const { telegram_id, amount } = withdrawalData.rows[0];

        await query(`
          UPDATE users
          SET ton_balance = ton_balance + $1
          WHERE telegram_id = $2
        `, [amount, telegram_id]);

        console.log(`Refunded ${amount} TON to user ${telegram_id} due to failed withdrawal ${withdrawalId}`);

        // Отправляем уведомление об ошибке
        await this.sendNotificationToUser(telegram_id, {
          type: 'withdrawal_failed',
          amount: amount,
          error: errorMessage
        });
      }

    } catch (error) {
      console.error(`Error marking withdrawal ${withdrawalId} as failed:`, error);
    }
  }

  private async sendNotificationToUser(telegramId: number, notification: { type: string; amount: number; txHash?: string; error?: string }) {
    try {
      // TODO: Интеграция с Telegram Bot для отправки уведомлений
      console.log(`Notification for user ${telegramId}:`, notification);
    } catch (error) {
      console.error(`Error sending notification to user ${telegramId}:`, error);
    }
  }

  // Метод для ручного запуска проверки автовыводов
  async triggerAutoWithdrawalCheck() {
    try {
      console.log('Triggering auto-withdrawal check...');

      const response = await fetch('/api/ton/withdrawal/auto-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });

      const result = await response.json();
      console.log('Auto-withdrawal check result:', result);

      return result;
    } catch (error) {
      console.error('Error triggering auto-withdrawal check:', error);
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  getStatus() {
    return {
      isRunning: this.intervalId !== null,
      isProcessing: this.isProcessing,
      processInterval: this.PROCESS_INTERVAL,
      maxConcurrentWithdrawals: this.MAX_CONCURRENT_WITHDRAWALS
    };
  }
}

export const withdrawalDaemon = new WithdrawalDaemon();
