import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';

// GET - получить список чат-комнат
export async function GET(request: NextRequest) {
  try {
    const client = await pool.connect();

    try {
      const result = await client.query(`
        SELECT
          id,
          name,
          description,
          is_general,
          created_at,
          (SELECT COUNT(*) FROM chat_messages WHERE room_id = chat_rooms.id) as message_count
        FROM chat_rooms
        ORDER BY is_general DESC, created_at ASC
      `);

      return NextResponse.json({
        success: true,
        data: result.rows
      });
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error fetching chat rooms:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка получения чат-комнат' },
      { status: 500 }
    );
  }
}

// POST - создать новую чат-комнату (только для админов)
export async function POST(request: NextRequest) {
  try {
    const { name, description } = await request.json();

    if (!name) {
      return NextResponse.json(
        { success: false, error: 'Название комнаты обязательно' },
        { status: 400 }
      );
    }

    const client = await pool.connect();

    try {
      const result = await client.query(`
        INSERT INTO chat_rooms (name, description, is_general)
        VALUES ($1, $2, false)
        RETURNING *
      `, [name, description || null]);

      return NextResponse.json({
        success: true,
        data: result.rows[0]
      });
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error creating chat room:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка создания чат-комнаты' },
      { status: 500 }
    );
  }
}
