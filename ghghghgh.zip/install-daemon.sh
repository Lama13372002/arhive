#!/bin/bash

# Скрипт установки TON Withdrawal Daemon на VPS

set -e

echo "🚀 Installing TON Withdrawal Daemon..."

# Проверяем что мы в правильной директории
if [ ! -f "standalone-withdrawal-daemon.js" ]; then
    echo "❌ Error: standalone-withdrawal-daemon.js not found in current directory"
    echo "Please run this script from your project directory"
    exit 1
fi

# Проверяем что .env файл существует
if [ ! -f ".env" ]; then
    echo "❌ Error: .env file not found"
    echo "Please create .env file with required environment variables"
    exit 1
fi

# Получаем текущую директорию
PROJECT_DIR=$(pwd)
echo "📁 Project directory: $PROJECT_DIR"

# Делаем скрипт исполняемым
chmod +x standalone-withdrawal-daemon.js

# Создаем systemd service файл
echo "📝 Creating systemd service file..."

cat > /etc/systemd/system/ton-withdrawal-daemon.service << EOF
[Unit]
Description=TON Withdrawal Daemon
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$PROJECT_DIR
ExecStart=/usr/bin/node $PROJECT_DIR/standalone-withdrawal-daemon.js start
Restart=always
RestartSec=10
Environment=NODE_ENV=production

# Логирование
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ton-withdrawal-daemon

# Безопасность
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

# Перезагружаем systemd
echo "🔄 Reloading systemd..."
systemctl daemon-reload

# Включаем автозапуск
echo "✅ Enabling auto-start..."
systemctl enable ton-withdrawal-daemon

echo "
🎉 Installation completed!

Commands to manage the daemon:

Start daemon:
  systemctl start ton-withdrawal-daemon

Stop daemon:
  systemctl stop ton-withdrawal-daemon

Check status:
  systemctl status ton-withdrawal-daemon

View logs:
  journalctl -u ton-withdrawal-daemon -f

Restart daemon:
  systemctl restart ton-withdrawal-daemon

Manual check (one-time):
  node standalone-withdrawal-daemon.js check

Show daemon status:
  node standalone-withdrawal-daemon.js status

To start the daemon now, run:
  systemctl start ton-withdrawal-daemon
"
