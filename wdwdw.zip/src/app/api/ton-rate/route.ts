import { NextResponse } from 'next/server';

// Простое кэширование в памяти
let cachedRate: { tonToUsd: number; timestamp: number } | null = null;
const CACHE_DURATION = 60000; // 1 минута

export async function GET() {
  try {
    // Проверяем кэш
    const now = Date.now();
    if (cachedRate && (now - cachedRate.timestamp) < CACHE_DURATION) {
      return NextResponse.json({
        success: true,
        tonToUsd: cachedRate.tonToUsd,
        starsToUsd: 0.015,
        timestamp: now
      });
    }

    // Прямой запрос к CoinGecko API
    const response = await fetch(
      'https://api.coingecko.com/api/v3/simple/price?ids=the-open-network&vs_currencies=usd',
      {
        headers: {
          'Accept': 'application/json',
        },
        cache: 'no-store'
      }
    );

    if (!response.ok) {
      throw new Error(`CoinGecko API returned ${response.status}`);
    }

    const data = await response.json();
    const tonToUsd = data['the-open-network']?.usd;

    if (!tonToUsd || typeof tonToUsd !== 'number') {
      throw new Error('Invalid TON rate data from CoinGecko');
    }

    // Обновляем кэш
    cachedRate = { tonToUsd, timestamp: now };

    return NextResponse.json({
      success: true,
      tonToUsd,
      starsToUsd: 0.015,
      timestamp: now
    });

  } catch (error) {
    console.error('Error fetching TON rate:', error);

    // Если есть кэшированное значение, используем его даже если оно старое
    if (cachedRate) {
      return NextResponse.json({
        success: true,
        tonToUsd: cachedRate.tonToUsd,
        starsToUsd: 0.015,
        timestamp: Date.now()
      });
    }

    // Только если нет кэша вообще - используем дефолтное значение
    return NextResponse.json({
      success: true,
      tonToUsd: 5.1, // только если нет кэша вообще
      starsToUsd: 0.015,
      timestamp: Date.now()
    });
  }
}
