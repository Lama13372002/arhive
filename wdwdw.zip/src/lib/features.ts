// Feature flags для управления видимостью функций
export const FEATURES = {
  SHOW_STARS: false, // Скрыть все функции связанные со Stars
  SHOW_TON: true,    // Показывать функции TON
} as const;
