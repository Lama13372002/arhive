import { NextResponse, NextRequest } from 'next/server';
import { createDbConnection } from '@/lib/database';

// Получить баланс токенов пользователя
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const userIdParam = searchParams.get('user_id');

  if (!userIdParam) {
    return NextResponse.json({ error: 'user_id обязателен' }, { status: 400 });
  }

  const userId = parseInt(userIdParam);
  const client = createDbConnection();

  try {
    await client.connect();

    // Получаем баланс токенов пользователя
    const result = await client.query(`
      SELECT token_balance
      FROM users
      WHERE id = $1
    `, [userId]);

    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Пользователь не найден' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      token_balance: result.rows[0].token_balance || 0
    });

  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      { error: 'Ошибка получения баланса токенов' },
      { status: 500 }
    );
  } finally {
    await client.end();
  }
}

// Списать токены с баланса пользователя (старая версия для совместимости)
export async function POST(request: NextRequest) {
  const client = createDbConnection();

  try {
    const {
      user_id,
      session_id,
      input_tokens,
      output_tokens,
      check_only = false
    } = await request.json();

    if (!user_id || !input_tokens || !output_tokens) {
      return NextResponse.json(
        { error: 'user_id, input_tokens и output_tokens обязательны' },
        { status: 400 }
      );
    }

    const total_tokens = input_tokens + output_tokens;

    try {
      await client.connect();
      await client.query('BEGIN');

      // Проверяем текущий баланс
      const balanceResult = await client.query(`
        SELECT token_balance
        FROM users
        WHERE id = $1
      `, [user_id]);

      if (balanceResult.rows.length === 0) {
        await client.query('ROLLBACK');
        return NextResponse.json({ error: 'Пользователь не найден' }, { status: 404 });
      }

      const currentBalance = balanceResult.rows[0].token_balance || 0;

      // Проверяем, достаточно ли токенов
      if (currentBalance < total_tokens) {
        await client.query('ROLLBACK');
        return NextResponse.json({
          success: false,
          error: 'Недостаточно токенов',
          current_balance: currentBalance,
          required_tokens: total_tokens
        }, { status: 402 }); // Payment Required
      }

      // Если это только проверка, возвращаем успех без списания
      if (check_only) {
        await client.query('ROLLBACK');
        return NextResponse.json({
          success: true,
          can_proceed: true,
          current_balance: currentBalance,
          tokens_after: currentBalance - total_tokens
        });
      }

      // Списываем токены
      const newBalance = currentBalance - total_tokens;
      await client.query(`
        UPDATE users
        SET token_balance = $1, updated_at = CURRENT_TIMESTAMP
        WHERE id = $2
      `, [newBalance, user_id]);

      // Логируем использование токенов
      await client.query(`
        INSERT INTO token_usage (user_id, session_id, input_tokens, output_tokens, total_tokens, cost_tokens, created_at)
        VALUES ($1, $2, $3, $4, $5, $6, CURRENT_TIMESTAMP)
      `, [user_id, session_id, input_tokens, output_tokens, total_tokens, total_tokens]);

      await client.query('COMMIT');

      return NextResponse.json({
        success: true,
        tokens_used: total_tokens,
        new_balance: newBalance,
        input_tokens,
        output_tokens
      });

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    }

  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      { error: 'Ошибка списания токенов' },
      { status: 500 }
    );
  } finally {
    await client.end();
  }
}

// Новый endpoint для списания токенов от GPT Realtime API
export async function PATCH(request: NextRequest) {
  const client = createDbConnection();

  try {
    const {
      user_id,
      session_id,
      usage,
      check_only = false
    } = await request.json();

    // Проверяем обязательные поля
    if (!user_id || !usage) {
      return NextResponse.json(
        { error: 'user_id и usage обязательны' },
        { status: 400 }
      );
    }

    // Извлекаем данные о токенах из структуры GPT Realtime API
    const {
      total_tokens,
      input_tokens,
      output_tokens,
      input_token_details = {},
      output_token_details = {}
    } = usage;

    if (!total_tokens || !input_tokens || !output_tokens) {
      return NextResponse.json(
        { error: 'Некорректная структура данных usage' },
        { status: 400 }
      );
    }

    // Извлекаем детализированные данные о токенах
    const input_text_tokens = input_token_details.text_tokens || 0;
    const input_audio_tokens = input_token_details.audio_tokens || 0;
    const input_image_tokens = input_token_details.image_tokens || 0;
    const cached_tokens = input_token_details.cached_tokens || 0;

    const output_text_tokens = output_token_details.text_tokens || 0;
    const output_audio_tokens = output_token_details.audio_tokens || 0;

    console.log('📊 Данные о токенах от GPT Realtime:', {
      total_tokens,
      input_tokens: `${input_tokens} (text: ${input_text_tokens}, audio: ${input_audio_tokens}, image: ${input_image_tokens}, cached: ${cached_tokens})`,
      output_tokens: `${output_tokens} (text: ${output_text_tokens}, audio: ${output_audio_tokens})`
    });

    try {
      await client.connect();
      await client.query('BEGIN');

      // Проверяем текущий баланс
      const balanceResult = await client.query(`
        SELECT token_balance
        FROM users
        WHERE id = $1
      `, [user_id]);

      if (balanceResult.rows.length === 0) {
        await client.query('ROLLBACK');
        return NextResponse.json({ error: 'Пользователь не найден' }, { status: 404 });
      }

      const currentBalance = balanceResult.rows[0].token_balance || 0;

      // Проверяем, достаточно ли токенов
      if (currentBalance < total_tokens) {
        await client.query('ROLLBACK');
        return NextResponse.json({
          success: false,
          error: 'Недостаточно токенов',
          current_balance: currentBalance,
          required_tokens: total_tokens,
          usage_details: {
            input_tokens,
            output_tokens,
            total_tokens,
            input_breakdown: {
              text: input_text_tokens,
              audio: input_audio_tokens,
              image: input_image_tokens,
              cached: cached_tokens
            },
            output_breakdown: {
              text: output_text_tokens,
              audio: output_audio_tokens
            }
          }
        }, { status: 402 });
      }

      // Если это только проверка, возвращаем успех без списания
      if (check_only) {
        await client.query('ROLLBACK');
        return NextResponse.json({
          success: true,
          can_proceed: true,
          current_balance: currentBalance,
          tokens_after: currentBalance - total_tokens,
          usage_details: {
            input_tokens,
            output_tokens,
            total_tokens
          }
        });
      }

      // Списываем токены
      const newBalance = currentBalance - total_tokens;
      await client.query(`
        UPDATE users
        SET token_balance = $1, updated_at = CURRENT_TIMESTAMP
        WHERE id = $2
      `, [newBalance, user_id]);

      // Расширенное логирование использования токенов с детализацией
      await client.query(`
        INSERT INTO token_usage (
          user_id, session_id, input_tokens, output_tokens, total_tokens, cost_tokens,
          input_text_tokens, input_audio_tokens, input_image_tokens, cached_tokens,
          output_text_tokens, output_audio_tokens, created_at
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, CURRENT_TIMESTAMP)
      `, [
        user_id, session_id, input_tokens, output_tokens, total_tokens, total_tokens,
        input_text_tokens, input_audio_tokens, input_image_tokens, cached_tokens,
        output_text_tokens, output_audio_tokens
      ]);

      await client.query('COMMIT');

      console.log(`✅ Списано ${total_tokens} токенов у пользователя ${user_id}. Новый баланс: ${newBalance}`);

      return NextResponse.json({
        success: true,
        tokens_used: total_tokens,
        new_balance: newBalance,
        usage_breakdown: {
          input: {
            total: input_tokens,
            text: input_text_tokens,
            audio: input_audio_tokens,
            image: input_image_tokens,
            cached: cached_tokens
          },
          output: {
            total: output_tokens,
            text: output_text_tokens,
            audio: output_audio_tokens
          },
          total: total_tokens
        }
      });

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    }

  } catch (error) {
    console.error('❌ Ошибка списания токенов Realtime API:', error);
    return NextResponse.json(
      { error: 'Ошибка списания токенов' },
      { status: 500 }
    );
  } finally {
    await client.end();
  }
}

// Пополнить баланс токенов (используется при покупке планов)
export async function PUT(request: NextRequest) {
  try {
    const { user_id, tokens_to_add } = await request.json();

    if (!user_id || !tokens_to_add || tokens_to_add <= 0) {
      return NextResponse.json(
        { error: 'user_id и tokens_to_add (> 0) обязательны' },
        { status: 400 }
      );
    }

    const client = createDbConnection();
    await client.connect();

    // Пополняем баланс токенов
    const result = await client.query(`
      UPDATE users
      SET token_balance = token_balance + $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING token_balance
    `, [tokens_to_add, user_id]);

    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Пользователь не найден' }, { status: 404 });
    }

    await client.end();

    return NextResponse.json({
      success: true,
      tokens_added: tokens_to_add,
      new_balance: result.rows[0].token_balance
    });

  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      { error: 'Ошибка пополнения токенов' },
      { status: 500 }
    );
  }
}
