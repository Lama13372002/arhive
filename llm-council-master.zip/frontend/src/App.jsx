import { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import VoicesInterface from './components/VoicesInterface';
import LiveCodingAssistant from './components/LiveCodingAssistant';
import { api } from './api';
import './App.css';

function App() {
  const [mode, setMode] = useState('chat'); // 'chat' or 'code'
  const [conversations, setConversations] = useState([]);
  const [currentConversationId, setCurrentConversationId] = useState(null);
  const [currentConversation, setCurrentConversation] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Load conversations on mount
  useEffect(() => {
    loadConversations();
  }, []);

  // Load conversation details when selected
  useEffect(() => {
    if (currentConversationId) {
      loadConversation(currentConversationId);
    }
  }, [currentConversationId]);

  const loadConversations = async () => {
    try {
      const convs = await api.listConversations();
      setConversations(convs);
    } catch (error) {
      console.error('Failed to load conversations:', error);
    }
  };

  const loadConversation = async (id) => {
    try {
      const conv = await api.getConversation(id);
      setCurrentConversation(conv);
    } catch (error) {
      console.error('Failed to load conversation:', error);
    }
  };

  const handleNewConversation = async () => {
    try {
      const newConv = await api.createConversation();
      setConversations([
        { id: newConv.id, created_at: newConv.created_at, message_count: 0 },
        ...conversations,
      ]);
      setCurrentConversationId(newConv.id);
    } catch (error) {
      console.error('Failed to create conversation:', error);
    }
  };

  const handleSelectConversation = (id) => {
    setCurrentConversationId(id);
  };

  const handleSendMessage = async (content) => {
    if (!currentConversationId) return;

    setIsLoading(true);
    try {
      // Optimistically add user message to UI
      const userMessage = { role: 'user', content };
      setCurrentConversation((prev) => ({
        ...prev,
        messages: [...prev.messages, userMessage],
      }));

      // Create a partial assistant message that will be updated progressively
      const assistantMessage = {
        role: 'assistant',
        discussion_rounds: [],
        final_decision: null,
        loading: true,
        currentRound: 0,
        voices_config: null,
      };

      // Add the partial assistant message
      setCurrentConversation((prev) => ({
        ...prev,
        messages: [...prev.messages, assistantMessage],
      }));

      // Send message with streaming
      await api.sendMessageStream(currentConversationId, content, (eventType, event) => {
        switch (eventType) {
          case 'voices_config':
            setCurrentConversation((prev) => {
              const messages = [...prev.messages];
              const lastMsg = messages[messages.length - 1];
              lastMsg.voices_config = event.data;
              return { ...prev, messages };
            });
            break;

          case 'round_start':
            setCurrentConversation((prev) => {
              const messages = [...prev.messages];
              const lastMsg = messages[messages.length - 1];
              lastMsg.currentRound = event.round;
              if (!lastMsg.discussion_rounds[event.round - 1]) {
                lastMsg.discussion_rounds[event.round - 1] = [];
              }
              return { ...prev, messages };
            });
            break;

          case 'voice_thinking':
            // Could add visual indicator that a voice is thinking
            break;

          case 'voice_response':
            setCurrentConversation((prev) => {
              const messages = [...prev.messages];
              const lastMsg = messages[messages.length - 1];
              const roundIdx = lastMsg.currentRound - 1;
              if (!lastMsg.discussion_rounds[roundIdx]) {
                lastMsg.discussion_rounds[roundIdx] = [];
              }
              lastMsg.discussion_rounds[roundIdx].push(event.data);
              return { ...prev, messages };
            });
            break;

          case 'round_complete':
            // Round completed
            break;

          case 'willpower_thinking':
            setCurrentConversation((prev) => {
              const messages = [...prev.messages];
              const lastMsg = messages[messages.length - 1];
              lastMsg.willpower_thinking = true;
              return { ...prev, messages };
            });
            break;

          case 'willpower_decision':
            setCurrentConversation((prev) => {
              const messages = [...prev.messages];
              const lastMsg = messages[messages.length - 1];
              lastMsg.final_decision = event.data;
              lastMsg.willpower_thinking = false;
              lastMsg.loading = false;
              return { ...prev, messages };
            });
            break;

          case 'title_complete':
            // Reload conversations to get updated title
            loadConversations();
            break;

          case 'complete':
            // Stream complete, reload conversations list
            loadConversations();
            setIsLoading(false);
            break;

          case 'error':
            console.error('Stream error:', event.message);
            setIsLoading(false);
            break;

          default:
            console.log('Unknown event type:', eventType);
        }
      });
    } catch (error) {
      console.error('Failed to send message:', error);
      // Remove optimistic messages on error
      setCurrentConversation((prev) => ({
        ...prev,
        messages: prev.messages.slice(0, -2),
      }));
      setIsLoading(false);
    }
  };

  return (
    <div className="app">
      {/* Mode Switcher */}
      <div className="mode-switcher">
        <button
          className={mode === 'chat' ? 'active' : ''}
          onClick={() => setMode('chat')}
        >
          🧠 Голоса в голове
        </button>
        <button
          className={mode === 'code' ? 'active' : ''}
          onClick={() => setMode('code')}
        >
          🚀 Live Coding Assistant
        </button>
      </div>

      {/* Content based on mode */}
      {mode === 'chat' ? (
        <div className="chat-mode-content">
          <Sidebar
            conversations={conversations}
            currentConversationId={currentConversationId}
            onSelectConversation={handleSelectConversation}
            onNewConversation={handleNewConversation}
          />
          <VoicesInterface
            conversation={currentConversation}
            onSendMessage={handleSendMessage}
            isLoading={isLoading}
            onNewConversation={handleNewConversation}
          />
        </div>
      ) : (
        <LiveCodingAssistant />
      )}
    </div>
  );
}

export default App;
