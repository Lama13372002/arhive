import { useState, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import './VoicesInterface.css';

// Компонент для эффекта печатания
function TypingText({ text, speed = 30, onComplete }) {
  const [displayedText, setDisplayedText] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);
  const containerRef = useRef(null);

  useEffect(() => {
    if (currentIndex < text.length) {
      const timeout = setTimeout(() => {
        setDisplayedText(prev => prev + text[currentIndex]);
        setCurrentIndex(prev => prev + 1);

        // Автоскролл во время печатания
        if (containerRef.current) {
          containerRef.current.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }, speed);
      return () => clearTimeout(timeout);
    } else if (onComplete && currentIndex === text.length && currentIndex > 0) {
      onComplete();
    }
  }, [currentIndex, text, speed, onComplete]);

  // Сброс при изменении текста
  useEffect(() => {
    setDisplayedText('');
    setCurrentIndex(0);
  }, [text]);

  return (
    <div ref={containerRef}>
      <ReactMarkdown>{displayedText}</ReactMarkdown>
    </div>
  );
}

export default function VoicesInterface({
  conversation,
  onSendMessage,
  isLoading,
  onNewConversation,
}) {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [conversation]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (input.trim() && !isLoading) {
      onSendMessage(input);
      setInput('');
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  if (!conversation) {
    return (
      <div className="voices-interface">
        <div className="empty-state">
          <h1>🧠 Голоса в голове</h1>
          <p>Создайте новый разговор, чтобы проконсультироваться с вашими внутренними голосами</p>
          <div className="voices-preview">
            <div className="voice-preview logic">🧠 Логика</div>
            <div className="voice-preview anxiety">😰 Тревожность</div>
            <div className="voice-preview aggression">😡 Агрессия</div>
            <div className="voice-preview empathy">💗 Эмпатия</div>
            <div className="voice-preview inner_child">🎈 Внутренний Ребенок</div>
          </div>
          <button className="create-conversation-btn" onClick={onNewConversation}>
            ✨ Создать новый разговор
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="voices-interface">
      <div className="messages-container">
        {conversation.messages.length === 0 ? (
          <div className="empty-state">
            <h2>Задайте вопрос</h2>
            <p>Ваши внутренние голоса обсудят его и помогут принять решение</p>
          </div>
        ) : (
          conversation.messages.map((msg, msgIndex) => (
            <div key={msgIndex} className="message-group">
              {msg.role === 'user' ? (
                <div className="user-message">
                  <div className="message-label">❓ Ваш вопрос</div>
                  <div className="message-content">
                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                  </div>
                </div>
              ) : (
                <div className="assistant-message">
                  {/* Discussion Rounds */}
                  {msg.discussion_rounds && msg.discussion_rounds.map((round, roundIdx) => (
                    <div key={roundIdx} className="discussion-round">
                      <div className="round-header">
                        <span>💭 Раунд {roundIdx + 1}</span>
                      </div>
                      <div className="voices-bubbles">
                        {round.map((voice, voiceIdx) => (
                          <div
                            key={voiceIdx}
                            className={`voice-bubble ${voice.voice_id}`}
                            style={{
                              borderColor: voice.color,
                              animationDelay: `${voiceIdx * 0.2}s`
                            }}
                          >
                            <div className="voice-header">
                              <span className="voice-emoji">{voice.emoji}</span>
                              <span className="voice-name">{voice.voice_name}</span>
                              <span className="typing-indicator">●●●</span>
                            </div>
                            <div className="voice-text">
                              {/* Используем typing эффект только для последнего сообщения в активной дискуссии */}
                              {msg.loading && msgIndex === conversation.messages.length - 1 ? (
                                <TypingText text={voice.response} speed={20} />
                              ) : (
                                <ReactMarkdown>{voice.response}</ReactMarkdown>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}

                  {/* Loading state */}
                  {msg.loading && (!msg.discussion_rounds || msg.discussion_rounds.length === 0) && (
                    <div className="voices-loading">
                      <div className="spinner"></div>
                      <span>Голоса просыпаются...</span>
                    </div>
                  )}

                  {/* Willpower thinking */}
                  {msg.willpower_thinking && !msg.final_decision && (
                    <div className="voices-loading willpower-loading">
                      <div className="spinner willpower"></div>
                      <span>⚡ Сила Воли принимает решение...</span>
                    </div>
                  )}

                  {/* Final Decision */}
                  {msg.final_decision && (
                    <div className="final-decision">
                      <div className="decision-header">
                        <span className="decision-emoji">{msg.final_decision.emoji}</span>
                        <span className="decision-name">{msg.final_decision.voice_name}</span>
                        {msg.loading && msgIndex === conversation.messages.length - 1 && (
                          <span className="typing-indicator decision">●●●</span>
                        )}
                      </div>
                      <div className="decision-content" style={{ borderColor: msg.final_decision.color }}>
                        {msg.loading && msgIndex === conversation.messages.length - 1 ? (
                          <TypingText text={msg.final_decision.response} speed={25} />
                        ) : (
                          <ReactMarkdown>{msg.final_decision.response}</ReactMarkdown>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <form className="input-form" onSubmit={handleSubmit}>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Задайте вопрос своим внутренним голосам..."
          disabled={isLoading}
          rows="3"
        />
        <button type="submit" disabled={isLoading || !input.trim()}>
          {isLoading ? '🧠 Думают...' : '💭 Спросить'}
        </button>
      </form>
    </div>
  );
}
