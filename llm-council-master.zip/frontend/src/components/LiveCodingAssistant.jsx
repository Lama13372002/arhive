import { useState, useRef, useCallback, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import { api } from '../api';
import './LiveCodingAssistant.css';

function LiveCodingAssistant() {
  const [code, setCode] = useState('# Start coding here...\n\n');
  const [language, setLanguage] = useState('python');
  const [suggestions, setSuggestions] = useState([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const [review, setReview] = useState(null);
  const [loadingReview, setLoadingReview] = useState(false);
  const [cursorPosition, setCursorPosition] = useState(0);
  const [selectedTab, setSelectedTab] = useState('suggestions'); // 'suggestions' | 'review'

  const editorRef = useRef(null);
  const debounceTimerRef = useRef(null);

  // Handle editor mount
  const handleEditorDidMount = (editor, monaco) => {
    editorRef.current = editor;

    // Track cursor position
    editor.onDidChangeCursorPosition((e) => {
      const model = editor.getModel();
      if (model) {
        const offset = model.getOffsetAt(e.position);
        setCursorPosition(offset);
      }
    });
  };

  // Handle code change with debounced suggestions
  const handleCodeChange = (value) => {
    setCode(value || '');

    // Clear existing timer
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    // Debounce suggestions (wait 1 second after user stops typing)
    debounceTimerRef.current = setTimeout(() => {
      if (value && value.trim().length > 10) {
        fetchSuggestions(value);
      }
    }, 1000);
  };

  // Fetch suggestions from API
  const fetchSuggestions = async (currentCode) => {
    setLoadingSuggestions(true);
    try {
      const response = await api.getCodeSuggestions({
        code: currentCode,
        cursor_position: cursorPosition,
        language: language,
        context: null
      });
      setSuggestions(response.suggestions || []);
    } catch (error) {
      console.error('Failed to fetch suggestions:', error);
      setSuggestions([]);
    } finally {
      setLoadingSuggestions(false);
    }
  };

  // Fetch code review
  const handleCodeReview = async () => {
    if (!code || code.trim().length < 10) {
      alert('Write some code first!');
      return;
    }

    setLoadingReview(true);
    setSelectedTab('review');
    try {
      const response = await api.getCodeReview({
        code: code,
        language: language
      });
      setReview(response);
    } catch (error) {
      console.error('Failed to get code review:', error);
      setReview(null);
    } finally {
      setLoadingReview(false);
    }
  };

  // Apply suggestion to editor
  const applySuggestion = (suggestion) => {
    const editor = editorRef.current;
    if (!editor) return;

    const position = editor.getPosition();
    const model = editor.getModel();

    if (position && model) {
      // Insert suggestion at cursor
      const range = {
        startLineNumber: position.lineNumber,
        startColumn: position.column,
        endLineNumber: position.lineNumber,
        endColumn: position.column
      };

      editor.executeEdits('', [{
        range: range,
        text: '\n' + suggestion.code
      }]);

      // Focus editor
      editor.focus();
    }
  };

  // Vote on suggestion
  const voteSuggestion = (index, delta) => {
    setSuggestions(prev => {
      const newSuggestions = [...prev];
      newSuggestions[index].votes += delta;
      return newSuggestions;
    });
  };

  // Language options
  const languages = [
    { value: 'python', label: 'Python' },
    { value: 'javascript', label: 'JavaScript' },
    { value: 'typescript', label: 'TypeScript' },
    { value: 'java', label: 'Java' },
    { value: 'cpp', label: 'C++' },
    { value: 'go', label: 'Go' },
    { value: 'rust', label: 'Rust' }
  ];

  return (
    <div className="live-coding-assistant">
      {/* Header */}
      <div className="lca-header">
        <h2>🚀 Live Coding Assistant</h2>
        <div className="lca-controls">
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="language-selector"
          >
            {languages.map(lang => (
              <option key={lang.value} value={lang.value}>{lang.label}</option>
            ))}
          </select>
          <button onClick={handleCodeReview} className="review-button">
            📝 Code Review
          </button>
        </div>
      </div>

      {/* Main Content - Split Screen */}
      <div className="lca-content">
        {/* Left Panel - Editor */}
        <div className="lca-editor-panel">
          <div className="panel-header">
            <span>✏️ Editor</span>
            <span className="panel-info">
              Cursor: {cursorPosition} | Lines: {code.split('\n').length}
            </span>
          </div>
          <Editor
            height="calc(100% - 40px)"
            language={language}
            value={code}
            onChange={handleCodeChange}
            onMount={handleEditorDidMount}
            theme="vs-dark"
            options={{
              minimap: { enabled: true },
              fontSize: 14,
              lineNumbers: 'on',
              automaticLayout: true,
              tabSize: 2,
              wordWrap: 'on'
            }}
          />
        </div>

        {/* Right Panel - Suggestions & Review */}
        <div className="lca-suggestions-panel">
          {/* Tabs */}
          <div className="suggestions-tabs">
            <button
              className={selectedTab === 'suggestions' ? 'active' : ''}
              onClick={() => setSelectedTab('suggestions')}
            >
              💡 Suggestions {loadingSuggestions && '⏳'}
            </button>
            <button
              className={selectedTab === 'review' ? 'active' : ''}
              onClick={() => setSelectedTab('review')}
            >
              🔍 Review {loadingReview && '⏳'}
            </button>
          </div>

          {/* Content */}
          <div className="suggestions-content">
            {selectedTab === 'suggestions' && (
              <div className="suggestions-list">
                {loadingSuggestions && (
                  <div className="loading-state">
                    <div className="spinner"></div>
                    <p>Getting suggestions from the council...</p>
                  </div>
                )}

                {!loadingSuggestions && suggestions.length === 0 && (
                  <div className="empty-state">
                    <p>Start typing to get suggestions from the council!</p>
                    <p className="hint">💡 The council will help you write better code</p>
                  </div>
                )}

                {!loadingSuggestions && suggestions.map((suggestion, index) => (
                  <div key={index} className="suggestion-card">
                    <div className="suggestion-header">
                      <span className="model-name">{suggestion.model}</span>
                      <div className="suggestion-actions">
                        <button
                          onClick={() => voteSuggestion(index, 1)}
                          className="vote-btn upvote"
                          title="Upvote"
                        >
                          👍
                        </button>
                        <span className="vote-count">{suggestion.votes}</span>
                        <button
                          onClick={() => voteSuggestion(index, -1)}
                          className="vote-btn downvote"
                          title="Downvote"
                        >
                          👎
                        </button>
                      </div>
                    </div>
                    <div className="suggestion-code">
                      <code>{suggestion.code}</code>
                    </div>
                    <button
                      onClick={() => applySuggestion(suggestion)}
                      className="apply-btn"
                    >
                      ✅ Apply
                    </button>
                  </div>
                ))}
              </div>
            )}

            {selectedTab === 'review' && (
              <div className="review-content">
                {loadingReview && (
                  <div className="loading-state">
                    <div className="spinner"></div>
                    <p>Council is reviewing your code...</p>
                  </div>
                )}

                {!loadingReview && !review && (
                  <div className="empty-state">
                    <p>Click "Code Review" to get feedback from the council!</p>
                  </div>
                )}

                {!loadingReview && review && (
                  <div className="review-results">
                    {/* Aggregated Issues */}
                    {review.aggregated_issues && review.aggregated_issues.length > 0 && (
                      <div className="aggregated-issues">
                        <h3>🎯 Key Issues ({review.total_issues})</h3>
                        {review.aggregated_issues.map((issue, index) => (
                          <div key={index} className={`issue-card ${issue.severity.toLowerCase()}`}>
                            <div className="issue-header">
                              <span className="severity-badge">{issue.severity}</span>
                              <span className="agreement">
                                {issue.agreement_count} model{issue.agreement_count > 1 ? 's' : ''} agree
                              </span>
                            </div>
                            <p className="issue-description">{issue.description}</p>
                            {issue.line && <span className="issue-line">Line {issue.line}</span>}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Individual Reviews */}
                    <div className="individual-reviews">
                      <h3>📋 Detailed Reviews</h3>
                      {review.reviews && review.reviews.map((modelReview, index) => (
                        <div key={index} className="model-review">
                          <h4>{modelReview.model}</h4>
                          <div className="review-text">
                            {modelReview.review}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default LiveCodingAssistant;
