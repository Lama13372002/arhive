"""Voices in Your Head orchestration system."""

import asyncio
from typing import List, Dict, Any
from .openrouter import query_model
from .config import VOICES, WILLPOWER, DEFAULT_MODEL, MAX_DISCUSSION_ROUNDS


async def get_voice_response(
    voice_id: str,
    user_query: str,
    discussion_history: List[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Получить ответ от одного голоса.

    Args:
        voice_id: ID голоса (logic, anxiety, aggression, etc.)
        user_query: Вопрос пользователя
        discussion_history: История обсуждения (предыдущие реплики других голосов)

    Returns:
        Dict с ответом голоса
    """
    voice = VOICES[voice_id]

    # Формируем контекст для голоса
    messages = [{"role": "system", "content": voice["system_prompt"]}]

    # Добавляем вопрос пользователя
    messages.append({
        "role": "user",
        "content": f"Вопрос от человека: {user_query}"
    })

    # Добавляем историю обсуждения, если есть
    if discussion_history:
        discussion_text = "\n\n".join([
            f"{item['voice_name']}: {item['response']}"
            for item in discussion_history
        ])
        messages.append({
            "role": "user",
            "content": f"Другие голоса уже высказались:\n\n{discussion_text}\n\nТеперь твоя очередь. Что ты думаешь? Можешь согласиться, возразить, добавить что-то своё."
        })

    # Запрос к модели
    response = await query_model(DEFAULT_MODEL, messages)

    return {
        "voice_id": voice_id,
        "voice_name": voice["name"],
        "emoji": voice["emoji"],
        "color": voice["color"],
        "response": response.get("content", "") if response else "..."
    }


async def conduct_discussion(
    user_query: str,
    active_voices: List[str] = None
) -> List[List[Dict[str, Any]]]:
    """
    Проводит обсуждение между голосами.

    Args:
        user_query: Вопрос пользователя
        active_voices: Список активных голосов (если None, используются все)

    Returns:
        List раундов, каждый раунд - это список ответов голосов
    """
    if active_voices is None:
        active_voices = list(VOICES.keys())

    discussion_rounds = []
    all_responses = []  # Вся история для контекста

    # Проводим несколько раундов обсуждения
    for round_num in range(MAX_DISCUSSION_ROUNDS):
        round_responses = []

        # Каждый голос высказывается по очереди
        for voice_id in active_voices:
            response = await get_voice_response(
                voice_id=voice_id,
                user_query=user_query,
                discussion_history=all_responses if round_num > 0 else None
            )
            round_responses.append(response)
            all_responses.append(response)

            # Небольшая задержка для имитации "печатания"
            await asyncio.sleep(0.1)

        discussion_rounds.append(round_responses)

        # Проверяем, достигли ли согласия (это упрощенная версия)
        # В реальности можно анализировать тональность или ключевые слова
        if round_num >= 1:  # Минимум 2 раунда
            break

    return discussion_rounds


async def get_willpower_decision(
    user_query: str,
    discussion_rounds: List[List[Dict[str, Any]]]
) -> Dict[str, Any]:
    """
    Получить финальное решение от Силы Воли.

    Args:
        user_query: Вопрос пользователя
        discussion_rounds: Все раунды обсуждения

    Returns:
        Dict с финальным решением
    """
    # Формируем сводку всех голосов
    all_voices_summary = []
    for round_num, round_responses in enumerate(discussion_rounds):
        all_voices_summary.append(f"=== Раунд {round_num + 1} ===")
        for response in round_responses:
            all_voices_summary.append(
                f"{response['voice_name']}: {response['response']}"
            )

    summary_text = "\n\n".join(all_voices_summary)

    # Формируем запрос для Силы Воли
    messages = [
        {"role": "system", "content": WILLPOWER["system_prompt"]},
        {
            "role": "user",
            "content": f"""Вопрос от человека: {user_query}

Обсуждение голосов:

{summary_text}

Теперь прими ФИНАЛЬНОЕ РЕШЕНИЕ, учитывая все мнения."""
        }
    ]

    # Запрос к модели
    response = await query_model(DEFAULT_MODEL, messages)

    return {
        "voice_id": "willpower",
        "voice_name": WILLPOWER["name"],
        "emoji": WILLPOWER["emoji"],
        "color": WILLPOWER["color"],
        "response": response.get("content", "") if response else "Не могу принять решение..."
    }


async def run_voices_session(
    user_query: str,
    active_voices: List[str] = None
) -> Dict[str, Any]:
    """
    Запускает полную сессию голосов.

    Args:
        user_query: Вопрос пользователя
        active_voices: Список активных голосов

    Returns:
        Dict с полными результатами сессии
    """
    # Проводим обсуждение
    discussion_rounds = await conduct_discussion(user_query, active_voices)

    # Получаем финальное решение от Силы Воли
    final_decision = await get_willpower_decision(user_query, discussion_rounds)

    return {
        "discussion_rounds": discussion_rounds,
        "final_decision": final_decision,
        "voices_config": {
            voice_id: {
                "name": VOICES[voice_id]["name"],
                "emoji": VOICES[voice_id]["emoji"],
                "color": VOICES[voice_id]["color"],
                "description": VOICES[voice_id]["description"]
            }
            for voice_id in (active_voices or VOICES.keys())
        }
    }
