"""FastAPI backend for Voices in Your Head."""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import uuid
import json
import asyncio

from . import storage
from .voices import run_voices_session, get_voice_response, get_willpower_decision
from .config import VOICES, WILLPOWER, DEFAULT_MODEL
from .openrouter import query_model

app = FastAPI(title="Voices in Your Head API")

# Enable CORS for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class CreateConversationRequest(BaseModel):
    """Request to create a new conversation."""
    pass


class SendMessageRequest(BaseModel):
    """Request to send a message in a conversation."""
    content: str


class ConversationMetadata(BaseModel):
    """Conversation metadata for list view."""
    id: str
    created_at: str
    title: str
    message_count: int


class Conversation(BaseModel):
    """Full conversation with all messages."""
    id: str
    created_at: str
    title: str
    messages: List[Dict[str, Any]]


@app.get("/")
async def root():
    """Health check endpoint."""
    return {"status": "ok", "service": "Voices in Your Head API"}


@app.get("/api/conversations", response_model=List[ConversationMetadata])
async def list_conversations():
    """List all conversations (metadata only)."""
    return storage.list_conversations()


@app.post("/api/conversations", response_model=Conversation)
async def create_conversation(request: CreateConversationRequest):
    """Create a new conversation."""
    conversation_id = str(uuid.uuid4())
    conversation = storage.create_conversation(conversation_id)
    return conversation


@app.get("/api/conversations/{conversation_id}", response_model=Conversation)
async def get_conversation(conversation_id: str):
    """Get a specific conversation with all its messages."""
    conversation = storage.get_conversation(conversation_id)
    if conversation is None:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return conversation


@app.post("/api/conversations/{conversation_id}/message")
async def send_message(conversation_id: str, request: SendMessageRequest):
    """
    Send a message and run the voices discussion process.
    Returns the complete response with all discussion rounds.
    """
    # Check if conversation exists
    conversation = storage.get_conversation(conversation_id)
    if conversation is None:
        raise HTTPException(status_code=404, detail="Conversation not found")

    # Check if this is the first message
    is_first_message = len(conversation["messages"]) == 0

    # Add user message
    storage.add_user_message(conversation_id, request.content)

    # If this is the first message, generate a title
    if is_first_message:
        title = await generate_conversation_title(request.content)
        storage.update_conversation_title(conversation_id, title)

    # Run the voices session (all voices by default)
    result = await run_voices_session(request.content)

    # Add assistant message with discussion and decision
    storage.add_assistant_message(
        conversation_id,
        result["discussion_rounds"],
        result["final_decision"]
    )

    # Return the complete response
    return result


async def generate_conversation_title(first_message: str) -> str:
    """Generate a short title for the conversation based on first message."""
    messages = [
        {
            "role": "system",
            "content": "Generate a very short title (2-5 words) for this conversation. Reply with ONLY the title, nothing else."
        },
        {
            "role": "user",
            "content": first_message
        }
    ]

    response = await query_model(DEFAULT_MODEL, messages)
    title = response.get("content", "Новый разговор") if response else "Новый разговор"

    # Clean up the title
    title = title.strip().strip('"').strip("'")
    if len(title) > 50:
        title = title[:50] + "..."

    return title


@app.post("/api/conversations/{conversation_id}/message/stream")
async def send_message_stream(conversation_id: str, request: SendMessageRequest):
    """
    Send a message and stream the voices discussion process.
    Returns Server-Sent Events as each voice speaks.
    """
    # Check if conversation exists
    conversation = storage.get_conversation(conversation_id)
    if conversation is None:
        raise HTTPException(status_code=404, detail="Conversation not found")

    # Check if this is the first message
    is_first_message = len(conversation["messages"]) == 0

    async def event_generator():
        try:
            # Add user message
            storage.add_user_message(conversation_id, request.content)

            # Start title generation in parallel (don't await yet)
            title_task = None
            if is_first_message:
                title_task = asyncio.create_task(generate_conversation_title(request.content))

            # Send voices config
            voices_config = {
                voice_id: {
                    "name": VOICES[voice_id]["name"],
                    "emoji": VOICES[voice_id]["emoji"],
                    "color": VOICES[voice_id]["color"],
                    "description": VOICES[voice_id]["description"]
                }
                for voice_id in VOICES.keys()
            }
            yield f"data: {json.dumps({'type': 'voices_config', 'data': voices_config})}\n\n"

            # Start discussion
            active_voices = list(VOICES.keys())
            all_responses = []
            discussion_rounds = []

            # Conduct discussion rounds
            from .config import MAX_DISCUSSION_ROUNDS
            for round_num in range(MAX_DISCUSSION_ROUNDS):
                yield f"data: {json.dumps({'type': 'round_start', 'round': round_num + 1})}\n\n"

                round_responses = []

                # Each voice speaks
                for voice_id in active_voices:
                    yield f"data: {json.dumps({'type': 'voice_thinking', 'voice_id': voice_id})}\n\n"

                    response = await get_voice_response(
                        voice_id=voice_id,
                        user_query=request.content,
                        discussion_history=all_responses if round_num > 0 else None
                    )

                    yield f"data: {json.dumps({'type': 'voice_response', 'data': response})}\n\n"

                    round_responses.append(response)
                    all_responses.append(response)

                    await asyncio.sleep(0.2)

                discussion_rounds.append(round_responses)
                yield f"data: {json.dumps({'type': 'round_complete', 'round': round_num + 1})}\n\n"

                # Stop after 2 rounds for now
                if round_num >= 1:
                    break

            # Get final decision from Willpower
            yield f"data: {json.dumps({'type': 'willpower_thinking'})}\n\n"
            final_decision = await get_willpower_decision(request.content, discussion_rounds)
            yield f"data: {json.dumps({'type': 'willpower_decision', 'data': final_decision})}\n\n"

            # Wait for title generation if it was started
            if title_task:
                title = await title_task
                storage.update_conversation_title(conversation_id, title)
                yield f"data: {json.dumps({'type': 'title_complete', 'data': {'title': title}})}\n\n"

            # Save complete assistant message
            storage.add_assistant_message(
                conversation_id,
                discussion_rounds,
                final_decision
            )

            # Send completion event
            yield f"data: {json.dumps({'type': 'complete'})}\n\n"

        except Exception as e:
            # Send error event
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )


class CodeSuggestionsRequest(BaseModel):
    """Request for code suggestions."""
    code: str
    cursor_position: int
    language: str = "python"
    context: str = None


class CodeReviewRequest(BaseModel):
    """Request for code review."""
    code: str
    language: str = "python"


class ExplainCodeRequest(BaseModel):
    """Request to explain code."""
    code: str
    language: str = "python"


@app.post("/api/code-assist/suggestions")
async def code_suggestions(request: CodeSuggestionsRequest):
    """Get real-time code suggestions from the council."""
    try:
        suggestions = await get_code_suggestions(
            request.code,
            request.cursor_position,
            request.language,
            request.context
        )
        return {"suggestions": suggestions}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/code-assist/review")
async def code_review(request: CodeReviewRequest):
    """Get instant code review from the council."""
    try:
        review = await get_code_review(request.code, request.language)
        return review
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/code-assist/explain")
async def code_explain(request: ExplainCodeRequest):
    """Get code explanation from the council."""
    try:
        explanation = await explain_code(request.code, request.language)
        return explanation
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
