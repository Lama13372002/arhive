"""Code assistance module for live coding features."""

from typing import List, Dict, Any, Optional
from .openrouter import query_models_parallel, query_model
from .config import COUNCIL_MODELS
import re


async def get_code_suggestions(
    code: str,
    cursor_position: int,
    language: str = "python",
    context: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Get code suggestions from multiple models for current cursor position.

    Args:
        code: Current code content
        cursor_position: Cursor position in code
        language: Programming language
        context: Optional context about what user is trying to do

    Returns:
        List of suggestions from different models with voting info
    """
    # Extract context around cursor
    lines = code.split('\n')
    cursor_line = code[:cursor_position].count('\n')

    # Get surrounding context (3 lines before, current line, 2 lines after)
    start_line = max(0, cursor_line - 3)
    end_line = min(len(lines), cursor_line + 3)
    context_code = '\n'.join(lines[start_line:end_line])

    # Build prompt for suggestions
    prompt = f"""You are a coding assistant. The user is writing {language} code.

Current code context:
```{language}
{context_code}
```

Cursor is at line {cursor_line + 1}.
{f"User's intent: {context}" if context else ""}

Provide 1-3 helpful suggestions for what the user might want to write next. Be concise and practical.
Format each suggestion on a new line starting with "SUGGESTION:" followed by the code.

Example:
SUGGESTION: def process_data(data: list) -> list:
SUGGESTION: # TODO: Add error handling
SUGGESTION: return [x * 2 for x in data]

Now provide your suggestions:"""

    messages = [{"role": "user", "content": prompt}]

    # Get suggestions from all models in parallel
    responses = await query_models_parallel(COUNCIL_MODELS[:3], messages)  # Use first 3 models for speed

    # Parse suggestions from each model
    suggestions = []
    for model, response in responses.items():
        if response is not None:
            content = response.get('content', '')
            parsed_suggestions = parse_suggestions(content)

            for suggestion in parsed_suggestions:
                suggestions.append({
                    "model": model,
                    "code": suggestion,
                    "votes": 0,
                    "applied": False
                })

    return suggestions


async def get_code_review(
    code: str,
    language: str = "python"
) -> Dict[str, Any]:
    """
    Get instant code review from the council.

    Args:
        code: Code to review
        language: Programming language

    Returns:
        Dict with reviews from each model and aggregate issues
    """
    prompt = f"""Review the following {language} code and provide constructive feedback.

Code:
```{language}
{code}
```

Focus on:
1. Potential bugs or errors
2. Code quality and best practices
3. Performance considerations
4. Security issues

Format your response as:
ISSUES:
- [SEVERITY] Issue description (line X)

SUGGESTIONS:
- Suggestion for improvement

Keep it concise and actionable."""

    messages = [{"role": "user", "content": prompt}]

    # Get reviews from all council models
    responses = await query_models_parallel(COUNCIL_MODELS, messages)

    # Collect reviews
    reviews = []
    all_issues = []

    for model, response in responses.items():
        if response is not None:
            content = response.get('content', '')
            issues = parse_issues(content)

            reviews.append({
                "model": model,
                "review": content,
                "issues": issues
            })
            all_issues.extend(issues)

    # Aggregate common issues
    aggregated_issues = aggregate_issues(all_issues)

    return {
        "reviews": reviews,
        "aggregated_issues": aggregated_issues,
        "total_issues": len(aggregated_issues)
    }


async def explain_code(
    code: str,
    language: str = "python"
) -> Dict[str, Any]:
    """
    Get explanations of code from multiple models.

    Args:
        code: Code to explain
        language: Programming language

    Returns:
        Dict with explanations from each model
    """
    prompt = f"""Explain what this {language} code does in simple terms:

```{language}
{code}
```

Provide:
1. High-level overview (1-2 sentences)
2. Step-by-step breakdown
3. Time/space complexity if applicable

Be clear and concise."""

    messages = [{"role": "user", "content": prompt}]

    # Get explanations from 2-3 models for speed
    selected_models = COUNCIL_MODELS[:2]
    responses = await query_models_parallel(selected_models, messages)

    explanations = []
    for model, response in responses.items():
        if response is not None:
            explanations.append({
                "model": model,
                "explanation": response.get('content', '')
            })

    return {"explanations": explanations}


def parse_suggestions(text: str) -> List[str]:
    """Parse SUGGESTION: lines from model response."""
    suggestions = []
    lines = text.split('\n')

    for line in lines:
        if line.strip().startswith('SUGGESTION:'):
            suggestion = line.replace('SUGGESTION:', '').strip()
            if suggestion:
                suggestions.append(suggestion)

    return suggestions


def parse_issues(text: str) -> List[Dict[str, Any]]:
    """Parse issues from review text."""
    issues = []

    # Look for common severity markers
    severity_pattern = r'\[(ERROR|WARNING|INFO|CRITICAL|BUG)\]'

    lines = text.split('\n')
    for line in lines:
        line = line.strip()
        if not line or line.startswith('#'):
            continue

        # Try to find severity marker
        severity_match = re.search(severity_pattern, line, re.IGNORECASE)
        if severity_match:
            severity = severity_match.group(1).upper()
            description = re.sub(severity_pattern, '', line).strip(' -')

            # Try to extract line number
            line_match = re.search(r'line (\d+)', description, re.IGNORECASE)
            line_number = int(line_match.group(1)) if line_match else None

            issues.append({
                "severity": severity,
                "description": description,
                "line": line_number
            })

    return issues


def aggregate_issues(issues: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Aggregate similar issues from multiple models."""
    from collections import defaultdict

    # Group by line number and similarity
    grouped = defaultdict(list)

    for issue in issues:
        key = f"{issue.get('line', 'general')}_{issue.get('severity', 'INFO')}"
        grouped[key].append(issue)

    # Create aggregated issues
    aggregated = []
    for group in grouped.values():
        if len(group) >= 2:  # At least 2 models agree
            aggregated.append({
                "severity": group[0]['severity'],
                "description": group[0]['description'],
                "line": group[0].get('line'),
                "agreement_count": len(group),
                "models": len(group)
            })

    # Sort by severity and agreement
    severity_order = {'CRITICAL': 0, 'ERROR': 1, 'BUG': 1, 'WARNING': 2, 'INFO': 3}
    aggregated.sort(key=lambda x: (severity_order.get(x['severity'], 4), -x['agreement_count']))

    return aggregated
