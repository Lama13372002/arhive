def main():
    print("Hello from llm-council!")


if __name__ == "__main__":
    main()
