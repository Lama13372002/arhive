'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

import { FileText, Shield } from 'lucide-react';

interface TermsPrivacyDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TermsPrivacyDialog({ isOpen, onClose }: TermsPrivacyDialogProps) {
  const [activeTab, setActiveTab] = useState('terms');

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[75vh] w-[90vw]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText size={24} className="text-primary" />
            Legal Documents
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="terms" className="flex items-center gap-2">
              <FileText size={16} />
              Terms of Service
            </TabsTrigger>
            <TabsTrigger value="privacy" className="flex items-center gap-2">
              <Shield size={16} />
              Privacy Policy
            </TabsTrigger>
          </TabsList>

          <TabsContent value="terms" className="mt-6">
            <div className="h-[45vh] overflow-y-auto pr-4 scrollbar-thin scrollbar-thumb-white/20 scrollbar-track-transparent">
              <div className="space-y-6 text-white/90">
                <div>
                  <h3 className="text-lg font-bold text-primary mb-3">Terms of Service</h3>
                  <p className="text-sm text-white/70 mb-4">Last updated: August 30, 2025</p>
                </div>

                <section>
                  <h4 className="font-semibold text-white mb-2">1. Acceptance of Terms</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    By accessing and using the Quantum Trade AI investment platform ("Platform"), you agree to be bound by these Terms of Service ("Terms"). If you do not agree to these Terms, you are not permitted to use the Platform.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">2. Definitions</h4>
                  <ul className="text-sm text-white/80 leading-relaxed ml-4 space-y-1">
                    <li>• User: An individual or legal entity registered on the Platform.</li>
                    <li>• Company: QUANTUM AI TECHNOLOGIES LTD, operator of the Platform and owner of all rights to the service.</li>
                    <li>• Account: A personal dashboard for managing balances, investments, and referral programs.</li>
                    <li>• Services: Investment, analytical, and referral tools provided by the Platform.</li>
                  </ul>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">3. User Eligibility</h4>
                  <div className="text-sm text-white/80 leading-relaxed space-y-2">
                    <p>3.1. Users must be at least 18 years old and legally capable of entering into binding agreements.</p>
                    <p>3.2. Users must successfully complete KYC verification to access certain features.</p>
                    <p>3.3. Users from restricted jurisdictions may not be eligible to access all or part of the services.</p>
                  </div>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">4. Account Registration and Security</h4>
                  <div className="text-sm text-white/80 leading-relaxed space-y-2">
                    <p>4.1. Registration is required to access the Platform (email confirmation is not mandatory).</p>
                    <p>4.2. Multi-accounts are strictly prohibited. A "multi-account" means a chain of accounts controlled by the same individual to exploit referral or profit mechanisms. If detected, only the principal deposit will be returned, excluding any unjustified profits.</p>
                    <p>4.3. Users are responsible for maintaining the confidentiality of login credentials. Any actions made through the account are considered actions of the User.</p>
                    <p>4.4. Users must immediately notify the Company of any unauthorized access. The Company is not responsible for losses caused by negligence in safeguarding account credentials.</p>
                    <p>4.5. Attempts to conduct DDoS attacks, hacking, or any interference with Platform operations are strictly prohibited.</p>
                  </div>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">5. Deposits and Withdrawals</h4>
                  <div className="text-sm text-white/80 leading-relaxed space-y-2">
                    <p>5.1. Deposits and withdrawals are available exclusively in USDT (TRC-20).</p>
                    <p>5.2. The minimum deposit amount is 250 USDT.</p>
                    <p>5.3. Deposit transactions are subject only to blockchain network fees. No additional fees are charged by the Company.</p>
                    <p>5.4. Withdrawals may take 24–48 hours to process and are subject to verification procedures. The Company reserves the right to request additional documents for large transactions.</p>
                    <p>5.5. Deposit principal is locked until the end of the chosen investment period. Daily profits can be withdrawn at any time.</p>
                    <p>5.6. Emergency withdrawal of deposit funds before the end of the selected plan term is not supported by the system.</p>
                  </div>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">6. Investment Plans and Returns</h4>
                  <div className="text-sm text-white/80 leading-relaxed space-y-2">
                    <p>6.1. Users may select from the following investment plans:</p>
                    <ul className="ml-4 space-y-1">
                      <li>• Plan 1: 12% per month (daily profit credited directly to balance)</li>
                      <li>• Plan 2: 15% for 1 month</li>
                      <li>• Plan 3: 20% for 3 months</li>
                      <li>• Plan 4: 30% for 6 months</li>
                      <li>• Plan 5: 40% for 12 months</li>
                    </ul>
                    <p>6.2. For Plan 1, profits are accrued daily and credited directly to the User's account balance.</p>
                    <p>6.3. For Plans 2–5, profits are calculated by the system but become available for withdrawal only after the plan term has ended.</p>
                    <p>6.4. The profitability of all plans is based on the principle of compound interest, where daily accruals generate additional returns over time, resulting in significantly higher yields compared to simple interest models.</p>
                    <p>6.5. Principal deposits are available for withdrawal only upon completion of the chosen plan term.</p>
                    <p>6.6. The Company guarantees profit accrual according to the selected plan. However, Users acknowledge that all investments in digital assets inherently involve risks and past performance does not guarantee future results.</p>
                    <p>6.7. All trading operations are executed by the system automatically without the knowledge or participation of Users. Profit is distributed from a common pool and credited to Users according to the chosen plan.</p>
                  </div>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">7. Products and Developments</h4>
                  <div className="text-sm text-white/80 leading-relaxed space-y-2">
                    <p>7.1. Users may purchase access to additional products and developments of the Company.</p>
                    <p>7.2. Requests should be sent to: product@quantum-bot.ai.</p>
                  </div>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">8. Referral Program</h4>
                  <div className="text-sm text-white/80 leading-relaxed space-y-2">
                    <p>8.1. The referral program provides multi-level rewards:</p>
                    <ul className="ml-4 space-y-1">
                      <li>• Level 1 (direct referrals): 5%</li>
                      <li>• Level 2: 2%</li>
                      <li>• Level 3: 1%</li>
                    </ul>
                    <p>8.2. Referral bonuses are credited in USDT and can be reinvested or withdrawn subject to minimum conditions.</p>
                    <p>8.3. Spam, fake accounts, and fraudulent schemes to exploit referrals are prohibited.</p>
                  </div>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">9. Ambassador Program</h4>
                  <div className="text-sm text-white/80 leading-relaxed space-y-2">
                    <p>9.1. An Ambassador Program is available for active partners, offering special conditions, bonuses, and privileges.</p>
                    <p>9.2. Applications should be submitted to: business@quantum-bot.ai.</p>
                  </div>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">10. Official Communications</h4>
                  <div className="text-sm text-white/80 leading-relaxed space-y-2">
                    <p>10.1. All official announcements are published only through:</p>
                    <ul className="ml-4 space-y-1">
                      <li>• X (Twitter)</li>
                      <li>• Telegram</li>
                    </ul>
                    <p>10.2. Additional channels may be announced in future updates to these Terms.</p>
                    <p>10.3. Any information not published through official channels is considered invalid.</p>
                  </div>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">11. Prohibited Activities</h4>
                  <p className="text-sm text-white/80 leading-relaxed mb-2">Users are prohibited from:</p>
                  <ul className="text-sm text-white/80 leading-relaxed ml-4 space-y-1">
                    <li>• Money laundering or terrorist financing</li>
                    <li>• Using the Platform for illegal purposes</li>
                    <li>• Attempting to exploit system vulnerabilities</li>
                    <li>• Creating multiple accounts for abuse</li>
                    <li>• Providing false or misleading information</li>
                  </ul>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">12. Technical Maintenance and Availability</h4>
                  <div className="text-sm text-white/80 leading-relaxed space-y-2">
                    <p>12.1. Scheduled maintenance does not affect profit accruals or withdrawals.</p>
                    <p>12.2. Updates and testing are performed on test servers before deployment.</p>
                    <p>12.3. Implementation of updates occurs during night hours to minimize inconvenience.</p>
                    <p>12.4. The Company strives to maintain uninterrupted availability but cannot guarantee access in the event of factors beyond its control.</p>
                  </div>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">13. Force Majeure</h4>
                  <p className="text-sm text-white/80 leading-relaxed mb-2">The Company is not liable for losses caused by events beyond its reasonable control, including but not limited to:</p>
                  <ul className="text-sm text-white/80 leading-relaxed ml-4 space-y-1">
                    <li>• Wars, military actions, terrorist acts</li>
                    <li>• Natural disasters</li>
                    <li>• Market shutdowns or currency interventions</li>
                    <li>• Regulatory changes</li>
                    <li>• Severe market instability or liquidity collapse</li>
                    <li>• Actions of government authorities</li>
                  </ul>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">14. Financial Stability and Security of Funds</h4>
                  <div className="text-sm text-white/80 leading-relaxed space-y-2">
                    <p><strong>14.1. Capital Adequacy:</strong> The Company maintains a reserve fund exceeding GBP 10,000,000, ensuring long-term operational stability and the ability to withstand market volatility.</p>
                    <p><strong>14.2. Client Fund Segregation:</strong> Client funds are segregated from operational funds and stored in separate cryptocurrency wallets, guaranteeing protection in case of unforeseen events.</p>
                    <p><strong>14.3. Risk Management Systems:</strong> The Company applies proprietary quantum algorithms and artificial intelligence for risk forecasting and mitigation:</p>
                    <ul className="ml-4 space-y-1">
                      <li>• Quantum Entanglement Neural Network (QENN) and Hyper-Dimensional Market Oracle (HDMO) provide forecasts with accuracy up to 99.7%</li>
                      <li>• Capital is diversified across multiple instruments to minimize losses</li>
                      <li>• AI Quantum Self-Evolution Engine (AQSEE) continuously improves algorithms for faster adaptation than traditional systems</li>
                    </ul>
                  </div>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">15. Limitation of Liability</h4>
                  <div className="text-sm text-white/80 leading-relaxed space-y-2">
                    <p>15.1. The Company is not a bank or licensed financial institution.</p>
                    <p>15.2. Despite advanced AI and quantum systems achieving high accuracy, all investments in digital assets carry inherent risks.</p>
                    <p>15.3. The Company is not liable for indirect, incidental, special, or consequential damages, including lost profits, arising from use of the Platform.</p>
                  </div>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">16. Changes to Terms</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    The Company reserves the right to amend these Terms at any time without prior notice. The latest version will always be available on the Platform.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">17. Governing Law</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    These Terms are governed by the laws of the jurisdiction where the Company is incorporated.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">18. Contact Information</h4>
                  <div className="text-sm text-white/80 leading-relaxed space-y-1">
                    <p><strong>QUANTUM AI TECHNOLOGIES LTD</strong></p>
                    <p>📍 Tower 42, International Financial Centre, 25 Old Broad Street, London, England, EC2N 1HN</p>
                    <p>📧 support@quantum-bot.ai</p>
                    <p>📧 product@quantum-bot.ai</p>
                    <p>📧 business@quantum-bot.ai (Ambassador Program)</p>
                    <p>📱 Telegram: t.me/QuantumAITrade_bot</p>
                  </div>
                </section>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="privacy" className="mt-6">
            <div className="h-[45vh] overflow-y-auto pr-4 scrollbar-thin scrollbar-thumb-white/20 scrollbar-track-transparent">
              <div className="space-y-6 text-white/90">
                <div>
                  <h3 className="text-lg font-bold text-primary mb-3">Privacy Policy</h3>
                  <p className="text-sm text-white/70 mb-4">Last updated: August 30, 2025</p>
                </div>

                <section>
                  <h4 className="font-semibold text-white mb-2">1. Information We Collect</h4>
                  <p className="text-sm text-white/80 leading-relaxed mb-2">
                    We collect the following categories of information:
                  </p>
                  <ul className="text-sm text-white/80 leading-relaxed ml-4 space-y-1">
                    <li>• Personal data (name, email, phone number)</li>
                    <li>• Financial information (USDT TRC-20 wallet details, deposit and withdrawal history)</li>
                    <li>• Technical information (IP address, device type, activity logs)</li>
                    <li>• KYC/AML documents (passport, ID, proof of address)</li>
                    <li>• Communication records (support requests, chats with the bot, inquiries)</li>
                  </ul>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">2. How We Use Your Information</h4>
                  <p className="text-sm text-white/80 leading-relaxed mb-2">
                    Your data is used to:
                  </p>
                  <ul className="text-sm text-white/80 leading-relaxed ml-4 space-y-1">
                    <li>• Provide and maintain Quantum AI investment services</li>
                    <li>• Process transactions and verify identity</li>
                    <li>• Comply with legal and regulatory requirements (AML/KYC)</li>
                    <li>• Improve the platform and user experience</li>
                    <li>• Send important updates, including security notifications</li>
                    <li>• Provide customer support and respond to requests</li>
                  </ul>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">3. Information Sharing</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    We do not sell personal data. Information may be shared with:
                  </p>
                  <ul className="text-sm text-white/80 leading-relaxed ml-4 space-y-1 mt-2">
                    <li>• Trusted third-party providers (KYC processors, payment providers, analytics)</li>
                    <li>• Legal authorities when required by law</li>
                    <li>• Affiliates of Quantum AI group companies to ensure service delivery</li>
                  </ul>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">4. Data Security</h4>
                  <p className="text-sm text-white/80 leading-relaxed mb-2">
                    We apply modern security measures, including:
                  </p>
                  <ul className="text-sm text-white/80 leading-relaxed ml-4 space-y-1">
                    <li>• Encryption of sensitive data</li>
                    <li>• Secure servers located in Tier 3+ data centers</li>
                    <li>• Regular audits and security assessments</li>
                  </ul>
                  <p className="text-sm text-white/80 leading-relaxed mt-2">
                    However, no method of internet transmission or storage is 100% secure, and we cannot guarantee absolute protection.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">5. Data Retention</h4>
                  <div className="text-sm text-white/80 leading-relaxed space-y-2">
                    <p>• Personal data is retained as long as necessary to provide services.</p>
                    <p>• KYC and transaction records may be stored for 5–10 years depending on legal requirements.</p>
                  </div>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">6. Your Rights</h4>
                  <p className="text-sm text-white/80 leading-relaxed mb-2">
                    Depending on your jurisdiction, you may have the right to:
                  </p>
                  <ul className="text-sm text-white/80 leading-relaxed ml-4 space-y-1">
                    <li>• Access your personal information</li>
                    <li>• Correct inaccuracies</li>
                    <li>• Request deletion of data (where not in conflict with legal obligations)</li>
                    <li>• Restrict processing</li>
                    <li>• Receive a copy of your data (data portability)</li>
                  </ul>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">7. Cookies and Tracking</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    We use cookies and similar technologies to analyze usage patterns, support platform functionality, and improve user experience.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">8. Third-Party Services</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    Our platform integrates with external providers (payment processors, KYC services, analytics). Each third-party has its own privacy policy, which we recommend reviewing.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">9. International Transfers</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    Your data may be processed in countries outside your residence. We ensure appropriate safeguards are in place to protect data in line with international standards (e.g., GDPR, UK Data Protection Act).
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">10. Children's Privacy</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    Our services are not intended for individuals under 18. If we become aware that such data has been provided, it will be deleted immediately.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">11. Changes to Privacy Policy</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    We may update this Privacy Policy from time to time. The latest version will always be available on our website and in the application. For significant changes, we will notify users via email or through our Telegram bot.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">12. Contact Us</h4>
                  <div className="text-sm text-white/80 leading-relaxed space-y-1">
                    <p><strong>QUANTUM AI TECHNOLOGIES LTD</strong></p>
                    <p>📍 Tower 42, International Financial Centre, 25 Old Broad Street, London, England, EC2N 1HN</p>
                    <p>📧 support@quantum-bot.ai</p>
                    <p>📧 business@quantum-bot.ai (Ambassador Program)</p>
                    <p>📱 Telegram: t.me/QuantumAITrade_bot</p>
                  </div>
                </section>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
