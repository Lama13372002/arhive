'use client';

import { useEffect } from 'react';
import { Loader2, TrendingDown, TrendingUp, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useDepositEstimate } from '@/hooks/use-deposit-estimate';
import { Card } from '@/components/ui/card';

interface DepositEstimateProps {
  amount: string;
  network: string;
  className?: string;
}

export function DepositEstimate({ amount, network, className = '' }: DepositEstimateProps) {
  const { estimate, isLoading, error, fetchEstimate } = useDepositEstimate();

  useEffect(() => {
    // Добавляем задержку для предотвращения слишком частых запросов
    const timeoutId = setTimeout(() => {
      fetchEstimate(amount, network);
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [amount, network, fetchEstimate]);

  if (!amount || parseFloat(amount) <= 0) {
    return null;
  }

  if (parseFloat(amount) < 1) {
    return (
      <Card className={`p-4 bg-gradient-to-r from-warning/10 via-warning/5 to-transparent border border-warning/20 ${className}`}>
        <div className="flex items-center space-x-2">
          <AlertCircle size={16} className="text-warning" />
          <p className="text-sm text-warning/90">
            Enter amount from 1 USDT to calculate fees
          </p>
        </div>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card className={`p-4 bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border border-primary/20 ${className}`}>
        <div className="flex items-center space-x-3">
          <Loader2 size={16} className="text-primary animate-spin" />
          <p className="text-sm text-primary/90">
            Calculating fees...
          </p>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className={`p-4 bg-gradient-to-r from-destructive/10 via-destructive/5 to-transparent border border-destructive/20 ${className}`}>
        <div className="flex items-center space-x-2">
          <AlertCircle size={16} className="text-destructive" />
          <p className="text-sm text-destructive/90">
            {error}
          </p>
        </div>
      </Card>
    );
  }

  if (!estimate) {
    return null;
  }

  const feeAmount = estimate.fees.total_fee.amount;
  const feePercent = estimate.fees.total_fee.percent;
  const payAmount = estimate.pay_amount;
  const desiredAmount = estimate.received_amount;

  return (
    <Card className={`p-4 bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border border-primary/20 shadow-lg shadow-primary/5 backdrop-blur-sm ${className}`}>
      <div className="space-y-3">
        {/* Заголовок */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <CheckCircle2 size={16} className="text-primary" />
            <h4 className="text-sm font-semibold text-white/95">Payment Calculation</h4>
          </div>
          {estimate.estimated && (
            <span className="text-xs text-warning/80 bg-warning/10 px-2 py-1 rounded-md">
              Estimate
            </span>
          )}
        </div>

        {/* Основные данные */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-xs text-white/60">You want to receive</p>
            <p className="text-sm font-bold text-white/90">
              {desiredAmount.toFixed(2)} USDT
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-white/60">You need to pay</p>
            <p className="text-lg font-bold text-primary">
              {payAmount.toFixed(2)} USDT
            </p>
          </div>
        </div>

        {/* Детали комиссий */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-sm">
            <span className="text-white/70">Desired amount:</span>
            <span className="text-white/90 font-medium">{desiredAmount.toFixed(2)} USDT</span>
          </div>

          <div className="flex items-center justify-between text-sm">
            <span className="text-white/70">Platform fee:</span>
            <span className="text-warning/90 font-medium">
              +{feeAmount.toFixed(4)} USDT ({feePercent.toFixed(2)}%)
            </span>
          </div>

          <div className="flex items-center justify-between text-sm border-t border-primary/20 pt-2">
            <span className="text-white/80 font-medium">Total to pay:</span>
            <div className="flex items-center space-x-1">
              <TrendingUp size={14} className="text-primary" />
              <span className="text-primary font-bold">
                {payAmount.toFixed(2)} USDT
              </span>
            </div>
          </div>
        </div>

        {/* Итоговая информация */}
        <div className="bg-gradient-to-r from-primary/20 to-primary/10 rounded-lg p-2.5 border border-primary/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <TrendingDown size={16} className="text-green-400" />
              <span className="text-white/90 font-semibold">Will receive:</span>
            </div>
            <span className="text-xl font-bold text-green-400">
              {desiredAmount.toFixed(2)} USDT
            </span>
          </div>
        </div>

        {/* Дополнительная информация */}
        {estimate.note && (
          <p className="text-xs text-primary/80 italic">
            {estimate.note}
          </p>
        )}

        <div className="flex items-center justify-between text-xs text-white/50">
          <span>Network: {estimate.payment_details.network_name}</span>
          <span>Fee varies per transaction</span>
        </div>
      </div>
    </Card>
  );
}
