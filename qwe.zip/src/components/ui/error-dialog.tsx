'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Copy, AlertTriangle, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ErrorDetails {
  error: string;
  details?: string;
  debugInfo?: Record<string, unknown>;
  timestamp?: string;
}

interface ErrorDialogProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  errorData: ErrorDetails;
}

export function ErrorDialog({ isOpen, onClose, title, errorData }: ErrorDialogProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  const copyToClipboard = async () => {
    const fullErrorText = `=== ${title} ===
Main Error: ${errorData.error}

${errorData.details ? `Details: ${errorData.details}` : ''}

${errorData.debugInfo ? `Debug Info:
${JSON.stringify(errorData.debugInfo, null, 2)}` : ''}

Timestamp: ${errorData.timestamp || new Date().toISOString()}
===========================`;

    try {
      await navigator.clipboard.writeText(fullErrorText);
      setCopied(true);
      toast({
        title: "Copied!",
        description: "Error details copied to clipboard",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Copy failed",
        description: "Could not copy to clipboard",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-600">
            <AlertTriangle className="h-5 w-5" />
            {title}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Main Error */}
          <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
            <h3 className="font-semibold text-red-800 mb-2">Error Message:</h3>
            <p className="text-red-700">{errorData.error}</p>
          </div>

          {/* Details */}
          {errorData.details && (
            <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
              <h3 className="font-semibold text-orange-800 mb-2">Details:</h3>
              <p className="text-orange-700 whitespace-pre-wrap font-mono text-sm">
                {errorData.details}
              </p>
            </div>
          )}

          {/* Debug Info */}
          {errorData.debugInfo && (
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h3 className="font-semibold text-blue-800 mb-2">Debug Information:</h3>
              <pre className="text-blue-700 text-xs overflow-x-auto whitespace-pre-wrap">
                {JSON.stringify(errorData.debugInfo, null, 2)}
              </pre>
            </div>
          )}

          {/* Timestamp */}
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Clock className="h-4 w-4" />
            <span>
              Occurred at: {errorData.timestamp || new Date().toISOString()}
            </span>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button
              variant="outline"
              onClick={copyToClipboard}
              className="flex items-center gap-2"
            >
              <Copy className="h-4 w-4" />
              {copied ? 'Copied!' : 'Copy Full Error'}
            </Button>
            <Button onClick={onClose}>Close</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
