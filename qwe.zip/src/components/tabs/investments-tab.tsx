'use client';

import { useState, useEffect, useCallback } from 'react';
import { TrendingUp, Clock, DollarSign, Calendar, Star, Zap, Crown, Gem } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { CountdownTimer } from '@/components/ui/countdown-timer';
import { useTelegram } from '@/components/providers/telegram-provider';
import { useToast } from '@/hooks/use-toast';

interface TariffPlan {
  id: number;
  code: string;
  name: string;
  minAmount: number;
  maxAmount: number;
  termDays: number;
  dailyPercent: number;
  isPopular?: boolean;
  icon: React.ReactNode;
  color: string;
  // Новые поля
  tariffType?: string;
  monthlyPercent?: number;
  totalReturnPercent?: number;
  isPerpetual?: boolean;
  autoReturnPrincipal?: boolean;
}

interface TariffData {
  id: number;
  code: string;
  name_en?: string;
  name_ru?: string;
  minAmount: number;
  maxAmount: number;
  termDays: number;
  dailyPercent: number;
  // Новые поля из API
  tariffType?: string;
  monthlyPercent?: number;
  totalReturnPercent?: number;
  isPerpetual?: boolean;
  autoReturnPrincipal?: boolean;
}

interface Investment {
  id: number;
  planName?: string;
  planCode: string;
  amount: number;
  dailyProfit?: number;
  dailyPercent: number;
  claimableAmount?: number;
  totalDays?: number;
  termDays?: number;
  daysLeft?: number;
  createdAt?: string;
  status?: string;
  principal_returned?: boolean;
  withdrawal_request_id?: number;
  tariff_type?: string;
  is_perpetual?: boolean;
}

export function InvestmentsTab() {
  const { user } = useTelegram();
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<TariffPlan | null>(null);
  const [investmentAmount, setInvestmentAmount] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [tariffPlans, setTariffPlans] = useState<TariffPlan[]>([]);
  const [activeInvestments, setActiveInvestments] = useState<Investment[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [debugInfo, setDebugInfo] = useState<string[]>([]);
  const [lastError, setLastError] = useState<string>('');

  const loadData = useCallback(async () => {
    try {
      const tRes = await fetch('/api/user/tariffs');
      const t = await tRes.json();
      if (t.success) {
        setTariffPlans(
          (t.data as TariffData[]).map((p) => ({
            id: p.id,
            code: p.code,
            name: p.name_en || p.name_ru || 'Unknown Plan',
            minAmount: p.minAmount,
            maxAmount: p.maxAmount,
            termDays: p.termDays,
            dailyPercent: p.dailyPercent,
            icon: <Star size={24} />,
            color: p.isPerpetual ? 'from-purple-500 to-purple-600' :
                   p.code === 'T2' ? 'from-primary to-primary/80' : 'from-blue-500 to-blue-600',
            isPopular: p.code === 'T2',
            // Новые поля
            tariffType: p.tariffType,
            monthlyPercent: p.monthlyPercent,
            totalReturnPercent: p.totalReturnPercent,
            isPerpetual: p.isPerpetual,
            autoReturnPrincipal: p.autoReturnPrincipal,
          }))
        );
      }
      if (user?.id) {
        const iRes = await fetch(`/api/user/investments?user_id=${String(user.id)}`);
        const inv = await iRes.json();

        // Сохраняем диагностическую информацию
        if (inv.debug && Array.isArray(inv.debug)) {
          setDebugInfo(inv.debug);
        }

        console.log('Full API Response:', inv);

        if (inv.success) {
          setActiveInvestments(inv.data);
          setLastError(''); // очищаем ошибку при успехе

          // cache to sessionStorage per telegram_id
          try {
            sessionStorage.setItem(`active_investments:${String(user.id)}`, JSON.stringify(inv.data ?? []));
          } catch {}
        } else {
          // Подробная информация об ошибке
          let errorDetails = inv.error || 'Unknown error';
          if (inv.errorDetails) {
            errorDetails += ' | Детали: ' + inv.errorDetails;
          }

          setLastError(errorDetails);
          console.error('API Error Details:', errorDetails);

          toast({
            title: 'API Error',
            description: errorDetails,
            variant: 'destructive'
          });
        }
      } else {
        toast({
          title: 'User Debug',
          description: 'User ID is missing',
          variant: 'destructive'
        });
      }
    } catch (e) {
      console.warn('loadData error', e);
    }
  }, [user?.id, toast]);

  // Mount/load and retry if user not ready yet
  useEffect(() => {
    let retryTimer: ReturnType<typeof setTimeout> | null = null;

    // prime from cache immediately to avoid flicker on tab switch
    try {
      if (user?.id) {
        const cached = sessionStorage.getItem(`active_investments:${String(user.id)}`);
        if (cached) {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed)) setActiveInvestments(parsed);
        }
      }
    } catch {}

    if (user?.id) {
      loadData();
    } else {
      // small retry to give Telegram provider time
      retryTimer = setTimeout(() => {
        if (user?.id) loadData();
      }, 500);
    }

    return () => {
      if (retryTimer) clearTimeout(retryTimer);
    };
  }, [user?.id, loadData]);

  // Reload when tab/page becomes visible again
  useEffect(() => {
    const onVis = () => {
      if (document.visibilityState === 'visible') {
        // prime cache
        try {
          if (user?.id) {
            const cached = sessionStorage.getItem(`active_investments:${String(user.id)}`);
            if (cached) {
              const parsed = JSON.parse(cached);
              if (Array.isArray(parsed)) setActiveInvestments(parsed);
            }
          }
        } catch {}
        loadData();
      }
    };
    const onFocus = () => {
      // same as visibility: refresh when window gains focus
      try {
        if (user?.id) {
          const cached = sessionStorage.getItem(`active_investments:${String(user.id)}`);
          if (cached) {
            const parsed = JSON.parse(cached);
            if (Array.isArray(parsed)) setActiveInvestments(parsed);
          }
        }
      } catch {}
      loadData();
    };
    document.addEventListener('visibilitychange', onVis);
    window.addEventListener('focus', onFocus);
    return () => {
      document.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('focus', onFocus);
    };
  }, [user?.id, loadData]);

  // Automatic data update every 30 seconds to refresh accumulated income
  useEffect(() => {
    if (!user?.id) return;

    const updateInterval = setInterval(() => {
      // Тихо обновляем данные без показа ошибок
      loadData().catch(() => {
        // Игнорируем ошибки при автоматическом обновлении
      });
    }, 30000); // Каждые 30 секунд

    return () => clearInterval(updateInterval);
  }, [user?.id, loadData]);

  const calculateProfit = (plan: TariffPlan, amount: number) => {
    const dailyProfit = (amount * plan.dailyPercent) / 100;
    const totalProfit = dailyProfit * plan.termDays;
    return { dailyProfit, totalProfit };
  };

  const handleInvest = async () => {
    if (!selectedPlan || !investmentAmount) return;
    if (!user?.id) {
      toast({ title: 'User not ready', description: 'Telegram not initialized', variant: 'destructive' });
      return;
    }

    const amount = parseFloat(investmentAmount);
    if (amount < selectedPlan.minAmount || amount > selectedPlan.maxAmount) {
      toast({
        title: 'Invalid amount',
        description: `Amount must be between ${selectedPlan.minAmount} and ${selectedPlan.maxAmount} USDT`,
        variant: 'destructive'
      });
      return;
    }

    try {
      setIsSubmitting(true);
      const res = await fetch('/api/user/investments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: String(user.id), tariff_code: selectedPlan.code, amount })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        toast({ title: 'Investment failed', description: data.error || 'Error', variant: 'destructive' });
        return;
      }
      toast({ title: 'Investment created', description: 'Funds locked, daily profit will accrue' });
      // сразу синхронизируемся с сервером без оптимистичного добавления
      await loadData();
      setIsDialogOpen(false);
      setInvestmentAmount('');
      setSelectedPlan(null);
    } catch (e) {
      toast({ title: 'Network error', description: String(e), variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleWithdrawalRequest = async (investmentId: number, investment: Investment) => {
    if (!user?.id) {
      toast({ title: 'User not ready', description: 'Telegram not initialized', variant: 'destructive' });
      return;
    }

    // Check that this is a perpetual tariff
    if (!investment.is_perpetual) {
      toast({ title: 'Unavailable', description: 'Principal withdrawal is only available for perpetual plans', variant: 'destructive' });
      return;
    }

    // Check that there is no active request
    if (investment.withdrawal_request_id) {
      toast({ title: 'Request already sent', description: 'Your principal withdrawal request is pending review', variant: 'destructive' });
      return;
    }

    try {
      const res = await fetch('/api/user/investments/withdrawal-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: String(user.id),
          investment_id: investmentId,
          reason: 'User request for principal withdrawal'
        })
      });
      const data = await res.json();

      if (!res.ok || !data.success) {
        toast({
          title: 'Request Error',
          description: data.error || 'Failed to send withdrawal request',
          variant: 'destructive'
        });
        return;
      }

      toast({
        title: 'Request Sent',
        description: 'Your principal withdrawal request has been sent to the administrator for review. You will receive a notification about the decision.'
      });
      await loadData();
    } catch (e) {
      toast({ title: 'Network error', description: String(e), variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-6">


      {/* Active Investments */}
      {activeInvestments.length > 0 && (
        <div className="space-y-5">
          <h3 className="text-lg font-bold text-white/95 flex items-center">
            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center mr-2">
              <TrendingUp size={14} className="text-primary" />
            </div>
            Active Investments
          </h3>

          {activeInvestments.map((investment: Investment) => (
            <Card key={investment.id} className="investment-card shine-effect overflow-hidden relative group">
              <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-primary/10 to-transparent opacity-30 -z-10"></div>
              <CardContent className="p-5 relative z-10">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="font-medium text-white/80">{investment.planName || investment.planCode} Plan</p>
                    <p className="text-2xl font-bold text-primary quantum-glow">{investment.amount} USDT</p>
                  </div>
                  <Badge variant="outline" className="text-primary border-primary/30 bg-primary/5 px-3 py-1 group-hover:bg-primary/10 transition-all duration-300">
                    <div className="w-2 h-2 rounded-full bg-primary animate-pulse mr-1.5"></div>
                    Active
                  </Badge>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between text-sm bg-white/5 p-3 rounded-lg border border-white/5 group-hover:border-primary/10 transition-all duration-300">
                    <span className="text-white/60">Daily Profit</span>
                    <span className="text-primary font-bold">
                      +{investment.dailyProfit ? investment.dailyProfit.toFixed(2) : ((investment.amount * investment.dailyPercent) / 100).toFixed(2)} USDT
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-sm bg-white/5 p-3 rounded-lg border border-white/5 group-hover:border-primary/10 transition-all duration-300">
                    <span className="text-white/60">
                      {investment.is_perpetual ? 'Accumulated Income' : 'Accumulated Interest'}
                    </span>
                    <span className="text-primary font-bold">
                      +{Number(investment.claimableAmount ?? 0).toFixed(2)} USDT
                    </span>
                  </div>

                  {!investment.is_perpetual && (
                    <div className="bg-blue-500/10 border border-blue-500/20 p-3 rounded-lg">
                      <div className="text-blue-400 text-sm font-medium">
                        ℹ️ Fixed Term Plan
                      </div>
                      <div className="text-blue-300/80 text-xs mt-1">
                        Interest and principal will be credited after the term ends
                      </div>
                    </div>
                  )}

                  {/* Статус запроса на возврат */}
                  {investment.withdrawal_request_id && (
                    <div className="bg-yellow-500/10 border border-yellow-500/20 p-3 rounded-lg">
                      <div className="text-yellow-400 text-sm font-medium">
                        📋 Principal withdrawal request sent
                      </div>
                      <div className="text-yellow-300/80 text-xs mt-1">
                        Awaiting administrator decision
                      </div>
                    </div>
                  )}

                  {/* Кнопки действий */}
                  <div className="flex gap-3">
                    {investment.is_perpetual && !investment.withdrawal_request_id && !investment.principal_returned && (
                      <Button
                        variant="outline"
                        onClick={() => handleWithdrawalRequest(investment.id, investment)}
                        className="flex-1 h-10 border-red-400/20 bg-red-500/5 hover:bg-red-500/10 hover:text-red-400 hover:border-red-400/30 transition-all duration-300 rounded-xl font-semibold"
                      >
                        Withdraw Principal
                      </Button>
                    )}

                    {investment.principal_returned && (
                      <div className="flex-1 p-3 bg-green-500/10 border border-green-500/20 rounded-lg text-center">
                        <div className="text-green-400 text-sm font-medium">
                          ✅ Principal Returned
                        </div>
                        <div className="text-green-300/80 text-xs">
                          Investment Completed
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Прогресс-бар только для срочных планов */}
                  {!investment.is_perpetual && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-white/60">Progress</span>
                        <span className="text-white/90">
                          {(investment.totalDays || investment.termDays || 0) - (investment.daysLeft || 0)}/{investment.totalDays || investment.termDays || 0} days
                        </span>
                      </div>
                      <Progress
                        value={
                          ((investment.totalDays || investment.termDays || 0) - (investment.daysLeft || 0)) /
                          (investment.totalDays || investment.termDays || 1) *
                          100
                        }
                        className="h-2.5 rounded-full bg-white/10 overflow-hidden"
                      />
                    </div>
                  )}

                  {/* Для бессрочных планов показываем дни с момента создания */}
                  {investment.is_perpetual && (
                    <div className="bg-purple-500/10 border border-purple-500/20 p-3 rounded-lg">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-purple-400 font-medium">♾️ Perpetual Plan</span>
                        <span className="text-purple-300">
                          Running for {(investment.totalDays || investment.termDays || 0) - (investment.daysLeft || 0)} days
                        </span>
                      </div>
                    </div>
                  )}

                  {investment.createdAt ? (
                    <CountdownTimer createdAt={investment.createdAt} />
                  ) : (
                    <div className="flex items-center text-sm text-white/60 bg-gradient-to-r from-primary/5 to-transparent p-2 rounded-lg">
                      <Clock size={14} className="mr-1.5 text-primary/80" />
                      {investment.daysLeft || 0} days remaining
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Investment Plans */}
      <div className="space-y-5">
        <h3 className="text-lg font-bold text-white/95 flex items-center">
          <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center mr-2">
            <Crown size={14} className="text-primary" />
          </div>
          Investment Plans
        </h3>

        <div className="grid gap-5">
          {tariffPlans.map((plan) => (
            <Card key={plan.id} className="glass-card shine-effect relative overflow-hidden group border border-white/5 hover:border-primary/20 transition-all duration-300">
              {plan.isPopular && (
                <div className="absolute -top-1 -right-1 z-10">
                  <div className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground text-xs font-bold px-3 py-1 rounded-bl-lg rounded-tr-lg shadow-lg shadow-primary/20">
                    POPULAR
                  </div>
                </div>
              )}

              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-20 transition-all duration-300 -z-10"></div>

              <CardHeader className="pb-3">
                <div className="flex items-center space-x-3">
                  <div className={`w-14 h-14 rounded-full bg-gradient-to-r ${plan.color} flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-all duration-300`}>
                    {plan.icon}
                  </div>
                  <div>
                    <CardTitle className="text-xl font-bold text-white">{plan.name}</CardTitle>
                    <p className="text-sm text-primary/80">{plan.code}</p>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="pt-0">
                <div className="space-y-5">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="p-3 rounded-lg bg-white/5 border border-white/5 group-hover:border-primary/10 transition-all duration-300">
                      <p className="text-white/60 mb-1">Min Amount</p>
                      <p className="font-bold text-white group-hover:text-primary transition-colors duration-300">{plan.minAmount} USDT</p>
                    </div>
                    <div className="p-3 rounded-lg bg-white/5 border border-white/5 group-hover:border-primary/10 transition-all duration-300">
                      <p className="text-white/60 mb-1">Max Amount</p>
                      <p className="font-bold text-white group-hover:text-primary transition-colors duration-300">{plan.maxAmount.toLocaleString()} USDT</p>
                    </div>
                    <div className="p-3 rounded-lg bg-white/5 border border-white/5 group-hover:border-primary/10 transition-all duration-300">
                      <p className="text-white/60 mb-1">Daily Profit</p>
                      <p className="font-bold text-primary">{plan.dailyPercent.toFixed(2)}%</p>
                    </div>
                    <div className="p-3 rounded-lg bg-white/5 border border-white/5 group-hover:border-primary/10 transition-all duration-300">
                      <p className="text-white/60 mb-1">Term</p>
                      <p className="font-bold text-white group-hover:text-primary transition-colors duration-300">
                        {plan.isPerpetual || plan.termDays > 365 ? '♾️ Perpetual' : `${plan.termDays} days`}
                      </p>
                    </div>
                  </div>

                  <div className="bg-gradient-to-r from-primary/10 to-transparent rounded-lg p-4 border border-primary/10">
                    <div className="flex items-center justify-between">
                      <span className="text-white/80 font-medium">
                        {plan.isPerpetual ? 'Monthly Return' : 'Total Return'}
                      </span>
                      <span className="text-primary font-bold text-lg">
                        {plan.isPerpetual ?
                          `${plan.monthlyPercent?.toFixed(2) || (plan.dailyPercent * 30).toFixed(2)}%` :
                          `${(plan.dailyPercent * plan.termDays).toFixed(2)}%`}
                      </span>
                    </div>
                  </div>

                  <Dialog open={isDialogOpen && selectedPlan?.id === plan.id} onOpenChange={setIsDialogOpen}>
                    <DialogTrigger asChild>
                      <Button
                        className="w-full deposit-button h-12 rounded-xl mt-2 group-hover:shadow-lg group-hover:shadow-primary/20 transition-all duration-300"
                        onClick={() => setSelectedPlan(plan)}
                      >
                        <TrendingUp size={18} className="mr-2" />
                        Invest Now
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-gradient-to-br from-card/98 via-card/95 to-card/98 backdrop-blur-xl border border-primary/20 shadow-2xl shadow-primary/10 max-w-md mx-auto">
                      <DialogHeader className="pb-4 border-b border-primary/10">
                        <DialogTitle className="text-2xl font-bold text-white flex items-center bg-gradient-to-r from-white via-primary/90 to-white bg-clip-text text-transparent">
                          <div className={`mr-4 w-12 h-12 rounded-full bg-gradient-to-r ${plan.color} flex items-center justify-center shadow-lg border border-white/20`}>
                            {plan.icon}
                          </div>
                          Invest in {plan.name} Plan
                        </DialogTitle>
                      </DialogHeader>

                      <div className="space-y-6 relative pt-2">
                        {plan.code !== 'T1' && (
                          <>
                            <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-br from-primary/20 to-primary/5 rounded-full blur-3xl -z-10 opacity-30"></div>
                            <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-primary/10 to-transparent rounded-full blur-2xl -z-10 opacity-20"></div>
                          </>
                        )}

                        <div className="space-y-3">
                          <Label htmlFor="amount" className="text-white/95 font-semibold text-sm tracking-wide">Investment Amount (USDT)</Label>
                          <Input
                            id="amount"
                            type="number"
                            placeholder={`Min: ${plan.minAmount}, Max: ${plan.maxAmount}`}
                            value={investmentAmount}
                            onChange={(e) => setInvestmentAmount(e.target.value)}
                            className="border-white/20 bg-gradient-to-r from-white/10 to-white/5 focus:border-primary/60 focus:bg-white/15 transition-all duration-300 h-14 rounded-xl text-white placeholder:text-white/50 shadow-inner"
                          />
                        </div>

                        {investmentAmount && (
                          <div className="bg-gradient-to-r from-primary/15 via-primary/8 to-transparent rounded-2xl p-5 border border-primary/25 space-y-4 shadow-lg shadow-primary/5 backdrop-blur-sm">
                            <div className="flex justify-between items-center">
                              <span className="text-white/80 font-medium">Daily Profit:</span>
                              <span className="text-primary font-bold text-lg">
                                +{calculateProfit(plan, parseFloat(investmentAmount) || 0).dailyProfit.toFixed(2)} USDT
                              </span>
                            </div>
                            <div className="flex justify-between items-center pt-3 border-t border-primary/20">
                              <span className="text-white/90 font-semibold">Total Profit:</span>
                              <span className="text-primary font-bold text-xl">
                                +{calculateProfit(plan, parseFloat(investmentAmount) || 0).totalProfit.toFixed(2)} USDT
                              </span>
                            </div>
                          </div>
                        )}

                        <div className="flex space-x-4 pt-4">
                          <Button
                            variant="outline"
                            onClick={() => setIsDialogOpen(false)}
                            className="flex-1 h-14 border-white/20 bg-white/5 hover:bg-white/10 hover:text-white hover:border-white/30 transition-all duration-300 rounded-xl font-semibold"
                          >
                            Cancel
                          </Button>
                          <Button
                            onClick={handleInvest}
                            disabled={isSubmitting}
                            className="flex-1 deposit-button h-14 rounded-xl font-semibold shadow-xl shadow-primary/30 hover:shadow-2xl hover:shadow-primary/40 transition-all duration-300"
                          >
                            {isSubmitting ? 'Processing...' : 'Confirm Investment'}
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
