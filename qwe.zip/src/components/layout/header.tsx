'use client';

import { Bell, User } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import Image from 'next/image';
import { useKycStatus } from '@/hooks/use-kyc-status';

interface HeaderProps {
  user: {
    id: number;
    first_name: string;
    last_name?: string;
    username?: string;
    language_code?: string;
  } | null | undefined;
}

export function Header({ user }: HeaderProps) {
  const { kycStatus, isLoading: kycLoading } = useKycStatus(user?.id);

  const getInitials = () => {
    if (!user) return 'U';
    const firstInitial = user.first_name?.[0] || '';
    const lastInitial = user.last_name?.[0] || '';
    return (firstInitial + lastInitial).toUpperCase() || user.username?.[0]?.toUpperCase() || 'U';
  };

  const getDisplayName = () => {
    if (!user) return 'User';
    return user.first_name + (user.last_name ? ` ${user.last_name}` : '');
  };

  const getVerificationStatus = () => {
    if (kycLoading) return 'Loading...';

    switch (kycStatus) {
      case 'completed':
        return 'Verified';
      case 'pending':
        return 'Under Review';
      case 'declined':
        return 'Verification Failed';
      default:
        return 'Not Verified';
    }
  };

  const getVerificationColor = () => {
    switch (kycStatus) {
      case 'completed':
        return 'border-primary/20 bg-primary/5 text-primary';
      case 'pending':
        return 'border-yellow-500/20 bg-yellow-500/5 text-yellow-500';
      case 'declined':
        return 'border-red-500/20 bg-red-500/5 text-red-500';
      default:
        return 'border-gray-500/20 bg-gray-500/5 text-gray-500';
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-gradient-to-b from-background via-card/95 to-card/90 backdrop-blur-xl border-b border-white/5 shadow-md shadow-black/20">
      <div className="container mx-auto px-4 py-3 max-w-md">
        <div className="flex items-center justify-between">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 flex items-center justify-center">
              <Image
                src="/logo.png"
                alt="Logo"
                width={40}
                height={40}
                className="object-contain"
              />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white quantum-glow tracking-wider">
                QUANTUM xAI
              </h1>
            </div>
          </div>

          {/* Right side controls */}
          <div className="flex items-center space-x-3">


            {/* User Avatar */}
            <div className="flex items-center">
              <Avatar className="w-8 h-8 border-2 border-primary/30 ring-2 ring-primary/10 transition-all duration-300 hover:ring-primary/30">
                <AvatarFallback className="bg-gradient-to-br from-primary/30 to-primary/10 text-xs font-bold text-primary-foreground">
                  {getInitials()}
                </AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>

        {/* Welcome message */}
        {user && (
          <div className="mt-2">
            <p className="text-sm text-white/90 font-medium">
              Welcome, <span className="text-primary">{getDisplayName()}</span>!
            </p>
            <Badge variant="outline" className={`text-xs mt-1 ${getVerificationColor()}`}>
              <User size={10} className="mr-1" />
              {getVerificationStatus()}
            </Badge>
          </div>
        )}
      </div>
    </header>
  );
}
