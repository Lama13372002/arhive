import { useState, useEffect, useCallback } from 'react';
import { useTelegram } from '@/components/providers/telegram-provider';

interface VerificationStatus {
  kycStatus: string;
  verification: {
    id: string;
    status: string;
    submitted_at: string;
    reviewed_at: string | null;
    rejection_reason: string | null;
    first_name: string;
    last_name: string;
    document_type: string;
  } | null;
  isCustomVerification: boolean;
}

export function useVerificationStatus() {
  const { user } = useTelegram();
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const checkVerificationStatus = useCallback(async () => {
    if (!user?.id) return;

    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`/api/verification/status?userId=${user.id}`);
      const data = await response.json();

      if (response.ok) {
        setVerificationStatus(data);
      } else {
        setError(data.error || 'Failed to check verification status');
      }
    } catch (err) {
      setError('Network error while checking verification status');
    } finally {
      setIsLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    checkVerificationStatus();
  }, [checkVerificationStatus]);

  const isVerified = verificationStatus?.kycStatus === 'completed';
  const isPending = verificationStatus?.kycStatus === 'pending';
  const isDeclined = verificationStatus?.kycStatus === 'declined';

  return {
    verificationStatus,
    isLoading,
    error,
    isVerified,
    isPending,
    isDeclined,
    refetch: checkVerificationStatus,
  };
}
