import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import crypto from 'crypto';

// Helper to notify referrer via Telegram Bot API
async function notifyReferrer(referrerTelegramId: number, newUserId: number) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return; // silently skip if not configured
  const text = '🎉 You have a new partner in the structure.\n\nCongratulations!\n— Your Quantum xAI';
  try {
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: referrerTelegramId, text }),
    });
  } catch (e) {
    console.warn('Failed to notify referrer:', e);
  }
}

interface RegisterUserRequest {
  telegram_id: string;
  phone?: string;
  language?: 'ru' | 'en';
  referred_by_code?: string;
  username?: string; // Добавляем username из TMA
  first_name?: string; // Добавляем имя из TMA
  last_name?: string; // Добавляем фамилию из TMA
}



export async function POST(request: NextRequest) {
  try {
    const {
      telegram_id,
      phone,
      language = 'ru',
      referred_by_code,
      username,
      first_name,
      last_name
    }: RegisterUserRequest = await request.json();

    if (!telegram_id) {
      return NextResponse.json(
        { success: false, error: 'Telegram ID is required' },
        { status: 400 }
      );
    }

    // Проверяем, существует ли уже пользователь
    const existingUser = await db.query(
      'SELECT id, ref_code, username FROM users WHERE telegram_id = $1',
      [telegram_id]
    );

    if (existingUser.rows.length > 0) {
      const userRow = existingUser.rows[0];
      const userId = userRow.id as number;
      const userRefCode = userRow.ref_code as string;
      const currentUsername = userRow.username as string | null;

      let shouldUpdate = false;
      const updates: string[] = [];
      const values: (string | number)[] = [];
      let paramCount = 1;

      // Проверяем, нужно ли обновить username
      if (username && currentUsername !== username) {
        updates.push(`username = $${++paramCount}`);
        values.push(username);
        shouldUpdate = true;
        console.log(`Обновляем username для пользователя ${telegram_id}: ${currentUsername} -> ${username}`);
      }

      // Если нужно обновить данные пользователя
      if (shouldUpdate) {
        updates.push(`updated_at = NOW()`);
        const updateQuery = `UPDATE users SET ${updates.join(', ')} WHERE telegram_id = $1 RETURNING id, ref_code, username`;
        values.unshift(telegram_id); // telegram_id идет первым параметром

        const updateResult = await db.query(updateQuery, values);

        // Логируем обновление username'а
        await db.query(
          `INSERT INTO audit_log
           (actor_user_id, action, target_type, target_id, metadata, created_at)
           VALUES ($1, 'username_updated', 'user', $2, $3, NOW())`,
          [userId, userId.toString(), JSON.stringify({
            telegram_id,
            old_username: currentUsername,
            new_username: username,
            first_name,
            last_name
          })]
        );

        return NextResponse.json({
          success: true,
          data: {
            user_id: updateResult.rows[0].id,
            ref_code: updateResult.rows[0].ref_code,
            message: 'User found and username updated',
            updated: true
          }
        });
      }

      return NextResponse.json({
        success: true,
        data: {
          user_id: userId,
          ref_code: userRefCode,
          message: 'User already exists',
          updated: false
        }
      });
    }

    // Генерируем уникальный реферальный код
    const generateRefCode = () => {
      return crypto.randomBytes(4).toString('hex').toUpperCase();
    };

    let refCode = generateRefCode();
    let isUniqueCode = false;
    let attempts = 0;

    // Проверяем уникальность реферального кода
    while (!isUniqueCode && attempts < 10) {
      const existingCodeResult = await db.query(
        'SELECT id FROM users WHERE ref_code = $1',
        [refCode]
      );

      if (existingCodeResult.rows.length === 0) {
        isUniqueCode = true;
      } else {
        refCode = generateRefCode();
        attempts++;
      }
    }

    if (!isUniqueCode) {
      return NextResponse.json(
        { success: false, error: 'Failed to generate unique referral code' },
        { status: 500 }
      );
    }

    // Проверяем реферера, если указан реферальный код
    let referredById: number | null = null;
    let referrerTelegramId: number | null = null;
    if (referred_by_code) {
      const referrerResult = await db.query(
        'SELECT id, telegram_id FROM users WHERE ref_code = $1',
        [referred_by_code]
      );

      if (referrerResult.rows.length > 0) {
        referredById = referrerResult.rows[0].id as number;
        referrerTelegramId = Number(referrerResult.rows[0].telegram_id);
      }
    }

    // Создаем пользователя в транзакции
    const result = await db.transaction(async (client) => {
      // Создаем пользователя с username'ом
      const userResult = await client.query(
        `INSERT INTO users
         (telegram_id, phone, language, ref_code, referred_by_id, username, created_at, updated_at)
         VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
         RETURNING id, ref_code, username`,
        [telegram_id, phone, language, refCode, referredById, username]
      );

      const userId = userResult.rows[0].id as number;

      // Создаем начальный баланс пользователя
      await client.query(
        `INSERT INTO users_balance
         (user_id, currency, available, bonus, locked, updated_at)
         VALUES ($1, 'USDT', 0, 0, 0, NOW())`,
        [userId]
      );

      // Логируем создание пользователя
      await client.query(
        `INSERT INTO audit_log
         (actor_user_id, action, target_type, target_id, metadata, created_at)
         VALUES ($1, 'user_registered', 'user', $2, $3, NOW())`,
        [userId, userId.toString(), JSON.stringify({
          telegram_id,
          language,
          username,
          first_name,
          last_name,
          referred_by_code: referred_by_code || null,
          referred_by_id: referredById
        })]
      );

      return {
        id: userId,
        ref_code: userResult.rows[0].ref_code,
        username: userResult.rows[0].username
      } as const;
    });

    // Fire-and-forget notify referrer after commit
    if (referredById && referrerTelegramId) {
      notifyReferrer(referrerTelegramId, result.id).catch(() => {});
    }

    return NextResponse.json({
      success: true,
      data: {
        user_id: result.id,
        ref_code: result.ref_code,
        username: result.username,
        message: 'User created successfully',
        updated: false
      }
    });

  } catch (error: unknown) {
    console.error('User registration error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// GET метод для проверки существования пользователя
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const telegram_id = searchParams.get('telegram_id');

    if (!telegram_id) {
      return NextResponse.json(
        { success: false, error: 'Telegram ID is required' },
        { status: 400 }
      );
    }

    const userResult = await db.query(
      'SELECT id, ref_code, language, username, created_at FROM users WHERE telegram_id = $1',
      [telegram_id]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json({
        success: false,
        error: 'User not found'
      }, { status: 404 });
    }

    const user = userResult.rows[0];

    return NextResponse.json({
      success: true,
      data: {
        user_id: user.id,
        ref_code: user.ref_code,
        language: user.language,
        username: user.username,
        created_at: user.created_at
      }
    });

  } catch (error: unknown) {
    console.error('User check error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
