import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { TransactionDBResult } from '@/types';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const user_id = searchParams.get('user_id');
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');

    if (!user_id) {
      return NextResponse.json(
        { success: false, error: 'User ID is required' },
        { status: 400 }
      );
    }

    const userResult = await db.query('SELECT id FROM users WHERE telegram_id = $1', [user_id]);
    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }
    const userId = userResult.rows[0].id;

    const depositsResult = await db.query(
      `SELECT
         'deposit' as type,
         id,
         COALESCE(desired_amount, amount) as amount,
         status,
         network_code as network,
         provider_tx_id as tx_hash,
         created_at as date,
         0 as fee
       FROM deposits
       WHERE user_id = $1
       ORDER BY created_at DESC`,
      [userId]
    );

    const withdrawalsResult = await db.query(
      `SELECT
         'withdrawal' as type,
         id,
         amount,
         status,
         network_code as network,
         txid as tx_hash,
         created_at as date,
         fee
       FROM withdrawals
       WHERE user_id = $1
       ORDER BY created_at DESC`,
      [userId]
    );

    const ledgerResult = await db.query(
      `SELECT
         CASE
           WHEN entry_type = 'admin_adjustment_plus' THEN 'admin_credit'
           WHEN entry_type = 'admin_adjustment_minus' THEN 'admin_debit'
           ELSE 'ledger_entry'
         END as type,
         id,
         amount,
         'completed' as status,
         NULL as network,
         NULL as tx_hash,
         created_at as date,
         0 as fee,
         description,
         balance_available_delta,
         balance_bonus_delta
       FROM ledger_entries
       WHERE user_id = $1
       AND entry_type IN ('admin_adjustment_plus', 'admin_adjustment_minus')
       ORDER BY created_at DESC`,
      [userId]
    );

    type Row = {
      id: number;
      type: 'deposit' | 'withdrawal' | 'admin_credit' | 'admin_debit' | 'ledger_entry';
      amount: string;
      status: string;
      network: string | null;
      tx_hash: string | null;
      date: string;
      fee: string | null;
      description?: string;
      balance_available_delta?: string;
      balance_bonus_delta?: string;
    };

    const transactions: Row[] = [
      ...depositsResult.rows,
      ...withdrawalsResult.rows,
      ...ledgerResult.rows
    ] as unknown as Row[];

    const sortedTransactions = transactions
      .sort((a, b) => new Date(String(b.date)).getTime() - new Date(String(a.date)).getTime())
      .slice(offset, offset + limit);

    const formattedTransactions = sortedTransactions.map((tx: Row) => ({
      id: tx.id,
      type: tx.type,
      amount: parseFloat(String(tx.amount)),
      status: tx.status,
      network: tx.network || '',
      tx_hash: tx.tx_hash,
      date: new Date(String(tx.date)).toISOString(),
      fee: tx.fee ? parseFloat(String(tx.fee)) : 0,
      description: tx.description || '',
      balance_available_delta: tx.balance_available_delta ? parseFloat(String(tx.balance_available_delta)) : 0,
      balance_bonus_delta: tx.balance_bonus_delta ? parseFloat(String(tx.balance_bonus_delta)) : 0
    }));

    return NextResponse.json({
      success: true,
      data: {
        transactions: formattedTransactions,
        total: depositsResult.rows.length + withdrawalsResult.rows.length + ledgerResult.rows.length,
        limit,
        offset
      }
    });

  } catch (error: unknown) {
    console.error('Transactions fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
