import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const telegram_id = searchParams.get('telegram_id');

    if (!telegram_id) {
      return NextResponse.json({ success: false, error: 'Telegram ID is required' }, { status: 400 });
    }

    const userRes = await db.query('SELECT id FROM users WHERE telegram_id = $1', [telegram_id]);
    if (userRes.rows.length === 0) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 });
    }
    const userId = userRes.rows[0].id as number;

    // Get total investments by level using recursive CTE
    const investmentsRes = await db.query(
      `with recursive tree as (
        select id, referred_by_id, 1 as level from users where referred_by_id = $1
        union all
        select u.id, u.referred_by_id, t.level + 1 from users u
        join tree t on u.referred_by_id = t.id
        where t.level < 3
      )
      select
        t.level,
        coalesce(sum(i.amount), 0) as total_invested,
        count(distinct t.id) as users_count,
        count(i.id) as investments_count
      from tree t
      left join investments i on i.user_id = t.id
      group by t.level
      order by t.level`,
      [userId]
    );

    // Initialize result with zeros
    const result = {
      level1: { totalInvested: 0, usersCount: 0, investmentsCount: 0 },
      level2: { totalInvested: 0, usersCount: 0, investmentsCount: 0 },
      level3: { totalInvested: 0, usersCount: 0, investmentsCount: 0 },
      totalInvested: 0,
      totalUsers: 0,
      totalInvestments: 0
    };

    // Process results
    let totalInvested = 0;
    let totalUsers = 0;
    let totalInvestments = 0;

    for (const row of investmentsRes.rows) {
      const level = Number(row.level);
      const invested = Number(row.total_invested);
      const usersCount = Number(row.users_count);
      const investmentsCount = Number(row.investments_count);

      totalInvested += invested;
      totalUsers += usersCount;
      totalInvestments += investmentsCount;

      if (level === 1) {
        result.level1 = { totalInvested: invested, usersCount, investmentsCount };
      } else if (level === 2) {
        result.level2 = { totalInvested: invested, usersCount, investmentsCount };
      } else if (level === 3) {
        result.level3 = { totalInvested: invested, usersCount, investmentsCount };
      }
    }

    result.totalInvested = totalInvested;
    result.totalUsers = totalUsers;
    result.totalInvestments = totalInvestments;

    return NextResponse.json({
      success: true,
      data: result
    });

  } catch (e) {
    console.error('Team investments error:', e);
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 });
  }
}
