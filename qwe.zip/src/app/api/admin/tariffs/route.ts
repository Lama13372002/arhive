import { NextRequest } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const res = await db.query(`SELECT * FROM tariff_plans ORDER BY id ASC`);
    return Response.json({ success: true, data: { items: res.rows } });
  } catch (e) {
    return Response.json({ success: false, error: 'DB_ERROR', details: (e as Error).message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      code,
      name_ru,
      name_en,
      min_amount,
      max_amount,
      term_days,
      daily_percent,
      tariff_type = 'perpetual',
      monthly_percent,
      total_return_percent,
      is_perpetual = true,
      auto_return_principal = false,
      is_active = true
    } = body;

    const q = `INSERT INTO tariff_plans(
      code, name_ru, name_en, min_amount, max_amount, term_days, daily_percent,
      tariff_type, monthly_percent, total_return_percent, is_perpetual, auto_return_principal, is_active
    ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`;

    const res = await db.query(q, [
      code, name_ru, name_en, min_amount, max_amount, term_days, daily_percent,
      tariff_type, monthly_percent, total_return_percent, is_perpetual, auto_return_principal, is_active
    ]);

    return Response.json({ success: true, data: res.rows[0] });
  } catch (e) {
    return Response.json({ success: false, error: 'DB_ERROR', details: (e as Error).message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, ...updates } = body;
    const fields = Object.keys(updates);
    const values = Object.values(updates);
    if (!id || fields.length === 0) return Response.json({ success: false, error: 'BAD_REQUEST' }, { status: 400 });
    const setSql = fields.map((k, i) => `${k} = $${i + 1}`).join(', ');
    const q = `UPDATE tariff_plans SET ${setSql}, updated_at = now() WHERE id = $${fields.length + 1} RETURNING *`;
    const res = await db.query(q, [...values, id]);
    return Response.json({ success: true, data: res.rows[0] });
  } catch (e) {
    return Response.json({ success: false, error: 'DB_ERROR', details: (e as Error).message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');
    if (!id) return Response.json({ success: false, error: 'BAD_REQUEST' }, { status: 400 });
    await db.query(`DELETE FROM tariff_plans WHERE id = $1`, [id]);
    return Response.json({ success: true });
  } catch (e) {
    return Response.json({ success: false, error: 'DB_ERROR', details: (e as Error).message }, { status: 500 });
  }
}
