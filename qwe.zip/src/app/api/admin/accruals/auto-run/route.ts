import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { PoolClient } from 'pg';

// Helper to notify user about daily accrual via Telegram Bot API
async function notifyDailyAccrual(
  userTelegramId: number,
  amount: number,
  tariffType: string,
  isPerpetual: boolean,
  debugInfo: string[]
) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return; // silently skip if not configured

  let text: string;

  if (isPerpetual) {
    // Для бессрочного плана - деньги зачислены на баланс
    text = `💰 Daily profit credited to your balance!\n\n` +
           `Amount: ${amount.toFixed(4)} USDT\n` +
           `Plan: ${tariffType}\n` +
           `Status: Available for withdrawal\n\n` +
           `— Your Quantum xAI`;
  } else {
    // Для срочных планов - деньги в накоплении
    text = `📈 Daily profit earned on your investment!\n\n` +
           `Amount: ${amount.toFixed(4)} USDT\n` +
           `Plan: ${tariffType}\n` +
           `Status: Accumulating (will be available at term end)\n\n` +
           `— Your Quantum xAI`;
  }

  try {
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: userTelegramId, text }),
    });
    debugInfo.push(`NOTIFICATION: Daily accrual notification sent to user ${userTelegramId}`);
  } catch (e) {
    debugInfo.push(`NOTIFICATION: Failed to notify user ${userTelegramId}: ${e}`);
  }
}

// Helper to notify user about investment completion via Telegram Bot API
async function notifyInvestmentCompletion(
  userTelegramId: number,
  totalProfit: number,
  principalAmount: number,
  tariffType: string,
  autoReturnPrincipal: boolean,
  debugInfo: string[]
) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return; // silently skip if not configured

  let text: string;

  if (autoReturnPrincipal) {
    // Автоматический возврат тела депозита
    text = `🎯 Investment completed successfully!\n\n` +
           `Final profit: ${totalProfit.toFixed(4)} USDT\n` +
           `Principal returned: ${principalAmount.toFixed(4)} USDT\n` +
           `Total credited: ${(totalProfit + principalAmount).toFixed(4)} USDT\n` +
           `Plan: ${tariffType}\n` +
           `Status: Available for withdrawal\n\n` +
           `— Your Quantum xAI`;
  } else {
    // Только прибыль зачислена, тело нужно выводить вручную
    text = `🎯 Investment term completed!\n\n` +
           `Final profit: ${totalProfit.toFixed(4)} USDT\n` +
           `Plan: ${tariffType}\n` +
           `Status: Profit available for withdrawal\n` +
           `Principal: Available for manual withdrawal request\n\n` +
           `— Your Quantum xAI`;
  }

  try {
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: userTelegramId, text }),
    });
    debugInfo.push(`NOTIFICATION: Investment completion notification sent to user ${userTelegramId}`);
  } catch (e) {
    debugInfo.push(`NOTIFICATION: Failed to notify user ${userTelegramId} about completion: ${e}`);
  }
}

function toISODate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return toISODate(d);
}

// Функция для начисления реферальных бонусов
async function processReferralBonuses(
  client: PoolClient,
  userId: number,
  investmentId: number,
  accrualId: number,
  profit: number,
  debugInfo: string[]
) {
  try {
    // Получаем настройки реферальных процентов
    const refPercRow = await client.query("SELECT value->>'L1' as l1, value->>'L2' as l2, value->>'L3' as l3 FROM app_config WHERE key = 'referral_percentages'");
    const l1 = Number(refPercRow.rows?.[0]?.l1 || 0);
    const l2 = Number(refPercRow.rows?.[0]?.l2 || 0);
    const l3 = Number(refPercRow.rows?.[0]?.l3 || 0);

    if (l1 === 0 && l2 === 0 && l3 === 0) {
      debugInfo.push(`REFERRALS: No referral percentages configured, skipping`);
      return;
    }

    // Получаем цепочку рефереров
    const upline = await client.query(
      `WITH RECURSIVE chain AS (
         SELECT id, referred_by_id, 1 AS lvl FROM users WHERE id = $1
         UNION ALL
         SELECT u.id, u.referred_by_id, c.lvl + 1 FROM users u JOIN chain c ON u.id = c.referred_by_id WHERE c.lvl < 4
       ) SELECT id, referred_by_id, lvl FROM chain`,
      [userId]
    );

    const levelMap: Array<{to_user_id:number, level:number, percent:number}> = [];
    const rows = upline.rows as Array<Record<string, unknown>>;
    const selfIdx = rows.findIndex(r => Number(r.id) === userId);

    if (selfIdx !== -1) {
      const baseLvl = Number(rows[selfIdx].lvl);
      const l1user = rows.find(r => Number(r.lvl) === baseLvl + 1);
      const l2user = rows.find(r => Number(r.lvl) === baseLvl + 2);
      const l3user = rows.find(r => Number(r.lvl) === baseLvl + 3);

      if (l1user && l1 > 0) levelMap.push({ to_user_id: Number(l1user.id), level: 1, percent: l1 });
      if (l2user && l2 > 0) levelMap.push({ to_user_id: Number(l2user.id), level: 2, percent: l2 });
      if (l3user && l3 > 0) levelMap.push({ to_user_id: Number(l3user.id), level: 3, percent: l3 });
    }

    debugInfo.push(`REFERRALS: Found ${levelMap.length} referrers for user ${userId}`);

    // Начисляем бонусы каждому рефереру
    for (const item of levelMap) {
      // Check if the user who should receive the commission has active investments
      const hasActiveInvestment = await client.query(
        'SELECT 1 FROM investments WHERE user_id = $1 AND status = $2 LIMIT 1',
        [item.to_user_id, 'active']
      );

      // Only give commission if the user has an active investment
      if (hasActiveInvestment.rows.length === 0) {
        debugInfo.push(`REFERRALS: Skipping level ${item.level} bonus for user ${item.to_user_id} (no active investment)`);
        continue; // Skip this user - no active investment
      }

      const reward = profit * item.percent;

      const rr = await client.query(
        `INSERT INTO referral_rewards(from_user_id, to_user_id, level, accrual_id, investment_id, percent, amount)
         VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
        [userId, item.to_user_id, item.level, accrualId, investmentId, item.percent, reward]
      );

      const rrId = Number(rr.rows[0].id);

      await client.query(
        `INSERT INTO ledger_entries(user_id, currency, entry_type, amount, balance_bonus_delta, related_referral_reward_id, related_accrual_id, related_investment_id)
         VALUES ($1,$2,'referral_bonus',$3,$3,$4,$5,$6)`,
        [item.to_user_id, 'USDT', reward, rrId, accrualId, investmentId]
      );

      debugInfo.push(`REFERRALS: Level ${item.level} bonus: ${reward.toFixed(4)} USDT to user ${item.to_user_id}`);
    }
  } catch (error) {
    debugInfo.push(`REFERRALS: Error processing referral bonuses: ${error}`);
  }
}

export async function POST(request: NextRequest) {
  const debugInfo: string[] = [];
  let processedCount = 0;
  let totalAccruals = 0;
  let totalAmount = 0;

  try {
    debugInfo.push('AUTO_ACCRUALS: 1. Starting automatic accruals process');

    // Получаем текущую дату
    const now = new Date();
    const todayISO = toISODate(now);
    debugInfo.push(`AUTO_ACCRUALS: 2. Processing date: ${todayISO}`);

    const result = await db.transaction(async (client: PoolClient) => {
      // Получаем все активные инвестиции
      debugInfo.push('AUTO_ACCRUALS: 3. Fetching active investments');
      const investmentsRes = await client.query(`
        SELECT
          i.id, i.user_id, i.amount, i.daily_percent, i.term_days,
          i.start_date, i.end_date, i.status, i.created_at,
          t.tariff_type, t.name_en, t.is_perpetual, t.auto_return_principal,
          u.telegram_id
        FROM investments i
        JOIN tariff_plans t ON t.id = i.tariff_id
        JOIN users u ON u.id = i.user_id
        WHERE i.status IN ('active', 'withdrawal_requested')
        ORDER BY i.id
      `);

      debugInfo.push(`AUTO_ACCRUALS: 4. Found ${investmentsRes.rows.length} active investments`);

      for (const investment of investmentsRes.rows) {
        const invId = Number(investment.id);
        const userId = Number(investment.user_id);
        const amount = Number(investment.amount);
        const dailyPercent = Number(investment.daily_percent);
        const startDate = String(investment.start_date);
        const endDate = String(investment.end_date);
        const createdAt = String(investment.created_at);
        const tariffType = String(investment.name_en || investment.tariff_type);
        const isPerpetual = Boolean(investment.is_perpetual);
        const autoReturnPrincipal = Boolean(investment.auto_return_principal);
        const telegramId = Number(investment.telegram_id);

        debugInfo.push(`AUTO_ACCRUALS: 5.${invId}. Processing investment ${invId}, amount: ${amount}, daily: ${dailyPercent}`);

        try {
          // Проверяем, не закончилась ли инвестиция
          const endTime = new Date(endDate);
          if (!isPerpetual && now > endTime) {
            debugInfo.push(`AUTO_ACCRUALS: 5.${invId}. Investment ended, processing final return`);

            // Зачисляем все накопленные проценты для срочных планов
            const totalAccrualsResult = await client.query(`
              SELECT SUM(profit_amount) as total_profit
              FROM accruals
              WHERE investment_id = $1
            `, [invId]);

            const totalProfit = Number(totalAccrualsResult.rows[0]?.total_profit || 0);

            if (totalProfit > 0) {
              await client.query(`
                INSERT INTO ledger_entries(
                  user_id, currency, entry_type, amount,
                  balance_available_delta, related_investment_id
                )
                VALUES ($1, 'USDT', 'final_profit', $2, $2, $3)
              `, [userId, totalProfit, invId]);

              debugInfo.push(`AUTO_ACCRUALS: 5.${invId}. Credited final profit: ${totalProfit} USDT`);
            }

            // Если тариф с автоматическим возвратом тела, возвращаем его
            if (autoReturnPrincipal) {
              await client.query(`
                UPDATE investments
                SET status = 'completed', principal_returned = true, updated_at = NOW()
                WHERE id = $1
              `, [invId]);

              await client.query(`
                INSERT INTO ledger_entries(
                  user_id, currency, entry_type, amount,
                  balance_available_delta, balance_locked_delta,
                  related_investment_id
                )
                VALUES ($1, 'USDT', 'principal_return', $2, $2, $3, $4)
              `, [userId, amount, -amount, invId]);

              debugInfo.push(`AUTO_ACCRUALS: 5.${invId}. Principal returned automatically`);

              // Отправляем уведомление о завершении инвестиции
              // Fire-and-forget notification after commit (вне транзакции)
              setImmediate(() => {
                notifyInvestmentCompletion(telegramId, totalProfit, amount, tariffType, autoReturnPrincipal, debugInfo).catch(() => {});
              });
            } else if (totalProfit > 0) {
              // Если нет автоматического возврата, но есть прибыль - уведомляем только о прибыли
              setImmediate(() => {
                notifyInvestmentCompletion(telegramId, totalProfit, amount, tariffType, false, debugInfo).catch(() => {});
              });
            }
            continue;
          }

          // Для бессрочных тарифов или если инвестиция еще активна
          const createdTime = new Date(createdAt);

          // Вычисляем, сколько полных 24-часовых периодов прошло с создания
          const hoursSinceCreation = (now.getTime() - createdTime.getTime()) / (1000 * 60 * 60);
          const fullPeriodsAvailable = Math.floor(hoursSinceCreation / 24);

          // Для фиксированных тарифов учитываем срок окончания
          let maxPeriods = fullPeriodsAvailable;
          if (!isPerpetual) {
            const maxHoursSinceCreation = (Math.min(now.getTime(), endTime.getTime()) - createdTime.getTime()) / (1000 * 60 * 60);
            maxPeriods = Math.floor(maxHoursSinceCreation / 24);
          }

          // Проверяем, сколько периодов уже начислено
          const accruedRes = await client.query(`
            SELECT COUNT(*) as count FROM accruals WHERE investment_id = $1
          `, [invId]);

          const alreadyAccrued = Number(accruedRes.rows[0].count);
          const periodsToAccrue = Math.max(0, Math.min(maxPeriods, fullPeriodsAvailable) - alreadyAccrued);

          debugInfo.push(`AUTO_ACCRUALS: 5.${invId}. Periods analysis: available=${fullPeriodsAvailable}, max=${maxPeriods}, accrued=${alreadyAccrued}, to_accrue=${periodsToAccrue}`);

          if (periodsToAccrue > 0) {
            for (let p = 0; p < periodsToAccrue; p++) {
              const periodNumber = alreadyAccrued + p + 1;
              const accrualTime = new Date(createdTime.getTime() + (periodNumber * 24 * 60 * 60 * 1000));
              const accrualDate = toISODate(accrualTime);
              const profit = amount * dailyPercent;

              // Создаем начисление
              const accrualRes = await client.query(`
                INSERT INTO accruals(
                  investment_id, user_id, accrual_date, base_amount,
                  percent, profit_amount, created_at
                )
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                ON CONFLICT (investment_id, accrual_date) DO NOTHING
                RETURNING id
              `, [invId, userId, accrualDate, amount, dailyPercent, profit, accrualTime.toISOString()]);

              if (accrualRes.rows.length > 0) {
                const accrualId = Number(accrualRes.rows[0].id);

                // Зачисляем прибыль на баланс ТОЛЬКО для бессрочных планов
                if (isPerpetual) {
                  await client.query(`
                    INSERT INTO ledger_entries(
                      user_id, currency, entry_type, amount,
                      balance_available_delta, related_investment_id
                    )
                    VALUES ($1, 'USDT', 'daily_profit', $2, $2, $3)
                  `, [userId, profit, invId]);
                  debugInfo.push(`AUTO_ACCRUALS: 5.${invId}.${p}. Accrued and credited ${profit} USDT (perpetual plan)`);
                } else {
                  debugInfo.push(`AUTO_ACCRUALS: 5.${invId}.${p}. Accrued ${profit} USDT (will be credited at term end)`);
                }

                // Начисляем реферальные бонусы
                await processReferralBonuses(client, userId, invId, accrualId, profit, debugInfo);

                // Отправляем уведомление пользователю о ежедневном зачислении
                // Fire-and-forget notification after commit (вне транзакции)
                setImmediate(() => {
                  notifyDailyAccrual(telegramId, profit, tariffType, isPerpetual, debugInfo).catch(() => {});
                });

                totalAccruals++;
                totalAmount += profit;
              }
            }
            processedCount++;
          }
        } catch (invError) {
          debugInfo.push(`AUTO_ACCRUALS: 5.${invId}. ERROR: ${invError}`);
          // Продолжаем обработку других инвестиций
        }
      }

      return {
        processed_investments: processedCount,
        total_accruals: totalAccruals,
        total_amount: totalAmount,
        debug: debugInfo
      };
    });

    debugInfo.push(`AUTO_ACCRUALS: 6. Process completed successfully`);
    debugInfo.push(`AUTO_ACCRUALS: 7. Summary: ${processedCount} investments processed, ${totalAccruals} accruals created, ${totalAmount.toFixed(4)} USDT total`);

    return NextResponse.json({
      success: true,
      data: result,
      message: `Auto accruals completed: ${totalAccruals} accruals created for ${processedCount} investments, total: ${totalAmount.toFixed(4)} USDT`
    });
  } catch (e) {
    debugInfo.push(`AUTO_ACCRUALS: ERROR: ${e instanceof Error ? e.message : String(e)}`);
    console.error('Auto accruals error:', e);

    return NextResponse.json({
      success: false,
      error: 'Auto accruals failed',
      debug: debugInfo,
      errorDetails: e instanceof Error ? e.message : String(e)
    }, { status: 500 });
  }
}

// GET endpoint для проверки статуса автоматических начислений
export async function GET(request: NextRequest) {
  try {
    // Статистика за последние 7 дней
    const statsRes = await db.query(`
      SELECT
        DATE(created_at) as accrual_date,
        COUNT(*) as accruals_count,
        SUM(profit_amount) as total_profit
      FROM accruals
      WHERE created_at >= NOW() - INTERVAL '7 days'
      GROUP BY DATE(created_at)
      ORDER BY accrual_date DESC
    `);

    // Активные инвестиции
    const activeRes = await db.query(`
      SELECT COUNT(*) as count FROM investments
      WHERE status IN ('active', 'withdrawal_requested')
    `);

    return NextResponse.json({
      success: true,
      data: {
        daily_stats: statsRes.rows,
        active_investments: Number(activeRes.rows[0]?.count || 0),
        last_check: new Date().toISOString()
      }
    });
  } catch (e) {
    console.error('Auto accruals status check error:', e);
    return NextResponse.json({
      success: false,
      error: 'Failed to get accruals status',
      details: (e as Error).message
    }, { status: 500 });
  }
}
