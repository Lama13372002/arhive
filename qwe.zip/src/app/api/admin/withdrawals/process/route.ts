import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { nowPayments } from '@/lib/nowpayments';
import { WithdrawalDBResult } from '@/types';

export async function POST(request: NextRequest) {
  let withdrawal_id: number | undefined;
  let action: string | undefined;
  let admin_id: number | undefined;

  try {
    const requestData = await request.json();
    withdrawal_id = requestData.withdrawal_id;
    action = requestData.action;
    admin_id = requestData.admin_id;

    // Валидация
    if (!withdrawal_id || !action || !admin_id) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    if (!['approve', 'reject'].includes(action)) {
      return NextResponse.json(
        { success: false, error: 'Invalid action' },
        { status: 400 }
      );
    }

    // Получаем данные о выводе
    const withdrawalResult = await db.query(
      `SELECT w.*, u.telegram_id
       FROM withdrawals w
       JOIN users u ON w.user_id = u.id
       WHERE w.id = $1 AND w.status = 'pending'`,
      [withdrawal_id]
    );

    if (withdrawalResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Withdrawal not found or already processed' },
        { status: 404 }
      );
    }

    const withdrawal = withdrawalResult.rows[0] as unknown as WithdrawalDBResult;

    // Маппинг валют для выплат в зависимости от сети
    // Проверенные валюты NOWPayments для выплат
    const currencyMap: Record<string, string> = {
      'TRON': 'usdttrc20',
      'BSC': 'usdtbep20',
      'ETH': 'usdt',
      'POLYGON': 'usdtpoly',
      'TON': 'usdtton'
    };

    if (action === 'reject') {
      // Отклоняем вывод и возвращаем средства
      await db.transaction(async (client) => {
        // Обновляем статус вывода
        await client.query(
          'UPDATE withdrawals SET status = $1, processed_at = NOW(), updated_at = NOW() WHERE id = $2',
          ['rejected', withdrawal_id]
        );

        // Возвращаем средства на баланс (сумма + комиссия) через ledger; баланс обновит триггер
        const totalAmount = parseFloat(String(withdrawal.amount)) + parseFloat(String(withdrawal.fee || 0));
        // Удаляем прямое обновление users_balance
        // Записываем в ledger возврат средств
        await client.query(
          `INSERT INTO ledger_entries
           (user_id, currency, entry_type, amount, balance_available_delta, balance_locked_delta, related_withdrawal_id, created_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
          [withdrawal.user_id, 'USDT', 'withdrawal_out', totalAmount, totalAmount, -totalAmount, withdrawal_id]
        );

        // Логируем действие админа
        await client.query(
          `INSERT INTO audit_log
           (actor_admin_id, action, target_type, target_id, metadata, created_at)
           VALUES ($1, $2, $3, $4, $5, NOW())`,
          [admin_id, 'withdrawal_rejected', 'withdrawal', withdrawal_id, JSON.stringify({ amount: withdrawal.amount, address: withdrawal.address })]
        );
      });

      return NextResponse.json({
        success: true,
        data: { status: 'rejected', message: 'Withdrawal rejected and funds returned to user' }
      });
    }

    // Подготавливаем переменные для использования в try/catch блоках
    const payoutCurrency = currencyMap[withdrawal.network_code || 'TRON'] || 'usdttrc20';

    // Рассчитываем NET (amount - fee) и форматируем для отправки
    const netAmount = Math.round((Number(withdrawal.amount) - Number(withdrawal.fee || 0)) * 100) / 100;
    const formattedAmount = Number(netAmount).toFixed(8).replace(/\.?0+$/, '');

    // Подготавливаем параметры для запроса
    const payoutParams = {
      address: String(withdrawal.address),
      currency: payoutCurrency,
      amount: formattedAmount,
      ipn_callback_url: process.env.NOWPAYMENTS_PAYOUT_WEBHOOK_URL,
      unique_external_id: String(withdrawal.provider_order_id || withdrawal.id),
      payout_description: `withdrawal_${withdrawal.id}`
    };

    // Одобряем вывод и инициируем выплату через NOWPayments
    try {
      await db.query(
        'UPDATE withdrawals SET status = $1, updated_at = NOW() WHERE id = $2',
        ['approved', withdrawal_id]
      );

      // Логируем точный запрос для отладки
      console.log('=== NOWPayments Payout Request ===');
      console.log('Params:', JSON.stringify(payoutParams, null, 2));
      console.log('Original amount:', withdrawal.amount);
      console.log('Net amount (amount - fee):', netAmount);
      console.log('Formatted amount:', formattedAmount);
      console.log('Currency mapping:', withdrawal.network_code, '->', payoutCurrency);
      console.log('================================');

      // Вызываем API payouts
      const payout = await nowPayments.createPayout(payoutParams);

      // Детальное логирование ответа API
      console.log('=== NOWPayments API Response ===');
      console.log('Response type:', typeof payout);
      console.log('Is array:', Array.isArray(payout));
      console.log('Response:', JSON.stringify(payout, null, 2));
      console.log('===============================');

      // Извлекаем ID из NOWPayments response
      const payoutId = payout?.withdrawals?.[0]?.id || null;
      const batchWithdrawalId = payout?.id || null;

      console.log('✅ Extracted IDs:');
      console.log('  payoutId:', payoutId);
      console.log('  batchWithdrawalId:', batchWithdrawalId);

      console.log('Final payoutId:', payoutId);

      // Автоматическое подтверждение через 2FA, если настроено
      if (batchWithdrawalId) {
        const twoFACode = nowPayments.generate2FACode();
        if (twoFACode) {
          try {
            await nowPayments.verifyPayout(batchWithdrawalId, twoFACode);
            console.log(`Payout ${batchWithdrawalId} automatically verified with 2FA`);
          } catch (verifyError) {
            console.warn(`Failed to auto-verify payout ${batchWithdrawalId}:`, verifyError);
            // Продолжаем выполнение, не прерывая процесс
          }
        }
      }

      // КРИТИЧЕСКАЯ ПРОВЕРКА: Если payoutId пустой, не продолжаем
      if (!payoutId) {
        console.error('❌ КРИТИЧЕСКАЯ ОШИБКА: payoutId не получен от NOWPayments API!');
        console.error('Response was:', JSON.stringify(payout, null, 2));
        throw new Error('NOWPayments API не вернул payout ID. Проверьте API ключи и параметры запроса.');
      }

      // Обновляем данные вывода
      await db.query(
        `UPDATE withdrawals SET
         status = $1,
         provider_uuid = $2,
         payer_currency = $3,
         payer_amount = $4,
         is_subtract = $5,
         processed_at = NOW(),
         updated_at = NOW()
         WHERE id = $6`,
        [
          'processing',
          payoutId,
          payoutCurrency,
          netAmount,
          true,
          withdrawal_id
        ]
      );

      console.log(`✅ Withdrawal ${withdrawal_id} обновлен с provider_uuid: ${payoutId}`);

      // Логируем вызов API
      await db.query(
        `INSERT INTO provider_call_logs
         (provider, endpoint, http_method, request_body, response_body, status_code, related_withdrawal_id, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
        [
          'nowpayments',
          '/payout',
          'POST',
          JSON.stringify({ ...payoutParams, net_amount: netAmount }),
          JSON.stringify(payout),
          200,
          withdrawal_id
        ]
      );

      // Логируем действие админа
      await db.query(
        `INSERT INTO audit_log
         (actor_admin_id, action, target_type, target_id, metadata, created_at)
         VALUES ($1, $2, $3, $4, $5, NOW())`,
        [admin_id, 'withdrawal_approved', 'withdrawal', withdrawal_id, JSON.stringify({ amount: withdrawal.amount, address: withdrawal.address, net_amount: netAmount })]
      );

      return NextResponse.json({
        success: true,
        data: {
          status: 'processing',
          message: 'Withdrawal approved and sent to NOWPayments.',
          sent_amount: netAmount,
          currency: payoutCurrency
        }
      });

    } catch (err: unknown) {
      console.error('=== NOWPayments Payout Error ===');
      console.error('Withdrawal ID:', withdrawal_id);
      console.error('User ID:', withdrawal.user_id);
      console.error('Amount:', withdrawal.amount);
      console.error('Net Amount:', netAmount);
      console.error('Address:', withdrawal.address);
      console.error('Network:', withdrawal.network_code);
      console.error('Error details:', err);
      console.error('===========================');

      // Извлекаем детальную информацию об ошибке
      let errorMessage = 'Failed to process withdrawal';
      let errorDetails = '';

      if (err instanceof Error) {
        errorMessage = err.message;
        errorDetails = `NOWPayments Payout Error: ${err.message}`;

        // Если это HTTP ошибка, добавляем больше деталей
        if (err.message.includes('NOWPayments payout error')) {
          const statusMatch = err.message.match(/NOWPayments payout error (\d+)/);
          if (statusMatch) {
            const statusCode = statusMatch[1];
            switch (statusCode) {
              case '400':
                errorDetails += '\n\n=== HTTP 400 - Bad Request ===\n' +
                  'ПРИЧИНА: Неверные параметры запроса\n\n' +
                  'ВОЗМОЖНЫЕ ПРОБЛЕМЫ:\n' +
                  '• Неверная валюта (проверьте currency: "' + currencyMap[withdrawal.network_code || 'TRON'] + '")\n' +
                  '• Некорректная сумма (минимум/максимум)\n' +
                  '• Неправильный формат адреса кошелька\n' +
                  '• Отсутствуют обязательные поля в запросе\n\n' +
                  'ЧТО ДЕЛАТЬ:\n' +
                  '1. Проверить правильность адреса кошелька\n' +
                  '2. Убедиться что сумма соответствует лимитам\n' +
                  '3. Проверить поддерживаемые валюты в NOWPayments\n' +
                  '4. Проверить формат запроса API';
                break;
              case '401':
                errorDetails += '\n\n=== HTTP 401 - Unauthorized ===\n' +
                  'ПРИЧИНА: Ошибка авторизации\n\n' +
                  'ВОЗМОЖНЫЕ ПРОБЛЕМЫ:\n' +
                  '• Неверный API ключ (NOWPAYMENTS_API_KEY)\n' +
                  '• Истек JWT токен для payouts\n' +
                  '• Неверные логин/пароль для получения JWT\n' +
                  '• API ключ деактивирован в NOWPayments\n\n' +
                  'ЧТО ДЕЛАТЬ:\n' +
                  '1. Проверить NOWPAYMENTS_API_KEY в .env файле\n' +
                  '2. Проверить NOWPAYMENTS_EMAIL и NOWPAYMENTS_PASSWORD\n' +
                  '3. Убедиться что аккаунт активен в NOWPayments\n' +
                  '4. Пересоздать API ключ в панели NOWPayments\n' +
                  '5. Проверить срок действия API ключа';
                break;
              case '403':
                errorDetails += '\n\n=== HTTP 403 - Forbidden ===\n' +
                  'ПРИЧИНА: Доступ запрещен\n\n' +
                  'НАИБОЛЕЕ ВЕРОЯТНЫЕ ПРОБЛЕМЫ:\n' +
                  '• IP адрес сервера НЕ добавлен в whitelist NOWPayments\n' +
                  '• Недостаточно средств на балансе NOWPayments аккаунта\n' +
                  '• Функция Payouts не активирована/верифицирована\n' +
                  '• Аккаунт заблокирован или ограничен\n\n' +
                  'ПОШАГОВОЕ РЕШЕНИЕ:\n' +
                  '1. ПРОВЕРИТЬ БАЛАНС:\n' +
                  '   - Войти в панель NOWPayments\n' +
                  '   - Проверить баланс в разделе "Payouts"\n' +
                  '   - Пополнить при необходимости\n\n' +
                  '2. ПРОВЕРИТЬ IP WHITELIST:\n' +
                  '   - Панель NOWPayments → Settings → API\n' +
                  '   - Добавить IP сервера в whitelist\n' +
                  '   - Для локальной разработки добавить внешний IP\n\n' +
                  '3. ПРОВЕРИТЬ СТАТУС PAYOUTS:\n' +
                  '   - Убедиться что Payouts включены в аккаунте\n' +
                  '   - Пройти верификацию если требуется\n' +
                  '   - Проверить лимиты на выплаты\n\n' +
                  '4. ПРОВЕРИТЬ СЕТЬ И ВАЛЮТУ:\n' +
                  '   - TON (usdtton) поддерживается?\n' +
                  '   - Проверить список поддерживаемых валют\n\n' +
                  'ТЕКУЩИЕ ДАННЫЕ:\n' +
                  '• Сеть: ' + withdrawal.network_code + '\n' +
                  '• Валюта: ' + currencyMap[withdrawal.network_code || 'TRON'] + '\n' +
                  '• Сумма: ' + withdrawal.amount + ' USDT\n' +
                  '• Адрес: ' + withdrawal.address;
                break;
              case '422':
                errorDetails += '\n\n=== HTTP 422 - Unprocessable Entity ===\n' +
                  'ПРИЧИНА: Ошибка валидации данных\n\n' +
                  'ВОЗМОЖНЫЕ ПРОБЛЕМЫ:\n' +
                  '• Неверный формат адреса кошелька для ' + withdrawal.network_code + ' сети\n' +
                  '• Валюта ' + currencyMap[withdrawal.network_code || 'TRON'] + ' не поддерживается\n' +
                  '• Сумма меньше минимальной или больше максимальной\n' +
                  '• Адрес не прошел валидацию формата\n\n' +
                  'ПРОВЕРИТЬ:\n' +
                  '1. Адрес ' + withdrawal.network_code + ': ' + withdrawal.address + '\n' +
                  '2. Валюта: ' + currencyMap[withdrawal.network_code || 'TRON'] + '\n' +
                  '3. Сумма: ' + withdrawal.amount + ' USDT\n' +
                  '4. Формат адреса для выбранной сети\n\n' +
                  'ЧТО ДЕЛАТЬ:\n' +
                  '1. Проверить правильность адреса кошелька\n' +
                  '2. Убедиться что сеть поддерживается\n' +
                  '3. Проверить минимальные лимиты для сети\n' +
                  '4. Попробовать другую сеть (TRON/BSC/ETH)';
                break;
              case '429':
                errorDetails += '\n\n=== HTTP 429 - Rate Limit Exceeded ===\n' +
                  'ПРИЧИНА: Превышен лимит запросов\n\n' +
                  'РЕШЕНИЕ:\n' +
                  '• Подождать 1-5 минут перед повторной попыткой\n' +
                  '• Снизить частоту запросов к API\n' +
                  '• Проверить лимиты API в документации NOWPayments\n' +
                  '• Возможно нужно обновить план аккаунта';
                break;
              case '500':
                errorDetails += '\n\n=== HTTP 500 - Internal Server Error ===\n' +
                  'ПРИЧИНА: Внутренняя ошибка сервера NOWPayments\n\n' +
                  'РЕШЕНИЕ:\n' +
                  '• Повторить попытку через 5-10 минут\n' +
                  '• Проверить статус сервисов NOWPayments\n' +
                  '• Обратиться в поддержку NOWPayments если проблема продолжается\n' +
                  '• Временно использовать другой метод выплат';
                break;
              case '503':
                errorDetails += '\n\n=== HTTP 503 - Service Unavailable ===\n' +
                  'ПРИЧИНА: Сервис NOWPayments временно недоступен\n\n' +
                  'РЕШЕНИЕ:\n' +
                  '• Повторить попытку через 10-30 минут\n' +
                  '• Проверить статус на status.nowpayments.io\n' +
                  '• Уведомить пользователя о временной недоступности\n' +
                  '• Попробовать позже или использовать резервный метод';
                break;
              default:
                errorDetails += `\n\n=== HTTP ${statusCode} - Неизвестная ошибка ===\n` +
                  'ПРИЧИНА: Неизвестный статус код\n\n' +
                  'РЕШЕНИЕ:\n' +
                  '• Проверить документацию NOWPayments API\n' +
                  '• Обратиться в поддержку с деталями ошибки\n' +
                  '• Попробовать альтернативный способ выплаты\n' +
                  '• Проверить changelog API NOWPayments';
            }
          }
        }
      }

      // Логируем детальную ошибку
      try {
        await db.query(
          `INSERT INTO provider_call_logs
           (provider, endpoint, http_method, request_body, response_body, status_code, related_withdrawal_id, created_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
          [
            'nowpayments',
            '/payout',
            'POST',
            JSON.stringify({
              ...payoutParams,
              original_amount: withdrawal.amount,
              net_amount: netAmount,
              formatted_amount: formattedAmount
            }),
            JSON.stringify({ error: errorDetails }),
            0,
            withdrawal_id
          ]
        );
      } catch (logError) {
        console.error('Failed to log payout error:', logError);
      }

      // Откатываем статус и возвращаем средства
      await db.transaction(async (client) => {
        await client.query(
          'UPDATE withdrawals SET status = $1, updated_at = NOW() WHERE id = $2',
          ['failed', withdrawal_id]
        );

        // При ошибке возвращаем полную сумму (amount + fee) через ledger; баланс обновит триггер
        const totalAmount = parseFloat(String(withdrawal.amount)) + parseFloat(String(withdrawal.fee || 0));
        // Удаляем прямое обновление users_balance
        await client.query(
          `INSERT INTO ledger_entries
           (user_id, currency, entry_type, amount, balance_available_delta, balance_locked_delta, related_withdrawal_id, created_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
          [withdrawal.user_id, 'USDT', 'withdrawal_out', totalAmount, totalAmount, -totalAmount, withdrawal_id]
        );
      });

      return NextResponse.json(
        {
          success: false,
          error: errorMessage,
          details: errorDetails,
          debugInfo: {
            withdrawal: {
              id: withdrawal_id,
              user_id: withdrawal.user_id,
              network: withdrawal.network_code,
              currency: currencyMap[withdrawal.network_code || 'TRON'] || 'usdttrc20',
              amount: withdrawal.amount,
              address: withdrawal.address,
              original_order_id: withdrawal.provider_order_id
            },
            environment: {
              api_key_configured: !!process.env.NOWPAYMENTS_API_KEY,
              email_configured: !!process.env.NOWPAYMENTS_EMAIL,
              password_configured: !!process.env.NOWPAYMENTS_PASSWORD,
              webhook_url: process.env.NOWPAYMENTS_PAYOUT_WEBHOOK_URL || 'не настроен',
              two_fa_configured: !!process.env.NOWPAYMENTS_2FA_SECRET
            },
            timestamp: new Date().toISOString(),
            recommended_actions: [
              'Проверить баланс NOWPayments аккаунта',
              'Добавить IP сервера в whitelist',
              'Убедиться что Payouts активированы',
              'Проверить поддержку валюты ' + currencyMap[withdrawal.network_code || 'TRON']
            ]
          }
        },
        { status: 500 }
      );
    }

  } catch (error: unknown) {
    console.error('=== Withdrawal Processing System Error ===');
    console.error('Request data:', { withdrawal_id, action, admin_id });
    console.error('Error details:', error);
    if (error instanceof Error && error.stack) {
      console.error('Stack trace:', error.stack);
    }
    console.error('========================================');

    let errorMessage = 'Internal server error';
    let errorDetails = '';

    if (error instanceof Error) {
      errorMessage = error.message;

      // Определяем тип системной ошибки
      if (error.message.includes('database') || error.message.includes('connection')) {
        errorDetails = '\n\n=== ОШИБКА БАЗЫ ДАННЫХ ===\n' +
          'ПРИЧИНА: Проблема с подключением к базе данных\n\n' +
          'ВОЗМОЖНЫЕ ПРИЧИНЫ:\n' +
          '• База данных недоступна\n' +
          '• Превышен таймаут подключения\n' +
          '• Неверная строка подключения\n' +
          '• Недостаточно прав доступа\n\n' +
          'РЕШЕНИЕ:\n' +
          '1. Проверить статус базы данных\n' +
          '2. Проверить переменные окружения DB_*\n' +
          '3. Перезапустить сервер приложения\n' +
          '4. Проверить логи базы данных\n\n' +
          'Техническая ошибка: ' + error.message;
      } else if (error.message.includes('fetch') || error.message.includes('network')) {
        errorDetails = '\n\n=== ОШИБКА СЕТИ ===\n' +
          'ПРИЧИНА: Проблема с сетевым подключением\n\n' +
          'ВОЗМОЖНЫЕ ПРИЧИНЫ:\n' +
          '• Отсутствует интернет соединение\n' +
          '• NOWPayments API недоступен\n' +
          '• Блокировка файрволом\n' +
          '• DNS проблемы\n\n' +
          'РЕШЕНИЕ:\n' +
          '1. Проверить интернет соединение сервера\n' +
          '2. Пропинговать api.nowpayments.io\n' +
          '3. Проверить настройки файрвола\n' +
          '4. Повторить через несколько минут\n\n' +
          'Техническая ошибка: ' + error.message;
      } else {
        errorDetails = '\n\n=== СИСТЕМНАЯ ОШИБКА ===\n' +
          'ПРИЧИНА: Неожиданная ошибка в коде приложения\n\n' +
          'ИНФОРМАЦИЯ ДЛЯ РАЗРАБОТЧИКА:\n' +
          'Ошибка: ' + error.message + '\n\n';

        // Добавляем стек трейс в детали для отладки
        if (error.stack) {
          errorDetails += 'Стек вызовов:\n' + error.stack.split('\n').slice(0, 5).join('\n') + '\n\n';
        }

        errorDetails += 'РЕКОМЕНДАЦИИ:\n' +
          '1. Проверить логи сервера\n' +
          '2. Обратиться к разработчику\n' +
          '3. Временно использовать другой метод выплат\n' +
          '4. Перезапустить сервер приложения';
      }
    }

    return NextResponse.json(
      {
        success: false,
        error: errorMessage,
        details: errorDetails,
        debugInfo: {
          system_error: {
            message: error instanceof Error ? error.message : 'Unknown error',
            type: error instanceof Error ? error.constructor.name : 'Unknown',
            stack_preview: error instanceof Error && error.stack ?
              error.stack.split('\n').slice(0, 3) : 'No stack trace'
          },
          request_info: {
            withdrawal_id,
            action,
            admin_id,
            timestamp: new Date().toISOString()
          },
          environment_check: {
            node_version: process.version,
            env_variables: {
              nowpayments_api_key: !!process.env.NOWPAYMENTS_API_KEY,
              nowpayments_email: !!process.env.NOWPAYMENTS_EMAIL,
              nowpayments_password: !!process.env.NOWPAYMENTS_PASSWORD,
              database_url: !!process.env.DATABASE_URL
            }
          },
          recommended_actions: [
            'Проверить логи сервера',
            'Убедиться что все env переменные настроены',
            'Проверить подключение к базе данных',
            'Проверить подключение к NOWPayments API'
          ]
        }
      },
      { status: 500 }
    );
  }
}
