"use client";
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { ConfigData } from '@/types';

export default function ConfigForm() {
  const [data, setData] = useState<ConfigData>({});
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const res = await fetch('/api/admin/config');
    const json = await res.json();
    setData(json.data || {});
    setLoading(false);
  };
  useEffect(()=>{ load(); },[]);

  const save = async () => {
    await fetch('/api/admin/config', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
    await load();
  };

  return (
    <div className="space-y-4">
      {loading ? <div className="text-sm text-neutral-500">Loading...</div> : (
        <Card>
          <CardContent className="p-4 space-y-3">
            <div>
              <div className="text-xs text-neutral-500 mb-1">Referral Percentages (JSON)</div>
              <Input value={JSON.stringify(data.referral_percentages||{})}
                     onChange={e=>setData({ ...data, referral_percentages: JSON.parse(e.target.value || '{}') })} />
            </div>
            <div>
              <div className="text-xs text-neutral-500 mb-1">Cron Times (JSON)</div>
              <Input value={JSON.stringify(data.cron_times||{})}
                     onChange={e=>setData({ ...data, cron_times: JSON.parse(e.target.value || '{}') })} />
            </div>
            <div>
              <div className="text-xs text-neutral-500 mb-1">Payout Status Mapping (JSON)</div>
              <Input value={JSON.stringify(data.payout_status_mapping||{})}
                     onChange={e=>setData({ ...data, payout_status_mapping: JSON.parse(e.target.value || '{}') })} />
            </div>
            <div>
              <div className="text-xs text-neutral-500 mb-1">Payment Status Mapping (JSON)</div>
              <Input value={JSON.stringify(data.payment_status_mapping||{})}
                     onChange={e=>setData({ ...data, payment_status_mapping: JSON.parse(e.target.value || '{}') })} />
            </div>
            <Button onClick={save}>Save</Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
