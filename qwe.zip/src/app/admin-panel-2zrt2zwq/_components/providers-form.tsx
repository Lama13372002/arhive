"use client";
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { ProviderSetting, ProviderService } from '@/types';

export default function ProvidersForm() {
  const [settings, setSettings] = useState<ProviderSetting[]>([]);
  const [services, setServices] = useState<ProviderService[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const [s1, s2] = await Promise.all([
      fetch('/api/admin/provider/settings').then(r=>r.json()),
      fetch('/api/admin/provider/services').then(r=>r.json()),
    ]);
    setSettings(s1.data?.items || []);
    setServices(s2.data?.items || []);
    setLoading(false);
  };
  useEffect(()=>{ load(); },[]);

  const updateSetting = async (provider: string, key: string, value: unknown) => {
    await fetch('/api/admin/provider/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ provider, key, value }) });
    await load();
  };

  const updateService = async (id: number, patch: Partial<ProviderService>) => {
    await fetch('/api/admin/provider/services', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, ...patch }) });
    await load();
  };

  // Фильтруем только nowpayments (убираем cryptomus)
  const filteredSettings = settings.filter(s => s.provider === 'nowpayments');

  return (
    <div className="space-y-6">
      {loading ? <div className="text-sm text-neutral-500">Loading...</div> : (
        <>
          {filteredSettings.length > 0 && (
            <Card>
              <CardContent className="p-4 space-y-2">
                <div className="font-medium">Provider Settings (nowpayments)</div>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-2 items-center border-b pb-2 mb-2 font-semibold text-sm">
                  <div>Provider</div>
                  <div>Key</div>
                  <div>Value</div>
                  <div>Updated</div>
                  <div>Action</div>
                </div>
                {filteredSettings.map(s => (
                  <div key={`${s.provider}-${s.key}`} className="grid grid-cols-1 md:grid-cols-5 gap-2 items-center border p-3 rounded-md">
                    <div className="text-sm">{s.provider}</div>
                    <div className="text-sm">{s.key}</div>
                    <Input defaultValue={JSON.stringify(s.value)} onBlur={(e)=>updateSetting(s.provider, s.key, JSON.parse(e.target.value||'{}'))} />
                    <div className="text-xs text-neutral-500">updated: {new Date(s.updated_at).toLocaleString()}</div>
                    <Button variant="outline" onClick={()=>updateSetting(s.provider, s.key, s.value)}>Save</Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          <Card>
            <CardContent className="p-4 space-y-2">
              <div className="font-medium">Настройки сетей (Provider Services)</div>

              {/* Заголовки для таблицы */}
              <div className="grid grid-cols-2 md:grid-cols-9 gap-2 items-center border-b border-gray-600 pb-2 mb-2 font-semibold text-sm bg-gray-800 text-white p-2 rounded">
                <div>Провайдер</div>
                <div>Тип</div>
                <div>Валюта</div>
                <div>Сеть</div>
                <div>Мин. сумма</div>
                <div>Макс. сумма</div>
                <div>Фикс. комиссия</div>
                <div>% комиссия</div>
                <div>Действие</div>
              </div>

              {/* Разделяем на пополнения и выводы */}
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-green-600 mb-2">💰 Пополнения (Payment)</h3>
                  {services.filter(s => s.service_type === 'payment').map(s => (
                    <div key={s.id} className="grid grid-cols-2 md:grid-cols-9 gap-2 items-center border border-green-600 p-3 rounded-md mb-2 bg-green-900/20 text-white">
                      <div className="font-medium">{s.provider}</div>
                      <div className="text-green-600">💳 {s.service_type}</div>
                      <div>{s.currency}</div>
                      <div className="font-bold">{s.network_code}</div>
                      <Input
                        type="number"
                        defaultValue={s.min_amount||0}
                        onBlur={(e)=>updateService(s.id, { min_amount: Number(e.target.value) })}
                        placeholder="Минимум"
                        className="h-8 bg-gray-800 border-gray-600 text-white"
                      />
                      <Input
                        type="number"
                        defaultValue={s.max_amount||0}
                        onBlur={(e)=>updateService(s.id, { max_amount: Number(e.target.value) })}
                        placeholder="Максимум"
                        className="h-8 bg-gray-800 border-gray-600 text-white"
                      />
                      <Input
                        type="number"
                        step="0.01"
                        defaultValue={s.fee_fixed||0}
                        onBlur={(e)=>updateService(s.id, { fee_fixed: Number(e.target.value) })}
                        placeholder="Фикс. $"
                        className="h-8 bg-gray-800 border-gray-600 text-white"
                      />
                      <Input
                        type="number"
                        step="0.001"
                        defaultValue={s.fee_percent||0}
                        onBlur={(e)=>updateService(s.id, { fee_percent: Number(e.target.value) })}
                        placeholder="% (0.02 = 2%)"
                        className="h-8 bg-gray-800 border-gray-600 text-white"
                      />
                      <Button
                        variant={s.is_available ? "default" : "outline"}
                        size="sm"
                        onClick={()=>updateService(s.id, { is_available: !s.is_available })}
                        className="h-8"
                      >
                        {s.is_available ? '✅ Вкл' : '❌ Выкл'}
                      </Button>
                    </div>
                  ))}
                </div>

                <div>
                  <h3 className="font-medium text-blue-600 mb-2">💸 Выводы (Payout)</h3>
                  {services.filter(s => s.service_type === 'payout').map(s => (
                    <div key={s.id} className="grid grid-cols-2 md:grid-cols-9 gap-2 items-center border border-blue-600 p-3 rounded-md mb-2 bg-blue-900/20 text-white">
                      <div className="font-medium">{s.provider}</div>
                      <div className="text-blue-600">💸 {s.service_type}</div>
                      <div>{s.currency}</div>
                      <div className="font-bold">{s.network_code}</div>
                      <Input
                        type="number"
                        defaultValue={s.min_amount||0}
                        onBlur={(e)=>updateService(s.id, { min_amount: Number(e.target.value) })}
                        placeholder="Минимум"
                        className="h-8 bg-gray-800 border-gray-600 text-white"
                      />
                      <Input
                        type="number"
                        defaultValue={s.max_amount||0}
                        onBlur={(e)=>updateService(s.id, { max_amount: Number(e.target.value) })}
                        placeholder="Максимум"
                        className="h-8 bg-gray-800 border-gray-600 text-white"
                      />
                      <Input
                        type="number"
                        step="0.01"
                        defaultValue={s.fee_fixed||0}
                        onBlur={(e)=>updateService(s.id, { fee_fixed: Number(e.target.value) })}
                        placeholder="Фикс. $"
                        className="h-8 bg-gray-800 border-gray-600 text-white"
                      />
                      <Input
                        type="number"
                        step="0.001"
                        defaultValue={s.fee_percent||0}
                        onBlur={(e)=>updateService(s.id, { fee_percent: Number(e.target.value) })}
                        placeholder="% (0.03 = 3%)"
                        className="h-8 bg-gray-800 border-gray-600 text-white"
                      />
                      <Button
                        variant={s.is_available ? "default" : "outline"}
                        size="sm"
                        onClick={()=>updateService(s.id, { is_available: !s.is_available })}
                        className="h-8"
                      >
                        {s.is_available ? '✅ Вкл' : '❌ Выкл'}
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
