"use client";
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { TariffPlan, TariffFormData } from '@/types';

// Тип для тарифов из БД (новые поля могут отсутствовать в старых записях)
interface TariffPlanFromDB extends Omit<TariffPlan, 'tariff_type' | 'is_perpetual' | 'auto_return_principal' | 'monthly_percent' | 'total_return_percent'> {
  tariff_type?: 'perpetual' | 'fixed_term_instant' | 'fixed_term_monthly' | 'fixed_term_6months' | 'fixed_term_12months';
  is_perpetual?: boolean;
  monthly_percent?: number;
  total_return_percent?: number;
  auto_return_principal?: boolean;
}

export default function TariffsForm() {
  const [items, setItems] = useState<TariffPlanFromDB[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<TariffFormData>({
    code: '',
    name_ru: '',
    name_en: '',
    min_amount: 0,
    max_amount: 0,
    term_days: 30,
    daily_percent: 0.01,
    tariff_type: 'perpetual',
    monthly_percent: 12,
    total_return_percent: 0,
    is_perpetual: true,
    auto_return_principal: false,
    is_active: true
  });

  const load = async () => {
    setLoading(true);
    const res = await fetch('/api/admin/tariffs');
    const data = await res.json();
    setItems(data.data?.items || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const create = async () => {
    const res = await fetch('/api/admin/tariffs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    if (res.ok) await load();
  };

  const update = async (id: number, patch: Partial<TariffPlan>) => {
    const res = await fetch('/api/admin/tariffs', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, ...patch }) });
    if (res.ok) await load();
  };

  const remove = async (id: number) => {
    if (!confirm('Вы уверены, что хотите удалить этот тариф?')) return;

    try {
      const res = await fetch(`/api/admin/tariffs?id=${id}`, { method: 'DELETE' });
      const data = await res.json();

      if (res.ok && data.success) {
        alert('✅ Тариф успешно удален');
        await load();
      } else {
        // Показываем понятное сообщение об ошибке
        const errorMessage = data.message || data.error || 'Не удалось удалить тариф';
        alert(`❌ ${errorMessage}`);
      }
    } catch (error) {
      alert('❌ Ошибка сети при удалении тарифа');
      console.error('Delete error:', error);
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-6 space-y-6">
          <h3 className="text-lg font-semibold">Создание нового тарифа</h3>

          {/* Основная информация */}
          <div className="space-y-4">
            <h4 className="font-medium text-gray-700">📋 Основная информация</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="code">Код тарифа (T1, T2, T3...)</Label>
                <Input
                  id="code"
                  placeholder="T1"
                  value={form.code}
                  onChange={e=>setForm({...form, code:e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="name_ru">Название (Русский)</Label>
                <Input
                  id="name_ru"
                  placeholder="Стартовый тариф"
                  value={form.name_ru}
                  onChange={e=>setForm({...form, name_ru:e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="name_en">Название (English)</Label>
                <Input
                  id="name_en"
                  placeholder="Starter Plan"
                  value={form.name_en}
                  onChange={e=>setForm({...form, name_en:e.target.value})}
                />
              </div>
            </div>
          </div>

          {/* Суммы инвестиций */}
          <div className="space-y-4">
            <h4 className="font-medium text-gray-700">💰 Лимиты инвестиций (USDT)</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="min_amount">Минимальная сумма</Label>
                <Input
                  id="min_amount"
                  type="number"
                  placeholder="100"
                  value={form.min_amount}
                  onChange={e=>setForm({...form, min_amount:Number(e.target.value)})}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="max_amount">Максимальная сумма</Label>
                <Input
                  id="max_amount"
                  type="number"
                  placeholder="50000"
                  value={form.max_amount}
                  onChange={e=>setForm({...form, max_amount:Number(e.target.value)})}
                />
              </div>
            </div>
          </div>

          {/* Тип тарифа */}
          <div className="space-y-4">
            <h4 className="font-medium text-gray-700">⚙️ Тип тарифа</h4>
            <div className="space-y-2">
              <Label>Выберите тип тарифа</Label>
              <Select value={form.tariff_type} onValueChange={(value: 'perpetual' | 'fixed_term_instant' | 'fixed_term_monthly' | 'fixed_term_6months' | 'fixed_term_12months') => {
                const updates: Partial<TariffFormData> = { tariff_type: value };
                if (value === 'perpetual') {
                  updates.is_perpetual = true;
                  updates.auto_return_principal = false;
                  updates.term_days = 999;
                  updates.monthly_percent = 12;
                  updates.daily_percent = 12 / 30 / 100; // 12% в месяц = 0.4% в день
                } else if (value === 'fixed_term_instant') {
                  updates.is_perpetual = false;
                  updates.auto_return_principal = true;
                  updates.term_days = 30;
                  updates.total_return_percent = 20;
                  updates.daily_percent = 20 / 30 / 100; // 20% за 30 дней
                } else if (value === 'fixed_term_monthly') {
                  updates.is_perpetual = false;
                  updates.auto_return_principal = true;
                  updates.term_days = 90;
                  updates.total_return_percent = 90;
                  updates.monthly_percent = 30;
                  updates.daily_percent = 30 / 30 / 100; // 30% в месяц
                } else if (value === 'fixed_term_6months') {
                  updates.is_perpetual = false;
                  updates.auto_return_principal = true;
                  updates.term_days = 180; // 6 месяцев
                  updates.total_return_percent = 240; // 40% в месяц * 6 месяцев
                  updates.monthly_percent = 40;
                  updates.daily_percent = 40 / 30 / 100; // 40% в месяц
                } else { // fixed_term_12months
                  updates.is_perpetual = false;
                  updates.auto_return_principal = true;
                  updates.term_days = 365; // 12 месяцев
                  updates.total_return_percent = 600; // 50% в месяц * 12 месяцев
                  updates.monthly_percent = 50;
                  updates.daily_percent = 50 / 30 / 100; // 50% в месяц
                }
                setForm({...form, ...updates});
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Выберите тип" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="perpetual">🔄 Бессрочный (возврат тела по запросу)</SelectItem>
                  <SelectItem value="fixed_term_instant">⚡ Фиксированный 1 месяц (авто-возврат)</SelectItem>
                  <SelectItem value="fixed_term_monthly">📅 Фиксированный 3 месяца (авто-возврат)</SelectItem>
                  <SelectItem value="fixed_term_6months">📅 Фиксированный 6 месяцев (авто-возврат)</SelectItem>
                  <SelectItem value="fixed_term_12months">📅 Фиксированный 12 месяцев (авто-возврат)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Настройки доходности */}
          <div className="space-y-4">
            <h4 className="font-medium text-gray-700">📈 Настройки доходности</h4>

            {form.tariff_type === 'perpetual' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="monthly_percent">Процент в месяц (%)</Label>
                  <Input
                    id="monthly_percent"
                    type="number"
                    step="0.01"
                    placeholder="12"
                    value={form.monthly_percent || 0}
                    onChange={e=>{
                      const monthlyPercent = Number(e.target.value);
                      setForm({
                        ...form,
                        monthly_percent: monthlyPercent,
                        daily_percent: monthlyPercent / 30 / 100 // Автоматически пересчитываем daily
                      });
                    }}
                  />
                  <p className="text-sm text-gray-500">
                    Daily: {((form.monthly_percent || 0) / 30).toFixed(4)}%
                  </p>
                </div>
              </div>
            )}

            {form.tariff_type === 'fixed_term_instant' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="term_days_instant">Срок (дней)</Label>
                  <Input
                    id="term_days_instant"
                    type="number"
                    value={form.term_days}
                    onChange={e=>setForm({...form, term_days:Number(e.target.value)})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="total_return_instant">Общий возврат (%)</Label>
                  <Input
                    id="total_return_instant"
                    type="number"
                    step="0.01"
                    placeholder="20"
                    value={form.total_return_percent || 0}
                    onChange={e=>{
                      const totalPercent = Number(e.target.value);
                      setForm({
                        ...form,
                        total_return_percent: totalPercent,
                        daily_percent: totalPercent / form.term_days / 100 // Автоматически пересчитываем daily
                      });
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Daily процент (авто)</Label>
                  <div className="p-2 bg-gray-50 rounded text-sm">
                    {(((form.total_return_percent || 0) / form.term_days)).toFixed(4)}%
                  </div>
                </div>
              </div>
            )}

            {form.tariff_type === 'fixed_term_monthly' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="monthly_percent_fixed">Процент в месяц (%)</Label>
                  <Input
                    id="monthly_percent_fixed"
                    type="number"
                    step="0.01"
                    placeholder="30"
                    value={form.monthly_percent || 0}
                    onChange={e=>{
                      const monthlyPercent = Number(e.target.value);
                      const totalPercent = monthlyPercent * 3; // 3 месяца
                      setForm({
                        ...form,
                        monthly_percent: monthlyPercent,
                        total_return_percent: totalPercent,
                        daily_percent: monthlyPercent / 30 / 100 // Автоматически пересчитываем daily
                      });
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Общий возврат (авто)</Label>
                  <div className="p-2 bg-gray-50 rounded text-sm">
                    {((form.monthly_percent || 0) * 3).toFixed(2)}% за 90 дней
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Daily процент (авто)</Label>
                  <div className="p-2 bg-gray-50 rounded text-sm">
                    {(((form.monthly_percent || 0) / 30)).toFixed(4)}%
                  </div>
                </div>
              </div>
            )}

            {form.tariff_type === 'fixed_term_6months' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="monthly_percent_6m">Процент в месяц (%)</Label>
                  <Input
                    id="monthly_percent_6m"
                    type="number"
                    step="0.01"
                    placeholder="40"
                    value={form.monthly_percent || 0}
                    onChange={e=>{
                      const monthlyPercent = Number(e.target.value);
                      const totalPercent = monthlyPercent * 6; // 6 месяцев
                      setForm({
                        ...form,
                        monthly_percent: monthlyPercent,
                        total_return_percent: totalPercent,
                        daily_percent: monthlyPercent / 30 / 100 // Автоматически пересчитываем daily
                      });
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Общий возврат (авто)</Label>
                  <div className="p-2 bg-gray-50 rounded text-sm">
                    {((form.monthly_percent || 0) * 6).toFixed(2)}% за 180 дней
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Daily процент (авто)</Label>
                  <div className="p-2 bg-gray-50 rounded text-sm">
                    {(((form.monthly_percent || 0) / 30)).toFixed(4)}%
                  </div>
                </div>
              </div>
            )}

            {form.tariff_type === 'fixed_term_12months' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="monthly_percent_12m">Процент в месяц (%)</Label>
                  <Input
                    id="monthly_percent_12m"
                    type="number"
                    step="0.01"
                    placeholder="50"
                    value={form.monthly_percent || 0}
                    onChange={e=>{
                      const monthlyPercent = Number(e.target.value);
                      const totalPercent = monthlyPercent * 12; // 12 месяцев
                      setForm({
                        ...form,
                        monthly_percent: monthlyPercent,
                        total_return_percent: totalPercent,
                        daily_percent: monthlyPercent / 30 / 100 // Автоматически пересчитываем daily
                      });
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Общий возврат (авто)</Label>
                  <div className="p-2 bg-gray-50 rounded text-sm">
                    {((form.monthly_percent || 0) * 12).toFixed(2)}% за 365 дней
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Daily процент (авто)</Label>
                  <div className="p-2 bg-gray-50 rounded text-sm">
                    {(((form.monthly_percent || 0) / 30)).toFixed(4)}%
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Статус */}
          <div className="space-y-4">
            <h4 className="font-medium text-gray-700">🎛️ Статус</h4>
            <div className="flex items-center space-x-2">
              <Switch
                id="active"
                checked={form.is_active}
                onCheckedChange={(checked) => setForm({...form, is_active: checked})}
              />
              <Label htmlFor="active">Тариф активен (доступен для инвестиций)</Label>
            </div>
          </div>

          <Button onClick={create} className="w-full" size="lg">
            ➕ Создать тариф
          </Button>
        </CardContent>
      </Card>

      {loading ? (
        <div className="text-center py-8">
          <div className="text-sm text-neutral-500">Загрузка тарифов...</div>
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-8">
          <div className="text-sm text-neutral-500">Тарифы не найдены</div>
        </div>
      ) : (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Существующие тарифы</h3>
          {items.map((t) => (
            <Card key={t.id} className="p-4 border-l-4" style={{
              borderLeftColor: t.is_active ? '#10b981' : '#ef4444'
            }}>
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">

                {/* Основная информация - 4 колонки */}
                <div className="lg:col-span-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-lg">{t.code}</span>
                    <span className={`px-2 py-1 rounded text-xs ${t.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                      {t.is_active ? 'Активен' : 'Отключен'}
                    </span>
                  </div>
                  <div className="text-sm font-medium">{t.name_ru}</div>
                  <div className="text-xs text-gray-600">
                    {t.tariff_type === 'perpetual' ? '🔄 Бессрочный' :
                     t.tariff_type === 'fixed_term_instant' ? '⚡ Фиксированный (мгновенный)' :
                     t.tariff_type === 'fixed_term_monthly' ? '📅 Фиксированный (ежемесячный)' :
                     t.tariff_type === 'fixed_term_6months' ? '📅 Фиксированный 6 месяцев' :
                     t.tariff_type === 'fixed_term_12months' ? '📅 Фиксированный 12 месяцев' :
                     '📊 Legacy'}
                  </div>
                </div>

                {/* Лимиты - 2 колонки */}
                <div className="lg:col-span-2 space-y-2">
                  <Label className="text-xs text-gray-500">ЛИМИТЫ (USDT)</Label>
                  <div className="space-y-1">
                    <div className="flex items-center gap-1">
                      <span className="text-xs w-8">Min:</span>
                      <Input
                        className="h-7 text-xs"
                        type="number"
                        defaultValue={t.min_amount}
                        onBlur={(e)=>update(t.id,{ min_amount:Number(e.target.value) })}
                      />
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-xs w-8">Max:</span>
                      <Input
                        className="h-7 text-xs"
                        type="number"
                        defaultValue={t.max_amount}
                        onBlur={(e)=>update(t.id,{ max_amount:Number(e.target.value) })}
                      />
                    </div>
                  </div>
                </div>

                {/* Доходность - 3 колонки */}
                <div className="lg:col-span-3 space-y-2">
                  <Label className="text-xs text-gray-500">ДОХОДНОСТЬ</Label>
                  <div className="space-y-1">
                    <div className="flex items-center gap-1">
                      <span className="text-xs w-12">Daily:</span>
                      <Input
                        className="h-7 text-xs"
                        type="number"
                        step="0.0001"
                        defaultValue={t.daily_percent}
                        onBlur={(e)=>update(t.id,{ daily_percent:Number(e.target.value) })}
                      />
                      <span className="text-xs">%</span>
                    </div>
                    {t.monthly_percent && (
                      <div className="flex items-center gap-1">
                        <span className="text-xs w-12">Month:</span>
                        <Input
                          className="h-7 text-xs"
                          type="number"
                          step="0.01"
                          defaultValue={t.monthly_percent}
                          onBlur={(e)=>update(t.id,{ monthly_percent:Number(e.target.value) })}
                        />
                        <span className="text-xs">%</span>
                      </div>
                    )}
                    <div className="text-xs text-gray-500">
                      Срок: {t.is_perpetual || t.term_days > 365 ? 'Бессрочно' : `${t.term_days} дней`}
                    </div>
                  </div>
                </div>

                {/* Управление - 3 колонки */}
                <div className="lg:col-span-3 space-y-2">
                  <Label className="text-xs text-gray-500">УПРАВЛЕНИЕ</Label>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-7 text-xs"
                      onClick={()=>update(t.id,{ is_active: !t.is_active })}
                    >
                      {t.is_active ? '🔴 Отключить' : '🟢 Включить'}
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      className="h-7 text-xs"
                      onClick={()=>remove(t.id)}
                    >
                      🗑️ Удалить
                    </Button>
                  </div>
                  <div className="text-xs text-gray-600">
                    ID: {t.id} | Обновлен: {new Date(t.updated_at).toLocaleDateString('ru-RU')}
                  </div>
                </div>

              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
