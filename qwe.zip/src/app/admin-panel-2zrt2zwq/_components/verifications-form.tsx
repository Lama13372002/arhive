'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import {
  Eye, Check, X, Clock, AlertCircle, User, Calendar,
  FileImage, Camera, MessageSquare, ChevronLeft, ChevronRight,
  Download, Search, Filter, RefreshCw
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Verification {
  id: number;
  status: 'pending' | 'under_review' | 'approved' | 'rejected';
  first_name: string;
  last_name: string;
  date_of_birth: string;
  document_type: string;
  document_number: string;
  document_front_url: string;
  document_back_url?: string;
  selfie_url: string;
  submitted_at: string;
  reviewed_at?: string;
  rejection_reason?: string;
  admin_notes?: string;
  telegram_id: string;
  username?: string;
  phone?: string;
  reviewed_by_username?: string;
}

interface StatusCounts {
  pending?: number;
  under_review?: number;
  approved?: number;
  rejected?: number;
}

export function VerificationsForm() {
  const { toast } = useToast();
  const [verifications, setVerifications] = useState<Verification[]>([]);
  const [statusCounts, setStatusCounts] = useState<StatusCounts>({});
  const [loading, setLoading] = useState(true);
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [selectedVerification, setSelectedVerification] = useState<Verification | null>(null);
  const [reviewNotes, setReviewNotes] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const fetchVerifications = async (status = selectedStatus, page = currentPage) => {
    try {
      setLoading(true);
      const response = await fetch(`/api/admin/verifications?status=${status}&page=${page}&limit=10`);
      const data = await response.json();

      if (response.ok) {
        setVerifications(data.verifications);
        setStatusCounts(data.statusCounts);
        setTotalPages(data.pagination.totalPages);
      } else {
        toast({
          title: 'Error',
          description: data.error || 'Failed to fetch verifications',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch verifications',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVerifications();
  }, [selectedStatus, currentPage]);

  const handleStatusChange = (status: string) => {
    setSelectedStatus(status);
    setCurrentPage(1);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handleReviewAction = async (verificationId: number, action: 'approve' | 'reject') => {
    if (action === 'reject' && !reviewNotes.trim()) {
      toast({
        title: 'Rejection reason required',
        description: 'Please provide a reason for rejection',
        variant: 'destructive'
      });
      return;
    }

    setIsProcessing(true);
    try {
      const response = await fetch('/api/admin/verifications', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          verificationId,
          action,
          notes: reviewNotes,
          adminId: 1 // You should get this from session/auth
        }),
      });

      const data = await response.json();

      if (response.ok) {
        toast({
          title: 'Success',
          description: data.message,
        });
        setSelectedVerification(null);
        setReviewNotes('');
        fetchVerifications();
      } else {
        toast({
          title: 'Error',
          description: data.error || 'Failed to process verification',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to process verification',
        variant: 'destructive'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      pending: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      under_review: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      approved: 'bg-green-500/20 text-green-400 border-green-500/30',
      rejected: 'bg-red-500/20 text-red-400 border-red-500/30'
    };

    const icons = {
      pending: <Clock size={12} />,
      under_review: <Eye size={12} />,
      approved: <Check size={12} />,
      rejected: <X size={12} />
    };

    return (
      <Badge variant="outline" className={variants[status as keyof typeof variants]}>
        {icons[status as keyof typeof icons]}
        <span className="ml-1 capitalize">{status.replace('_', ' ')}</span>
      </Badge>
    );
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const VerificationDetailDialog = ({ verification }: { verification: Verification }) => (
    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-card border-white/10">
      <DialogHeader>
        <DialogTitle className="text-xl font-bold text-white flex items-center">
          <User size={20} className="mr-2 text-primary" />
          Verification Details - {verification.first_name} {verification.last_name}
        </DialogTitle>
      </DialogHeader>

      <div className="space-y-6">
        {/* Personal Information */}
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="text-lg text-white flex items-center">
              <User size={16} className="mr-2 text-primary" />
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-white/70">Full Name</Label>
              <p className="text-white">{verification.first_name} {verification.last_name}</p>
            </div>
            <div>
              <Label className="text-white/70">Date of Birth</Label>
              <p className="text-white">{new Date(verification.date_of_birth).toLocaleDateString()}</p>
            </div>
            <div>
              <Label className="text-white/70">Telegram ID</Label>
              <p className="text-white">{verification.telegram_id}</p>
            </div>
            <div>
              <Label className="text-white/70">Username</Label>
              <p className="text-white">{verification.username || 'N/A'}</p>
            </div>
            <div>
              <Label className="text-white/70">Document Type</Label>
              <p className="text-white capitalize">{verification.document_type.replace('_', ' ')}</p>
            </div>
            <div>
              <Label className="text-white/70">Document Number</Label>
              <p className="text-white">{verification.document_number}</p>
            </div>
          </CardContent>
        </Card>

        {/* Documents */}
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="text-lg text-white flex items-center">
              <FileImage size={16} className="mr-2 text-primary" />
              Uploaded Documents
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label className="text-white/70 mb-2 block">Document Front</Label>
                <div className="relative group">
                  <img
                    src={verification.document_front_url}
                    alt="Document Front"
                    className="w-full h-32 object-cover rounded-lg border border-white/10 cursor-pointer hover:border-primary/50 transition-all"
                    onClick={() => window.open(verification.document_front_url, '_blank')}
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-lg">
                    <Eye size={20} className="text-white" />
                  </div>
                </div>
              </div>

              {verification.document_back_url && (
                <div>
                  <Label className="text-white/70 mb-2 block">Document Back</Label>
                  <div className="relative group">
                    <img
                      src={verification.document_back_url}
                      alt="Document Back"
                      className="w-full h-32 object-cover rounded-lg border border-white/10 cursor-pointer hover:border-primary/50 transition-all"
                      onClick={() => window.open(verification.document_back_url, '_blank')}
                    />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-lg">
                      <Eye size={20} className="text-white" />
                    </div>
                  </div>
                </div>
              )}

              <div>
                <Label className="text-white/70 mb-2 block">Selfie</Label>
                <div className="relative group">
                  <img
                    src={verification.selfie_url}
                    alt="Selfie"
                    className="w-full h-32 object-cover rounded-lg border border-white/10 cursor-pointer hover:border-primary/50 transition-all"
                    onClick={() => window.open(verification.selfie_url, '_blank')}
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-lg">
                    <Camera size={20} className="text-white" />
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Review Section */}
        {verification.status === 'pending' && (
          <Card className="bg-white/5 border-white/10">
            <CardHeader>
              <CardTitle className="text-lg text-white flex items-center">
                <MessageSquare size={16} className="mr-2 text-primary" />
                Review Verification
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="reviewNotes" className="text-white/70">Notes / Rejection Reason</Label>
                <textarea
                  id="reviewNotes"
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  className="w-full mt-1 p-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/50 resize-none"
                  rows={3}
                  placeholder="Add notes or rejection reason..."
                />
              </div>

              <div className="flex space-x-3">
                <Button
                  onClick={() => handleReviewAction(verification.id, 'approve')}
                  disabled={isProcessing}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                >
                  <Check size={16} className="mr-2" />
                  Approve
                </Button>
                <Button
                  onClick={() => handleReviewAction(verification.id, 'reject')}
                  disabled={isProcessing}
                  variant="outline"
                  className="flex-1 border-red-500/50 text-red-400 hover:bg-red-500/10"
                >
                  <X size={16} className="mr-2" />
                  Reject
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Review History */}
        {(verification.reviewed_at || verification.admin_notes || verification.rejection_reason) && (
          <Card className="bg-white/5 border-white/10">
            <CardHeader>
              <CardTitle className="text-lg text-white">Review History</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {verification.reviewed_at && (
                <div>
                  <Label className="text-white/70">Reviewed At</Label>
                  <p className="text-white">{formatDate(verification.reviewed_at)}</p>
                </div>
              )}
              {verification.reviewed_by_username && (
                <div>
                  <Label className="text-white/70">Reviewed By</Label>
                  <p className="text-white">{verification.reviewed_by_username}</p>
                </div>
              )}
              {verification.admin_notes && (
                <div>
                  <Label className="text-white/70">Admin Notes</Label>
                  <p className="text-white">{verification.admin_notes}</p>
                </div>
              )}
              {verification.rejection_reason && (
                <div>
                  <Label className="text-white/70">Rejection Reason</Label>
                  <p className="text-red-400">{verification.rejection_reason}</p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </DialogContent>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">Identity Verifications</h2>
          <p className="text-white/60">Manage user verification requests</p>
        </div>
        <Button
          onClick={() => fetchVerifications()}
          variant="outline"
          className="border-white/20 hover:border-primary/40"
        >
          <RefreshCw size={16} className="mr-2" />
          Refresh
        </Button>
      </div>

      {/* Status Tabs */}
      <Tabs value={selectedStatus} onValueChange={handleStatusChange}>
        <TabsList className="bg-white/5 border-white/10">
          <TabsTrigger value="all" className="data-[state=active]:bg-primary/20">
            All ({Object.values(statusCounts).reduce((a, b) => a + b, 0)})
          </TabsTrigger>
          <TabsTrigger value="pending" className="data-[state=active]:bg-yellow-500/20">
            Pending ({statusCounts.pending || 0})
          </TabsTrigger>
          <TabsTrigger value="under_review" className="data-[state=active]:bg-blue-500/20">
            Under Review ({statusCounts.under_review || 0})
          </TabsTrigger>
          <TabsTrigger value="approved" className="data-[state=active]:bg-green-500/20">
            Approved ({statusCounts.approved || 0})
          </TabsTrigger>
          <TabsTrigger value="rejected" className="data-[state=active]:bg-red-500/20">
            Rejected ({statusCounts.rejected || 0})
          </TabsTrigger>
        </TabsList>

        <TabsContent value={selectedStatus}>
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-0">
              {loading ? (
                <div className="p-8 text-center">
                  <RefreshCw size={32} className="mx-auto mb-4 text-primary animate-spin" />
                  <p className="text-white/60">Loading verifications...</p>
                </div>
              ) : verifications.length === 0 ? (
                <div className="p-8 text-center">
                  <AlertCircle size={32} className="mx-auto mb-4 text-white/40" />
                  <p className="text-white/60">No verifications found</p>
                </div>
              ) : (
                <div className="divide-y divide-white/5">
                  {verifications.map((verification) => (
                    <div key={verification.id} className="p-4 hover:bg-white/5 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                              <User size={16} className="text-primary" />
                            </div>
                            <div>
                              <h3 className="font-semibold text-white">
                                {verification.first_name} {verification.last_name}
                              </h3>
                              <p className="text-sm text-white/60">
                                @{verification.username || verification.telegram_id}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center space-x-4 text-sm text-white/60">
                            <span>Document: {verification.document_type.replace('_', ' ')}</span>
                            <span>•</span>
                            <span>Submitted: {formatDate(verification.submitted_at)}</span>
                          </div>
                        </div>

                        <div className="flex items-center space-x-3">
                          {getStatusBadge(verification.status)}
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                className="border-white/20 hover:border-primary/40"
                                onClick={() => setSelectedVerification(verification)}
                              >
                                <Eye size={16} className="mr-2" />
                                View Details
                              </Button>
                            </DialogTrigger>
                            {selectedVerification?.id === verification.id && (
                              <VerificationDetailDialog verification={selectedVerification} />
                            )}
                          </Dialog>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="p-4 border-t border-white/5">
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-white/60">
                      Page {currentPage} of {totalPages}
                    </p>
                    <div className="flex space-x-2">
                      <Button
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                        variant="outline"
                        size="sm"
                        className="border-white/20"
                      >
                        <ChevronLeft size={16} />
                      </Button>
                      <Button
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages}
                        variant="outline"
                        size="sm"
                        className="border-white/20"
                      >
                        <ChevronRight size={16} />
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
