module.exports = {
  apps: [
    {
      name: process.env.APP_NAME || 'tma-app',
      script: 'bun',
      args: 'run start',
      cwd: process.env.WORK_DIR || process.cwd(),
      env: {
        PORT: process.env.NODE_PORT || '3000',
        NODE_ENV: 'production',
      },
      instances: 1,
      exec_mode: 'fork',
      max_memory_restart: '512M',
      listen_timeout: 10000,
      kill_timeout: 5000,
      out_file: './.pm2/out.log',
      error_file: './.pm2/error.log',
      merge_logs: true,
      autorestart: true,
      watch: false,
    },
  ],
};
