#!/bin/bash

# Цвета для красивого вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🚀 Скрипт управления Deposit Monitor${NC}"
echo ""

case "$1" in
  "start")
    echo -e "${YELLOW}📦 Запуск deposit-monitor через PM2...${NC}"
    # Создаем директорию для логов если не существует
    mkdir -p .pm2

    # Останавливаем если уже запущен
    pm2 stop deposit-monitor 2>/dev/null || true
    pm2 delete deposit-monitor 2>/dev/null || true

    # Запускаем с конфигурацией
    pm2 start deposit-monitor.config.js

    echo -e "${GREEN}✅ Deposit-monitor запущен!${NC}"
    echo ""
    echo -e "${BLUE}📊 Информация о процессе:${NC}"
    pm2 list
    echo ""
    echo -e "${BLUE}📋 Полезные команды:${NC}"
    echo "  pm2 logs deposit-monitor    - просмотр логов"
    echo "  pm2 monit                   - мониторинг"
    echo "  pm2 restart deposit-monitor - перезапуск"
    echo "  ./manage-deposit-monitor.sh stop - остановка"
    ;;

  "stop")
    echo -e "${YELLOW}🛑 Остановка deposit-monitor...${NC}"
    pm2 stop deposit-monitor
    pm2 delete deposit-monitor
    echo -e "${GREEN}✅ Deposit-monitor остановлен!${NC}"
    ;;

  "restart")
    echo -e "${YELLOW}🔄 Перезапуск deposit-monitor...${NC}"
    pm2 restart deposit-monitor
    echo -e "${GREEN}✅ Deposit-monitor перезапущен!${NC}"
    ;;

  "status")
    echo -e "${BLUE}📊 Статус deposit-monitor:${NC}"
    pm2 list deposit-monitor
    ;;

  "logs")
    echo -e "${BLUE}📋 Логи deposit-monitor:${NC}"
    pm2 logs deposit-monitor --lines 50
    ;;

  "setup")
    echo -e "${YELLOW}🔧 Установка зависимостей...${NC}"

    # Проверяем наличие PM2
    if ! command -v pm2 &> /dev/null; then
      echo -e "${YELLOW}📦 Установка PM2...${NC}"
      npm install -g pm2
    else
      echo -e "${GREEN}✅ PM2 уже установлен${NC}"
    fi

    # Проверяем наличие pg
    if ! node -e "require('pg')" 2>/dev/null; then
      echo -e "${YELLOW}📦 Установка PostgreSQL клиента...${NC}"
      npm install pg
    else
      echo -e "${GREEN}✅ PostgreSQL клиент уже установлен${NC}"
    fi

    # Создаем директорию для логов
    mkdir -p .pm2

    echo -e "${GREEN}✅ Настройка завершена!${NC}"
    echo -e "${BLUE}💡 Теперь можно запустить: ./manage-deposit-monitor.sh start${NC}"
    ;;

  "autostart")
    echo -e "${YELLOW}🔧 Настройка автозапуска...${NC}"

    # Сохраняем текущую конфигурацию PM2
    pm2 save

    # Генерируем startup скрипт
    echo -e "${BLUE}💡 Выполните следующую команду с правами sudo:${NC}"
    pm2 startup

    echo ""
    echo -e "${GREEN}✅ После выполнения команды выше deposit-monitor будет автоматически запускаться при перезагрузке системы${NC}"
    ;;

  *)
    echo -e "${BLUE}📖 Использование:${NC}"
    echo "  ./manage-deposit-monitor.sh setup     - установка зависимостей"
    echo "  ./manage-deposit-monitor.sh start     - запуск мониторинга"
    echo "  ./manage-deposit-monitor.sh stop      - остановка мониторинга"
    echo "  ./manage-deposit-monitor.sh restart   - перезапуск мониторинга"
    echo "  ./manage-deposit-monitor.sh status    - проверка статуса"
    echo "  ./manage-deposit-monitor.sh logs      - просмотр логов"
    echo "  ./manage-deposit-monitor.sh autostart - настройка автозапуска"
    echo ""
    echo -e "${YELLOW}💡 Для первого запуска выполните:${NC}"
    echo "  chmod +x manage-deposit-monitor.sh"
    echo "  ./manage-deposit-monitor.sh setup"
    echo "  ./manage-deposit-monitor.sh start"
    ;;
esac
