import type React from 'react';
import { useRef, useEffect, forwardRef } from 'react';
import { Input } from './input';
import { cn } from '@/lib/utils';

interface WalletInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
  label?: string;
  hint?: string;
}

export const WalletInput = forwardRef<HTMLInputElement, WalletInputProps>(({
  value,
  onChange,
  placeholder = "UQ... или 0:...",
  className,
  disabled = false,
  label = "Адрес кошелька",
  hint = "Введите адрес вашего кошелька"
}, ref) => {
  const internalRef = useRef<HTMLInputElement>(null);
  const inputRef = ref || internalRef;

  // Обработка стандартной вставки через контекстное меню или Ctrl+V
  const handleInputPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    // Позволяем стандартное поведение вставки
    const pastedText = e.clipboardData.getData('text');
    if (pastedText) {
      // Небольшая задержка чтобы дать браузеру обработать вставку
      setTimeout(() => {
        onChange(pastedText.trim());
      }, 10);
    }
  };

  // iOS Safari фикс - предотвращаем зум при фокусе
  useEffect(() => {
    const input = typeof inputRef === 'object' && inputRef?.current ? inputRef.current : null;
    if (input) {
      // Устанавливаем font-size минимум 16px для предотвращения зума на iOS
      input.style.fontSize = '16px';

      // Обработка фокуса для iOS
      const handleFocus = () => {
        // Небольшая задержка для корректной работы на iOS
        setTimeout(() => {
          input.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 300);
      };

      input.addEventListener('focus', handleFocus);
      return () => {
        input.removeEventListener('focus', handleFocus);
      };
    }
  }, [inputRef]);

  return (
    <div className="space-y-2">
      {label && (
        <label className="text-sm font-medium text-slate-300 block">
          {label}
        </label>
      )}

      <div className="relative">
        <Input
          ref={inputRef as React.RefObject<HTMLInputElement>}
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onPaste={handleInputPaste}
          placeholder={placeholder}
          disabled={disabled}
          className={cn(
            "bg-white/5 border-white/10 focus:border-blue-500/50 focus:bg-white/10 transition-all duration-200 text-sm h-12 rounded-lg",
            "ios-input", // Дополнительный класс для iOS стилей
            className
          )}
          style={{
            fontSize: '16px', // Предотвращает зум на iOS
            WebkitAppearance: 'none',
            WebkitBorderRadius: '0.5rem',
          }}
        />
      </div>

      {hint && (
        <p className="text-[10px] text-slate-500">
          {hint}
        </p>
      )}
    </div>
  );
});

WalletInput.displayName = 'WalletInput';
