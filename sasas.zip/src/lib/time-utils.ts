// Общие утилиты для работы со временем матчей
// Основано на логике из HomePage.tsx с улучшениями

export interface TimeDisplayResult {
  text: string;
  color: string;
  icon: string;
  badgeVariant?: 'default' | 'destructive' | 'secondary' | 'outline';
}

export interface MatchTimeData {
  status?: string;
  minute?: number;
  fullDateTime?: string;
  startTime?: string;
  start_time?: string;
  match_start_time?: string;
  created_at?: string;
}

// Функция для парсинга fullDateTime в формате "дд,мм,чч,мм"
export const parseFullDateTime = (fullDateTime: string): Date | null => {
  if (!fullDateTime) return null;

  try {
    const today = new Date();
    const parts = fullDateTime.split(/[,\s:]+/);

    if (parts.length >= 4) {
      const day = parseInt(parts[0]);
      const month = parseInt(parts[1]) - 1; // месяцы в JS начинаются с 0
      const hours = parseInt(parts[2]);
      const minutes = parseInt(parts[3]);

      // Создаем дату с правильным годом
      const eventDate = new Date(today.getFullYear(), month, day, hours, minutes, 0, 0);

      // Если получившаяся дата в прошлом, вероятно это следующий год
      if (eventDate < today && (today.getTime() - eventDate.getTime()) > 30 * 24 * 60 * 60 * 1000) {
        eventDate.setFullYear(today.getFullYear() + 1);
      }

      return eventDate;
    }
  } catch (e) {
    console.warn('Ошибка парсинга даты:', fullDateTime, e);
  }

  return null;
};

// Проверка актуальности матча (не завершен и не слишком старый)
export const isMatchRelevant = (matchData: MatchTimeData): boolean => {
  // Завершенные матчи не показываем
  if (matchData.status === 'finished' || matchData.status === 'ft' || matchData.status === 'completed') {
    return false;
  }

  // Live и halftime матчи всегда показываем
  if (matchData.status === 'live' || matchData.status === 'halftime' ||
      matchData.status === '1h' || matchData.status === '2h' || matchData.status === 'ht') {
    return true;
  }

  // Для upcoming матчей проверяем время
  const now = new Date();

  // Парсим время матча из fullDateTime
  if (matchData.fullDateTime) {
    const matchTime = parseFullDateTime(matchData.fullDateTime);
    if (matchTime) {
      // Не показываем матчи старше 3 часов (возможно уже завершились, но API не обновился)
      const threeHoursAgo = now.getTime() - (3 * 60 * 60 * 1000);
      if (matchTime.getTime() < threeHoursAgo) {
        return false;
      }
    }
  }

  return true;
};

// Основная функция для получения статуса и времени матча
export const getMatchStatusAndTime = (
  matchData: MatchTimeData,
  t?: (key: string, params?: Record<string, string | number>) => string,
  locale: 'ru-RU' | 'en-US' = 'ru-RU'
): TimeDisplayResult => {
  const status = (matchData.status || '').toLowerCase();
  const minute = matchData.minute;

  // Live матчи
  if (status === 'live' || status === 'in_progress' || status === '1h' || status === '2h') {
    return {
      text: minute ? `${minute}'` : (t ? t('match_in_progress') : 'Идет матч'),
      color: 'text-green-400',
      icon: '🔴',
      badgeVariant: 'destructive'
    };
  }

  // Перерыв
  if (status === 'halftime' || status === 'ht') {
    return {
      text: t ? t('halftime') : 'Перерыв',
      color: 'text-orange-400',
      icon: '⏸️',
      badgeVariant: 'secondary'
    };
  }

  // Завершенные матчи
  if (status === 'finished' || status === 'ft' || status === 'completed') {
    return {
      text: t ? t('finished') : 'Завершен',
      color: 'text-gray-400',
      icon: '⚽',
      badgeVariant: 'outline'
    };
  }

  // Отмененные/отложенные матчи
  if (status === 'cancelled') {
    return {
      text: t ? t('cancelled') : 'Отменен',
      color: 'text-red-400',
      icon: '❌',
      badgeVariant: 'destructive'
    };
  }

  if (status === 'postponed') {
    return {
      text: t ? t('postponed') : 'Отложен',
      color: 'text-yellow-400',
      icon: '⏰',
      badgeVariant: 'secondary'
    };
  }

  // Для upcoming матчей определяем дату
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(today.getDate() + 1);

  let eventDate: Date | null = null;

  // Пытаемся распарсить дату из fullDateTime
  if (matchData.fullDateTime) {
    eventDate = parseFullDateTime(matchData.fullDateTime);
  }

  // Если не удалось из fullDateTime, пытаемся из других полей
  if (!eventDate) {
    const startTime = matchData.start_time || matchData.match_start_time || matchData.created_at;
    if (startTime) {
      try {
        eventDate = new Date(startTime);
      } catch (e) {
        console.warn('Ошибка парсинга startTime:', startTime, e);
      }
    }
  }

  // Если удалось распарсить дату, определяем как показывать
  if (eventDate && !isNaN(eventDate.getTime())) {
    const now = new Date();
    const timeDiffMinutes = Math.floor((eventDate.getTime() - now.getTime()) / (1000 * 60));

    // Матч уже должен был начаться
    if (timeDiffMinutes <= 0) {
      return {
        text: t ? t('soon') : 'Скоро',
        color: 'text-orange-400',
        icon: '⚡',
        badgeVariant: 'secondary'
      };
    }

    // Ближайшие матчи
    if (timeDiffMinutes <= 15) {
      return {
        text: t ? t('soon') : 'Скоро',
        color: 'text-orange-400',
        icon: '⚡',
        badgeVariant: 'secondary'
      };
    }

    if (timeDiffMinutes <= 60) {
      return {
        text: t ? t('in_minutes', { m: timeDiffMinutes }) : `Через ${timeDiffMinutes} мин`,
        color: 'text-blue-400',
        icon: '⏰',
        badgeVariant: 'secondary'
      };
    }

    if (timeDiffMinutes <= 1440) { // Менее суток
      const hours = Math.floor(timeDiffMinutes / 60);
      const minutes = timeDiffMinutes % 60;
      return {
        text: hours > 0
          ? (t ? t('in_hours_minutes', { h: hours, m: minutes }) : `Через ${hours}ч ${minutes}м`)
          : (t ? t('in_minutes', { m: minutes }) : `Через ${minutes} мин`),
        color: 'text-foreground/70',
        icon: '⏰',
        badgeVariant: 'secondary'
      };
    }

    // Проверяем, сегодня ли это
    const isSameDay = eventDate.getDate() === today.getDate() &&
                     eventDate.getMonth() === today.getMonth() &&
                     eventDate.getFullYear() === today.getFullYear();

    // Проверяем, завтра ли это
    const isTomorrow = eventDate.getDate() === tomorrow.getDate() &&
                      eventDate.getMonth() === tomorrow.getMonth() &&
                      eventDate.getFullYear() === tomorrow.getFullYear();

    const timeStr = eventDate.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });

    if (isSameDay) {
      return {
        text: t ? `${t('today_at')} ${timeStr}` : `Сегодня в ${timeStr}`,
        color: 'text-foreground/70',
        icon: '📅',
        badgeVariant: 'secondary'
      };
    }

    if (isTomorrow) {
      return {
        text: t ? `${t('tomorrow_at')} ${timeStr}` : `Завтра в ${timeStr}`,
        color: 'text-foreground/70',
        icon: '📅',
        badgeVariant: 'secondary'
      };
    }

    // Для других дней показываем дату в формате дд.мм время
    const dateStr = eventDate.toLocaleDateString('ru-RU', {
      day: '2-digit',
      month: '2-digit'
    });

    return {
      text: `${dateStr} ${timeStr}`,
      color: 'text-foreground/70',
      icon: '📅',
      badgeVariant: 'secondary'
    };
  }

  // Fallback: показываем как есть
  const fallbackTime = matchData.fullDateTime || matchData.startTime || 'TBD';
  return {
    text: fallbackTime,
    color: 'text-foreground/70',
    icon: '📅',
    badgeVariant: 'secondary'
  };
};

// Функция для создания Badge компонента (для совместимости с HomePage)
export const getStatusBadge = (
  status: string,
  minute?: number,
  fullDateTime?: string,
  startTime?: string,
  t?: (key: string) => string
) => {
  const matchData: MatchTimeData = {
    status,
    minute,
    fullDateTime,
    startTime
  };

  return getMatchStatusAndTime(matchData, t);
};
