"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

interface ParserConfig {
  MAX_RETRIES: number;
  REQUEST_TIMEOUT: number;
  BATCH_SIZE_PAGES: number;
  BATCH_SIZE_PRODUCTS: number;
  BATCH_SIZE_UNQUOTE: number;
  SLEEP_BETWEEN_BATCHES: number;
  SLEEP_ON_CLOUDFLARE: number;
  ACCESS_DENIED_CHECK_INTERVAL: number;
  CONFIG_CHECK_INTERVAL: number;
}

export default function Home() {
  const [config, setConfig] = useState<ParserConfig>({
    MAX_RETRIES: 3,
    REQUEST_TIMEOUT: 120,
    BATCH_SIZE_PAGES: 30,
    BATCH_SIZE_PRODUCTS: 70,
    BATCH_SIZE_UNQUOTE: 250,
    SLEEP_BETWEEN_BATCHES: 3,
    SLEEP_ON_CLOUDFLARE: 30,
    ACCESS_DENIED_CHECK_INTERVAL: 60,
    CONFIG_CHECK_INTERVAL: 5,
  });

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    try {
      const response = await fetch('/api/config');
      const data = await response.json();
      setConfig(data);
      setIsLoading(false);
    } catch (error) {
      toast.error('Ошибка загрузки конфигурации');
      setIsLoading(false);
    }
  };

  const saveConfig = async () => {
    setIsSaving(true);
    try {
      const response = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });

      if (response.ok) {
        toast.success('Конфигурация сохранена!', {
          description: 'Парсер подхватит изменения в течение нескольких секунд'
        });
      } else {
        toast.error('Ошибка сохранения');
      }
    } catch (error) {
      toast.error('Ошибка сохранения конфигурации');
    } finally {
      setIsSaving(false);
    }
  };

  const resetToDefaults = () => {
    setConfig({
      MAX_RETRIES: 3,
      REQUEST_TIMEOUT: 120,
      BATCH_SIZE_PAGES: 30,
      BATCH_SIZE_PRODUCTS: 70,
      BATCH_SIZE_UNQUOTE: 250,
      SLEEP_BETWEEN_BATCHES: 3,
      SLEEP_ON_CLOUDFLARE: 30,
      ACCESS_DENIED_CHECK_INTERVAL: 60,
      CONFIG_CHECK_INTERVAL: 5,
    });
    toast.info('Настройки сброшены к значениям по умолчанию');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Загрузка...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="container mx-auto p-8 max-w-6xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            PlayStation Store Parser Dashboard
          </h1>
          <p className="text-slate-400">
            Управление скоростью парсинга в реальном времени
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 mb-6">
          {/* Batch Sizes */}
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white">📦 Размеры пакетов</CardTitle>
              <CardDescription>Количество элементов в одном пакете</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label className="text-slate-300">Страницы</Label>
                  <Badge variant="secondary">{config.BATCH_SIZE_PAGES}</Badge>
                </div>
                <Slider
                  value={[config.BATCH_SIZE_PAGES]}
                  onValueChange={([value]) => setConfig({ ...config, BATCH_SIZE_PAGES: value })}
                  min={1}
                  max={100}
                  step={1}
                />
                <p className="text-xs text-slate-500">
                  Больше = быстрее, но выше нагрузка
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label className="text-slate-300">Продукты</Label>
                  <Badge variant="secondary">{config.BATCH_SIZE_PRODUCTS}</Badge>
                </div>
                <Slider
                  value={[config.BATCH_SIZE_PRODUCTS]}
                  onValueChange={([value]) => setConfig({ ...config, BATCH_SIZE_PRODUCTS: value })}
                  min={1}
                  max={200}
                  step={5}
                />
                <p className="text-xs text-slate-500">
                  Оптимально: 50-100
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label className="text-slate-300">Разворачивание Concept</Label>
                  <Badge variant="secondary">{config.BATCH_SIZE_UNQUOTE}</Badge>
                </div>
                <Slider
                  value={[config.BATCH_SIZE_UNQUOTE]}
                  onValueChange={([value]) => setConfig({ ...config, BATCH_SIZE_UNQUOTE: value })}
                  min={10}
                  max={500}
                  step={10}
                />
                <p className="text-xs text-slate-500">
                  Можно ставить высокое значение
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Delays */}
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white">⏱️ Задержки</CardTitle>
              <CardDescription>Паузы между запросами (секунды)</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label className="text-slate-300">Между пакетами</Label>
                  <Badge variant="secondary">{config.SLEEP_BETWEEN_BATCHES}с</Badge>
                </div>
                <Slider
                  value={[config.SLEEP_BETWEEN_BATCHES]}
                  onValueChange={([value]) => setConfig({ ...config, SLEEP_BETWEEN_BATCHES: value })}
                  min={0}
                  max={30}
                  step={1}
                />
                <p className="text-xs text-slate-500">
                  Меньше = быстрее, но риск блокировки
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label className="text-slate-300">При Cloudflare</Label>
                  <Badge variant="secondary">{config.SLEEP_ON_CLOUDFLARE}с</Badge>
                </div>
                <Slider
                  value={[config.SLEEP_ON_CLOUDFLARE]}
                  onValueChange={([value]) => setConfig({ ...config, SLEEP_ON_CLOUDFLARE: value })}
                  min={10}
                  max={120}
                  step={5}
                />
                <p className="text-xs text-slate-500">
                  Пауза при обнаружении защиты
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label className="text-slate-300">Проверка доступа</Label>
                  <Badge variant="secondary">{config.ACCESS_DENIED_CHECK_INTERVAL}с</Badge>
                </div>
                <Slider
                  value={[config.ACCESS_DENIED_CHECK_INTERVAL]}
                  onValueChange={([value]) => setConfig({ ...config, ACCESS_DENIED_CHECK_INTERVAL: value })}
                  min={10}
                  max={300}
                  step={10}
                />
                <p className="text-xs text-slate-500">
                  Интервал проверки при блокировке
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Connection Settings */}
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white">🔄 Настройки подключения</CardTitle>
              <CardDescription>Параметры запросов и повторов</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label className="text-slate-300">Максимум попыток</Label>
                  <Badge variant="secondary">{config.MAX_RETRIES}</Badge>
                </div>
                <Slider
                  value={[config.MAX_RETRIES]}
                  onValueChange={([value]) => setConfig({ ...config, MAX_RETRIES: value })}
                  min={1}
                  max={10}
                  step={1}
                />
                <p className="text-xs text-slate-500">
                  Количество повторных попыток при ошибке
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label className="text-slate-300">Таймаут запроса</Label>
                  <Badge variant="secondary">{config.REQUEST_TIMEOUT}с</Badge>
                </div>
                <Slider
                  value={[config.REQUEST_TIMEOUT]}
                  onValueChange={([value]) => setConfig({ ...config, REQUEST_TIMEOUT: value })}
                  min={30}
                  max={300}
                  step={10}
                />
                <p className="text-xs text-slate-500">
                  Время ожидания ответа от сервера
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label className="text-slate-300">Интервал проверки конфига</Label>
                  <Badge variant="secondary">{config.CONFIG_CHECK_INTERVAL}с</Badge>
                </div>
                <Slider
                  value={[config.CONFIG_CHECK_INTERVAL]}
                  onValueChange={([value]) => setConfig({ ...config, CONFIG_CHECK_INTERVAL: value })}
                  min={1}
                  max={60}
                  step={1}
                />
                <p className="text-xs text-slate-500">
                  Как часто парсер проверяет изменения
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Quick Presets */}
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white">⚡ Быстрые пресеты</CardTitle>
              <CardDescription>Готовые конфигурации</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => {
                  setConfig({
                    ...config,
                    BATCH_SIZE_PAGES: 10,
                    BATCH_SIZE_PRODUCTS: 20,
                    BATCH_SIZE_UNQUOTE: 50,
                    SLEEP_BETWEEN_BATCHES: 10,
                  });
                  toast.info('Применен медленный режим');
                }}
              >
                🐌 Медленно и безопасно
              </Button>

              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => {
                  setConfig({
                    ...config,
                    BATCH_SIZE_PAGES: 30,
                    BATCH_SIZE_PRODUCTS: 70,
                    BATCH_SIZE_UNQUOTE: 250,
                    SLEEP_BETWEEN_BATCHES: 3,
                  });
                  toast.info('Применен сбалансированный режим');
                }}
              >
                ⚖️ Сбалансированно (по умолчанию)
              </Button>

              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => {
                  setConfig({
                    ...config,
                    BATCH_SIZE_PAGES: 50,
                    BATCH_SIZE_PRODUCTS: 150,
                    BATCH_SIZE_UNQUOTE: 500,
                    SLEEP_BETWEEN_BATCHES: 1,
                  });
                  toast.warning('Применен быстрый режим (риск блокировки)');
                }}
              >
                🚀 Максимальная скорость
              </Button>

              <div className="pt-4 border-t border-slate-800">
                <Button
                  variant="secondary"
                  className="w-full"
                  onClick={resetToDefaults}
                >
                  Сбросить все настройки
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4">
          <Button
            size="lg"
            className="flex-1"
            onClick={saveConfig}
            disabled={isSaving}
          >
            {isSaving ? 'Сохранение...' : '💾 Сохранить конфигурацию'}
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={loadConfig}
          >
            🔄 Перезагрузить
          </Button>
        </div>

        {/* Info */}
        <Card className="mt-6 bg-blue-950/30 border-blue-900/50">
          <CardContent className="pt-6">
            <div className="flex gap-3">
              <span className="text-2xl">💡</span>
              <div>
                <h3 className="font-semibold text-white mb-1">Как это работает?</h3>
                <p className="text-sm text-slate-400">
                  Парсер автоматически проверяет файл <code className="bg-slate-800 px-1 rounded">parser-config.json</code> каждые {config.CONFIG_CHECK_INTERVAL} секунд.
                  Изменения применяются на лету без перезапуска парсера.
                  Все настройки сохраняются в формате JSON и могут быть отредактированы вручную.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
