import asyncio
import aiohttp
from json import dumps, loads
from random import choice
from bs4 import BeautifulSoup as bs
from time import perf_counter
from re import findall
import re
import asyncpg
from dotenv import load_dotenv
from datetime import datetime
import os
import pickle
from typing import List, Dict, Set, Tuple, Optional
from dataclasses import dataclass
import hashlib
import sys


load_dotenv()


# ==================== MODE CONFIGURATION ====================
# Режим работы:
# False - полный парсинг (по умолчанию)
# True - только загрузка из result.pkl в базу данных
LOAD_MODE = "--load" in sys.argv or "--load-only" in sys.argv

if LOAD_MODE:
    print("=" * 80)
    print("📂 РЕЖИМ ЗАГРУЗКИ ИЗ result.pkl В БАЗУ ДАННЫХ")
    print("=" * 80)
    print("⚠️  Все данные парсера будут удалены и заменены данными из result.pkl")
    print("=" * 80 + "\n")
else:
    print("=" * 80)
    print("🔍 РЕЖИМ ПОЛНОГО ПАРСИНГА")
    print("=" * 80 + "\n")


# ==================== CONFIGURATION ====================
class ParserConfig:
    """Конфигурация парсера с автоматической перезагрузкой из JSON"""

    CONFIG_FILE = "parser-dashboard/public/parser-config.json"

    def __init__(self):
        self.last_modified = 0
        self.load_config()

    def load_config(self):
        """Загружает конфигурацию из JSON файла"""
        try:
            if os.path.exists(self.CONFIG_FILE):
                # Проверяем время модификации
                current_modified = os.path.getmtime(self.CONFIG_FILE)

                if current_modified != self.last_modified:
                    with open(self.CONFIG_FILE, 'r', encoding='utf-8') as f:
                        config = loads(f.read())

                    self.MAX_RETRIES = config.get('MAX_RETRIES', 3)
                    self.REQUEST_TIMEOUT = config.get('REQUEST_TIMEOUT', 120)
                    self.BATCH_SIZE_PAGES = config.get('BATCH_SIZE_PAGES', 30)
                    self.BATCH_SIZE_PRODUCTS = config.get('BATCH_SIZE_PRODUCTS', 70)
                    self.BATCH_SIZE_UNQUOTE = config.get('BATCH_SIZE_UNQUOTE', 250)
                    self.SLEEP_BETWEEN_BATCHES = config.get('SLEEP_BETWEEN_BATCHES', 3)
                    self.SLEEP_ON_CLOUDFLARE = config.get('SLEEP_ON_CLOUDFLARE', 30)
                    self.ACCESS_DENIED_CHECK_INTERVAL = config.get('ACCESS_DENIED_CHECK_INTERVAL', 60)
                    self.CONFIG_CHECK_INTERVAL = config.get('CONFIG_CHECK_INTERVAL', 5)

                    self.last_modified = current_modified

                    if current_modified > 0:
                        print(f"🔄 Конфигурация обновлена: BATCH_PRODUCTS={self.BATCH_SIZE_PRODUCTS}, SLEEP={self.SLEEP_BETWEEN_BATCHES}с")
            else:
                # Значения по умолчанию
                self.set_defaults()
        except Exception as e:
            print(f"⚠️  Ошибка загрузки конфигурации: {e}, используются значения по умолчанию")
            self.set_defaults()

    def set_defaults(self):
        """Устанавливает значения по умолчанию"""
        self.MAX_RETRIES = 3
        self.REQUEST_TIMEOUT = 120
        self.BATCH_SIZE_PAGES = 30
        self.BATCH_SIZE_PRODUCTS = 70
        self.BATCH_SIZE_UNQUOTE = 250
        self.SLEEP_BETWEEN_BATCHES = 3
        self.SLEEP_ON_CLOUDFLARE = 30
        self.ACCESS_DENIED_CHECK_INTERVAL = 60
        self.CONFIG_CHECK_INTERVAL = 5

    # Дополнительные категории для парсинга
    EXTRA_CATEGORIES = [
        "https://store.playstation.com/ru-ua/category/d0446d4b-dc9a-4f1e-86ec-651f099c9b29",
        "https://store.playstation.com/ru-ua/category/30e3fe35-8f2d-4496-95bc-844f56952e3c"
    ]


# Глобальный экземпляр конфигурации
parser_config = ParserConfig()


# ==================== ACCESS CONTROL ====================
class AccessController:
    """Контроллер для управления доступом при блокировках"""

    def __init__(self):
        self.is_blocked = False
        self.test_url = "https://store.playstation.com/ru-ua/pages/browse"

    async def check_access(self, session: aiohttp.ClientSession) -> bool:
        """Проверяет доступность сайта"""
        try:
            async with session.get(self.test_url, headers=get_page_headers(), timeout=aiohttp.ClientTimeout(30)) as resp:
                html = await resp.text()

            # Проверяем только конкретную фразу блокировки Cloudflare
            if "You don't have permission to access" in html:
                return False
            return True
        except:
            return False

    async def wait_for_access(self, session: aiohttp.ClientSession):
        """Ожидает восстановления доступа"""
        if not self.is_blocked:
            self.is_blocked = True
            print("\n" + "=" * 80)
            print("🚫 ОБНАРУЖЕНА БЛОКИРОВКА ДОСТУПА")
            print("=" * 80)
            print(f"⏳ Ожидание восстановления доступа (проверка каждые {parser_config.ACCESS_DENIED_CHECK_INTERVAL} сек)...")

        while True:
            has_access = await self.check_access(session)
            if has_access:
                self.is_blocked = False
                print("\n" + "=" * 80)
                print("✅ ДОСТУП ВОССТАНОВЛЕН")
                print("=" * 80)
                print("🔄 Продолжение парсинга...\n")
                return True

            await asyncio.sleep(parser_config.ACCESS_DENIED_CHECK_INTERVAL)


# Глобальный экземпляр контроллера доступа
access_controller = AccessController()


# ==================== EDITION TYPE NORMALIZER ====================
class EditionTypeNormalizer:
    """Унификация типов изданий"""

    EDITION_MAPPINGS = {
        "Полная версия игры": "Игра",
        "PS2 HD+": "Игра",
        "Полная ознакомительная версия игры": "Демо",
        "Демоверсия": "Демо",
        "Набор": "Набор",
        "Сезонный абонемент": "Season Pass",
        "Пакет": "Дополнение",
        "Дополнение": "Дополнение",
        "Валюта игры": "Внутриигровая валюта",
        "Косметический предмет": "Косметика",
    }

    EDITION_NAMES = {
        "deluxe": "Deluxe Edition",
        "premium": "Premium Edition",
        "ultimate": "Ultimate Edition",
        "gold": "Gold Edition",
        "standard": "Standard Edition",
        "complete": "Complete Edition",
        "goty": "Game of the Year Edition",
        "digital deluxe": "Digital Deluxe Edition",
        "season pass": "Season Pass",
        "collectors": "Collector's Edition",
        "limited": "Limited Edition",
        "definitive": "Definitive Edition",
        "enhanced": "Enhanced Edition",
    }

    @staticmethod
    def normalize_type(product_type: str) -> str:
        """Нормализует тип продукта"""
        if not product_type:
            return "Игра"

        product_type_lower = product_type.lower()

        # Проверяем точные совпадения
        if product_type in EditionTypeNormalizer.EDITION_MAPPINGS:
            return EditionTypeNormalizer.EDITION_MAPPINGS[product_type]

        # Проверяем подстроки
        if "подписка" in product_type_lower:
            return "Подписка"
        if "демо" in product_type_lower or "demo" in product_type_lower:
            return "Демо"
        if "предзаказ" in product_type_lower:
            return "Предзаказ"
        if "дополнение" in product_type_lower or "dlc" in product_type_lower:
            return "DLC"
        if "набор" in product_type_lower or "bundle" in product_type_lower:
            return "Набор"
        if "валюта" in product_type_lower or "points" in product_type_lower or "баксы" in product_type_lower:
            return "Внутриигровая валюта"

        return "Игра"

    @staticmethod
    def extract_edition_name(name: str, edition: str, main_name: str) -> Tuple[str, str]:
        """
        Извлекает правильное название игры и издания
        Возвращает кортеж (очищенное_название_игры, название_издания)
        """
        # Разделители для отделения названия издания от названия игры
        separators = ['—', '–', '-', ':', '|']

        # Ключевые слова для изданий (расширенный список)
        edition_keywords = {
            # Основные издания
            'deluxe': 'Deluxe Edition',
            'premium': 'Premium Edition',
            'ultimate': 'Ultimate Edition',
            'gold': 'Gold Edition',
            'standard': 'Standard Edition',
            'complete': 'Complete Edition',
            'goty': 'Game of the Year Edition',
            'game of the year': 'Game of the Year Edition',
            'digital deluxe': 'Digital Deluxe Edition',
            'season pass': 'Season Pass',
            'collectors': "Collector's Edition",
            'collector\'s': "Collector's Edition",
            'limited': 'Limited Edition',
            'definitive': 'Definitive Edition',
            'enhanced': 'Enhanced Edition',
            'remastered': 'Remastered Edition',
            'remake': 'Remake Edition',
            'special': 'Special Edition',

            # Классические и переиздания
            'classic': 'Classic Edition',
            'classics': 'Classic Edition',
            'legacy': 'Legacy Edition',  # ← ВАЖНОЕ ДОБАВЛЕНИЕ!
            'anniversary': 'Anniversary Edition',
            'legendary': 'Legendary Edition',
            'platinum': 'Platinum Edition',
            'vintage': 'Vintage Edition',
            'retro': 'Retro Edition',
            'original': 'Original Edition',

            # Расширенные издания
            'royal': 'Royal Edition',
            'royale': 'Royale Edition',
            'master': 'Master Edition',
            'champion': 'Champion Edition',
            'champion\'s': "Champion's Edition",
            'galactic': 'Galactic Edition',
            'cosmic': 'Cosmic Edition',
            'atomic': 'Atomic Edition',

            # Специальные издания
            'founder': 'Founder Edition',
            'founders': 'Founder Edition',
            'pre-order': 'Pre-Order Edition',
            'preorder': 'Pre-Order Edition',
            'day one': 'Day One Edition',
            'launch': 'Launch Edition',
            'exclusive': 'Exclusive Edition',
            'director\'s cut': "Director's Cut",
            'directors cut': "Director's Cut",

            # Комплекты
            'bundle': 'Bundle',
            'набор': 'Bundle',
            'mega bundle': 'Mega Bundle',
            'super bundle': 'Super Bundle',

            # Расширенные версии
            'extended': 'Extended Edition',
            'expanded': 'Expanded Edition',
            'ultimate collector\'s': "Ultimate Collector's Edition",
            'ultimate collectors': "Ultimate Collector's Edition",

            # VR издания
            'vr edition': 'VR Edition',
            'vr': 'VR Edition',
            'playstation vr': 'PlayStation VR Edition',

            # Русские названия
            'полное издание': 'Complete Edition',
            'полная версия': 'Complete Edition',
            'делюкс': 'Deluxe Edition',
            'премиум': 'Premium Edition',
            'золотое издание': 'Gold Edition',
            'коллекционное': "Collector's Edition",
            'расширенное': 'Extended Edition',
            'классическое': 'Classic Edition',

            # Generic markers (должны быть в конце)
            'издание': '',
            'edition': '',
        }

        # Ключевые слова DLC
        dlc_keywords = [
            'длс', 'dlc', 'дополнение', 'expansion', 'расширение',
            'пакет', 'pack', 'content', 'контент'
        ]

        # Пробуем разобрать название игры
        clean_name = name.strip()
        edition_part = ""

        # Проверяем наличие разделителей
        for separator in separators:
            if separator in clean_name:
                parts = clean_name.split(separator)
                if len(parts) >= 2:
                    # Первая часть - название игры
                    game_part = parts[0].strip()
                    # Остальное - потенциальное название издания
                    potential_edition = separator.join(parts[1:]).strip()

                    # Проверяем, является ли это изданием или DLC
                    potential_lower = potential_edition.lower()

                    # Проверка на DLC
                    is_dlc = any(keyword in potential_lower for keyword in dlc_keywords)

                    # Проверка на ключевые слова изданий
                    found_edition = None
                    for keyword, edition_name in edition_keywords.items():
                        if keyword in potential_lower:
                            if edition_name:
                                found_edition = edition_name
                            else:
                                # Если нашли generic keyword, используем сам текст
                                found_edition = potential_edition
                            break

                    if found_edition:
                        clean_name = game_part
                        edition_part = found_edition
                        break
                    elif is_dlc:
                        # Это DLC, оставляем как есть
                        clean_name = game_part
                        edition_part = potential_edition
                        break
                    # Если не нашли ключевые слова издания или DLC,
                    # значит это просто подзаголовок игры (например, "Miles Morales")
                    # Оставляем полное название и не вырезаем ничего

        # Если не нашли разделители, проверяем наличие ключевых слов в самом названии
        if not edition_part:
            name_lower = clean_name.lower()
            for keyword, edition_name in edition_keywords.items():
                if keyword in name_lower:
                    # Пытаемся вырезать ключевое слово и все после него
                    idx = name_lower.find(keyword)
                    if idx > 0:
                        clean_name = clean_name[:idx].strip()
                        edition_part = edition_name if edition_name else clean_name[idx:].strip()
                    elif edition_name:
                        edition_part = edition_name
                    break

        # Очистка от специальных символов в конце
        clean_name = clean_name.rstrip(' -—–:|')

        # Если edition_part пустой, проверяем параметр edition
        if not edition_part and edition and edition.strip():
            edition_lower = edition.lower()

            # Проверяем ключевые слова
            for keyword, edition_name in edition_keywords.items():
                if keyword in edition_lower:
                    edition_part = edition_name if edition_name else edition
                    break

            # Если не нашли ключевые слова, но edition != name
            if not edition_part and edition != name and edition != main_name:
                edition_part = edition

        # Финальная проверка
        if not edition_part or edition_part.strip() == "":
            edition_part = "Standard Edition"

        return (clean_name, edition_part)


# ==================== DUPLICATE DETECTOR ====================
class DuplicateDetector:
    """Детектор дубликатов продуктов"""

    def __init__(self):
        self.seen_urls: Set[str] = set()
        self.seen_products: Set[str] = set()
        self.seen_hashes: Set[str] = set()

    def is_duplicate_url(self, url: str) -> bool:
        """Проверяет, является ли URL дубликатом"""
        normalized_url = self._normalize_url(url)
        if normalized_url in self.seen_urls:
            return True
        self.seen_urls.add(normalized_url)
        return False

    def is_duplicate_product(self, name: str, edition: str, platforms: List[str], description: str) -> bool:
        """Проверяет, является ли продукт дубликатом (используется после парсинга)"""
        product_key = (
            name.strip().lower(),
            edition.strip().lower() if edition else "",
            " ".join(sorted(platforms)) if platforms else "",
            (description[:100] if description else "").strip().lower()
        )

        if product_key in self.seen_products:
            return True
        self.seen_products.add(product_key)
        return False

    def get_product_hash(self, product: Dict) -> str:
        """Создает хэш продукта для проверки дубликатов"""
        hash_string = f"{product.get('name', '')}_{product.get('edition', '')}_{product.get('platforms', '')}_{product.get('id', '')}"
        return hashlib.md5(hash_string.encode()).hexdigest()

    def is_duplicate_hash(self, product_hash: str) -> bool:
        """Проверяет дубликат по хэшу"""
        if product_hash in self.seen_hashes:
            return True
        self.seen_hashes.add(product_hash)
        return False

    @staticmethod
    def _normalize_url(url: str) -> str:
        """Нормализует URL для сравнения"""
        url = url.lower().strip()
        # Убираем trailing slash
        url = url.rstrip('/')
        # Убираем query параметры для некоторых URL
        if '?' in url and 'concept' not in url and 'product' not in url:
            url = url.split('?')[0]
        return url


# ==================== UTILITY FUNCTIONS ====================
def format_time(seconds: float) -> str:
    """Форматирует секунды в читаемый формат (Ч:ММ:СС)"""
    if seconds < 0:
        return "0:00:00"

    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)

    if hours > 0:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    else:
        return f"{minutes}:{secs:02d}"


def print_progress_bar(current: int, total: int, elapsed: float, prefix: str = "", suffix: str = ""):
    """Выводит прогресс-бар с ETA"""
    if total == 0:
        return

    progress = current / total
    percent = progress * 100

    # Рассчитываем ETA
    if current > 0 and progress > 0:
        avg_time_per_item = elapsed / current
        remaining_items = total - current
        eta_seconds = avg_time_per_item * remaining_items
        eta_str = format_time(eta_seconds)
    else:
        eta_str = "расчет..."

    # Прогресс-бар
    bar_length = 40
    filled_length = int(bar_length * progress)
    bar = '█' * filled_length + '░' * (bar_length - filled_length)

    # Скорость
    items_per_sec = current / elapsed if elapsed > 0 else 0

    print(f"\r{prefix} |{bar}| {percent:.1f}% [{current}/{total}] | "
          f"⏱️ {format_time(elapsed)} | 🚀 {items_per_sec:.1f}/с | ⏳ ETA: {eta_str} {suffix}",
          end='', flush=True)


# ==================== HEADER GENERATORS ====================
def get_random_user_agent() -> str:
    """Возвращает случайный User-Agent"""
    return choice([
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    ])


def get_json_headers(url: str) -> Dict[str, str]:
    """Генерирует заголовки для JSON запросов"""
    return {
        "Accept": "application/json",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "en-US,ru;q=0.9",
        "apollographql-client-name": "@sie-private/web-commerce-anywhere",
        "apollographql-client-version": "3.23.0",
        "Cache-Control": "no-cache",
        "Content-Type": "application/json",
        "disable_query_whitelist": "false",
        "Origin": "https://store.playstation.com",
        "Pragma": "no-cache",
        "Priority": "u=1, i",
        "Referer": "https://store.playstation.com/",
        "sec-ch-ua": '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "User-Agent": get_random_user_agent(),
        "x-psn-app-ver": "@sie-private/web-commerce-anywhere/3.23.0-d3947b39a30477ef83ad9e5fc7f3f6a72e17bb6b",
        "x-psn-store-locale-override": url.split("/")[-3] if len(url.split("/")) > 3 else "ru-ua"
    }


def get_page_headers() -> Dict[str, str]:
    """Генерирует заголовки для страниц"""
    return {
        "authority": "store.playstation.com",
        "method": "GET",
        "scheme": "https",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "accept-encoding": "gzip, deflate, br, zstd",
        "accept-language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
        "cache-control": "no-cache",
        "pragma": "no-cache",
        "priority": "u=0, i",
        "sec-ch-ua": '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "same-origin",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "user-agent": get_random_user_agent()
    }


# ==================== QUERY PARAMETERS ====================
def get_params(url: str) -> List[Dict]:
    """Получает параметры запроса на основе URL"""
    product_type, sku = url.split("/")[-2:]
    queries = {
        "concept": {
            "operationName": "conceptRetrieveForCtasWithPrice",
            "variables": dumps({"conceptId": sku}),
            "extensions": dumps({
                "persistedQuery": {
                    "version": 1,
                    "sha256Hash": "eab9d873f90d4ad98fd55f07b6a0a606e6b3925f2d03b70477234b79c1df30b5"
                }
            })
        },
        "product": [
            {
                "operationName": "productRetrieveForCtasWithPrice",
                "variables": dumps({"productId": sku}),
                "extensions": dumps({
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "8872b0419dcab2fea5916ef698544c237b1096f9e76acc6aacf629551adee8cd"
                    }
                })
            },
            {
                "operationName": "productRetrieveForUpsellWithCtas",
                "variables": dumps({"productId": sku}),
                "extensions": dumps({
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "fb0bfa0af4d8dc42b28fa5c077ed715543e7fb8a3deff8117a50b99864d246f1"
                    }
                })
            }
        ]
    }
    return queries[product_type]


async def get_tr_data(session: aiohttp.ClientSession, tr_url: str, params: Dict) -> Optional[Dict]:
    """
    Получает TR данные по точному product ID с fallback на перебор последней цифры CUSA
    """
    # Сначала пробуем точный product ID
    try:
        async with session.get(
            "https://web.np.playstation.com/api/graphql/v1/op",
            params=params,
            headers=get_json_headers(tr_url),
            timeout=aiohttp.ClientTimeout(30)
        ) as resp:
            text = await resp.text()
            data = loads(text)

            # Проверяем успешность запроса
            if data.get("data") and data["data"].get("productRetrieve"):
                return data
    except Exception:
        pass

    # Если не получилось, пробуем варианты CUSA с разными последними цифрами
    # Извлекаем product_id из params
    try:
        params_dict = loads(params.get("variables", "{}")) if isinstance(params.get("variables"), str) else params.get("variables", {})
        original_product_id = params_dict.get("productId", "")

        if original_product_id and "CUSA" in original_product_id:
            # Ищем CUSA в product_id (формат: EP0001-CUSA05848_00-FARCRY5GAME00000)
            import re
            match = re.search(r'(CUSA\d{4})(\d)', original_product_id)

            if match:
                cusa_base = match.group(1)  # CUSA05848 -> CUSA0584
                last_digit = match.group(2)  # 8

                # Перебираем цифры от 0 до 9, кроме уже проверенной
                for digit in range(10):
                    if str(digit) == last_digit:
                        continue  # Уже проверили

                    # Формируем новый product_id с другой последней цифрой
                    new_product_id = original_product_id.replace(
                        f"{cusa_base}{last_digit}",
                        f"{cusa_base}{digit}"
                    )

                    # Формируем новые params
                    new_params_dict = params_dict.copy()
                    new_params_dict["productId"] = new_product_id

                    new_params = params.copy()
                    new_params["variables"] = dumps(new_params_dict)

                    try:
                        async with session.get(
                            "https://web.np.playstation.com/api/graphql/v1/op",
                            params=new_params,
                            headers=get_json_headers(tr_url),
                            timeout=aiohttp.ClientTimeout(30)
                        ) as resp:
                            text = await resp.text()
                            data = loads(text)

                            # Проверяем успешность запроса
                            if data.get("data") and data["data"].get("productRetrieve"):
                                print(f"  ✓ TR CUSA fallback: {original_product_id} -> {new_product_id}")
                                return data
                    except Exception:
                        continue
    except Exception:
        pass

    return None


# ==================== PAGE PARSERS ====================
async def get_pages(session: aiohttp.ClientSession, url: str) -> List[str]:
    """Получает список страниц категории"""
    try:
        async with session.get(url, headers=get_page_headers()) as resp:
            html = await resp.text()

        if "You don't have permission to access" in html:
            print(f"⚠️  Обнаружена блокировка на {url}")
            await access_controller.wait_for_access(session)
            # Повторяем запрос после восстановления доступа
            return await get_pages(session, url)

        soup = bs(html, "html.parser")
        _main = soup.find("div", {"id": "__next"})
        if not _main:
            return []

        _main = _main.find("main")
        if not _main:
            return []

        section = _main.find("section", {"class": "ems-sdk-grid"})
        if not section:
            return [url]

        psw = section.find("div", {"class": "psw-l-stack-center"})
        if not psw:
            return [url]

        nav = psw.find("nav")
        if not nav:
            return [url]

        ol = nav.find("ol")
        if not ol:
            return [url]

        items = ol.find_all("li")
        if not items:
            return [url]

        count = int(items[-1].find("span").text)
        return [f"{url}/{i}" for i in range(1, count + 1)]

    except (asyncio.CancelledError, KeyboardInterrupt):
        return []
    except Exception as e:
        print(f"❌ Error getting pages from {url}: {e}")
        return []


async def get_products(session: aiohttp.ClientSession, url: str) -> List[str]:
    """Получает список продуктов со страницы"""
    for attempt in range(parser_config.MAX_RETRIES):
        try:
            async with session.get(url, headers=get_page_headers()) as resp:
                html = await resp.text()

            if "You don't have permission to access" in html:
                await access_controller.wait_for_access(session)
                # Повторяем запрос после восстановления доступа
                continue

            soup = bs(html, "html.parser")
            _main = soup.find("div", {"id": "__next"})
            if not _main:
                continue

            _main = _main.find("main")
            if not _main:
                continue

            section = _main.find("section", {"class": "ems-sdk-grid"})
            if not section:
                continue

            ul = section.find("ul", {"class": "psw-grid-list psw-l-grid"})
            if not ul:
                continue

            products = ul.find_all("li")
            return ["https://store.playstation.com" + i.find("a")["href"] for i in products if i.find("a")]

        except (asyncio.CancelledError, KeyboardInterrupt):
            return []
        except Exception as e:
            if attempt == parser_config.MAX_RETRIES - 1:
                print(f"❌ Failed to get products from {url}: {e}")
            await asyncio.sleep(2)

    return []


async def unquote(session: aiohttp.ClientSession, url: str) -> List[str]:
    """Разворачивает concept URL в product URL"""
    try:
        if "product" in url:
            return [url]

        async with session.get(
            "https://web.np.playstation.com/api/graphql/v1/op",
            headers=get_json_headers(url),
            params=get_params(url)
        ) as resp:
            text = await resp.text()

        json_data = loads(text)
        products = json_data.get("data", {}).get("conceptRetrieve", {}).get("products", [])

        if not products:
            return []

        base_url = "/".join(url.split("/")[:4])
        return [f'{base_url}/product/{product["id"]}' for product in products]

    except (asyncio.CancelledError, KeyboardInterrupt):
        return []
    except Exception:
        return []


# ==================== PRODUCT PARSER ====================
async def get_ext_data(session: aiohttp.ClientSession, product_id: str) -> Optional[Tuple]:
    """Получает расширенные данные о продукте"""
    counter = 0

    while counter < parser_config.MAX_RETRIES:
        try:
            async with session.get(
                f"https://store.playstation.com/ru-ua/product/{product_id}",
                headers=get_page_headers()
            ) as resp:
                text = await resp.text()

            if "You don't have permission to access" in text:
                counter = 0
                await access_controller.wait_for_access(session)
                continue

            soup = bs(text, "html.parser")
            _main = soup.find("main")
            if not _main:
                counter += 1
                await asyncio.sleep(3)
                continue

            pdp = _main.find("div", {"class": "pdp-main psw-dark-theme"})
            if not pdp:
                counter += 1
                await asyncio.sleep(3)
                continue

            psw_elements = pdp.find_all("div", {"class": "psw-m-t-10 psw-fill-x"})
            psw = None
            for _psw in psw_elements:
                if _psw.find("div", {"class": "pdp-info"}):
                    psw = _psw
                    break

            if not psw:
                counter += 1
                await asyncio.sleep(3)
                continue

            game_info = psw.find("div", {"data-qa": "gameInfo"})
            if not game_info:
                counter += 1
                await asyncio.sleep(3)
                continue

            dl = game_info.find("dl")
            if not dl:
                counter += 1
                await asyncio.sleep(3)
                continue

            # Extract JSON data
            json_script = soup.find("script", {"id": "__NEXT_DATA__", "type": "application/json"})
            if not json_script:
                counter += 1
                await asyncio.sleep(3)
                continue

            json_data = loads(json_script.text)

            # Extract platforms
            platforms = None
            platform_elem = dl.find("dd", {"data-qa": "gameInfo#releaseInformation#platform-value"})
            if platform_elem:
                platforms = [p.strip() for p in platform_elem.text.split(',')]

            # Extract publisher
            publisher = None
            publisher_elem = dl.find("dd", {"data-qa": "gameInfo#releaseInformation#publisher-value"})
            if publisher_elem:
                publisher = publisher_elem.text.strip()

            # Extract voice languages
            voice_languages = ""
            for qa in ["gameInfo#releaseInformation#voice-value",
                      "gameInfo#releaseInformation#ps5Voice-value",
                      "gameInfo#releaseInformation#ps4Voice-value"]:
                elem = dl.find("dd", {"data-qa": qa})
                if elem:
                    voice_languages += elem.text

            # Extract subtitles
            subtitles = ""
            for qa in ["gameInfo#releaseInformation#subtitles-value",
                      "gameInfo#releaseInformation#ps5Subtitles-value",
                      "gameInfo#releaseInformation#ps4Subtitles-value"]:
                elem = dl.find("dd", {"data-qa": qa})
                if elem:
                    subtitles += elem.text

            # Extract description
            description = ""
            overview = json_data.get("props", {}).get("pageProps", {}).get("batarangs", {}).get("overview", {})
            if overview and "text" in overview:
                description = bs(overview["text"], "html.parser").get_text("\n\n", strip=True)

            # Extract ext_info
            ext_info = ""
            compat = json_data.get("props", {}).get("pageProps", {}).get("batarangs", {}).get("compatibility-notices", {})
            if compat and "text" in compat:
                _tmp = findall(r">([^<]+)</", compat["text"])
                if len(_tmp) > 1:
                    ext_info = dumps(_tmp[1:])

            return (product_id, platforms, publisher, voice_languages, subtitles, description, ext_info, json_data)

        except (asyncio.CancelledError, KeyboardInterrupt):
            return None
        except Exception as e:
            counter += 1
            await asyncio.sleep(3)

    return None


async def parse_product(session: aiohttp.ClientSession, url: str, duplicate_detector: DuplicateDetector) -> List[Dict]:
    """Парсит информацию о продукте"""
    params_price, params = get_params(url)

    tr_url_parts = url.split("/")
    tr_url_parts[3] = "en-tr"
    tr_url = "/".join(tr_url_parts)

    for attempt in range(parser_config.MAX_RETRIES):
        try:
            # Get UA data
            async with session.get(
                "https://web.np.playstation.com/api/graphql/v1/op",
                params=params,
                headers=get_json_headers(url)
            ) as ua_resp:
                ua_text = await ua_resp.text()

            async with session.get(
                "https://web.np.playstation.com/api/graphql/v1/op",
                params=params_price,
                headers=get_json_headers(url)
            ) as ua_resp_price:
                ua_price_text = await ua_resp_price.text()

            ua = loads(ua_text)
            ua_price = loads(ua_price_text)

            if "errors" in ua or not ua.get("data", {}).get("productRetrieve"):
                return []

            product_retrieve = ua["data"]["productRetrieve"]

            # Check if it's an addon
            is_addon = product_retrieve.get("topCategory") == "ADD_ON"

            ua_products = []
            ua_price_product = []

            if not is_addon and product_retrieve.get("concept", {}).get("products"):
                ua_products = product_retrieve["concept"]["products"]

                # Получаем TR данные
                tr_price = await get_tr_data(session, tr_url, params)
                if not tr_price:
                    # Если нет данных для TR, создаем пустую структуру
                    tr_price = {"data": {"productRetrieve": {}}}
            else:
                ua_price_product = ua_price["data"]["productRetrieve"]

                # Получаем TR данные
                tr_price = await get_tr_data(session, tr_url, params_price)
                if not tr_price:
                    # Если нет данных для TR, создаем пустую структуру
                    tr_price = {"data": {"productRetrieve": {}}}

            if not tr_price or not tr_price.get("data", {}).get("productRetrieve"):
                # Если TR недоступен, продолжаем только с UA данными
                tr_price = {"data": {"productRetrieve": {}}}

            # Get TR price products
            tr_price_data = tr_price["data"]["productRetrieve"]
            tr_price_products = []

            if "concept" in tr_price_data and "products" in tr_price_data["concept"]:
                tr_price_products = tr_price_data["concept"]["products"]
            elif "webctas" in tr_price_data:
                tr_price_products = [tr_price_data]

            main_name = product_retrieve.get("concept", {}).get("name", "")

            result = []
            tags = [main_name] if main_name else []

            # Process products
            if ua_products:
                # Get extended data for all products
                ext_data_list = await asyncio.gather(*[
                    get_ext_data(session, p["id"]) for p in ua_products
                ])
                ext_data = {data[0]: data[1:] for data in ext_data_list if data}

                for product in ua_products:
                    product_id = product["id"]

                    if product_id not in ext_data:
                        continue

                    platforms, publisher, voice_languages, subtitles, description, ext_info, json_data = ext_data[product_id]

                    if not publisher:
                        continue

                    # Extract rating
                    stars = 0.0
                    try:
                        star_rating_text = json_data.get("props", {}).get("pageProps", {}).get("batarangs", {}).get("star-rating", {}).get("text", "")
                        if star_rating_text:
                            stars_json = loads(findall(r">([^<]+)</", star_rating_text)[0])
                            stars = stars_json.get("cache", {}).get(f"Product:{product_id}", {}).get("starRating", {}).get("averageRating", 0.0)
                    except:
                        stars = 0.0

                    name = product.get("name", "")

                    # Determine category
                    category = []
                    if product.get("localizedGenres"):
                        category = list(set(genre["value"] for genre in product["localizedGenres"]))

                    # Determine product type
                    product_type = ""
                    if "Подписка" in name:
                        product_type = "Подписка"
                    elif product.get("skus") and len(product["skus"]) > 0:
                        sku_name = product["skus"][0].get("name", "").lower()
                        if sku_name not in ["демоверсия", "полная ознакомительная версия игры"]:
                            product_type = product["skus"][0].get("name", "")
                        elif len(product["skus"]) > 1:
                            product_type = product["skus"][1].get("name", "")

                    if not product_type or product_type.lower() in ["демоверсия", "полная ознакомительная версия игры"]:
                        product_type = "Игра"

                    # Normalize product type
                    product_type = EditionTypeNormalizer.normalize_type(product_type)

                    # Get image
                    image = ""
                    media = product.get("media", [])
                    if not media:
                        media = tr_price.get("data", {}).get("productRetrieve", {}).get("concept", {}).get("media", [])

                    for img in media:
                        if img.get("role") == "MASTER":
                            image = img.get("url", "")
                            break

                    # Add tags
                    if name not in tags:
                        tags.append(name)

                    invariant_name = product.get("invariantName", "")
                    if invariant_name and invariant_name != name and invariant_name not in tags:
                        tags.append(invariant_name)

                    # Process prices
                    price_data = extract_prices(product.get("webctas", []))
                    tr_price_data = {}

                    # Find matching TR product (with fallback to partial ID match)
                    for tr_product in tr_price_products:
                        tr_id = tr_product.get("id", "")
                        # Сначала проверяем точное совпадение
                        if tr_id == product_id:
                            tr_price_data = extract_tr_prices(tr_product.get("webctas", []))
                            if tr_price_data.get("trl_price"):
                                print(f"  ✓ TR exact match: {product_id} -> {tr_price_data.get('trl_price')} TRL")
                            break
                        # Fallback: сравниваем ID без последней цифры (как в старом коде)
                        # Проверяем, есть ли точное совпадение хотя бы у одного продукта
                        has_exact_match = any(tr["id"] == product_id for tr in tr_price_products)
                        if not has_exact_match:
                            # Если нет точного совпадения, используем частичное
                            eq_id = tr_id.split("-")[-1][:-1] == product_id.split("-")[-1][:-1]
                            if eq_id:
                                tr_price_data = extract_tr_prices(tr_product.get("webctas", []))
                                if tr_price_data.get("trl_price"):
                                    print(f"  ✓ TR fallback match: {product_id} -> {tr_id} -> {tr_price_data.get('trl_price')} TRL")
                                break

                    # Get edition info
                    edition_obj = product.get("edition")
                    compound = ""
                    edition_name = ""

                    if edition_obj:
                        if edition_obj.get("features"):
                            compound = dumps(edition_obj["features"])
                        edition_name = edition_obj.get("name", "")
                        if not edition_name:
                            edition_name = name

                    # Extract proper edition name and clean game name
                    clean_name, edition_name = EditionTypeNormalizer.extract_edition_name(name, edition_name, main_name)
                    # Используем очищенное название игры
                    name = clean_name

                    # Calculate localization
                    # None - нет информации о языках (блок локализации не показываем)
                    # 1 - есть русская озвучка и субтитры
                    # 2 - есть только русская озвучка
                    # 3 - есть только русские субтитры
                    # 4 - нет русского языка (показываем "Нет русского языка")
                    localization = None

                    has_voice_info = voice_languages and voice_languages.strip()
                    has_subtitle_info = subtitles and subtitles.strip()

                    if has_voice_info or has_subtitle_info:
                        # Есть информация о языках
                        localization = 4  # По умолчанию "нет русского"

                        if has_voice_info and "русский" in voice_languages.lower():
                            localization -= 2
                        if has_subtitle_info and "русский" in subtitles.lower():
                            localization -= 1
                    # Если нет информации вообще, localization остается None

                    # Clean tags
                    cleaned_tags = clean_tags(tags)

                    # Не проверяем дубликаты здесь - будем проверять после парсинга всех продуктов
                    if product_type:
                        product_dict = {
                            "id": product_id,
                            "category": category,
                            "type": product_type,
                            "name": name,
                            "main_name": main_name,
                            "image": image,
                            "compound": compound,
                            "platforms": platforms,
                            "publisher": publisher,
                            "localization": localization,
                            "rating": stars,
                            "info": ext_info,
                            **price_data,
                            **tr_price_data,
                            "tags": set(cleaned_tags),
                            "edition": edition_name,
                            "description": description
                        }

                        result.append(product_dict)

            else:
                # Process single product (addon)
                product_id = ua_price_product.get("id", "")
                ext_data_tuple = await get_ext_data(session, product_id)

                if not ext_data_tuple:
                    return result

                _, platforms, publisher, voice_languages, subtitles, description, ext_info, json_data = ext_data_tuple

                if not publisher:
                    return result

                # Extract rating
                stars = 0.0
                try:
                    star_rating_text = json_data.get("props", {}).get("pageProps", {}).get("batarangs", {}).get("star-rating", {}).get("text", "")
                    if star_rating_text:
                        stars_json = loads(findall(r">([^<]+)</", star_rating_text)[0])
                        stars = stars_json.get("cache", {}).get(f"Product:{product_id}", {}).get("starRating", {}).get("averageRating", 0.0)
                except:
                    stars = 0.0

                name = ua_price_product.get("name", "")
                category = [ua_price_product["skus"][0]["name"]] if ua_price_product.get("skus") else []
                product_type = EditionTypeNormalizer.normalize_type("Дополнение")

                # Get image
                image = ""
                try:
                    bg_image_text = json_data.get("props", {}).get("pageProps", {}).get("batarangs", {}).get("background-image", {}).get("text", "")
                    if bg_image_text:
                        image_json = loads(findall(r">([^<]+)</", bg_image_text)[0])
                        media = image_json.get("cache", {}).get(f"Product:{product_id}", {}).get("media", [])
                        for img in media:
                            if img.get("role") == "MASTER":
                                image = img.get("url", "")
                                break
                except:
                    pass

                compound = ""

                # Tags
                tags = [main_name, name]
                invariant_name = ua_price_product.get("invariantName", "")
                if invariant_name and invariant_name != name:
                    tags.append(invariant_name)

                # Prices
                price_data = extract_prices(ua_price_product.get("webctas", []))

                # TR prices (exact match by ID only)
                tr_price_data = {}
                if isinstance(tr_price_products, list) and len(tr_price_products) > 0:
                    for tr_prod in tr_price_products:
                        if tr_prod.get("id") == product_id:
                            tr_price_data = extract_tr_prices(tr_prod.get("webctas", []))
                            if tr_price_data.get("trl_price"):
                                print(f"  ✓ TR addon match: {product_id} -> {tr_price_data.get('trl_price')} TRL")
                            break

                edition_name_raw = ua_price_product["skus"][0]["name"] if ua_price_product.get("skus") else ""
                clean_name, edition_name = EditionTypeNormalizer.extract_edition_name(name, edition_name_raw, main_name)
                # Используем очищенное название игры
                name = clean_name

                # Localization
                # None - нет информации о языках (блок локализации не показываем)
                # 1 - есть русская озвучка и субтитры
                # 2 - есть только русская озвучка
                # 3 - есть только русские субтитры
                # 4 - нет русского языка (показываем "Нет русского языка")
                localization = None

                has_voice_info = voice_languages and voice_languages.strip()
                has_subtitle_info = subtitles and subtitles.strip()

                if has_voice_info or has_subtitle_info:
                    # Есть информация о языках
                    localization = 4  # По умолчанию "нет русского"

                    if has_voice_info and "русский" in voice_languages.lower():
                        localization -= 2
                    if has_subtitle_info and "русский" in subtitles.lower():
                        localization -= 1
                # Если нет информации вообще, localization остается None

                cleaned_tags = clean_tags(tags)

                # Не проверяем дубликаты здесь - будем проверять после парсинга всех продуктов
                if True:
                        result.append({
                            "id": product_id,
                            "category": category,
                            "type": product_type,
                            "name": name,
                            "main_name": main_name,
                            "image": image,
                            "compound": compound,
                            "platforms": platforms,
                            "publisher": publisher,
                            "localization": localization,
                            "rating": stars,
                            "info": ext_info,
                            **price_data,
                            **tr_price_data,
                            "tags": set(cleaned_tags),
                            "edition": edition_name,
                            "description": description
                        })

            return result

        except (asyncio.CancelledError, KeyboardInterrupt):
            return []
        except Exception as e:
            if attempt == parser_config.MAX_RETRIES - 1:
                print(f"❌ Failed to parse {url}: {e}")
            await asyncio.sleep(3)

    return []


def extract_prices(webctas: List[Dict]) -> Dict:
    """Извлекает информацию о ценах из webctas"""
    result = {
        "uah_price": 0,
        "uah_old_price": 0,
        "ps_price_ua": None,
        "ea_price_ua": None,
        "discount": "",
        "discount_end": None,
        "ps_plus": False,
        "ea_access": False,
    }

    for cta in webctas:
        cta_type = cta.get("type", "")
        price_info = cta.get("price", {})

        is_purchase = cta_type in ["ADD_TO_CART", "PREORDER", "BUY_NOW"]
        is_upsell = "UPSELL" in cta_type and ("EA_ACCESS" in cta_type or "PS_PLUS" in cta_type) and "TRIAL" not in cta_type

        if is_purchase or is_upsell:
            discounted = price_info.get("discountedPrice")
            base = price_info.get("basePrice")

            if is_purchase and discounted and not result["uah_price"]:
                result["uah_price"] = price_info.get("discountedValue", 0) / 100

            if is_purchase and base and not result["uah_old_price"]:
                result["uah_old_price"] = price_info.get("basePriceValue", 0) / 100

            if "PS_PLUS" in cta_type and discounted == "Входит в подписку":
                result["ps_plus"] = True

            if "EA_ACCESS" in cta_type and discounted == "Входит в подписку":
                result["ea_access"] = True

            if cta_type == "UPSELL_PS_PLUS_DISCOUNT":
                result["ps_price_ua"] = price_info.get("discountedValue", 0) / 100

            if cta_type == "UPSELL_EA_ACCESS_DISCOUNT":
                result["ea_price_ua"] = price_info.get("discountedValue", 0) / 100

            if is_purchase and price_info.get("discountText"):
                result["discount"] = price_info["discountText"]

            if is_purchase and price_info.get("endTime"):
                result["discount_end"] = datetime.fromtimestamp(int(price_info["endTime"]) // 1000)

    if not result["uah_price"]:
        result["uah_price"] = result["uah_old_price"]

    # Add TR price fields (empty by default)
    result["trl_price"] = 0
    result["trl_old_price"] = 0
    result["ps_price_tr"] = None
    result["ea_price_tr"] = None

    return result


def extract_tr_prices(webctas: List[Dict]) -> Dict:
    """Извлекает информацию о TR ценах из webctas"""
    result = {
        "trl_price": 0,
        "trl_old_price": 0,
        "ps_price_tr": None,
        "ea_price_tr": None,
    }

    for cta in webctas:
        cta_type = cta.get("type", "")
        price_info = cta.get("price", {})

        is_purchase = cta_type in ["ADD_TO_CART", "PREORDER", "BUY_NOW"]
        is_upsell = "UPSELL" in cta_type and ("EA_ACCESS" in cta_type or "PS_PLUS" in cta_type) and "TRIAL" not in cta_type

        if is_purchase or is_upsell:
            discounted = price_info.get("discountedPrice")
            base = price_info.get("basePrice")

            if is_purchase and discounted and not result["trl_price"]:
                result["trl_price"] = price_info.get("discountedValue", 0) / 100

            if is_purchase and base and not result["trl_old_price"]:
                result["trl_old_price"] = price_info.get("basePriceValue", 0) / 100

            if cta_type == "UPSELL_PS_PLUS_DISCOUNT":
                result["ps_price_tr"] = price_info.get("discountedValue", 0) / 100

            if cta_type == "UPSELL_EA_ACCESS_DISCOUNT":
                result["ea_price_tr"] = price_info.get("discountedValue", 0) / 100

    if not result["trl_price"]:
        result["trl_price"] = result["trl_old_price"]

    return result


def clean_tags(tags: List[str]) -> List[str]:
    """Очищает теги от специальных символов"""
    cleaned = []
    for tag in tags:
        cleaned_tag = tag
        for char in ['™', '®', '©', '℗', '℠']:
            cleaned_tag = cleaned_tag.replace(char, '')
        cleaned_tag = cleaned_tag.replace("'", "'")
        if cleaned_tag.strip():
            cleaned.append(cleaned_tag.strip())
    return cleaned


def remove_duplicates(products: List[Dict]) -> List[Dict]:
    """Удаляет дубликаты продуктов (аналог функции uni() из старого кода)"""
    seen = set()
    unique_products = []

    for product in products:
        product_key = (
            product["name"],
            product["edition"],
            " ".join(product["platforms"]) if product["platforms"] else None,
            product["description"]
        )

        if product_key not in seen:
            seen.add(product_key)
            unique_products.append(product)

    return unique_products


# ==================== PROMO PARSER ====================
async def get_promo_names(session: aiohttp.ClientSession, url: str) -> List[str]:
    """Получает список названий промо игр"""
    async def _get_names_from_page(page_url: str) -> List[str]:
        try:
            async with session.get(page_url, headers=get_page_headers()) as resp:
                html = await resp.text()

            if "You don't have permission to access" in html:
                await access_controller.wait_for_access(session)
                # Повторяем запрос после восстановления доступа
                return await _get_names_from_page(page_url)

            soup = bs(html, "html.parser")
            _main = soup.find("div", {"id": "__next"})
            if not _main:
                return []

            _main = _main.find("main")
            if not _main:
                return []

            section = _main.find("section", {"class": "ems-sdk-grid"})
            if not section:
                return []

            ul = section.find("ul", {"class": "psw-grid-list psw-l-grid"})
            if not ul:
                return []

            products = ul.find_all("li")
            names = []
            for product in products:
                try:
                    link = product.find("a")
                    if link and link.get("data-telemetry-meta"):
                        meta = loads(link["data-telemetry-meta"])
                        if "name" in meta:
                            names.append(meta["name"])
                except:
                    continue

            return names
        except:
            return []

    pages = await get_pages(session, url)
    if not pages:
        return []

    print(f"🎯 Парсинг промо: найдено {len(pages)} страниц")

    all_names = []
    batch_size = parser_config.BATCH_SIZE_PAGES

    for i in range(0, len(pages), batch_size):
        # Перезагружаем конфигурацию на каждой итерации
        parser_config.load_config()
        batch_size = parser_config.BATCH_SIZE_PAGES

        batch = pages[i:min(len(pages), i + batch_size)]
        names_batch = await asyncio.gather(*[_get_names_from_page(page) for page in batch])
        all_names.extend(sum(names_batch, []))

        await asyncio.sleep(parser_config.SLEEP_BETWEEN_BATCHES)

        progress = min(len(pages), i + batch_size) * 100 / len(pages)
        print(f"📊 Получение промо названий: {progress:.1f}%")

    print(f"✅ Получено {len(all_names)} промо названий")
    return all_names


async def init_update_table(conn: asyncpg.Connection):
    """Инициализирует таблицу update_info"""
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS update_info (
            id TEXT,
            edition_id INTEGER,
            currency INTEGER
        )
    """)


# ==================== LOAD FROM PICKLE ====================
async def load_from_pickle_and_save_to_db():
    """Загружает данные из result.pkl и сохраняет в базу данных"""
    print("=" * 80)
    print("📂 ЗАГРУЗКА ДАННЫХ ИЗ result.pkl")
    print("=" * 80)

    start_time = perf_counter()

    # Check if result.pkl exists
    if not os.path.exists("result.pkl"):
        print("❌ Файл result.pkl не найден!")
        print("💡 Сначала запустите полный парсинг без параметра --load")
        return

    # Load promo data
    promo = []
    if os.path.exists("promo.pkl"):
        try:
            with open("promo.pkl", "rb") as f:
                promo = pickle.load(f)
            print(f"✅ Загружено {len(promo)} промо названий из promo.pkl")
        except Exception as e:
            print(f"⚠️  Ошибка загрузки promo.pkl: {e}")
    else:
        print("⚠️  Файл promo.pkl не найден, продолжаем без промо данных")

    # Load products from result.pkl
    print("\n📦 Загрузка продуктов из result.pkl...")
    try:
        with open("result.pkl", "rb") as f:
            all_products = pickle.load(f)
        print(f"✅ Загружено {len(all_products)} продуктов")
    except Exception as e:
        print(f"❌ Ошибка загрузки result.pkl: {e}")
        return

    # Process data - this is the same logic as in main() starting from STEP 7
    print("\n" + "=" * 80)
    print("📋 ОБРАБОТКА ДАННЫХ")
    print("=" * 80)

    # Group products by name
    product_cards_dict = {}

    for product in all_products:
        if not product.get("uah_price", 0) and not product.get("trl_price", 0):
            continue

        main_name = product["main_name"]
        name = product["name"]

        if any(skip in name for skip in ["Подписка PlayStation Plus", "EA Play на", "FC Points", "В-бакс"]):
            product_cards_dict[name] = [product]
        else:
            if main_name in product_cards_dict:
                product_cards_dict[main_name].append(product)
            else:
                product_cards_dict[main_name] = [product]

    # Separate games and addons
    final_cards = {}
    for main_name, products in product_cards_dict.items():
        has_game = any(p["type"] == "Игра" for p in products)
        has_addon = any("DLC" in p["type"] or "Дополнение" in p["type"] for p in products)

        if has_game and has_addon:
            games = [p for p in products if p["type"] == "Игра"]
            addons = [p for p in products if "DLC" in p["type"] or "Дополнение" in p["type"]]

            final_cards[main_name] = games
            addon_key = main_name + " "
            while addon_key in final_cards:
                addon_key += " "
            final_cards[addon_key] = addons
        else:
            final_cards[main_name] = products

    print(f"✅ Создано {len(final_cards)} карточек продуктов")

    # Prepare database data
    print("\n" + "=" * 80)
    print("📋 ПОДГОТОВКА ДАННЫХ ДЛЯ БД")
    print("=" * 80)

    # Create product cards
    product_cards = []
    card_id_map = {}

    for card_id, (name, products) in enumerate(final_cards.items(), 1):
        if any(p["type"] == "Игра" for p in products):
            product_type = "Игра"
            product = min([p for p in products if p["type"] == "Игра"], key=lambda x: x["uah_price"] or float('inf'))
        else:
            product = min(products, key=lambda x: x["uah_price"] or float('inf'))
            product_type = product["type"]

        product_cards.append((
            card_id, name, product["image"], product["ea_access"],
            product["ps_plus"], product["ps_plus"], product["ps_plus"],
            product["rating"], product_type, product["tags"],
            datetime.now(), datetime.now(), 'parser'
        ))
        card_id_map[name] = card_id

    # Create edition names
    edition_names = {}
    # ВАЖНО: Standard Edition всегда первое (ID=1) как дефолтное значение
    edition_names["Standard Edition"] = (1, "Standard Edition", datetime.now(), datetime.now())
    edition_id = 2  # Начинаем со 2

    for products in final_cards.values():
        for product in products:
            edition_name = product["edition"]
            if edition_name and edition_name not in edition_names:
                edition_names[edition_name] = (edition_id, edition_name, datetime.now(), datetime.now())
                edition_id += 1

    print(f"✅ Создано {len(edition_names)} уникальных названий изданий")

    # Create editions
    editions = []
    platforms = []
    localizations = []
    product_card_genres = []
    product_collection_editions = []
    update_info = []

    edition_id = 1
    genre_id_map = {}
    current_genre_id = 1
    pcg_id = 1

    for card_name, products in final_cards.items():
        card_id = card_id_map[card_name]

        for product in products:
            edition_name = product["edition"]
            # Если edition_name пустой или не найден, используем Standard Edition (ID=1)
            if edition_name and edition_name in edition_names:
                edition_name_id = edition_names[edition_name][0]
            else:
                edition_name_id = edition_names["Standard Edition"][0]  # Всегда ID=1

            discount = 0
            if product.get("discount"):
                try:
                    discount = 1 - int(product["discount"][1:-1]) / 100
                except:
                    discount = 0

            # UA edition
            if product.get("uah_price"):
                base_price = product["uah_price"] / discount if discount else product["uah_price"]

                editions.append([
                    edition_id, edition_name_id, product.get("description", ""),
                    card_id, base_price, 3, product["uah_price"],
                    product.get("ea_price_ua"), product.get("ps_price_ua"),
                    product.get("discount_end"), product["rating"], datetime.now(), datetime.now(),
                    product["type"], 'parser', product["image"]
                ])

                update_info.append([product["id"], edition_id, 3])

                # Platforms
                if product.get("platforms"):
                    for platform in product["platforms"]:
                        if "PS4" in platform:
                            platforms.append([edition_id, 5])
                        if "PS5" in platform:
                            platforms.append([edition_id, 6])

                # Localization
                if product["localization"] is not None:
                    localizations.append([edition_id, product["localization"], datetime.now(), datetime.now()])

                # Collections
                if "EA Play на" in product["name"]:
                    product_collection_editions.append([32, edition_id, datetime.now(), datetime.now()])
                elif "PlayStation Plus" in product["name"]:
                    product_collection_editions.append([29, edition_id, datetime.now(), datetime.now()])
                elif "FC Points" in product["name"]:
                    product_collection_editions.append([13, edition_id, datetime.now(), datetime.now()])
                elif "В-бакс" in product["name"] and "Fortnite" in product["name"]:
                    product_collection_editions.append([12, edition_id, datetime.now(), datetime.now()])
                elif product["name"] in promo:
                    product_collection_editions.append([37, edition_id, datetime.now(), datetime.now()])

                edition_id += 1

            # TR edition
            if product.get("trl_price"):
                base_price_tr = product["trl_price"] / discount if discount else product["trl_price"]

                editions.append([
                    edition_id, edition_name_id, product.get("description", ""),
                    card_id, base_price_tr, 2, product["trl_price"],
                    product.get("ea_price_tr"), product.get("ps_price_tr"),
                    product.get("discount_end"), product["rating"], datetime.now(), datetime.now(),
                    product["type"], 'parser', product["image"]
                ])

                update_info.append([product["id"], edition_id, 2])

                # Platforms
                if product.get("platforms"):
                    for platform in product["platforms"]:
                        if "PS4" in platform:
                            platforms.append([edition_id, 5])
                        if "PS5" in platform:
                            platforms.append([edition_id, 6])

                # Localization
                if product["localization"] is not None:
                    localizations.append([edition_id, product["localization"], datetime.now(), datetime.now()])

                # Collections (same logic)
                if "EA Play на" in product["name"]:
                    product_collection_editions.append([32, edition_id, datetime.now(), datetime.now()])
                elif "PlayStation Plus" in product["name"]:
                    product_collection_editions.append([29, edition_id, datetime.now(), datetime.now()])
                elif "FC Points" in product["name"]:
                    product_collection_editions.append([13, edition_id, datetime.now(), datetime.now()])
                elif "В-бакс" in product["name"] and "Fortnite" in product["name"]:
                    product_collection_editions.append([12, edition_id, datetime.now(), datetime.now()])
                elif product["name"] in promo:
                    product_collection_editions.append([37, edition_id, datetime.now(), datetime.now()])

                edition_id += 1

        # Genres
        first_product = products[0]
        for genre_name in first_product.get("category", []):
            if genre_name not in genre_id_map:
                genre_id_map[genre_name] = current_genre_id
                current_genre_id += 1

            product_card_genres.append([pcg_id, card_id, genre_id_map[genre_name]])
            pcg_id += 1

    genres = [(gid, name, datetime.now(), datetime.now()) for name, gid in genre_id_map.items()]

    # Statistics
    ua_editions = sum(1 for e in editions if e[5] == 3)
    tr_editions = sum(1 for e in editions if e[5] == 2)

    print(f"✅ Создано {len(editions)} изданий")
    print(f"  📊 UA изданий (currency=3): {ua_editions}")
    print(f"  📊 TR изданий (currency=2): {tr_editions}")
    print(f"✅ Создано {len(platforms)} связей платформ")
    print(f"✅ Создано {len(localizations)} локализаций")
    print(f"✅ Создано {len(genres)} жанров")
    print(f"✅ Создано {len(product_card_genres)} связей жанров")
    print(f"✅ Создано {len(product_collection_editions)} связей коллекций")

    # Save to database
    print("\n" + "=" * 80)
    print("📋 СОХРАНЕНИЕ В БАЗУ ДАННЫХ")
    print("=" * 80)

    conn = await asyncpg.connect(
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        database=os.getenv("DB_NAME"),
        host="193.17.92.132",
        port=5432
    )

    try:
        # Delete parser data
        print("🗑️  Удаление старых данных парсера...")
        await conn.execute('DELETE FROM "ProductCards" WHERE source = \'parser\'')
        await conn.execute('DELETE FROM "Editions" WHERE source = \'parser\'')
        await conn.execute('''
            DELETE FROM "EditionNames"
            WHERE id NOT IN (
                SELECT DISTINCT edition_name_id
                FROM "Editions"
                WHERE source = 'manual' AND edition_name_id IS NOT NULL
            )
        ''')
        await conn.execute('''
            DELETE FROM "Genres"
            WHERE id NOT IN (
                SELECT DISTINCT pcg.genre_id
                FROM "ProductCardGenres" pcg
                JOIN "ProductCards" pc ON pcg.product_card_id = pc.id
                WHERE pc.source = 'manual'
            )
        ''')
        print("✅ Старые данные удалены")

        # Insert new data
        print("💾 Вставка новых данных...")

        await conn.executemany('''
            INSERT INTO "ProductCards" (
                id, name, image_url, free_with_ea_play,
                free_with_ps_plus_essential, free_with_ps_plus_extra,
                free_with_ps_plus_deluxe, rating, edition_type, tags,
                created_at, updated_at, source
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        ''', product_cards)
        print(f"  ✅ Вставлено {len(product_cards)} карточек продуктов")

        await conn.executemany('''
            INSERT INTO "EditionNames" (id, name, created_at, updated_at)
            VALUES ($1, $2, $3, $4)
        ''', list(edition_names.values()))
        print(f"  ✅ Вставлено {len(edition_names)} названий изданий")

        await conn.executemany('''
            INSERT INTO "Editions" (
                id, edition_name_id, description, product_card_id,
                price, display_currency_id, discount_amount,
                ea_play_price, ps_plus_price, promotion_end_date,
                rating, created_at, updated_at, product_type, source, image_url
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
        ''', editions)
        print(f"  ✅ Вставлено {len(editions)} изданий")

        await conn.executemany('''
            INSERT INTO "edition_platforms" (edition_id, platform_id)
            VALUES ($1, $2)
        ''', platforms)
        print(f"  ✅ Вставлено {len(platforms)} платформ")

        await conn.executemany('''
            INSERT INTO "Genres" (id, name, created_at, updated_at)
            VALUES ($1, $2, $3, $4)
        ''', genres)
        print(f"  ✅ Вставлено {len(genres)} жанров")

        await conn.executemany('''
            INSERT INTO "edition_localizations" (
                edition_id, localization_id, "createdAt", "updatedAt"
            ) VALUES ($1, $2, $3, $4)
        ''', localizations)
        print(f"  ✅ Вставлено {len(localizations)} локализаций")

        await conn.executemany('''
            INSERT INTO "ProductCardGenres" (id, product_card_id, genre_id)
            VALUES ($1, $2, $3)
        ''', product_card_genres)
        print(f"  ✅ Вставлено {len(product_card_genres)} связей жанров")

        await conn.executemany('''
            INSERT INTO "ProductCollectionEditions" (
                product_collection_id, edition_id, created_at, updated_at
            ) VALUES ($1, $2, $3, $4)
        ''', product_collection_editions)
        print(f"  ✅ Вставлено {len(product_collection_editions)} связей коллекций")

        await conn.execute('DELETE FROM "update_info"')
        await conn.executemany('''
            INSERT INTO "update_info" (id, edition_id, currency)
            VALUES ($1, $2, $3)
        ''', update_info)
        print(f"  ✅ Вставлено {len(update_info)} записей update_info")

        print("✅ Все данные успешно сохранены в БД")

    finally:
        await conn.close()

    end_time = perf_counter()
    total_time = end_time - start_time

    print("\n" + "=" * 80)
    print("🎉 ЗАГРУЗКА ЗАВЕРШЕНА УСПЕШНО!")
    print("=" * 80)
    print(f"⏱️  Общее время: {total_time:.2f} секунд ({total_time/60:.1f} минут)")
    print(f"📦 Загружено карточек: {len(product_cards)}")
    print(f"📚 Загружено изданий: {len(editions)}")
    print("=" * 80)


# ==================== MAIN PARSING LOGIC ====================
async def main():
    """Главная функция парсера"""
    # Проверяем режим работы
    if LOAD_MODE:
        await load_from_pickle_and_save_to_db()
        return

    print("=" * 80)
    print("🚀 ЗАПУСК МОЩНОГО ПАРСЕРА PLAYSTATION STORE")
    print("=" * 80)

    start_time = perf_counter()
    duplicate_detector = DuplicateDetector()

    # Initialize database
    await init_update_table(await asyncpg.connect(
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        database=os.getenv("DB_NAME"),
        host="193.17.92.132",
        port=5432
    ))

    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(parser_config.REQUEST_TIMEOUT)) as session:

        # ==================== STEP 1: GET PROMO ====================
        print("\n" + "=" * 80)
        print("📋 ШАГ 1: Получение промо акций")
        print("=" * 80)

        promo_url = "https://store.playstation.com/ru-ua/category/3f772501-f6f8-49b7-abac-874a88ca4897"
        promo = await get_promo_names(session, promo_url)

        with open("promo.pkl", "wb") as f:
            pickle.dump(promo, f)

        # ==================== STEP 2: GET PAGE URLS ====================
        print("\n" + "=" * 80)
        print("📋 ШАГ 2: Получение URL страниц")
        print("=" * 80)

        base_categories = [
            "https://store.playstation.com/ru-ua/pages/browse",
            "https://store.playstation.com/ru-ua/category/51c9aa7a-c0c7-4b68-90b4-328ad11bf42e",  # Addons
            "https://store.playstation.com/ru-ua/category/3c49d223-9344-4009-b296-08e168854749",  # Items
        ]

        extra_categories = parser_config.EXTRA_CATEGORIES

        print(f"🔍 Парсинг основных категорий: {len(base_categories)}")
        pages_tasks = [get_pages(session, url) for url in base_categories]
        pages_results = await asyncio.gather(*pages_tasks)
        pages = sum(pages_results, [])

        print(f"✅ Получено {len(pages)} страниц из основных категорий")

        # ==================== STEP 3: GET EXTRA CATEGORY PAGES ====================
        print(f"\n🔍 Парсинг дополнительных категорий: {len(extra_categories)}")
        extra_pages_tasks = [get_pages(session, url) for url in extra_categories]
        extra_pages_results = await asyncio.gather(*extra_pages_tasks)
        extra_pages = sum(extra_pages_results, [])

        print(f"✅ Получено {len(extra_pages)} страниц из дополнительных категорий")
        print(f"📊 Всего страниц: {len(pages) + len(extra_pages)}")

        # ==================== STEP 4: GET PRODUCT URLS ====================
        print("\n" + "=" * 80)
        print("📋 ШАГ 3: Получение URL продуктов")
        print("=" * 80)

        all_pages = pages + extra_pages
        product_urls = []
        batch_size = parser_config.BATCH_SIZE_PAGES
        pages_start = perf_counter()

        for i in range(0, len(all_pages), batch_size):
            # Перезагружаем конфигурацию на каждой итерации
            parser_config.load_config()
            batch_size = parser_config.BATCH_SIZE_PAGES

            batch = all_pages[i:min(len(all_pages), i + batch_size)]
            urls_batch = await asyncio.gather(*[get_products(session, page) for page in batch])

            for urls in urls_batch:
                for url in urls:
                    if not duplicate_detector.is_duplicate_url(url):
                        product_urls.append(url)

            await asyncio.sleep(parser_config.SLEEP_BETWEEN_BATCHES)

            current = min(len(all_pages), i + batch_size)
            elapsed = perf_counter() - pages_start
            print_progress_bar(
                current,
                len(all_pages),
                elapsed,
                prefix="🔗 Получение URL",
                suffix=f"| Уникальных: {len(product_urls)}"
            )

        print()

        print(f"✅ Получено {len(product_urls)} уникальных URL продуктов")

        # Add special products
        special_products = [
            "https://store.playstation.com/ru-ua/concept/10004507",
            "https://store.playstation.com/ru-ua/concept/10010783"
        ]

        for url in special_products:
            if not duplicate_detector.is_duplicate_url(url):
                product_urls.append(url)

        product_urls.reverse()  # Reverse for newest first

        # ==================== STEP 5: UNQUOTE URLS ====================
        print("\n" + "=" * 80)
        print("📋 ШАГ 4: Разворачивание concept URLs")
        print("=" * 80)

        unquoted_urls = []
        batch_size = parser_config.BATCH_SIZE_UNQUOTE
        unquote_start = perf_counter()

        for i in range(0, len(product_urls), batch_size):
            # Перезагружаем конфигурацию на каждой итерации
            parser_config.load_config()
            batch_size = parser_config.BATCH_SIZE_UNQUOTE

            batch = product_urls[i:min(len(product_urls), i + batch_size)]
            unquoted_batch = await asyncio.gather(*[unquote(session, url) for url in batch])

            for urls in unquoted_batch:
                for url in urls:
                    # Локальная проверка дубликатов (не используем duplicate_detector)
                    # т.к. product URLs уже были отфильтрованы на ШАГе 3
                    if url not in unquoted_urls:
                        unquoted_urls.append(url)

            await asyncio.sleep(parser_config.SLEEP_BETWEEN_BATCHES)

            current = min(len(product_urls), i + batch_size)
            elapsed = perf_counter() - unquote_start
            print_progress_bar(
                current,
                len(product_urls),
                elapsed,
                prefix="📦 Разворачивание",
                suffix=f"| Уникальных: {len(unquoted_urls)}"
            )

        print()

        print(f"✅ Получено {len(unquoted_urls)} уникальных развернутых URLs")

        with open("products.pkl", "wb") as f:
            pickle.dump(unquoted_urls, f)

        # ==================== STEP 5: CHECK ALREADY PARSED ====================
        print("\n" + "=" * 80)
        print("📋 ШАГ 5: Проверка уже спарсенных продуктов")
        print("=" * 80)

        # Пытаемся загрузить список всех продуктов
        all_product_urls = []
        try:
            if os.path.exists("products.pkl"):
                with open("products.pkl", "rb") as f:
                    all_product_urls = pickle.load(f)
                print(f"📂 Загружено {len(all_product_urls)} URL из products.pkl")
            else:
                print("⚠️  Файл products.pkl не найден, используем текущий список")
                all_product_urls = unquoted_urls
        except Exception as e:
            print(f"⚠️  Ошибка загрузки products.pkl: {e}")
            all_product_urls = unquoted_urls

        # Пытаемся загрузить уже спарсенные продукты
        # Структура: {product_id: {"ua": True/False, "tr": True/False}}
        parsed_products_map = {}
        already_parsed = []

        try:
            if os.path.exists("result.pkl"):
                with open("result.pkl", "rb") as f:
                    already_parsed = pickle.load(f)

                # Создаем карту: какие валюты уже есть для каждого продукта
                for product in already_parsed:
                    product_id = product.get("id")
                    if not product_id:
                        continue

                    if product_id not in parsed_products_map:
                        parsed_products_map[product_id] = {"ua": False, "tr": False}

                    # Проверяем наличие цен
                    if product.get("uah_price", 0) > 0:
                        parsed_products_map[product_id]["ua"] = True
                    if product.get("trl_price", 0) > 0:
                        parsed_products_map[product_id]["tr"] = True

                print(f"📂 Загружено {len(already_parsed)} уже спарсенных продуктов")
                print(f"🆔 Найдено {len(parsed_products_map)} уникальных product ID")
            else:
                print("⚠️  Файл result.pkl не найден, парсим все продукты")
        except Exception as e:
            print(f"⚠️  Ошибка загрузки result.pkl: {e}")

        # Фильтруем список, оставляя только не полностью спарсенные
        urls_to_parse = []
        fully_parsed_count = 0
        partially_parsed_count = 0

        for url in all_product_urls:
            # Извлекаем product ID из URL (последняя часть после последнего /)
            product_id = url.split("/")[-1]

            if product_id not in parsed_products_map:
                # Продукт вообще не парсился
                urls_to_parse.append(url)
            else:
                # Проверяем, полностью ли спарсен (и UA и TR)
                ua_parsed = parsed_products_map[product_id]["ua"]
                tr_parsed = parsed_products_map[product_id]["tr"]

                if ua_parsed and tr_parsed:
                    # Полностью спарсен
                    fully_parsed_count += 1
                else:
                    # Частично спарсен, нужно допарсить
                    urls_to_parse.append(url)
                    partially_parsed_count += 1

        print("\n" + "-" * 80)
        print("📊 СТАТИСТИКА ПАРСИНГА:")
        print(f"  📦 Всего продуктов: {len(all_product_urls)}")
        print(f"  ✅ Полностью спарсено (UA + TR): {fully_parsed_count}")
        print(f"  ⚠️  Частично спарсено: {partially_parsed_count}")
        print(f"  ⏳ Осталось спарсить: {len(urls_to_parse)}")
        print(f"  📈 Прогресс: {(fully_parsed_count / len(all_product_urls) * 100) if all_product_urls else 0:.1f}%")

        # Детальная статистика по валютам
        ua_count = sum(1 for p in parsed_products_map.values() if p["ua"])
        tr_count = sum(1 for p in parsed_products_map.values() if p["tr"])
        print(f"\n  💰 Продуктов с UAH: {ua_count}")
        print(f"  💰 Продуктов с TRL: {tr_count}")
        print("-" * 80)

        # Если есть уже спарсенные продукты, используем их как базу
        if parsed_products_map:
            print("🔄 Продолжаем парсинг с учетом уже спарсенных продуктов\n")
            all_products = already_parsed
        else:
            all_products = []
            print("🆕 Начинаем парсинг с нуля\n")

        # Используем отфильтрованный список для парсинга
        unquoted_urls = urls_to_parse

        # ==================== STEP 6: PARSE PRODUCTS ====================
        print("\n" + "=" * 80)
        print("📋 ШАГ 6: Парсинг продуктов")
        print("=" * 80)

        # all_products уже инициализирован в ШАГе 5
        newly_parsed = []

        if not unquoted_urls:
            print("✅ Все продукты уже спарсены! Переходим к обработке данных...")
        else:
            print(f"🔄 Парсим {len(unquoted_urls)} оставшихся продуктов...")

        batch_size = parser_config.BATCH_SIZE_PRODUCTS
        parse_start = perf_counter()

        for i in range(0, len(unquoted_urls), batch_size):
            # Перезагружаем конфигурацию на каждой итерации
            parser_config.load_config()
            batch_size = parser_config.BATCH_SIZE_PRODUCTS

            batch = unquoted_urls[i:min(len(unquoted_urls), i + batch_size)]
            products_batch = await asyncio.gather(*[
                parse_product(session, url, duplicate_detector) for url in batch
            ])

            for products in products_batch:
                newly_parsed.extend(products)

            await asyncio.sleep(parser_config.SLEEP_BETWEEN_BATCHES)

            parse_end = perf_counter()
            current = min(len(unquoted_urls), i + batch_size)
            elapsed = parse_end - parse_start

            # Красивый прогресс-бар с ETA
            print_progress_bar(
                current,
                len(unquoted_urls),
                elapsed,
                prefix="📦 Парсинг продуктов",
                suffix=f"| Новых: {len(newly_parsed)}"
            )

        # Переход на новую строку после завершения
        print()

        # Добавляем новые продукты к уже существующим
        all_products.extend(newly_parsed)

        print(f"✅ Спарсено {len(newly_parsed)} новых продуктов")
        print(f"📦 Всего продуктов в базе: {len(all_products)}")

        # Подсчет продуктов с TR ценами
        products_with_tr = sum(1 for p in all_products if p.get("trl_price"))
        products_with_ua = sum(1 for p in all_products if p.get("uah_price"))
        print(f"  📊 Продуктов с UA ценами: {products_with_ua}")
        print(f"  📊 Продуктов с TR ценами: {products_with_tr}")

        # Удаляем дубликаты
        print("🔍 Удаление дубликатов...")
        all_products = remove_duplicates(all_products)
        print(f"✅ После удаления дубликатов: {len(all_products)} уникальных продуктов")

        products_with_tr = sum(1 for p in all_products if p.get("trl_price"))
        products_with_ua = sum(1 for p in all_products if p.get("uah_price"))
        print(f"  📊 Продуктов с UA ценами: {products_with_ua}")
        print(f"  📊 Продуктов с TR ценами: {products_with_tr}")

        with open("result.pkl", "wb") as f:
            pickle.dump(all_products, f)

        # ==================== STEP 7: PROCESS DATA ====================
        print("\n" + "=" * 80)
        print("📋 ШАГ 7: Обработка данных")
        print("=" * 80)

        # Group products by name
        product_cards_dict = {}

        for product in all_products:
            if not product.get("uah_price", 0) and not product.get("trl_price", 0):
                continue

            # Skip subscriptions and currency
            main_name = product["main_name"]
            name = product["name"]

            if any(skip in name for skip in ["Подписка PlayStation Plus", "EA Play на", "FC Points", "В-бакс"]):
                product_cards_dict[name] = [product]
            else:
                if main_name in product_cards_dict:
                    product_cards_dict[main_name].append(product)
                else:
                    product_cards_dict[main_name] = [product]

        # Separate games and addons
        final_cards = {}
        for main_name, products in product_cards_dict.items():
            has_game = any(p["type"] == "Игра" for p in products)
            has_addon = any("DLC" in p["type"] or "Дополнение" in p["type"] for p in products)

            if has_game and has_addon:
                games = [p for p in products if p["type"] == "Игра"]
                addons = [p for p in products if "DLC" in p["type"] or "Дополнение" in p["type"]]

                final_cards[main_name] = games
                addon_key = main_name + " "
                while addon_key in final_cards:
                    addon_key += " "
                final_cards[addon_key] = addons
            else:
                final_cards[main_name] = products

        print(f"✅ Создано {len(final_cards)} карточек продуктов")

        # ==================== STEP 8: PREPARE DB DATA ====================
        print("\n" + "=" * 80)
        print("📋 ШАГ 8: Подготовка данных для БД")
        print("=" * 80)

        # Create product cards
        product_cards = []
        card_id_map = {}

        for card_id, (name, products) in enumerate(final_cards.items(), 1):
            if any(p["type"] == "Игра" for p in products):
                product_type = "Игра"
                product = min([p for p in products if p["type"] == "Игра"], key=lambda x: x["uah_price"] or float('inf'))
            else:
                product = min(products, key=lambda x: x["uah_price"] or float('inf'))
                product_type = product["type"]

            product_cards.append((
                card_id, name, product["image"], product["ea_access"],
                product["ps_plus"], product["ps_plus"], product["ps_plus"],
                product["rating"], product_type, product["tags"],
                datetime.now(), datetime.now(), 'parser'
            ))
            card_id_map[name] = card_id

        # Create edition names
        edition_names = {}
        # ВАЖНО: Standard Edition всегда первое (ID=1) как дефолтное значение
        edition_names["Standard Edition"] = (1, "Standard Edition", datetime.now(), datetime.now())
        edition_id = 2  # Начинаем со 2

        for products in final_cards.values():
            for product in products:
                edition_name = product["edition"]
                if edition_name and edition_name not in edition_names:
                    edition_names[edition_name] = (edition_id, edition_name, datetime.now(), datetime.now())
                    edition_id += 1

        print(f"✅ Создано {len(edition_names)} уникальных названий изданий")

        # Create editions
        editions = []
        platforms = []
        localizations = []
        product_card_genres = []
        product_collection_editions = []
        update_info = []

        edition_id = 1
        genre_id_map = {}
        current_genre_id = 1
        pcg_id = 1

        for card_name, products in final_cards.items():
            card_id = card_id_map[card_name]

            for product in products:
                edition_name = product["edition"]
                # Если edition_name пустой или не найден, используем Standard Edition (ID=1)
                if edition_name and edition_name in edition_names:
                    edition_name_id = edition_names[edition_name][0]
                else:
                    edition_name_id = edition_names["Standard Edition"][0]  # Всегда ID=1

                discount = 0
                if product.get("discount"):
                    try:
                        discount = 1 - int(product["discount"][1:-1]) / 100
                    except:
                        discount = 0

                # UA edition
                if product.get("uah_price"):
                    base_price = product["uah_price"] / discount if discount else product["uah_price"]

                    editions.append([
                        edition_id, edition_name_id, product.get("description", ""),
                        card_id, base_price, 3, product["uah_price"],
                        product.get("ea_price_ua"), product.get("ps_price_ua"),
                        product.get("discount_end"), product["rating"], datetime.now(), datetime.now(),
                        product["type"], 'parser', product["image"]
                    ])

                    update_info.append([product["id"], edition_id, 3])

                    # Platforms
                    if product.get("platforms"):
                        for platform in product["platforms"]:
                            if "PS4" in platform:
                                platforms.append([edition_id, 5])
                            if "PS5" in platform:
                                platforms.append([edition_id, 6])

                    # Localization
                    if product["localization"] is not None:
                        localizations.append([edition_id, product["localization"], datetime.now(), datetime.now()])

                    # Collections
                    if "EA Play на" in product["name"]:
                        product_collection_editions.append([32, edition_id, datetime.now(), datetime.now()])
                    elif "PlayStation Plus" in product["name"]:
                        product_collection_editions.append([29, edition_id, datetime.now(), datetime.now()])
                    elif "FC Points" in product["name"]:
                        product_collection_editions.append([13, edition_id, datetime.now(), datetime.now()])
                    elif "В-бакс" in product["name"] and "Fortnite" in product["name"]:
                        product_collection_editions.append([12, edition_id, datetime.now(), datetime.now()])
                    elif product["name"] in promo:
                        product_collection_editions.append([37, edition_id, datetime.now(), datetime.now()])

                    edition_id += 1

                # TR edition
                if product.get("trl_price"):
                    base_price_tr = product["trl_price"] / discount if discount else product["trl_price"]

                    editions.append([
                        edition_id, edition_name_id, product.get("description", ""),
                        card_id, base_price_tr, 2, product["trl_price"],
                        product.get("ea_price_tr"), product.get("ps_price_tr"),
                        product.get("discount_end"), product["rating"], datetime.now(), datetime.now(),
                        product["type"], 'parser', product["image"]
                    ])

                    update_info.append([product["id"], edition_id, 2])

                    # Platforms
                    if product.get("platforms"):
                        for platform in product["platforms"]:
                            if "PS4" in platform:
                                platforms.append([edition_id, 5])
                            if "PS5" in platform:
                                platforms.append([edition_id, 6])

                    # Localization
                    if product["localization"] is not None:
                        localizations.append([edition_id, product["localization"], datetime.now(), datetime.now()])

                    # Collections (same logic)
                    if "EA Play на" in product["name"]:
                        product_collection_editions.append([32, edition_id, datetime.now(), datetime.now()])
                    elif "PlayStation Plus" in product["name"]:
                        product_collection_editions.append([29, edition_id, datetime.now(), datetime.now()])
                    elif "FC Points" in product["name"]:
                        product_collection_editions.append([13, edition_id, datetime.now(), datetime.now()])
                    elif "В-бакс" in product["name"] and "Fortnite" in product["name"]:
                        product_collection_editions.append([12, edition_id, datetime.now(), datetime.now()])
                    elif product["name"] in promo:
                        product_collection_editions.append([37, edition_id, datetime.now(), datetime.now()])

                    edition_id += 1

            # Genres
            first_product = products[0]
            for genre_name in first_product.get("category", []):
                if genre_name not in genre_id_map:
                    genre_id_map[genre_name] = current_genre_id
                    current_genre_id += 1

                product_card_genres.append([pcg_id, card_id, genre_id_map[genre_name]])
                pcg_id += 1

        genres = [(gid, name, datetime.now(), datetime.now()) for name, gid in genre_id_map.items()]

        # Подсчет изданий по регионам
        ua_editions = sum(1 for e in editions if e[5] == 3)
        tr_editions = sum(1 for e in editions if e[5] == 2)

        print(f"✅ Создано {len(editions)} изданий")
        print(f"  📊 UA изданий (currency=3): {ua_editions}")
        print(f"  📊 TR изданий (currency=2): {tr_editions}")
        print(f"✅ Создано {len(platforms)} связей платформ")
        print(f"✅ Создано {len(localizations)} локализаций")
        print(f"✅ Создано {len(genres)} жанров")
        print(f"✅ Создано {len(product_card_genres)} связей жанров")
        print(f"✅ Создано {len(product_collection_editions)} связей коллекций")

        # ==================== STEP 9: SAVE TO DATABASE ====================
        print("\n" + "=" * 80)
        print("📋 ШАГ 9: Сохранение в базу данных")
        print("=" * 80)

        conn = await asyncpg.connect(
            user=os.getenv("DB_USER"),
            password=os.getenv("DB_PASSWORD"),
            database=os.getenv("DB_NAME"),
            host="193.17.92.132",
            port=5432
        )

        try:
            # Delete parser data
            print("🗑️  Удаление старых данных парсера...")
            await conn.execute('DELETE FROM "ProductCards" WHERE source = \'parser\'')
            await conn.execute('DELETE FROM "Editions" WHERE source = \'parser\'')
            await conn.execute('''
                DELETE FROM "EditionNames"
                WHERE id NOT IN (
                    SELECT DISTINCT edition_name_id
                    FROM "Editions"
                    WHERE source = 'manual' AND edition_name_id IS NOT NULL
                )
            ''')
            await conn.execute('''
                DELETE FROM "Genres"
                WHERE id NOT IN (
                    SELECT DISTINCT pcg.genre_id
                    FROM "ProductCardGenres" pcg
                    JOIN "ProductCards" pc ON pcg.product_card_id = pc.id
                    WHERE pc.source = 'manual'
                )
            ''')
            print("✅ Старые данные удалены")

            # Insert new data
            print("💾 Вставка новых данных...")

            await conn.executemany('''
                INSERT INTO "ProductCards" (
                    id, name, image_url, free_with_ea_play,
                    free_with_ps_plus_essential, free_with_ps_plus_extra,
                    free_with_ps_plus_deluxe, rating, edition_type, tags,
                    created_at, updated_at, source
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
            ''', product_cards)
            print(f"  ✅ Вставлено {len(product_cards)} карточек продуктов")

            await conn.executemany('''
                INSERT INTO "EditionNames" (id, name, created_at, updated_at)
                VALUES ($1, $2, $3, $4)
            ''', list(edition_names.values()))
            print(f"  ✅ Вставлено {len(edition_names)} названий изданий")

            await conn.executemany('''
                INSERT INTO "Editions" (
                    id, edition_name_id, description, product_card_id,
                    price, display_currency_id, discount_amount,
                    ea_play_price, ps_plus_price, promotion_end_date,
                    rating, created_at, updated_at, product_type, source, image_url
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
            ''', editions)
            print(f"  ✅ Вставлено {len(editions)} изданий")

            await conn.executemany('''
                INSERT INTO "edition_platforms" (edition_id, platform_id)
                VALUES ($1, $2)
            ''', platforms)
            print(f"  ✅ Вставлено {len(platforms)} платформ")

            await conn.executemany('''
                INSERT INTO "Genres" (id, name, created_at, updated_at)
                VALUES ($1, $2, $3, $4)
            ''', genres)
            print(f"  ✅ Вставлено {len(genres)} жанров")

            await conn.executemany('''
                INSERT INTO "edition_localizations" (
                    edition_id, localization_id, "createdAt", "updatedAt"
                ) VALUES ($1, $2, $3, $4)
            ''', localizations)
            print(f"  ✅ Вставлено {len(localizations)} локализаций")

            await conn.executemany('''
                INSERT INTO "ProductCardGenres" (id, product_card_id, genre_id)
                VALUES ($1, $2, $3)
            ''', product_card_genres)
            print(f"  ✅ Вставлено {len(product_card_genres)} связей жанров")

            await conn.executemany('''
                INSERT INTO "ProductCollectionEditions" (
                    product_collection_id, edition_id, created_at, updated_at
                ) VALUES ($1, $2, $3, $4)
            ''', product_collection_editions)
            print(f"  ✅ Вставлено {len(product_collection_editions)} связей коллекций")

            await conn.execute('DELETE FROM "update_info"')
            await conn.executemany('''
                INSERT INTO "update_info" (id, edition_id, currency)
                VALUES ($1, $2, $3)
            ''', update_info)
            print(f"  ✅ Вставлено {len(update_info)} записей update_info")

            print("✅ Все данные успешно сохранены в БД")

        finally:
            await conn.close()

    end_time = perf_counter()
    total_time = end_time - start_time

    print("\n" + "=" * 80)
    print("🎉 ПАРСИНГ ЗАВЕРШЕН УСПЕШНО!")
    print("=" * 80)
    print(f"⏱️  Общее время: {total_time:.2f} секунд ({total_time/60:.1f} минут)")
    print(f"📊 Спарсено продуктов: {len(all_products)}")
    print(f"📦 Создано карточек: {len(product_cards)}")
    print(f"📚 Создано изданий: {len(editions)}")
    print("=" * 80)


if __name__ == "__main__":
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(main())
    except KeyboardInterrupt:
        print("\n⚠️  Парсинг прерван пользователем")
    finally:
        print("\n👋 До свидания!")
