import { createDbConnection, type RawProxy, type Proxy, type ProxyStats, type ProxyUsage } from './database';
import { HttpsProxyAgent } from 'https-proxy-agent';

export class ProxyService {
  private static instance: ProxyService;
  private currentWorkingProxy: Proxy | null = null;
  private proxyCheckInProgress = false;

  public static getInstance(): ProxyService {
    if (!ProxyService.instance) {
      ProxyService.instance = new ProxyService();
    }
    return ProxyService.instance;
  }

  /**
   * Парсит строку прокси в нужном формате
   * Формат: "143.20.172.60	4598	14598	user326029	ejdif4	user326029:ejdif4@143.20.172.60:4598"
   */
  public parseProxyString(proxyLine: string): Omit<Proxy, 'id' | 'created_at' | 'updated_at' | 'last_check_at'> | null {
    try {
      const parts = proxyLine.trim().split('\t');
      if (parts.length < 6) {
        return null;
      }

      const [ip, port, auth_port, username, password, full_url] = parts;

      return {
        ip: ip.trim(),
        port: parseInt(port.trim()),
        auth_port: auth_port ? parseInt(auth_port.trim()) : undefined,
        username: username.trim(),
        password: password.trim(),
        full_url: full_url.trim(),
        status: 'active',
        response_time: 0,
        success_count: 0,
        failure_count: 0
      };
    } catch (error) {
      console.error('Ошибка парсинга прокси строки:', error);
      return null;
    }
  }

  /**
   * Добавляет несколько прокси из текста (каждый с новой строки)
   */
  public async addProxiesBatch(proxiesText: string): Promise<{ added: number; errors: string[] }> {
    const client = createDbConnection();
    const errors: string[] = [];
    let added = 0;

    try {
      await client.connect();

      const lines = proxiesText.split('\n').filter(line => line.trim());

      for (const line of lines) {
        try {
          const proxyData = this.parseProxyString(line);
          if (!proxyData) {
            errors.push(`Неверный формат строки: ${line}`);
            continue;
          }

          // Проверяем, не существует ли уже такой прокси
          const existingProxy = await client.query(
            'SELECT id FROM proxies WHERE ip = $1 AND port = $2',
            [proxyData.ip, proxyData.port]
          );

          if (existingProxy.rows.length > 0) {
            errors.push(`Прокси ${proxyData.ip}:${proxyData.port} уже существует`);
            continue;
          }

          // Добавляем прокси
          await client.query(
            `INSERT INTO proxies (ip, port, auth_port, username, password, full_url, status)
             VALUES ($1, $2, $3, $4, $5, $6, $7)`,
            [proxyData.ip, proxyData.port, proxyData.auth_port, proxyData.username,
             proxyData.password, proxyData.full_url, proxyData.status]
          );

          added++;
        } catch (error) {
          errors.push(`Ошибка добавления прокси: ${line} - ${error}`);
        }
      }

    } catch (error) {
      console.error('Ошибка при пакетном добавлении прокси:', error);
      errors.push(`Ошибка подключения к БД: ${error}`);
    } finally {
      await client.end();
    }

    return { added, errors };
  }

  /**
   * Проверяет работоспособность прокси
   */
  public async checkProxy(proxy: Proxy, testUrl = 'https://httpbin.org/ip', timeout = 10000): Promise<{
    success: boolean;
    responseTime: number;
    error?: string;
  }> {
    const startTime = Date.now();

    try {
      const proxyAgent = new HttpsProxyAgent(
        `http://${proxy.username}:${proxy.password}@${proxy.ip}:${proxy.port}`
      );

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);

      const response = await fetch(testUrl, {
        // @ts-expect-error - HttpsProxyAgent works with fetch
        agent: proxyAgent,
        signal: controller.signal,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });

      clearTimeout(timeoutId);

      const responseTime = Date.now() - startTime;

      if (response.ok) {
        await this.updateProxyStats(proxy.id, true, responseTime);
        return { success: true, responseTime };
      } else {
        await this.updateProxyStats(proxy.id, false, responseTime);
        return { success: false, responseTime, error: `HTTP ${response.status}` };
      }

    } catch (error) {
      const responseTime = Date.now() - startTime;
      await this.updateProxyStats(proxy.id, false, responseTime);
      return {
        success: false,
        responseTime,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Обновляет статистику прокси после проверки
   */
  private async updateProxyStats(proxyId: number, success: boolean, responseTime: number): Promise<void> {
    const client = createDbConnection();
    try {
      await client.connect();

      const updateQuery = success
        ? `UPDATE proxies SET
           success_count = success_count + 1,
           response_time = $2,
           last_check_at = CURRENT_TIMESTAMP,
           status = 'active'
           WHERE id = $1`
        : `UPDATE proxies SET
           failure_count = failure_count + 1,
           response_time = $2,
           last_check_at = CURRENT_TIMESTAMP,
           status = CASE
             WHEN failure_count >= 3 THEN 'failed'
             ELSE 'inactive'
           END
           WHERE id = $1`;

      await client.query(updateQuery, [proxyId, responseTime]);
    } catch (error) {
      console.error('Ошибка обновления статистики прокси:', error);
    } finally {
      await client.end();
    }
  }

  /**
   * Получает список активных прокси, отсортированных по качеству
   */
  public async getActiveProxies(): Promise<ProxyStats[]> {
    const client = createDbConnection();
    try {
      await client.connect();

      const result = await client.query(`
        SELECT * FROM proxy_stats
        WHERE status IN ('active', 'checking')
        ORDER BY success_rate DESC, response_time ASC
      `);

      return result.rows.map(this.convertRawProxyStats);
    } catch (error) {
      console.error('Ошибка получения активных прокси:', error);
      return [];
    } finally {
      await client.end();
    }
  }

  /**
   * Получает лучший рабочий прокси с кэшированием
   */
  public async getBestWorkingProxy(): Promise<Proxy | null> {
    // Если есть кэшированный рабочий прокси, проверяем его еще раз
    if (this.currentWorkingProxy) {
      const checkResult = await this.checkProxy(this.currentWorkingProxy);
      if (checkResult.success) {
        return this.currentWorkingProxy;
      } else {
        this.currentWorkingProxy = null;
      }
    }

    // Ищем новый рабочий прокси
    const activeProxies = await this.getActiveProxies();

    for (const proxy of activeProxies) {
      if (this.proxyCheckInProgress) {
        await new Promise(resolve => setTimeout(resolve, 100));
        continue;
      }

      this.proxyCheckInProgress = true;
      const checkResult = await this.checkProxy(this.convertProxyStatsToProxy(proxy));
      this.proxyCheckInProgress = false;

      if (checkResult.success) {
        const convertedProxy = this.convertProxyStatsToProxy(proxy);
        this.currentWorkingProxy = convertedProxy;
        return convertedProxy;
      }
    }

    return null;
  }

  /**
   * Создает прокси-агент для HTTP запросов
   */
  public async createProxyAgent(): Promise<HttpsProxyAgent | null> {
    const proxy = await this.getBestWorkingProxy();
    if (!proxy) {
      return null;
    }

    return new HttpsProxyAgent(
      `http://${proxy.username}:${proxy.password}@${proxy.ip}:${proxy.port}`
    );
  }

  /**
   * Логирует использование прокси
   */
  public async logProxyUsage(
    proxyId: number,
    userId: number,
    sessionId: string,
    requestUrl: string,
    responseTime: number,
    statusCode: number,
    success: boolean,
    errorMessage?: string
  ): Promise<void> {
    const client = createDbConnection();
    try {
      await client.connect();

      await client.query(
        `INSERT INTO proxy_usage
         (proxy_id, user_id, session_id, request_url, response_time, status_code, success, error_message)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
        [proxyId, userId, sessionId, requestUrl, responseTime, statusCode, success, errorMessage]
      );
    } catch (error) {
      console.error('Ошибка логирования использования прокси:', error);
    } finally {
      await client.end();
    }
  }

  /**
   * Получает все прокси с фильтрацией
   */
  public async getAllProxies(
    status?: string,
    limit = 50,
    offset = 0
  ): Promise<{ proxies: ProxyStats[]; total: number }> {
    const client = createDbConnection();
    try {
      await client.connect();

      let whereClause = '';
      const params: string[] = [];

      if (status) {
        whereClause = 'WHERE status = $1';
        params.push(status);
      }

      const countResult = await client.query(
        `SELECT COUNT(*) FROM proxy_stats ${whereClause}`,
        params
      );
      const total = parseInt(countResult.rows[0].count);

      const proxiesResult = await client.query(
        `SELECT * FROM proxy_stats ${whereClause}
         ORDER BY success_rate DESC, response_time ASC
         LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
        [...params, limit.toString(), offset.toString()]
      );

      return {
        proxies: proxiesResult.rows.map(this.convertRawProxyStats),
        total
      };
    } catch (error) {
      console.error('Ошибка получения списка прокси:', error);
      return { proxies: [], total: 0 };
    } finally {
      await client.end();
    }
  }

  /**
   * Удаляет прокси
   */
  public async deleteProxy(proxyId: number): Promise<boolean> {
    const client = createDbConnection();
    try {
      await client.connect();

      const result = await client.query('DELETE FROM proxies WHERE id = $1', [proxyId]);
      return result.rowCount > 0;
    } catch (error) {
      console.error('Ошибка удаления прокси:', error);
      return false;
    } finally {
      await client.end();
    }
  }

  /**
   * Обновляет статус прокси
   */
  public async updateProxyStatus(proxyId: number, status: string): Promise<boolean> {
    const client = createDbConnection();
    try {
      await client.connect();

      const result = await client.query(
        'UPDATE proxies SET status = $1 WHERE id = $2',
        [status, proxyId]
      );
      return result.rowCount > 0;
    } catch (error) {
      console.error('Ошибка обновления статуса прокси:', error);
      return false;
    } finally {
      await client.end();
    }
  }

  /**
   * Преобразует ProxyStats в Proxy
   */
  private convertProxyStatsToProxy(proxyStats: ProxyStats): Proxy {
    return {
      id: proxyStats.id,
      ip: proxyStats.ip,
      port: proxyStats.port,
      auth_port: proxyStats.auth_port,
      username: proxyStats.username,
      password: proxyStats.password,
      full_url: proxyStats.full_url,
      status: proxyStats.status as 'active' | 'inactive' | 'failed' | 'checking',
      last_check_at: proxyStats.last_check_at,
      response_time: proxyStats.response_time,
      success_count: proxyStats.success_count,
      failure_count: proxyStats.failure_count,
      created_at: proxyStats.created_at,
      updated_at: proxyStats.updated_at
    };
  }

  /**
   * Конвертирует сырые данные прокси в типизированный объект
   */
  private convertRawProxyStats(raw: Record<string, unknown>): ProxyStats {
    return {
      id: raw.id,
      ip: raw.ip,
      port: raw.port,
      auth_port: raw.auth_port,
      username: raw.username,
      password: raw.password,
      full_url: raw.full_url,
      status: raw.status,
      last_check_at: raw.last_check_at ? new Date(raw.last_check_at) : undefined,
      response_time: raw.response_time,
      success_count: raw.success_count,
      failure_count: raw.failure_count,
      created_at: new Date(raw.created_at),
      updated_at: new Date(raw.updated_at),
      success_rate: parseFloat(raw.success_rate || '0'),
      last_used: raw.last_used ? new Date(raw.last_used) : undefined
    };
  }
}
