'use client';

import { useEffect, useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useVoiceAI } from '@/hooks/useVoiceAI';
import {
  Mic,
  MicOff,
  Trash2,
  Download,
  Filter,
  Play,
  Square,
  Eye,
  EyeOff
} from 'lucide-react';

interface LogEntry {
  id: string;
  timestamp: string;
  message: string;
  type: 'info' | 'success' | 'error' | 'event';
  data?: unknown;
}

export default function DebugPage() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isAutoScroll, setIsAutoScroll] = useState(true);
  const [filterType, setFilterType] = useState<string>('all');
  const [showRawData, setShowRawData] = useState(false);
  const logsEndRef = useRef<HTMLDivElement>(null);

  const { state, isConnected, connect, disconnect, error, logs: voiceLogs } = useVoiceAI();

  // Синхронизируем логи из useVoiceAI
  useEffect(() => {
    if (voiceLogs.length > logs.length) {
      const newLogs = voiceLogs.slice(logs.length).map((log, index) => {
        const id = `${Date.now()}-${index}`;
        const timestamp = new Date().toLocaleTimeString('ru-RU', {
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          fractionalSecondDigits: 3
        });

        let type: LogEntry['type'] = 'info';
        let data = undefined;

        // Определяем тип лога и извлекаем JSON данные
        if (log.includes('❌') || log.includes('Ошибка')) {
          type = 'error';
        } else if (log.includes('✅') || log.includes('Сохранено')) {
          type = 'success';
        } else if (log.includes('🎯') || log.includes('Событие:')) {
          type = 'event';
        }

        // Пытаемся извлечь JSON из лога
        const jsonMatch = log.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          try {
            data = JSON.parse(jsonMatch[0]);
          } catch (e) {
            // Не JSON
          }
        }

        return {
          id,
          timestamp,
          message: log.replace(/^\[.*?\]\s*/, ''), // Убираем timestamp из сообщения
          type,
          data
        };
      });

      setLogs(prev => [...prev, ...newLogs]);
    }
  }, [voiceLogs, logs.length]);

  // Автопрокрутка
  useEffect(() => {
    if (isAutoScroll && logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, isAutoScroll]);

  const clearLogs = () => {
    setLogs([]);
  };

  const downloadLogs = () => {
    const logText = logs.map(log => `[${log.timestamp}] ${log.message}`).join('\n');
    const blob = new Blob([logText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `voice-ai-logs-${new Date().toISOString().slice(0, 19)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleConnect = async () => {
    await connect(1); // Используем тестовый user_id = 1
  };

  const filteredLogs = logs.filter(log => {
    if (filterType === 'all') return true;
    return log.type === filterType;
  });

  const getLogBadgeColor = (type: LogEntry['type']) => {
    switch (type) {
      case 'error': return 'bg-red-500 text-white';
      case 'success': return 'bg-green-500 text-white';
      case 'event': return 'bg-blue-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const formatJSON = (data: unknown) => {
    return JSON.stringify(data, null, 2);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Заголовок */}
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
            🐛 OpenAI Realtime API Debug
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Отладка событий и сохранения истории сообщений
          </p>
        </div>

        {/* Управление */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Подключение */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mic className="w-5 h-5" />
                Управление подключением
              </CardTitle>
              <CardDescription>
                Статус: {' '}
                <Badge className={isConnected ? 'bg-green-500' : 'bg-gray-500'}>
                  {isConnected ? 'Подключен' : 'Отключен'}
                </Badge>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {!isConnected ? (
                <Button
                  onClick={handleConnect}
                  disabled={state === 'connecting'}
                  className="w-full"
                >
                  {state === 'connecting' ? (
                    <>Подключение...</>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      Подключиться к ИИ
                    </>
                  )}
                </Button>
              ) : (
                <Button
                  onClick={disconnect}
                  variant="outline"
                  className="w-full"
                >
                  <Square className="w-4 h-4 mr-2" />
                  Отключиться
                </Button>
              )}

              {error && (
                <div className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded">
                  <p className="text-red-800 dark:text-red-200 text-sm">{error}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Управление логами */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="w-5 h-5" />
                Управление логами
              </CardTitle>
              <CardDescription>
                Всего событий: {logs.length}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex gap-2">
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="flex-1 px-3 py-2 border rounded bg-white dark:bg-gray-800"
                >
                  <option value="all">Все события</option>
                  <option value="info">Информация</option>
                  <option value="event">События ИИ</option>
                  <option value="success">Успешные</option>
                  <option value="error">Ошибки</option>
                </select>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowRawData(!showRawData)}
                >
                  {showRawData ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearLogs}
                  className="flex-1"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Очистить
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={downloadLogs}
                  className="flex-1"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Скачать
                </Button>
              </div>

              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={isAutoScroll}
                  onChange={(e) => setIsAutoScroll(e.target.checked)}
                />
                Автопрокрутка
              </label>
            </CardContent>
          </Card>
        </div>

        {/* Логи */}
        <Card>
          <CardHeader>
            <CardTitle>События в реальном времени</CardTitle>
            <CardDescription>
              Отображаются {filteredLogs.length} из {logs.length} событий
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-96 overflow-y-auto bg-gray-900 text-green-400 p-4 rounded font-mono text-sm">
              {filteredLogs.length === 0 ? (
                <div className="text-gray-500 text-center py-8">
                  Нет событий для отображения
                </div>
              ) : (
                filteredLogs.map((log) => (
                  <div key={log.id} className="mb-2 border-b border-gray-800 pb-2">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-gray-400">[{log.timestamp}]</span>
                      <Badge className={`text-xs ${getLogBadgeColor(log.type)}`}>
                        {log.type}
                      </Badge>
                    </div>

                    <div className="text-gray-200">{log.message}</div>

                    {showRawData && log.data !== undefined && (
                      <details className="mt-2">
                        <summary className="text-blue-400 cursor-pointer hover:text-blue-300">
                          Показать JSON данные
                        </summary>
                        <pre className="mt-2 p-2 bg-gray-800 rounded text-xs overflow-x-auto">
                          {formatJSON(log.data)}
                        </pre>
                      </details>
                    )}
                  </div>
                ))
              )}
              <div ref={logsEndRef} />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
