import { NextRequest, NextResponse } from 'next/server';
import { ProxyService } from '@/lib/proxy-service';
import type { Proxy } from '@/lib/database';

const proxyService = ProxyService.getInstance();

// POST - проверить прокси
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { proxyId, testUrl } = body;

    if (!proxyId) {
      return NextResponse.json(
        { success: false, error: 'Не указан ID прокси' },
        { status: 400 }
      );
    }

    // Получаем прокси из базы
    const proxies = await proxyService.getAllProxies();
    const proxy = proxies.proxies.find(p => p.id === proxyId);

    if (!proxy) {
      return NextResponse.json(
        { success: false, error: 'Прокси не найден' },
        { status: 404 }
      );
    }

    // Проверяем прокси - преобразуем ProxyStats в Proxy
    const proxyForCheck: Proxy = {
      id: proxy.id,
      ip: proxy.ip,
      port: proxy.port,
      auth_port: proxy.auth_port,
      username: proxy.username,
      password: proxy.password,
      full_url: proxy.full_url,
      status: proxy.status as 'active' | 'inactive' | 'failed' | 'checking',
      last_check_at: proxy.last_check_at,
      response_time: proxy.response_time,
      success_count: proxy.success_count,
      failure_count: proxy.failure_count,
      created_at: proxy.created_at,
      updated_at: proxy.updated_at
    };
    const checkResult = await proxyService.checkProxy(proxyForCheck, testUrl);

    return NextResponse.json({
      success: true,
      data: {
        proxyId,
        working: checkResult.success,
        responseTime: checkResult.responseTime,
        error: checkResult.error
      }
    });
  } catch (error) {
    console.error('Ошибка проверки прокси:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка проверки прокси' },
      { status: 500 }
    );
  }
}

// GET - получить лучший рабочий прокси
export async function GET() {
  try {
    const bestProxy = await proxyService.getBestWorkingProxy();

    if (bestProxy) {
      return NextResponse.json({
        success: true,
        data: {
          id: bestProxy.id,
          ip: bestProxy.ip,
          port: bestProxy.port,
          status: bestProxy.status,
          responseTime: bestProxy.response_time,
          successRate: bestProxy.success_count / (bestProxy.success_count + bestProxy.failure_count) * 100
        }
      });
    } else {
      return NextResponse.json({
        success: false,
        error: 'Нет рабочих прокси'
      });
    }
  } catch (error) {
    console.error('Ошибка получения лучшего прокси:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка получения лучшего прокси' },
      { status: 500 }
    );
  }
}
