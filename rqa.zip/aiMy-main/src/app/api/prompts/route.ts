import { NextResponse, NextRequest } from 'next/server';
import { createDbConnection } from '@/lib/database';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userIdParam = searchParams.get('user_id');

    if (!userIdParam) {
      return NextResponse.json(
        { error: 'user_id обязателен' },
        { status: 400 }
      );
    }

    const userId = parseInt(userIdParam);
    const client = createDbConnection();

    try {
      await client.connect();

      // Получаем текущий план пользователя
      const userPlanResult = await client.query(`
        SELECT
          COALESCE(sp.name, 'Бесплатный план') as plan_name,
          CASE
            WHEN sp.name = 'Базовый' THEN 1
            WHEN sp.name = 'Премиум' THEN 2
            WHEN sp.name = 'Про' THEN 3
            ELSE 1
          END as plan_level
        FROM users u
        LEFT JOIN user_subscriptions us ON u.id = us.user_id AND us.status = 'active'
        LEFT JOIN subscription_plans sp ON us.plan_id = sp.id
        WHERE u.id = $1
      `, [userId]);

      const userPlan = userPlanResult.rows[0] || { plan_name: 'Бесплатный план', plan_level: 1 };

      // Получаем базовые промпты, доступные для плана пользователя
      let basePromptsQuery: string;
      let basePromptsParams: number[];

      if (userPlan.plan_level === 3) {
        // Для Про плана - ВСЕ базовые промпты
        basePromptsQuery = `
          SELECT id, title, description, content, plan_required, category, voice_gender
          FROM voice_prompts
          WHERE is_base = true
            AND is_active = true
          ORDER BY plan_required ASC, title ASC
        `;
        basePromptsParams = [];
      } else {
        // Для остальных планов - по уровню доступа
        basePromptsQuery = `
          SELECT id, title, description, content, plan_required, category, voice_gender
          FROM voice_prompts
          WHERE is_base = true
            AND plan_required <= $1
            AND is_active = true
          ORDER BY plan_required ASC, title ASC
        `;
        basePromptsParams = [userPlan.plan_level];
      }

      const basePromptsResult = await client.query(basePromptsQuery, basePromptsParams);

      // Получаем пользовательские промпты
      const userPromptsResult = await client.query(`
        SELECT id, title, description, content, category, voice_gender, created_at
        FROM voice_prompts
        WHERE user_id = $1
          AND is_base = false
          AND is_active = true
        ORDER BY created_at DESC
      `, [userId]);

      // Получаем выбранный промпт пользователя
      const selectedPromptResult = await client.query(`
        SELECT selected_prompt_id
        FROM users
        WHERE id = $1
      `, [userId]);

      const selectedPromptId = selectedPromptResult.rows[0]?.selected_prompt_id;

      // Подсчитываем лимиты для создания промптов
      const userPromptCount = userPromptsResult.rows.length;
      let maxUserPrompts = 0;

      switch (userPlan.plan_level) {
        case 1: maxUserPrompts = 0; break; // Базовый план - только базовые промпты
        case 2: maxUserPrompts = 3; break; // Премиум план - 3 пользовательских промпта
        case 3: maxUserPrompts = -1; break; // Про план - неограниченно
      }

      await client.end();

      return NextResponse.json({
        success: true,
        data: {
          userPlan: userPlan,
          basePrompts: basePromptsResult.rows,
          userPrompts: userPromptsResult.rows,
          selectedPromptId: selectedPromptId,
          promptLimits: {
            current: userPromptCount,
            max: maxUserPrompts, // -1 означает неограниченно
            canCreateMore: maxUserPrompts === -1 || userPromptCount < maxUserPrompts
          }
        }
      });

    } catch (dbError) {
      console.error('Database error:', dbError);
      return NextResponse.json(
        { error: 'Ошибка базы данных' },
        { status: 500 }
      );
    }

  } catch (error) {
    console.error('Error fetching prompts:', error);
    return NextResponse.json(
      { error: 'Ошибка получения промптов' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { user_id, title, description, content, category, voice_gender } = body;

    if (!user_id || !title || !content) {
      return NextResponse.json(
        { error: 'user_id, title и content обязательны' },
        { status: 400 }
      );
    }

    const client = createDbConnection();

    try {
      await client.connect();

      // Проверяем лимиты пользователя
      const userPlanResult = await client.query(`
        SELECT
          CASE
            WHEN sp.name = 'Базовый' THEN 1
            WHEN sp.name = 'Премиум' THEN 2
            WHEN sp.name = 'Про' THEN 3
            ELSE 1
          END as plan_level
        FROM users u
        LEFT JOIN user_subscriptions us ON u.id = us.user_id AND us.status = 'active'
        LEFT JOIN subscription_plans sp ON us.plan_id = sp.id
        WHERE u.id = $1
      `, [user_id]);

      const planLevel = userPlanResult.rows[0]?.plan_level || 1;

      // Проверяем количество созданных промптов
      const userPromptCountResult = await client.query(`
        SELECT COUNT(*) as count
        FROM voice_prompts
        WHERE user_id = $1 AND is_base = false AND is_active = true
      `, [user_id]);

      const currentCount = parseInt(userPromptCountResult.rows[0].count);

      let maxPrompts = 0;
      switch (planLevel) {
        case 1: maxPrompts = 0; break;
        case 2: maxPrompts = 3; break;
        case 3: maxPrompts = -1; break; // неограниченно
      }

      if (maxPrompts !== -1 && currentCount >= maxPrompts) {
        return NextResponse.json(
          { error: `Достигнут лимит промптов для вашего плана (${maxPrompts})` },
          { status: 403 }
        );
      }

      // Создаем новый промпт
      const insertResult = await client.query(`
        INSERT INTO voice_prompts (user_id, title, description, content, category, voice_gender, is_base)
        VALUES ($1, $2, $3, $4, $5, $6, false)
        RETURNING id, title, description, category, voice_gender, created_at
      `, [user_id, title, description || '', content, category || 'general', voice_gender || 'any']);

      await client.end();

      return NextResponse.json({
        success: true,
        prompt: insertResult.rows[0]
      });

    } catch (dbError) {
      console.error('Database error:', dbError);
      return NextResponse.json(
        { error: 'Ошибка создания промпта' },
        { status: 500 }
      );
    }

  } catch (error) {
    console.error('Error creating prompt:', error);
    return NextResponse.json(
      { error: 'Ошибка создания промпта' },
      { status: 500 }
    );
  }
}
