module.exports = {
  apps: [
    {
      name: 'deposit-monitor',
      script: 'deposit-monitor.js',
      cwd: process.cwd(),
      env: {
        NODE_ENV: 'production',
      },
      instances: 1, // Важно: только один экземпляр для избежания race conditions
      exec_mode: 'fork',
      max_memory_restart: '256M',
      listen_timeout: 10000,
      kill_timeout: 10000,
      out_file: './.pm2/deposit-monitor-out.log',
      error_file: './.pm2/deposit-monitor-error.log',
      merge_logs: true,
      autorestart: true,
      watch: false,
      restart_delay: 5000, // задержка 5 секунд перед перезапуском
      max_restarts: 10, // максимум 10 перезапусков подряд
      min_uptime: '30s', // минимальное время работы для считания стабильным
      exp_backoff_restart_delay: 100, // экспоненциальная задержка при ошибках
      // Мониторинг и алерты
      pmx: true,
      // Переменные окружения
      env_production: {
        NODE_ENV: 'production'
      }
    }
  ]
};
