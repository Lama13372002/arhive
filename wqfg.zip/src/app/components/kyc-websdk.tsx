"use client";
import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';

export default function KycWebSdk({ userId, email, phone }: { userId: number; email?: string; phone?: string; }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [loading, setLoading] = useState(false);
  const [launched, setLaunched] = useState(false);

  const launch = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/kyc/token', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId, email, phone }) });
      const { token } = await res.json();
      // Dynamically import websdk in client
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const snsWebSdk: any = (await import('@sumsub/websdk')).default;
      const instance = snsWebSdk
        .init(token, async () => {
          const r = await fetch('/api/kyc/token', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId, email, phone }) });
          const j = await r.json();
          return j.token;
        })
        .withConf({ lang: 'en' })
        .on('onError', (error: unknown) => console.error('Sumsub SDK error', error))
        .onMessage((type: string, payload: unknown) => console.log('Sumsub SDK message', type, payload))
        .build();
      if (containerRef.current) instance.launch(containerRef.current);
      setLaunched(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-3">
      {!launched && <Button onClick={launch} disabled={loading}>{loading ? 'Loading...' : 'Start Verification'}</Button>}
      <div ref={containerRef} id="sumsub-websdk-container" />
    </div>
  );
}
