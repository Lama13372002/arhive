import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { BalanceDBResult } from '@/types';

function round2(n: number) { return Math.round(n * 100) / 100; }

export async function POST(request: NextRequest) {
  try {
    const { amount, address, network, user_id } = await request.json();

    // Валидация входных данных
    if (!amount || !address || !network || !user_id) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Проверяем лимиты и комиссии для выбранной сети (authoritative source)
    const serviceResult = await db.query(
      'SELECT min_amount, max_amount, fee_fixed, fee_percent FROM provider_services WHERE service_type = $1 AND network_code = $2 AND is_available = true',
      ['payout', network]
    );

    if (serviceResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: `Network ${network} is not available for withdrawals` },
        { status: 400 }
      );
    }

    const service = serviceResult.rows[0];
    const minAmount = round2(parseFloat(String(service.min_amount || '10')));
    const maxAmount = round2(parseFloat(String(service.max_amount || '1000000')));
    const feeFixed = round2(parseFloat(String(service.fee_fixed || '0')));
    const feePercent = parseFloat(String(service.fee_percent || '0')); // as fraction (e.g., 0.03)

    const grossAmount = round2(parseFloat(String(amount))); // what user requested to withdraw

    if (grossAmount < minAmount) {
      return NextResponse.json(
        { success: false, error: `Minimum withdrawal amount is ${minAmount} USDT` },
        { status: 400 }
      );
    }

    if (grossAmount > maxAmount) {
      return NextResponse.json(
        { success: false, error: `Maximum withdrawal amount is ${maxAmount} USDT` },
        { status: 400 }
      );
    }

    // Проверяем существование пользователя
    const userResult = await db.query(
      'SELECT id FROM users WHERE telegram_id = $1',
      [user_id]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = userResult.rows[0].id;

    // Проверяем баланс пользователя (доступный)
    const balanceResult = await db.query(
      'SELECT available FROM users_balance WHERE user_id = $1 AND currency = $2',
      [userId, 'USDT']
    );

    if (balanceResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'No balance found' },
        { status: 400 }
      );
    }

    const availableBalance = parseFloat((balanceResult.rows[0] as unknown as BalanceDBResult).available);

    // Рассчитываем комиссию и NET (то, что получит пользователь)
    let feeTotal = feeFixed;
    if (feePercent > 0) {
      feeTotal += grossAmount * feePercent;
    }
    feeTotal = round2(feeTotal);
    const netAmount = round2(grossAmount - feeTotal);

    if (netAmount <= 0) {
      return NextResponse.json(
        { success: false, error: 'Withdrawal amount is too small after fees' },
        { status: 400 }
      );
    }

    // Блокируем только GROSS с баланса (списываем ровно то, что ввёл пользователь)
    if (availableBalance < grossAmount) {
      return NextResponse.json(
        { success: false, error: `Insufficient balance. Required: ${grossAmount.toFixed(2)} USDT, Available: ${availableBalance.toFixed(2)} USDT` },
        { status: 400 }
      );
    }

    const orderId = `withdrawal_${userId}_${Date.now()}`;

    await db.transaction(async (client) => {
      // Анти-дубликат за последние 3 минуты с теми же параметрами
      const duplicateCheck = await client.query(
        `SELECT id, amount, address, network_code, fee, provider_order_id, created_at
         FROM withdrawals
         WHERE user_id = $1
           AND currency = 'USDT'
           AND status = 'pending'
           AND amount = $2
           AND address = $3
           AND network_code = $4
           AND created_at >= NOW() - INTERVAL '3 minutes'
         ORDER BY id DESC
         LIMIT 1`,
        [userId, grossAmount, address, network]
      );

      if (duplicateCheck.rows.length > 0) {
        const existing = duplicateCheck.rows[0];
        throw new Error(JSON.stringify({
          __dedup_return: true,
          data: {
            order_id: existing.provider_order_id,
            gross_amount: grossAmount,
            net_amount: round2(grossAmount - (existing.fee || 0)),
            address,
            network,
            fee: existing.fee,
            status: 'pending',
            message: 'Withdrawal request already exists (deduplicated).'
          }
        }));
      }

      // Ledger: блокируем только GROSS
      await client.query(
        `INSERT INTO ledger_entries
         (user_id, currency, entry_type, amount, balance_available_delta, balance_locked_delta, idempotency_key, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
        [userId, 'USDT', 'withdrawal_lock', grossAmount, -grossAmount, grossAmount, orderId]
      );

      // Записываем вывод: amount = GROSS; fee; и можно добавить net_amount в отдельное поле, если есть
      await client.query(
        `INSERT INTO withdrawals
         (user_id, currency, amount, address, fee, status, network_code, provider, provider_order_id, requested_at, created_at, updated_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW(), NOW())`,
        [userId, 'USDT', grossAmount, address, feeTotal, 'pending', network, 'nowpayments', orderId]
      );
    });

    // Возвращаем все расчёты, чтобы UI и админ видели NET
    return NextResponse.json({
      success: true,
      data: {
        order_id: orderId,
        gross_amount: grossAmount,
        net_amount: netAmount,
        address: address,
        network: network,
        fee: feeTotal,
        status: 'pending',
        message: 'Withdrawal request created. It will be processed by admin within 24 hours.'
      }
    });

  } catch (error: unknown) {
    if (error instanceof Error) {
      try {
        const payload = JSON.parse(error.message);
        if (payload && payload.__dedup_return) {
          return NextResponse.json({ success: true, data: payload.data });
        }
      } catch (_) {}
    }

    console.error('Withdrawal creation error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
