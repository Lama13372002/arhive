import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const telegram_id = searchParams.get('telegram_id');
    if (!telegram_id) {
      return NextResponse.json({ success: false, error: 'Telegram ID is required' }, { status: 400 });
    }

    const userRes = await db.query('SELECT id FROM users WHERE telegram_id = $1', [telegram_id]);
    if (userRes.rows.length === 0) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 });
    }
    const userId = userRes.rows[0].id as number;

    const rows = await db.query(
      `select rr.id,
              rr.amount,
              rr.level,
              rr.created_at,
              fu.telegram_id as from_telegram_id
       from referral_rewards rr
       join users fu on fu.id = rr.from_user_id
       where rr.to_user_id = $1
       order by rr.created_at desc
       limit 100`,
      [userId]
    );

    const items = rows.rows.map((r) => ({
      id: Number(r.id),
      amount: Number(r.amount),
      level: Number(r.level),
      date: r.created_at,
      from_telegram_id: Number(r.from_telegram_id),
    }));

    return NextResponse.json({ success: true, data: items });
  } catch (e) {
    console.error('Referral earnings error:', e);
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 });
  }
}
