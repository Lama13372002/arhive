import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

type ReferralCfg = { L1?: number; L2?: number; L3?: number };

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const telegram_id = searchParams.get('telegram_id');
    if (!telegram_id) {
      return NextResponse.json({ success: false, error: 'Telegram ID is required' }, { status: 400 });
    }

    const userRes = await db.query('SELECT id FROM users WHERE telegram_id = $1', [telegram_id]);
    if (userRes.rows.length === 0) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 });
    }
    const userId = userRes.rows[0].id as number;

    // totals by levels 1-3
    const levelCountsRes = await db.query(
      `with recursive tree as (
        select id, referred_by_id, 1 as level from users where referred_by_id = $1
        union all
        select u.id, u.referred_by_id, t.level + 1 from users u
        join tree t on u.referred_by_id = t.id
        where t.level < 3
      )
      select
        sum(case when level = 1 then 1 else 0 end) as level1,
        sum(case when level = 2 then 1 else 0 end) as level2,
        sum(case when level = 3 then 1 else 0 end) as level3
      from tree`,
      [userId]
    );
    const level1 = Number(levelCountsRes.rows[0]?.level1 || 0);
    const level2 = Number(levelCountsRes.rows[0]?.level2 || 0);
    const level3 = Number(levelCountsRes.rows[0]?.level3 || 0);

    // earnings total and this month
    const earningsRes = await db.query(
      `select
         coalesce(sum(amount),0) as total,
         coalesce(sum(case when date_trunc('month', created_at) = date_trunc('month', now()) then amount else 0 end),0) as this_month
       from referral_rewards
       where to_user_id = $1`,
      [userId]
    );
    const totalEarned = Number(earningsRes.rows[0]?.total || 0);
    const thisMonth = Number(earningsRes.rows[0]?.this_month || 0);

    // commission percentages from app_config
    const percRes = await db.query(`select value from app_config where key = 'referral_percentages'`);
    const raw = percRes.rows[0]?.value as unknown as ReferralCfg | undefined;
    const parsed: ReferralCfg = raw && typeof raw === 'object' ? raw : { L1: 0.05, L2: 0.02, L3: 0.01 };
    const L1 = Number(parsed.L1 ?? 0.05);
    const L2 = Number(parsed.L2 ?? 0.02);
    const L3 = Number(parsed.L3 ?? 0.01);

    return NextResponse.json({
      success: true,
      data: {
        totalEarned,
        thisMonth,
        totalReferrals: level1 + level2 + level3,
        level1,
        level2,
        level3,
        commissionRates: {
          level1: L1 * 100,
          level2: L2 * 100,
          level3: L3 * 100,
        },
      },
    });
  } catch (e) {
    console.error('Referral stats error:', e);
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 });
  }
}
