import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { mapSumsubAnswerToStatus } from '@/lib/sumsub';
import crypto from 'crypto';

function verifySignature(req: NextRequest, rawBody: string): boolean {
  const secret = process.env.SUMSUB_WEBHOOK_SECRET;
  if (!secret) return true; // allow if not configured yet
  const sigHeader = req.headers.get('x-payload-digest') || req.headers.get('x-signature') || '';
  // Sumsub usually sends SHA256 hex of body with shared secret
  const expected = crypto.createHmac('sha256', secret).update(Buffer.from(rawBody, 'utf8')).digest('hex');
  return sigHeader === expected;
}

async function updateUserKycByExternalUserId(externalUserId: string, reviewResult?: { reviewAnswer?: string; reviewRejectType?: string }, reviewStatus?: string) {
  const userRes = await db.query('SELECT id FROM users WHERE telegram_id = $1', [externalUserId]);
  if (!userRes.rowCount) return;
  const userId = userRes.rows[0].id as number;
  const status = mapSumsubAnswerToStatus(reviewResult?.reviewAnswer, reviewResult?.reviewRejectType);
  const finalStatus = reviewStatus === 'completed' && status === 'pending' ? 'completed' : status;

  await db.query(
    `INSERT INTO sumsub_applications (user_id, external_applicant_id, review_status, review_result)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (user_id, external_applicant_id)
     DO UPDATE SET review_status = EXCLUDED.review_status, review_result = EXCLUDED.review_result, updated_at = now()`,
    [userId, String(externalUserId), finalStatus, reviewResult]
  );
  await db.query('UPDATE users SET kyc_status = $1, updated_at = now() WHERE id = $2', [finalStatus, userId]);
}

export async function POST(req: NextRequest) {
  const raw = await req.text();
  let payload: {
    type?: unknown;
    eventType?: unknown;
    applicantId?: unknown;
    externalUserId?: unknown;
    reviewResult?: unknown;
    reviewStatus?: unknown;
    data?: {
      applicantId?: unknown;
      externalUserId?: unknown;
      reviewResult?: unknown;
      reviewStatus?: unknown;
      [key: string]: unknown;
    };
    [key: string]: unknown;
  } | null = null;
  try {
    payload = JSON.parse(raw);
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON' }, { status: 400 });
  }

  if (!verifySignature(req, raw)) {
    return NextResponse.json({ ok: false, error: 'Invalid signature' }, { status: 401 });
  }

  try {
    const eventType: string | undefined = (payload?.type as string) ?? (payload?.eventType as string);
    const applicantId: string | undefined = (payload?.applicantId as string) ?? (payload?.data?.applicantId as string);
    const externalUserId: string | undefined = (payload?.externalUserId as string) ?? (payload?.data?.externalUserId as string);
    const reviewResult = payload?.reviewResult ?? payload?.data?.reviewResult;
    const reviewStatus: string | undefined = (payload?.reviewStatus as string) ?? (payload?.data?.reviewStatus as string);

    const idemRes = await db.query(
      `INSERT INTO idempotency_keys (source, operation_type, external_id)
       VALUES ($1, $2, $3)
       ON CONFLICT (source, operation_type, external_id, COALESCE(user_id, 0)) DO NOTHING
       RETURNING id`,
      ['sumsub', eventType || 'unknown', String(payload?.id ?? applicantId ?? externalUserId ?? 'unknown')]
    );
    const idemId = idemRes.rows[0]?.id ?? null;

    await db.query(
      `INSERT INTO inbound_webhooks (source, signature, event_type, external_id, payload, idempotency_key_id)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      ['sumsub', req.headers.get('x-payload-digest') ?? req.headers.get('x-signature') ?? null, eventType ?? null, applicantId ?? externalUserId ?? null, payload, idemId]
    );

    // Map relevant events to user status updates
    const kycAffecting = new Set([
      'applicantReviewed',
      'applicantPending',
      'applicantOnHold',
      'applicantAwaitingUser',
      'applicantAwaitingService',
      'applicantWorkflowCompleted',
      'applicantWorkflowFailed',
      'applicantPersonalInfoChanged',
      'applicantTagsChanged',
    ]);

    if (externalUserId && kycAffecting.has(eventType || '')) {
      await updateUserKycByExternalUserId(externalUserId, reviewResult as { reviewAnswer?: string; reviewRejectType?: string }, reviewStatus);
    }

    return NextResponse.json({ ok: true });
  } catch (e: unknown) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : 'Internal error' }, { status: 500 });
  }
}
