import { NextRequest, NextResponse } from 'next/server';
import { generateRandomFee, calculateDepositWithFee } from '@/lib/utils';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const amount = searchParams.get('amount');
    const network = searchParams.get('network');

    if (!amount || !network) {
      return NextResponse.json(
        { success: false, error: 'Amount and network are required' },
        { status: 400 }
      );
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return NextResponse.json(
        { success: false, error: 'Invalid amount' },
        { status: 400 }
      );
    }

    // Маппинг сетей на валюты
    const payCurrencyMap: Record<string, string> = {
      'TRON': 'usdttrc20',
      'BSC': 'usdtbsc',
      'ETH': 'usdterc20',
      'POLYGON': 'usdtmatic',
      'TON': 'usdtton',
    };

    const payCurrency = payCurrencyMap[network];
    if (!payCurrency) {
      return NextResponse.json(
        { success: false, error: `Network ${network} is not supported` },
        { status: 400 }
      );
    }

    try {
      // Генерируем случайную комиссию от 1.5% до 2.5%
      const randomFeePercent = generateRandomFee();

      // Рассчитываем сумму к оплате
      // numAmount - это желаемая сумма к получению
      const calculation = calculateDepositWithFee(numAmount, randomFeePercent);

      return NextResponse.json({
        success: true,
        data: {
          network,
          desired_amount: calculation.desired_amount,    // Желаемая сумма к получению
          pay_amount: calculation.pay_amount,           // Сумма к оплате (больше desired_amount)
          received_amount: calculation.desired_amount,   // Сумма которую получит на баланс
          fees: {
            platform_fee: {
              amount: calculation.fee_amount,
              percent: calculation.fee_percent
            },
            total_fee: {
              amount: calculation.fee_amount,
              percent: calculation.fee_percent
            }
          },
          payment_details: {
            currency: payCurrency,
            network_name: network
          },
          note: `Platform fee: ${calculation.fee_percent}%`
        }
      });

    } catch (error) {
      console.error('Fee calculation error:', error);

      // Возвращаем оценку с базовой комиссией 2%
      const fallbackFeePercent = 2.0;
      const calculation = calculateDepositWithFee(numAmount, fallbackFeePercent);

      return NextResponse.json({
        success: true,
        data: {
          network,
          desired_amount: calculation.desired_amount,
          pay_amount: calculation.pay_amount,
          received_amount: calculation.desired_amount,
          fees: {
            platform_fee: {
              amount: calculation.fee_amount,
              percent: calculation.fee_percent
            },
            total_fee: {
              amount: calculation.fee_amount,
              percent: calculation.fee_percent
            }
          },
          payment_details: {
            currency: payCurrency,
            network_name: network
          },
          estimated: true,
          note: `Platform fee: ${calculation.fee_percent}% (fallback)`
        }
      });
    }

  } catch (error) {
    console.error('Fee estimation error:', error);

    return NextResponse.json(
      {
        success: false,
        error: 'Failed to estimate fees',
        details: error instanceof Error ? error.message : String(error)
      },
      { status: 500 }
    );
  }
}
