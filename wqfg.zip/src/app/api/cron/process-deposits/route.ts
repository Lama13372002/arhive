import { NextRequest, NextResponse } from 'next/server';
import { processConfirmedDeposits } from '@/lib/cron';
import type { ProcessDepositsResult } from '@/types';

export async function POST(request: NextRequest) {
  try {
    console.log('⚠️ DEPRECATED: Cron обработка депозитов отключена');
    console.log('💡 Используйте deposit-monitor.js для обработки депозитов');

    return NextResponse.json({
      success: false,
      error: 'Deposit processing disabled in API - use deposit-monitor.js',
      message: 'Этот endpoint отключен. Обработка депозитов выполняется через deposit-monitor.js'
    }, { status: 200 });

  } catch (error) {
    console.error('❌ Cron API error:', error);
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

// Разрешаем только GET для статуса
export async function GET() {
  return NextResponse.json({
    status: 'ready',
    message: 'Deposit processing endpoint is ready'
  });
}
