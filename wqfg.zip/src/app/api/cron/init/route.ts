import { NextRequest, NextResponse } from 'next/server';
import { initializeCron } from '@/lib/cron';

// Инициализация cron при старте приложения
export async function POST(request: NextRequest) {
  try {
    // Проверяем что это внутренний запрос
    const userAgent = request.headers.get('user-agent');
    if (!userAgent?.includes('Internal') && process.env.NODE_ENV === 'production') {
      return NextResponse.json({
        success: false,
        error: 'Unauthorized'
      }, { status: 401 });
    }

    await initializeCron();

    return NextResponse.json({
      success: true,
      message: 'Cron jobs initialized',
      environment: process.env.NODE_ENV,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to initialize cron:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to initialize cron',
      details: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}

// Для проверки статуса
export async function GET(request: NextRequest) {
  return NextResponse.json({
    success: true,
    message: 'Cron service is available',
    environment: process.env.NODE_ENV,
    isProduction: process.env.NODE_ENV === 'production',
    isVercel: !!process.env.VERCEL,
    isNetlify: !!process.env.NETLIFY,
    timestamp: new Date().toISOString()
  });
}
