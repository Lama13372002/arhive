'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { TelegramWebApp, ApiResponse } from '@/types';
import { useToast } from '@/hooks/use-toast';

interface TelegramContextType {
  webApp: TelegramWebApp | null;
  user: TelegramWebApp['initDataUnsafe']['user'] | null;
  startParam: string | null;
  isReady: boolean;
  onAppResume?: () => void;
}

const TelegramContext = createContext<TelegramContextType>({
  webApp: null,
  user: null,
  startParam: null,
  isReady: false,
});

export const useTelegram = () => useContext(TelegramContext);

type EnsureUserResult =
  | { existed: true }
  | { existed: false; registered: true }
  | { existed: false; registered: false };

interface UserApiData {
  user_id: number;
  ref_code: string;
  username?: string;
  message: string;
  updated?: boolean;
  created_at?: string;
  language?: string;
}

export function TelegramProvider({ children }: { children: React.ReactNode }) {
  const [webApp, setWebApp] = useState<TelegramWebApp | null>(null);
  const [user, setUser] = useState<TelegramWebApp['initDataUnsafe']['user'] | null>(null);
  const [startParam, setStartParam] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [hasAuthed, setHasAuthed] = useState(false);
  const [appResumeCallbacks, setAppResumeCallbacks] = useState<(() => void)[]>([]);
  const { toast } = useToast();

  const addAppResumeCallback = (callback: () => void) => {
    setAppResumeCallbacks(prev => [...prev, callback]);
  };

  const removeAppResumeCallback = (callback: () => void) => {
    setAppResumeCallbacks(prev => prev.filter(cb => cb !== callback));
  };

  useEffect(() => {
    async function ensureUser(
      telegramId: number,
      phone?: string,
      language?: string,
      referredByCode?: string,
      username?: string,
      firstName?: string,
      lastName?: string
    ): Promise<EnsureUserResult> {
      const regFlagKey = `user_registered:${telegramId}`;
      try {
        // 1) check if exists
        const checkRes = await fetch(`/api/user/register?telegram_id=${telegramId}`);
        if (checkRes.ok) {
          const checkData: ApiResponse = await checkRes.json();

          // Если пользователь существует, но нужно обновить username
          if (checkData.success && checkData.data && username) {
            const userData = checkData.data as UserApiData;
            if (userData.username !== username) {
              console.log(`Username изменился: ${userData.username} -> ${username}`);

              // Отправляем POST запрос для обновления username'а
              const updateBody = {
                telegram_id: String(telegramId),
                phone,
                language: (language === 'ru' || language === 'en') ? language : 'ru',
                referred_by_code: referredByCode || undefined,
                username,
                first_name: firstName,
                last_name: lastName,
              };

              const updateRes = await fetch('/api/user/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updateBody),
              });

              const updateData: ApiResponse = await updateRes.json();
              if (updateData.success && (updateData.data as UserApiData)?.updated) {
                console.log('Username успешно обновлен в базе данных');
                toast({
                  title: 'Profile Updated',
                  description: 'Your username has been automatically updated.',
                });
              }
            }
          }

          // Persist that this user is registered to suppress future referral toasts
          try { localStorage.setItem(regFlagKey, '1'); } catch {}
          setHasAuthed(true);
          return { existed: true } as const;
        }

        // 2) register (include referral code if present)
        const body = {
          telegram_id: String(telegramId),
          phone,
          language: (language === 'ru' || language === 'en') ? language : 'ru',
          referred_by_code: referredByCode || undefined,
          username,
          first_name: firstName,
          last_name: lastName,
        };
        const regRes = await fetch('/api/user/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        });
        const data: ApiResponse = await regRes.json();
        if (!regRes.ok || !data.success) {
          console.warn('Auto registration failed:', data);
          return { existed: false, registered: false } as const;
        } else {
          // Persist registered flag
          try { localStorage.setItem(regFlagKey, '1'); } catch {}
          setHasAuthed(true);
          return { existed: false, registered: true } as const;
        }
      } catch (e) {
        console.warn('Auto registration error:', e);
        return { existed: false, registered: false } as const;
      }
    }

    if (typeof window !== 'undefined' && window.Telegram?.WebApp) {
      const tg = window.Telegram.WebApp;
      tg.ready();
      tg.expand();

      // Theme hookup
      if (tg.colorScheme) {
        document.documentElement.setAttribute('data-theme', tg.colorScheme);
      }
      if (tg.themeParams) {
        const root = document.documentElement;
        root.style.setProperty('--tg-theme-bg-color', tg.themeParams.bg_color || '#1a1d26');
        root.style.setProperty('--tg-theme-text-color', tg.themeParams.text_color || '#ffffff');
        root.style.setProperty('--tg-theme-hint-color', tg.themeParams.hint_color || '#999999');
        root.style.setProperty('--tg-theme-link-color', tg.themeParams.link_color || '#2ea043');
        root.style.setProperty('--tg-theme-button-color', tg.themeParams.button_color || '#2ea043');
        root.style.setProperty('--tg-theme-button-text-color', tg.themeParams.button_text_color || '#ffffff');
      }

      setWebApp(tg);
      const tgUser = tg.initDataUnsafe?.user || null;
      setUser(tgUser);
      // Capture referral start_param from deep link
      const sp = tg.initDataUnsafe?.start_param || null;
      setStartParam(sp);

      // auto-check/register user including referral code and username
      if (tgUser?.id && !hasAuthed) {
        ensureUser(
          tgUser.id,
          undefined,
          tgUser.language_code,
          sp || undefined,
          tgUser.username,
          tgUser.first_name,
          tgUser.last_name
        ).then((res: EnsureUserResult) => {
          // Show referral welcome toast ONLY if:
          // - there is a ref code (sp)
          // - user did not exist before (res.existed === false)
          // - and registration succeeded now (res.registered === true)
          if (sp && res.existed === false && res.registered === true) {
            const key = `ref_welcome_shown:${sp}`;
            try {
              const shown = typeof window !== 'undefined' ? localStorage.getItem(key) : '1';
              if (!shown) {
                toast({
                  title: 'Welcome!',
                  description: 'You followed a referral link. Enjoy using the app!',
                });
                localStorage.setItem(key, '1');
              }
            } catch {}
          }
        });
      }

      // Обработчики для отслеживания возвращения в приложение
      const handleAppResume = () => {
        appResumeCallbacks.forEach(callback => callback());
      };

      // Слушаем события возвращения в приложение
      document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
          handleAppResume();
        }
      });

      window.addEventListener('focus', handleAppResume);

      setIsReady(true);
    } else {
      // Development fallback: mock user so local testing works
      if (process.env.NODE_ENV === 'development') {
        const mockUser = {
          id: 123456789,
          first_name: 'Test',
          last_name: 'User',
          username: 'testuser',
          language_code: 'ru',
        } as const;
        setUser(mockUser as TelegramWebApp['initDataUnsafe']['user']);
        const sp = 'ref123456';
        setStartParam(sp);
        if (!hasAuthed) {
          ensureUser(
            mockUser.id,
            undefined,
            mockUser.language_code,
            sp,
            mockUser.username,
            mockUser.first_name,
            mockUser.last_name
          ).then((res: EnsureUserResult) => {
            if (sp && res.existed === false && res.registered === true) {
              const key = `ref_welcome_shown:${sp}`;
              try {
                const shown = typeof window !== 'undefined' ? localStorage.getItem(key) : '1';
                if (!shown) {
                  toast({
                    title: 'Добро пожаловать!',
                    description: 'Вы перешли по реферальной ссылке. Приятного пользования!',
                  });
                  localStorage.setItem(key, '1');
                }
              } catch {}
            }
          });
        }
        setIsReady(true);
      }
    }
  }, [hasAuthed, toast]);

  const value: TelegramContextType = {
    webApp,
    user,
    startParam,
    isReady,
    onAppResume: () => {
      appResumeCallbacks.forEach(callback => callback());
    },
  };

  return (
    <TelegramContext.Provider value={value}>
      {children}
    </TelegramContext.Provider>
  );
}

// Extend Window interface for TypeScript
declare global {
  interface Window {
    Telegram?: {
      WebApp: TelegramWebApp;
    };
  }
}
