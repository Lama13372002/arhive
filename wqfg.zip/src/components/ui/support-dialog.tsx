'use client';

import { useState } from 'react';
import { Copy, Mail, MessageCircle, HelpCircle, CheckCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface SupportDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SupportDialog({ isOpen, onClose }: SupportDialogProps) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const supportEmail = process.env.NEXT_PUBLIC_SUPPORT_EMAIL || 'support@example.com';

  const copyEmail = async () => {
    try {
      await navigator.clipboard.writeText(supportEmail);
      setCopied(true);
      toast({
        title: "Email Copied",
        description: "Support email has been copied to clipboard",
      });

      // Reset copied state after 2 seconds
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Unable to copy email. Please copy manually.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[75vh] w-[90vw] overflow-y-auto bg-card border border-border/60 shadow-xl rounded-2xl">
        <DialogHeader className="pb-4 border-b border-border/60">
          <DialogTitle className="text-xl font-semibold flex items-center">
            <div className="mr-3 rounded-full p-2 border border-border/60 bg-primary/10">
              <HelpCircle size={20} className="text-primary" />
            </div>
            Get Support
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 pt-2">
          {/* Welcome Message */}
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
              <MessageCircle size={20} className="text-primary" />
            </div>
            <h3 className="text-base font-semibold text-white">We're Here to Help!</h3>
            <p className="text-xs text-muted-foreground">
              Have questions or need assistance? Our support team is ready to help you.
            </p>
          </div>

          {/* Contact Information */}
          <div className="space-y-4">
            <div className="rounded-xl border border-border/60 bg-card/50 p-4">
              <div className="flex items-center mb-3">
                <Mail size={18} className="text-primary mr-2" />
                <span className="font-medium text-white">Email Support</span>
              </div>

              <div className="flex items-center justify-between rounded-lg border border-border/40 bg-card/60 px-3 py-2">
                <span className="text-sm font-mono text-white/90">{supportEmail}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={copyEmail}
                  className="ml-2 flex-shrink-0 h-8 w-8 p-0"
                >
                  {copied ? (
                    <CheckCircle size={14} className="text-green-500" />
                  ) : (
                    <Copy size={14} />
                  )}
                </Button>
              </div>

              <p className="text-xs text-muted-foreground mt-2">
                Click the copy button to copy our email address
              </p>
            </div>

            {/* What we can help with */}
            <div className="space-y-2">
              <h4 className="font-medium text-xs text-white">What can we help you with?</h4>
              <div className="grid grid-cols-1 gap-1 text-xs text-muted-foreground">
                <div className="flex items-center">
                  <div className="w-1 h-1 rounded-full bg-primary mr-2"></div>
                  Account & verification issues
                </div>
                <div className="flex items-center">
                  <div className="w-1 h-1 rounded-full bg-primary mr-2"></div>
                  Deposits & withdrawals
                </div>
                <div className="flex items-center">
                  <div className="w-1 h-1 rounded-full bg-primary mr-2"></div>
                  Investment plans
                </div>
                <div className="flex items-center">
                  <div className="w-1 h-1 rounded-full bg-primary mr-2"></div>
                  Technical support
                </div>
              </div>
            </div>

            {/* Response time */}
            <div className="rounded-lg bg-primary/5 border border-primary/20 p-2">
              <p className="text-xs text-primary font-medium">
                ⏱️ Response: Within 24 hours
              </p>
            </div>
          </div>


        </div>
      </DialogContent>
    </Dialog>
  );
}
