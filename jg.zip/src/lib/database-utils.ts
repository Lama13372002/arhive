import { query } from './database';

export interface BetResult {
  bet_id: number;
  user_id: number;
  win_amount?: number;
  loss_amount?: number;
  transaction_type: 'bet_win' | 'bet_create' | 'bet_join';
  currency: 'TON' | 'STARS';
}

/**
 * Получает информацию о выигрышах и проигрышах пользователя по спорам
 */
export async function getUserBetResults(userId: number): Promise<BetResult[]> {
  try {
    const result = await query(`
      SELECT
        t.bet_id,
        t.user_id,
        t.transaction_type,
        t.currency,
        t.amount,
        b.status as bet_status,
        CASE
          WHEN t.transaction_type = 'bet_win' THEN t.amount
          ELSE NULL
        END as win_amount,
        CASE
          WHEN t.transaction_type IN ('bet_create', 'bet_join') AND b.status IN ('completed', 'cancelled')
               AND NOT EXISTS (
                 SELECT 1 FROM transactions t2
                 WHERE t2.bet_id = t.bet_id
                 AND t2.user_id = t.user_id
                 AND t2.transaction_type = 'bet_win'
               )
          THEN t.amount
          ELSE NULL
        END as loss_amount
      FROM transactions t
      JOIN bets b ON t.bet_id = b.id
      WHERE t.user_id = $1
        AND t.bet_id IS NOT NULL
        AND t.transaction_type IN ('bet_win', 'bet_create', 'bet_join')
      ORDER BY t.created_at DESC
    `, [userId]);

    return result.rows as BetResult[];
  } catch (error) {
    console.error('Error fetching user bet results:', error);
    return [];
  }
}

/**
 * Получает результат конкретного спора для пользователя
 */
export async function getBetResultForUser(betId: number, userId: number): Promise<{
  win_amount?: number;
  loss_amount?: number;
  currency: 'TON' | 'STARS';
} | null> {
  try {
    // Сначала проверяем, выиграл ли пользователь
    const winResult = await query(`
      SELECT amount, currency
      FROM transactions
      WHERE bet_id = $1 AND user_id = $2 AND transaction_type = 'bet_win'
      ORDER BY created_at DESC
      LIMIT 1
    `, [betId, userId]);

    if (winResult.rows.length > 0) {
      return {
        win_amount: winResult.rows[0].amount,
        currency: winResult.rows[0].currency
      };
    }

    // Если не выиграл, проверяем проиграл ли (потратил деньги на спор)
    const lossResult = await query(`
      SELECT
        SUM(t.amount) as total_spent,
        t.currency,
        b.status
      FROM transactions t
      JOIN bets b ON t.bet_id = b.id
      WHERE t.bet_id = $1
        AND t.user_id = $2
        AND t.transaction_type IN ('bet_create', 'bet_join')
        AND b.status IN ('completed', 'cancelled')
      GROUP BY t.currency, b.status
    `, [betId, userId]);

    if (lossResult.rows.length > 0) {
      return {
        loss_amount: lossResult.rows[0].total_spent,
        currency: lossResult.rows[0].currency
      };
    }

    return null;
  } catch (error) {
    console.error('Error fetching bet result for user:', error);
    return null;
  }
}
