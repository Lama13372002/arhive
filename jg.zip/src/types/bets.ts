// Типы для системы споров

export interface User {
  id: number;
  telegram_id: number;
  username?: string;
  first_name?: string;
  last_name?: string;
  ton_balance: number;
  stars_balance: number;
  created_at: string;
  updated_at: string;
}

export interface Match {
  id: number;
  api_fixture_id?: number;
  home_team: string;
  away_team: string;
  home_team_logo?: string;
  away_team_logo?: string;
  league: string;
  league_logo?: string;
  start_time: string;
  status: 'upcoming' | 'live' | 'halftime' | 'finished' | 'cancelled' | 'postponed';
  home_score?: number;
  away_score?: number;
  venue?: string;
  created_at: string;
  updated_at: string;
}

export type PredictionType = 'home' | 'draw' | 'away';
export type Currency = 'TON' | 'STARS';
export type BetStatus = 'open' | 'closed' | 'completed' | 'cancelled' | 'refunded';
export type ParticipantPosition = 'for' | 'against';

export interface Bet {
  id: number;
  creator_id: number;
  match_id: number;
  prediction_type: PredictionType;
  prediction_text: string;
  amount: number;
  currency: Currency;
  odds: number;
  max_participants: number;
  comment?: string;
  status: BetStatus;
  created_at: string;
  updated_at: string;
  expires_at?: string;

  // Новые поля для правильного отображения прогноза пользователя
  user_prediction_type?: PredictionType;
  user_prediction_text?: string;

  // Поля для совместимости с API ответом
  home_team?: string;
  away_team?: string;
  home_team_logo?: string;
  away_team_logo?: string;
  league?: string;
  league_logo?: string;

  result?: {
    finalScore?: { home: number; away: number };
    payout?: number;
  };

  user_participation?: {
    amount: number;
    position?: string;
    joined_at: string;
    role: "creator" | "participant";
  };

  user_status?: string;

  // Связанные данные
  creator?: User;
  match?: Match;
  participants?: BetParticipant[];
  participants_count?: number;
}

export interface BetParticipant {
  id: number;
  bet_id: number;
  user_id: number;
  amount: number;
  prediction_type: PredictionType;
  joined_at: string;
  comment?: string;

  // Связанные данные
  user?: User;
}

export type TransactionType = 'bet_create' | 'bet_join' | 'bet_win' | 'bet_refund' | 'deposit' | 'withdrawal';

export interface Transaction {
  id: number;
  user_id: number;
  bet_id?: number;
  transaction_type: TransactionType;
  currency: Currency;
  amount: number;
  description?: string;
  created_at: string;
}

export type NotificationType = 'bet_joined' | 'bet_completed' | 'match_started' | 'match_finished' | 'bet_cancelled';

export interface Notification {
  id: number;
  user_id: number;
  bet_id: number;
  notification_type: NotificationType;
  title: string;
  message: string;
  is_read: boolean;
  sent_to_telegram: boolean;
  created_at: string;
}

// Типы для создания матча
export interface CreateMatchData {
  home_team: string;
  away_team: string;
  home_team_logo?: string;
  away_team_logo?: string;
  league: string;
  league_logo?: string;
  start_time: string;
  venue?: string;
  fixture_id?: number;
}

// Типы для API запросов
export interface CreateBetRequest {
  match_id: number;
  match_data?: CreateMatchData;
  prediction_type: PredictionType;
  prediction_text: string;
  amount: number;
  currency: Currency;
  odds?: number;
  max_participants?: number;
  comment?: string;
}

export interface JoinBetRequest {
  bet_id: number;
  amount: number;
  prediction_type: PredictionType;
  comment?: string;
}

export interface GetBetsRequest {
  status?: BetStatus;
  currency?: Currency;
  creator_id?: number;
  participant_id?: number;
  match_id?: number;
  sort_by?: 'created_at' | 'amount' | 'expires_at';
  sort_order?: 'asc' | 'desc';
  limit?: number;
  offset?: number;
}

export interface BetWithDetails extends Bet {
  creator: User;
  match: Match;
  participants: (BetParticipant & { user: User })[];
  potential_winnings: number;
  time_left?: string;
  can_join: boolean;
  user_participation?: {
    amount: number;
    position?: string;
    joined_at: string;
    role: "creator" | "participant";
  };
}

// Типы для валидации
export interface CurrencyConfig {
  id: Currency;
  name: string;
  icon: string;
  min_amount: number;
  color: string;
}

export interface ValidationError {
  field: string;
  message: string;
}

// Типы для фильтрации
export interface BetFilters {
  currency: 'all' | Currency;
  status: 'all' | BetStatus;
  sort_by: 'time' | 'amount' | 'participants';
  search?: string;
}

// Типы для статистики
export interface BetStats {
  total_bets: number;
  active_bets: number;
  total_volume_ton: number;
  total_volume_stars: number;
  user_bets_created: number;
  user_bets_joined: number;
  user_winnings_ton: number;
  user_winnings_stars: number;
}

// Новые типы для правильной логики ставок
export interface AvailablePrediction {
  type: PredictionType;
  text: string;
  team: string | null;
}

export interface PotentialWinnings {
  total_bank: number;
  commission_amount: number;
  net_winnings: number;
  note: string;
}

export interface AvailablePredictionsResponse {
  success: boolean;
  bet: {
    id: number;
    creator_prediction: PredictionType;
    creator_amount: number;
    currency: Currency;
    home_team: string;
    away_team: string;
    home_team_logo?: string;
    away_team_logo?: string;
    total_bank: number;
    commission_rate: number;
  };
  available_predictions: AvailablePrediction[];
  potential_winnings: PotentialWinnings;
}
