"use client";
import type React from "react";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

type Lang = "ru" | "en";

type Dict = Record<string, string>;

const ru: Dict = {
  // General
  loading: "Загрузка...",
  registering_user: "Регистрация пользователя...",
  error: "Ошибка",

  // Bottom nav
  nav_home: "Главная",
  nav_open_bets: "Споры",
  nav_create: "Создать",
  nav_chat: "Чат",
  nav_my: "Мои",
  nav_menu: "Меню",

  // Menu page
  profile_user: "Пользователь",
  profile_stats: "Статистика",
  profile_winrate: "Процент побед",
  balance_title: "Баланс",
  deposit: "Пополнить",
  withdraw: "Вывести",
  to_ton: "В TON",
  recent_transactions: "Недавние транзакции",
  secured: "Защищено",
  settings_title: "Настройки",
  language: "Язык",
  ru_short: "РУС",
  en_short: "ENG",
  notifications: "Уведомления",
  sound: "Звук",
  vibration: "Вибрация",
  faq_title: "Часто задаваемые вопросы",
  ton_wallet: "TON Кошелек",
  loading_balance: "Загрузка...",
  transactions_soon: "История транзакций будет доступна в следующей версии приложения",
  language_changed_ru: "Язык изменен на русский",
  language_changed_en: "Язык изменен на английский",
  notifications_on: "Уведомления включены",
  notifications_off: "Уведомления выключены",
  sound_on: "Звук включен",
  sound_off: "Звук выключен",
  vibration_on: "Вибрация включена",
  vibration_off: "Вибрация выключена",

  // FAQ items (original RU kept here)
  faq_q1: "Как создать спор?",
  faq_a1: "Нажмите \"Создать спор\" на главной → выберите событие → укажите сумму → подтвердите.",
  faq_q2: "Как вывести средства?",
  faq_a2: "В меню → Баланс → Вывод. Средства поступят на ваш Telegram Wallet.",
  faq_q3: "Что происходит при отмене матча?",
  faq_a3: "Все споры автоматически возвращаются участникам в полном объеме.",
  faq_q4: "Какая комиссия сервиса?",
  faq_a4: "10% с каждого участника спора при выигрыше.",
  faq_q5: "Как работает автоматический расчет?",
  faq_a5: "Результаты определяются через API-FOOTBALL в режиме реального времени.",

  // Extra keys used in component mapping
  user: "Пользователь",
  stats: "Статистика",
  balance: "Баланс",
  protected: "Защищено",
  settings: "Настройки",
  lang_ru: "РУС",
  lang_en: "ENG",
  // Header titles
  header_sports: "Спорт",
  header_create_bet: "Создать спор",
  header_open_bets: "Открытые споры",
  header_chat: "Чат",
  header_my_bets: "Мои споры",
  header_menu: "Меню",
  // Header top up menu
  header_topup_choose_method: "Выберите способ пополнения",
  header_topup_ton: "Пополнить TON",
  header_topup_ton_hint: "Быстрый блокчейн-перевод",
  header_topup_stars: "Пополнить Stars",
  header_topup_stars_hint: "Внутренняя валюта платформы",

  // User Guide Button
  user_guide_title: "Руководство FanFray",
  user_guide_description: "Как пользоваться платформой",

  // Referral Program Block (Menu Page)
  referral_program_title: "Реферальная программа",
  referral_invite_friends: "Приглашай друзей",
  referral_earn_commission: "Получай 5% с их депозитов",
  referral_count_label: "Рефералов",
  referral_my_program: "Моя реферальная программа",
};

const en: Dict = {
  // General
  loading: "Loading...",
  registering_user: "Registering user...",
  error: "Error",

  // Bottom nav
  nav_home: "Home",
  nav_open_bets: "Bets",
  nav_create: "Create",
  nav_chat: "Chat",
  nav_my: "My",
  nav_menu: "Menu",

  // Menu page
  profile_user: "User",
  profile_stats: "Statistics",
  balance_title: "Balance",
  deposit: "Deposit",
  withdraw: "Withdraw",
  to_ton: "To TON",
  recent_transactions: "Recent transactions",
  secured: "Secured",
  settings_title: "Settings",
  language: "Language",
  ru_short: "RU",
  en_short: "EN",
  notifications: "Notifications",
  sound: "Sound",
  vibration: "Vibration",
  faq_title: "Frequently Asked Questions",
  ton_wallet: "TON Wallet",
  loading_balance: "Loading...",
  transactions_soon: "Transactions history will be available in the next app version",
  language_changed_ru: "Language changed to Russian",
  language_changed_en: "Language changed to English",
  notifications_on: "Notifications enabled",
  notifications_off: "Notifications disabled",
  sound_on: "Sound enabled",
  sound_off: "Sound disabled",
  vibration_on: "Vibration enabled",
  vibration_off: "Vibration disabled",

  // FAQ items - translated
  faq_q1: "How to create a bet?",
  faq_a1: "Tap \"Create bet\" on Home → select an event → enter amount → confirm.",
  faq_q2: "How to withdraw funds?",
  faq_a2: "Menu → Balance → Withdraw. Funds will arrive to your Telegram Wallet.",
  faq_q3: "What happens if a match is canceled?",
  faq_a3: "All bets are automatically refunded to participants in full.",
  faq_q4: "What is the service fee?",
  faq_a4: "10% from each participant in case of a win.",
  faq_q5: "How does automatic settlement work?",
  faq_a5: "Results are determined via API-FOOTBALL in real time.",

  // Extra keys used in component mapping
  user: "User",
  stats: "Statistics",
  balance: "Balance",
  protected: "Secured",
  settings: "Settings",
  lang_ru: "RU",
  lang_en: "EN",
  // Header titles
  header_sports: "Sports",
  header_create_bet: "Create bet",
  header_open_bets: "Open bets",
  header_chat: "Chat",
  header_my_bets: "My bets",
  header_menu: "Menu",
  // Header top up menu
  header_topup_choose_method: "Choose a deposit method",
  header_topup_ton: "Deposit TON",
  header_topup_ton_hint: "Fast blockchain transfer",
  header_topup_stars: "Deposit Stars",
  header_topup_stars_hint: "In-app currency",

  // User Guide Button
  user_guide_title: "FanFray Guide",
  user_guide_description: "How to use the platform",

  // Referral Program Block (Menu Page)
  referral_program_title: "Referral Program",
  referral_invite_friends: "Invite friends",
  referral_earn_commission: "Earn 5% from their deposits",
  referral_count_label: "Referrals",
  referral_my_program: "My referral program",
};

const dicts: Record<Lang, Dict> = { ru, en };

type I18nContextType = {
  lang: Lang;
  t: (key: string) => string;
  setLanguage: (lang: Lang) => void;
};

const I18nContext = createContext<I18nContextType | undefined>(undefined);

export const I18nProvider: React.FC<{ children: React.ReactNode; defaultLang?: Lang }> = ({ children, defaultLang = "ru" }) => {
  const [lang, setLang] = useState<Lang>(defaultLang);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const saved = localStorage.getItem("app_lang");
    if (saved === "ru" || saved === "en") setLang(saved);
  }, []);

  const setLanguage = useCallback((l: Lang) => {
    setLang(l);
    if (typeof window !== "undefined") localStorage.setItem("app_lang", l);
  }, []);

  const t = useCallback((key: string) => {
    const d = dicts[lang] || en;
    return d[key] ?? key;
  }, [lang]);

  const value = useMemo(() => ({ lang, t, setLanguage }), [lang, t, setLanguage]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
};

export const useI18n = () => {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
};
