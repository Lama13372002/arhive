import CollectionShowcaseEdition from '../../models/collectionShowcaseEdition.js';
import ProductCollection from '../../models/productCollection.js';
import Edition from '../../models/edition.js';
import Currency from '../../models/currency.js';
import ProductCard from '../../models/productCard.js';
import EditionName from '../../models/editionName.js';

export const collectionShowcaseEditionResource = {
	resource: CollectionShowcaseEdition,
	options: {
		navigation: {
			name: 'Коллекции',
			icon: 'Catalog',
		},
		parent: {
			name: 'Коллекции',
			icon: 'Catalog',
		},
		properties: {
			id: {
				position: 1,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
			},
			collection_id: {
				position: 2,
				isRequired: true,
				isTitle: false,
				type: 'reference',
				reference: 'ProductCollections',
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: true,
				},
			},
			currency_id: {
				position: 3,
				isRequired: true,
				type: 'reference',
				reference: 'Currencies',
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: true,
				},
			},
			edition_id: {
				position: 4,
				isRequired: true,
				type: 'reference',
				reference: 'Editions',
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: true,
				},
			},
			position: {
				position: 5,
				isRequired: true,
				type: 'number',
				props: {
					min: 1,
					max: 3,
				},
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: true,
				},
				description: 'Позиция в витрине (1-3)',
			},
			created_at: {
				position: 6,
				isVisible: {
					list: true,
					filter: false,
					show: true,
					edit: false,
				},
			},
			updated_at: {
				position: 7,
				isVisible: {
					list: false,
					filter: false,
					show: true,
					edit: false,
				},
			},
		},
		actions: {
			list: {
				before: async (request, context) => {
					// Включаем связанные данные для отображения
					context.query = {
						...context.query,
						include: [
							{
								model: ProductCollection,
								as: 'collection',
								attributes: ['id', 'name'],
							},
							{
								model: Currency,
								as: 'currency',
								attributes: ['id', 'code', 'name'],
							},
							{
								model: Edition,
								as: 'edition',
								attributes: ['id', 'price'],
								include: [
									{
										model: ProductCard,
										as: 'productCard',
										attributes: ['id', 'name'],
									},
									{
										model: EditionName,
										as: 'editionName',
										attributes: ['id', 'name'],
									},
								],
							},
						],
					};
					return request;
				},
			},
			show: {
				before: async (request, context) => {
					context.query = {
						...context.query,
						include: [
							{
								model: ProductCollection,
								as: 'collection',
								attributes: ['id', 'name'],
							},
							{
								model: Currency,
								as: 'currency',
								attributes: ['id', 'code', 'name'],
							},
							{
								model: Edition,
								as: 'edition',
								attributes: ['id', 'price'],
								include: [
									{
										model: ProductCard,
										as: 'productCard',
										attributes: ['id', 'name'],
									},
									{
										model: EditionName,
										as: 'editionName',
										attributes: ['id', 'name'],
									},
								],
							},
						],
					};
					return request;
				},
			},
			new: {
				before: async (request, context) => {
					// Валидация перед созданием
					if (request.method === 'post') {
						const { collection_id, currency_id, position, edition_id } = request.payload;

						// Проверяем, не занята ли уже эта позиция
						const existing = await CollectionShowcaseEdition.findOne({
							where: {
								collection_id,
								currency_id,
								position,
							},
						});

						if (existing) {
							throw new Error(
								`Позиция ${position} для этой коллекции и валюты уже занята`
							);
						}

						// Проверяем, не добавлено ли уже это издание
						const existingEdition = await CollectionShowcaseEdition.findOne({
							where: {
								collection_id,
								currency_id,
								edition_id,
							},
						});

						if (existingEdition) {
							throw new Error(
								'Это издание уже добавлено в витрину для данной валюты'
							);
						}
					}
					return request;
				},
			},
			edit: {
				before: async (request, context) => {
					// Валидация перед обновлением
					if (request.method === 'post') {
						const { collection_id, currency_id, position, edition_id } = request.payload;
						const recordId = context.record.params.id;

						// Проверяем, не занята ли уже эта позиция другим элементом
						const existing = await CollectionShowcaseEdition.findOne({
							where: {
								collection_id,
								currency_id,
								position,
							},
						});

						if (existing && existing.id !== parseInt(recordId)) {
							throw new Error(
								`Позиция ${position} для этой коллекции и валюты уже занята`
							);
						}

						// Проверяем, не добавлено ли уже это издание
						const existingEdition = await CollectionShowcaseEdition.findOne({
							where: {
								collection_id,
								currency_id,
								edition_id,
							},
						});

						if (existingEdition && existingEdition.id !== parseInt(recordId)) {
							throw new Error(
								'Это издание уже добавлено в витрину для данной валюты'
							);
						}
					}
					return request;
				},
			},
		},
		listProperties: [
			'id',
			'collection_id',
			'currency_id',
			'edition_id',
			'position',
			'created_at',
		],
		filterProperties: [
			'collection_id',
			'currency_id',
			'position',
			'created_at',
		],
		editProperties: [
			'collection_id',
			'currency_id',
			'edition_id',
			'position',
		],
		showProperties: [
			'id',
			'collection_id',
			'currency_id',
			'edition_id',
			'position',
			'created_at',
			'updated_at',
		],
	},
};
