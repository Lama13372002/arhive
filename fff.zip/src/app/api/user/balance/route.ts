import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';

export async function GET(request: NextRequest) {
  try {
    const telegramId = request.headers.get('x-telegram-user-id');
    if (!telegramId) {
      return NextResponse.json({ error: 'User not authenticated' }, { status: 401 });
    }

    const userResult = await pool.query(`
      SELECT id, telegram_id, username, first_name, last_name, ton_balance, stars_balance, created_at
      FROM users WHERE telegram_id = $1
    `, [telegramId]);

    if (userResult.rows.length === 0) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const user = userResult.rows[0];

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        telegram_id: user.telegram_id,
        username: user.username,
        first_name: user.first_name,
        last_name: user.last_name,
        ton_balance: parseFloat(user.ton_balance),
        stars_balance: parseFloat(user.stars_balance),
        created_at: user.created_at
      }
    });

  } catch (error) {
    console.error('Error fetching user balance:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
