import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const telegramId = searchParams.get('telegramId');

  try {
    console.log('Debug: Received telegramId:', telegramId);

    // Проверяем, есть ли пользователь с таким telegram_id
    const userResult = await pool.query('SELECT id, telegram_id, username, first_name FROM users WHERE telegram_id = $1', [telegramId]);
    console.log('Debug: User found:', userResult.rows);

    // Получаем все конвертации для этого пользователя
    const conversionsResult = await pool.query(
      `SELECT
        ct.*,
        u.telegram_id,
        u.username,
        u.first_name
       FROM conversion_transactions ct
       LEFT JOIN users u ON ct.user_id = u.id
       WHERE u.telegram_id = $1
       ORDER BY ct.created_at DESC`,
      [telegramId]
    );
    console.log('Debug: Conversions found:', conversionsResult.rows);

    // Также проверим все конвертации без фильтра
    const allConversionsResult = await pool.query(
      `SELECT
        ct.*,
        u.telegram_id,
        u.username,
        u.first_name
       FROM conversion_transactions ct
       LEFT JOIN users u ON ct.user_id = u.id
       ORDER BY ct.created_at DESC
       LIMIT 10`
    );
    console.log('Debug: All conversions (top 10):', allConversionsResult.rows);

    return NextResponse.json({
      telegramId,
      user: userResult.rows[0] || null,
      userConversions: conversionsResult.rows,
      allConversions: allConversionsResult.rows,
      debug: {
        userFound: userResult.rows.length > 0,
        userConversionsCount: conversionsResult.rows.length,
        allConversionsCount: allConversionsResult.rows.length
      }
    });

  } catch (error) {
    console.error('Debug: Error:', error);
    return NextResponse.json({
      error: 'Database error',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}
