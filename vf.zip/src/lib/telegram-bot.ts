interface TelegramMessage {
  chat_id: number;
  text: string;
  parse_mode?: 'HTML' | 'Markdown';
  disable_web_page_preview?: boolean;
  reply_markup?: {
    inline_keyboard: Array<Array<{
      text: string;
      web_app?: { url: string };
      url?: string;
    }>>;
  };
}

interface NotificationData {
  user_id: number;
  telegram_id: number;
  type: 'bet_win' | 'bet_loss' | 'bet_refund' | 'bet_joined' | 'bet_created';
  bet_id: number;
  amount?: number;
  currency?: string;
  match_info?: {
    home_team: string;
    away_team: string;
    league: string;
  };
  additional_info?: Record<string, string | number | boolean>;
}

class TelegramBotService {
  private botToken: string;
  private apiUrl: string;

  constructor() {
    this.botToken = process.env.TELEGRAM_BOT_TOKEN || '';
    this.apiUrl = `https://api.telegram.org/bot${this.botToken}`;

    if (!this.botToken) {
      console.warn('TELEGRAM_BOT_TOKEN не настроен в переменных окружения');
    }
  }

  /**
   * Отправить сообщение пользователю в Telegram
   */
  async sendMessage(telegramId: number, text: string, parseMode: 'HTML' | 'Markdown' = 'HTML', inlineKeyboard?: Array<Array<{text: string; web_app?: {url: string}; url?: string}>>): Promise<boolean> {
    if (!this.botToken) {
      console.warn('Telegram Bot Token не настроен, уведомление не отправлено');
      return false;
    }

    try {
      const message: TelegramMessage = {
        chat_id: telegramId,
        text,
        parse_mode: parseMode,
        disable_web_page_preview: true
      };

      if (inlineKeyboard) {
        message.reply_markup = {
          inline_keyboard: inlineKeyboard
        };
      }

      const response = await fetch(`${this.apiUrl}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(message),
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Ошибка отправки Telegram сообщения:', errorData);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Ошибка при отправке уведомления в Telegram:', error);
      return false;
    }
  }

  /**
   * Создать красивое уведомление о победе в споре
   */
  createWinNotification(data: NotificationData): { text: string; keyboard: Array<Array<{text: string; web_app: {url: string}}>> } {
    const { amount, currency, match_info, additional_info } = data;
    const winAmount = amount || 0;
    const totalBank = additional_info?.total_bank || 0;

    const text = `🎉 <b>Поздравляем! Вы выиграли!</b> 🎉

💰 <b>Выигрыш:</b> ${winAmount} ${currency}
💎 <b>Общий банк:</b> ${totalBank} ${currency}

⚽ <b>Матч:</b> ${match_info?.home_team} vs ${match_info?.away_team}
🏆 <b>Лига:</b> ${match_info?.league}

💳 Средства уже зачислены на ваш баланс!`;

    const keyboard = [[
      {
        text: "🔗 Открыть приложение",
        web_app: { url: process.env.APP_URL || process.env.NEXTAUTH_URL || 'https://your-app.com' }
      }
    ]];

    return { text, keyboard };
  }

  /**
   * Создать уведомление о проигрыше в ставке
   */
  createLossNotification(data: NotificationData): { text: string; keyboard: Array<Array<{text: string; web_app: {url: string}}>> } {
    const { amount, currency, match_info } = data;
    const lostAmount = amount || 0;

    const text = `😔 <b>К сожалению, вы проиграли спор</b>

💸 <b>Потеряно:</b> ${lostAmount} ${currency}

⚽ <b>Матч:</b> ${match_info?.home_team} vs ${match_info?.away_team}
🏆 <b>Лига:</b> ${match_info?.league}

🍀 Удача обязательно улыбнется вам в следующий раз!`;

    const keyboard = [[
      {
        text: "🔗 Создать новый спор",
        web_app: { url: process.env.APP_URL || process.env.NEXTAUTH_URL || 'https://your-app.com' }
      }
    ]];

    return { text, keyboard };
  }

  /**
   * Создать уведомление о возврате средств
   */
  createRefundNotification(data: NotificationData): { text: string; keyboard: Array<Array<{text: string; web_app: {url: string}}>> } {
    const { amount, currency, match_info, additional_info } = data;
    const refundAmount = amount || 0;
    const reason = String(additional_info?.reason || 'К вашему спору никто не присоединился');

    let text: string;
    if (reason.includes('никто не присоединился')) {
      text = `⏰ <b>Время вышло - возврат средств</b>

💰 <b>Возвращено:</b> ${refundAmount} ${currency}
📝 <b>Причина:</b> ${reason}

⚽ <b>Матч:</b> ${match_info?.home_team} vs ${match_info?.away_team}
🏆 <b>Лига:</b> ${match_info?.league}

💳 Средства зачислены обратно на ваш баланс.
🎯 Попробуйте создать спор на другой матч!`;
    } else {
      text = `↩️ <b>Возврат средств</b>

💰 <b>Возвращено:</b> ${refundAmount} ${currency}
📝 <b>Причина:</b> ${reason}

⚽ <b>Матч:</b> ${match_info?.home_team} vs ${match_info?.away_team}
🏆 <b>Лига:</b> ${match_info?.league}

💳 Средства зачислены обратно на ваш баланс.`;
    }

    const keyboard = [[
      {
        text: "🔗 Создать новый спор",
        web_app: { url: process.env.APP_URL || process.env.NEXTAUTH_URL || 'https://your-app.com' }
      }
    ]];

    return { text, keyboard };
  }

  /**
   * Создать уведомление о присоединении к ставке
   */
  createJoinedNotification(data: NotificationData): { text: string; keyboard: Array<Array<{text: string; web_app: {url: string}}>> } {
    const { match_info, additional_info } = data;
    const joinerName = additional_info?.joiner_name || 'Пользователь';

    const text = `👥 <b>К вашему спору присоединился игрок!</b>

👤 <b>Игрок:</b> ${joinerName}

⚽ <b>Матч:</b> ${match_info?.home_team} vs ${match_info?.away_team}
🏆 <b>Лига:</b> ${match_info?.league}

🎯 Теперь спор активен! Ждем результатов матча.`;

    const keyboard = [[
      {
        text: "🔗 Посмотреть спор",
        web_app: { url: process.env.APP_URL || process.env.NEXTAUTH_URL || 'https://your-app.com' }
      }
    ]];

    return { text, keyboard };
  }

  /**
   * Создать уведомление о создании новой ставки
   */
  createNewBetNotification(data: NotificationData): { text: string; keyboard: Array<Array<{text: string; web_app: {url: string}}>> } {
    const { amount, currency, match_info, additional_info } = data;
    const betAmount = amount || 0;
    const prediction = additional_info?.prediction || '';

    const text = `🆕 <b>Спор успешно создан!</b>

💰 <b>Сумма:</b> ${betAmount} ${currency}
🎯 <b>Прогноз:</b> ${prediction}

⚽ <b>Матч:</b> ${match_info?.home_team} vs ${match_info?.away_team}
🏆 <b>Лига:</b> ${match_info?.league}

⏳ Ожидаем других игроков...`;

    // Убираем кнопку "Поделиться спором"
    const keyboard: Array<Array<{text: string; web_app: {url: string}}>> = [];

    return { text, keyboard };
  }

  /**
   * Отправить уведомление пользователю
   */
  async sendNotification(data: NotificationData): Promise<boolean> {
    let notificationData: { text: string; keyboard: Array<Array<{text: string; web_app: {url: string}}>> };

    switch (data.type) {
      case 'bet_win':
        notificationData = this.createWinNotification(data);
        break;
      case 'bet_loss':
        notificationData = this.createLossNotification(data);
        break;
      case 'bet_refund':
        notificationData = this.createRefundNotification(data);
        break;
      case 'bet_joined':
        notificationData = this.createJoinedNotification(data);
        break;
      case 'bet_created':
        notificationData = this.createNewBetNotification(data);
        break;
      default:
        console.error('Неизвестный тип уведомления:', data.type);
        return false;
    }

    return await this.sendMessage(data.telegram_id, notificationData.text, 'HTML', notificationData.keyboard);
  }
}

export const telegramBot = new TelegramBotService();
export type { NotificationData };
