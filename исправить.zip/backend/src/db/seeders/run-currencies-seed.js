import { config } from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Sequelize } from 'sequelize';

// Загружаем переменные окружения
config({ path: '../../../.env.development' });

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const sequelize = new Sequelize({
    database: process.env.DB_NAME,
    username: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    dialect: 'postgres'
});

async function runSeed() {
    try {
        // Читаем SQL файл
        const sqlPath = path.join(__dirname, 'add-currencies.sql');
        const sql = fs.readFileSync(sqlPath, 'utf8');

        // Выполняем SQL запрос
        await sequelize.query(sql);
        
        console.log('Currencies have been successfully added to the database');
    } catch (error) {
        console.error('Error seeding currencies:', error);
    } finally {
        await sequelize.close();
    }
}

runSeed();
