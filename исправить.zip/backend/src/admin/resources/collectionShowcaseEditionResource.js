import CollectionShowcaseEdition from '../../models/collectionShowcaseEdition.js';
import ProductCollection from '../../models/productCollection.js';
import Edition from '../../models/edition.js';
import Currency from '../../models/currency.js';

export const collectionShowcaseEditionResource = {
	resource: CollectionShowcaseEdition,
	options: {
		navigation: {
			name: 'Коллекции',
			icon: 'Catalog',
		},
		properties: {
			id: {
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
			},
			collection_id: {
				isRequired: true,
				reference: 'ProductCollection',
			},
			edition_id: {
				isRequired: true,
				reference: 'Edition',
			},
			currency_id: {
				isRequired: true,
				reference: 'Currency',
			},
			position: {
				isRequired: true,
				type: 'number',
				props: {
					min: 1,
					max: 3,
				},
			},
			created_at: {
				isVisible: {
					list: true,
					filter: false,
					show: true,
					edit: false,
				},
			},
			updated_at: {
				isVisible: {
					list: true,
					filter: false,
					show: true,
					edit: false,
				},
			},
		},
		actions: {
			list: {
				before: async (request, context) => {
					if (request.query?.filters) {
						const filters = {};

						if (request.query.filters.collection_id) {
							filters.collection_id = request.query.filters.collection_id;
						}

						if (request.query.filters.currency_id) {
							filters.currency_id = request.query.filters.currency_id;
						}

						request.query.filters = filters;
					}
					return request;
				},
			},
			new: {
				before: async (request, context) => {
					// Валидация: проверяем, что позиция не занята
					const { collection_id, currency_id, position } = request.payload;

					if (collection_id && currency_id && position) {
						const existing = await CollectionShowcaseEdition.findOne({
							where: {
								collection_id,
								currency_id,
								position,
							},
						});

						if (existing) {
							throw new Error(
								`Позиция ${position} уже занята для этой коллекции и валюты`
							);
						}
					}

					return request;
				},
			},
			edit: {
				before: async (request, context) => {
					// Валидация при редактировании
					const { collection_id, currency_id, position } = request.payload;
					const recordId = context.record?.params?.id;

					if (collection_id && currency_id && position && recordId) {
						const existing = await CollectionShowcaseEdition.findOne({
							where: {
								collection_id,
								currency_id,
								position,
							},
						});

						if (existing && existing.id !== parseInt(recordId)) {
							throw new Error(
								`Позиция ${position} уже занята для этой коллекции и валюты`
							);
						}
					}

					return request;
				},
			},
		},
	},
};
