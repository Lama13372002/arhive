import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

class ProductCollection extends Model {
	static associate(models) {
		ProductCollection.belongsToMany(models.Edition, {
			through: 'ProductCollectionEditions',
			foreignKey: 'product_collection_id',
			otherKey: 'edition_id',
			as: 'editions',
			timestamps: true,
			createdAt: 'created_at',
			updatedAt: 'updated_at',
		});

		ProductCollection.belongsToMany(models.FeedItem, {
			through: 'FeedItemCollections',
			foreignKey: 'collection_id',
			otherKey: 'feed_item_id',
			as: 'feedItems',
			timestamps: false,
			underscored: true,
		});

		// Связь с витринными товарами
		ProductCollection.hasMany(models.CollectionShowcaseEdition, {
			foreignKey: 'collection_id',
			as: 'showcaseEditions',
		});
	}
}

ProductCollection.init(
	{
		id: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
		},
		name: {
			type: DataTypes.STRING,
			allowNull: false,
		},
		description: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		image_url: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		is_active: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
	},
	{
		sequelize,
		modelName: 'ProductCollection',
		tableName: 'ProductCollections',
		underscored: true,
	}
);

export default ProductCollection;
