import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';

// POST - изменить баланс пользователя
export async function POST(
  request: NextRequest,
  context: { params: Promise<{ userId: string }> }
) {
  try {
    const { adminPassword, currency, amount, operation, description } = await request.json();
    const params = await context.params;
    const userId = params.userId;

    // Простая проверка админ пароля
    if (adminPassword !== process.env.ADMIN_PASSWORD) {
      return NextResponse.json(
        { success: false, error: 'Неверный пароль администратора' },
        { status: 401 }
      );
    }

    // Валидация
    if (!currency || !['TON', 'STARS'].includes(currency)) {
      return NextResponse.json(
        { success: false, error: 'Неверная валюта. Должна быть TON или STARS' },
        { status: 400 }
      );
    }

    if (!operation || !['add', 'subtract', 'set'].includes(operation)) {
      return NextResponse.json(
        { success: false, error: 'Неверная операция. Должна быть add, subtract или set' },
        { status: 400 }
      );
    }

    const balanceAmount = parseFloat(amount);
    if (isNaN(balanceAmount)) {
      return NextResponse.json(
        { success: false, error: 'Неверная сумма' },
        { status: 400 }
      );
    }

    // Получаем текущий баланс пользователя
    const userResult = await query(
      `SELECT id, telegram_id, username, first_name, ton_balance, stars_balance FROM users WHERE id = $1`,
      [userId]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Пользователь не найден' },
        { status: 404 }
      );
    }

    const user = userResult.rows[0];
    const balanceField = currency === 'TON' ? 'ton_balance' : 'stars_balance';
    const currentBalance = parseFloat(user[balanceField]);

    let newBalance: number;

    switch (operation) {
      case 'add':
        newBalance = currentBalance + balanceAmount;
        break;
      case 'subtract':
        newBalance = Math.max(0, currentBalance - balanceAmount); // Не позволяем отрицательный баланс
        break;
      case 'set':
        newBalance = Math.max(0, balanceAmount);
        break;
      default:
        throw new Error('Неверная операция');
    }

    // Обновляем баланс пользователя
    const updateSQL = currency === 'TON' ?
      `UPDATE users SET ton_balance = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2` :
      `UPDATE users SET stars_balance = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2`;

    await query(updateSQL, [newBalance, userId]);

    // Записываем в историю балансов
    try {
      const balanceChangeDescription = description ||
        `Админ ${operation === 'add' ? 'добавил' : operation === 'subtract' ? 'вычел' : 'установил'} ${balanceAmount} ${currency}`;

      const historyType = operation === 'add' ? 'admin_deposit' :
                         operation === 'subtract' ? 'admin_withdrawal' : 'admin_set';

      await query(
        `INSERT INTO balance_history (telegram_id, type, amount, balance_type, description, created_at)
         VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)`,
        [
          user.telegram_id,
          historyType,
          operation === 'set' ? newBalance : balanceAmount,
          currency.toLowerCase(),
          balanceChangeDescription
        ]
      );
    } catch (historyError) {
      console.error('Ошибка при записи в историю балансов:', historyError);
      // Не прерываем выполнение, так как основная операция уже выполнена
    }

    console.log(`Админ изменил баланс пользователя ${user.username || user.first_name} (ID: ${userId}): ${operation} ${balanceAmount} ${currency}. Новый баланс: ${newBalance}`);

    return NextResponse.json({
      success: true,
      message: `Баланс успешно обновлен`,
      oldBalance: currentBalance,
      newBalance,
      currency,
      operation,
      user: {
        id: user.id,
        username: user.username,
        first_name: user.first_name
      }
    });

  } catch (error) {
    console.error('Ошибка при изменении баланса пользователя:', error);
    console.error('Stack trace:', error instanceof Error ? error.stack : 'No stack trace');
    return NextResponse.json(
      {
        success: false,
        error: 'Ошибка при изменении баланса',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}
