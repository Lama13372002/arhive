#!/bin/sh

log() {
    echo -e "\033[0;34m[$(date +'%Y-%m-%d %H:%M:%S')]\033[0m $1"
}

success() {
    echo -e "\033[0;32m[$(date +'%Y-%m-%d %H:%M:%S')] ✓\033[0m $1"
}

error() {
    echo -e "\033[0;31m[$(date +'%Y-%m-%d %H:%M:%S')] ✗\033[0m $1"
}

log "🔧 Настраиваем Nginx для TMA..."

# Проверяем, что nginx установлен
if ! command -v nginx &> /dev/null; then
    log "Устанавливаем Nginx..."
    sudo apt update
    sudo apt install -y nginx
fi

# Копируем конфигурацию
log "📁 Настраиваем конфигурацию сайта..."
sudo cp nginx-native.conf /etc/nginx/sites-available/fanfray.pro

# Создаем символическую ссылку
log "🔗 Активируем сайт..."
sudo ln -sf /etc/nginx/sites-available/fanfray.pro /etc/nginx/sites-enabled/

# Удаляем дефолтный сайт
sudo rm -f /etc/nginx/sites-enabled/default

# Проверяем конфигурацию
log "✅ Проверяем конфигурацию Nginx..."
if sudo nginx -t; then
    success "Конфигурация Nginx корректна"

    # Перезапускаем nginx
    log "🔄 Перезапускаем Nginx..."
    sudo systemctl restart nginx
    sudo systemctl enable nginx

    success "Nginx настроен и запущен!"
else
    error "Ошибка в конфигурации Nginx!"
    exit 1
fi

log "🌐 Теперь ваш сайт доступен по адресу: http://fanfray.pro"
log "📝 Не забудьте настроить DNS записи в панели REG.RU!"
