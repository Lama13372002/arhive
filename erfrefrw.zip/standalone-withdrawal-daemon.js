#!/usr/bin/env node

import { TonClient, WalletContractV4, Address, beginCell, toNano, internal } from '@ton/ton';
import { mnemonicToWalletKey } from '@ton/crypto';
import pg from 'pg';
import dotenv from 'dotenv';

// Загружаем переменные окружения
dotenv.config();

const { Pool } = pg;

class StandaloneWithdrawalDaemon {
  constructor() {
    this.isRunning = false;
    this.checkInterval = 30000; // 30 секунд
    this.intervalId = null;

    // Настройка TON клиента
    this.isTestnet = process.env.TON_NETWORK === 'testnet';
    this.tonClient = new TonClient({
      endpoint: this.isTestnet
        ? 'https://testnet.toncenter.com/api/v2/jsonRPC'
        : 'https://toncenter.com/api/v2/jsonRPC',
      apiKey: process.env.TON_API_KEY
    });

    this.walletMnemonic = process.env.TON_WALLET_MNEMONIC || '';

    // Настройка базы данных
    this.pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    });

    console.log('🚀 Standalone Withdrawal Daemon initialized:');
    console.log('- Network:', this.isTestnet ? 'testnet' : 'mainnet');
    console.log('- Check interval:', this.checkInterval / 1000, 'seconds');
    console.log('- Mnemonic configured:', !!this.walletMnemonic);
    console.log('- Database configured:', !!process.env.DATABASE_URL);
  }

  async query(text, params = []) {
    const client = await this.pool.connect();
    try {
      const result = await client.query(text, params);
      return result;
    } catch (error) {
      console.error('Database query error:', error);
      throw error;
    } finally {
      client.release();
    }
  }

  async getWalletBalance() {
    const key = await mnemonicToWalletKey(this.walletMnemonic.split(' '));
    const wallet = WalletContractV4.create({ workchain: 0, publicKey: key.publicKey });
    const contract = this.tonClient.open(wallet);

    let balance;
    let attempts = 0;
    const maxAttempts = 3;
    const delayMs = 2000;

    while (attempts < maxAttempts) {
      try {
        attempts++;
        console.log(`Balance check attempt ${attempts}/${maxAttempts}...`);

        balance = await contract.getBalance();
        break;

      } catch (error) {
        console.log(`Balance check attempt ${attempts} failed:`, error instanceof Error ? error.message : 'Unknown error');

        if (attempts < maxAttempts) {
          console.log(`Waiting ${delayMs}ms before retry...`);
          await new Promise(resolve => setTimeout(resolve, delayMs));
        } else {
          throw error;
        }
      }
    }

    if (balance === undefined) {
      throw new Error('Failed to get wallet balance after all attempts');
    }

    const balanceInTon = parseFloat((Number(balance) / 1000000000).toFixed(9));
    return balanceInTon;
  }

  async processWithdrawal(request) {
    try {
      console.log(`Processing withdrawal ${request.id} for ${request.net_amount} TON to ${request.target_wallet}`);

      if (!this.walletMnemonic) {
        throw new Error('Wallet mnemonic not configured');
      }

      // Проверяем валидность адреса получателя
      let destinationAddress;
      try {
        destinationAddress = Address.parse(request.target_wallet);
      } catch (error) {
        throw new Error('Invalid destination wallet address');
      }

      // Создаем кошелек отправителя
      const key = await mnemonicToWalletKey(this.walletMnemonic.split(' '));
      const wallet = WalletContractV4.create({ workchain: 0, publicKey: key.publicKey });
      const contract = this.tonClient.open(wallet);

      // Проверяем баланс кошелька
      const balance = await contract.getBalance();
      const amountToSend = toNano(request.net_amount.toString());
      const minBalance = toNano('0.1'); // Минимальный остаток для комиссий

      console.log('Balance check details:');
      console.log('- Current balance (TON):', parseFloat((Number(balance) / 1000000000).toFixed(9)));
      console.log('- Amount to send (TON):', request.net_amount);
      console.log('- Required total (TON):', parseFloat((Number(amountToSend + minBalance) / 1000000000).toFixed(9)));

      if (balance < amountToSend + minBalance) {
        const currentBalanceTon = parseFloat((Number(balance) / 1000000000).toFixed(9));
        const requiredTotalTon = parseFloat((Number(amountToSend + minBalance) / 1000000000).toFixed(9));
        throw new Error(`Insufficient balance. Available: ${currentBalanceTon} TON, Required: ${requiredTotalTon} TON`);
      }

      // Создаем и отправляем транзакцию
      const seqno = await contract.getSeqno();

      const transfer = await contract.createTransfer({
        seqno,
        secretKey: key.secretKey,
        messages: [internal({
          to: destinationAddress,
          value: amountToSend,
          body: beginCell()
            .storeUint(0, 32)
            .storeStringTail(`Withdrawal #${request.id}`)
            .endCell(),
          bounce: false
        })]
      });

      await contract.send(transfer);

      const txHash = `tx_${Date.now()}_${request.id}`;
      console.log('Transaction sent successfully');
      console.log('Seqno:', seqno);
      console.log('TX Hash:', txHash);

      return { success: true, txHash };

    } catch (error) {
      console.error('Error processing withdrawal:', error);
      return { success: false, error: error.message };
    }
  }

  async checkAndProcessWithdrawals() {
    try {
      console.log(`\n⏰ [${new Date().toISOString()}] Checking for pending withdrawals...`);

      // Получаем pending запросы
      const pendingResult = await this.query(`
        SELECT id, telegram_id, amount, commission, net_amount, target_wallet
        FROM withdrawal_requests
        WHERE status = 'pending'
        ORDER BY created_at ASC
        LIMIT 10
      `);

      const pendingWithdrawals = pendingResult.rows;

      if (pendingWithdrawals.length === 0) {
        console.log('✅ No pending withdrawals found');
        return;
      }

      console.log(`📋 Found ${pendingWithdrawals.length} pending withdrawal(s)`);

      for (const request of pendingWithdrawals) {
        try {
          // Обновляем статус на processing
          await this.query(`
            UPDATE withdrawal_requests
            SET status = 'processing', processed_at = NOW()
            WHERE id = $1
          `, [request.id]);

          console.log(`\n🔄 Processing withdrawal ${request.id}...`);

          // Обрабатываем вывод
          const result = await this.processWithdrawal(request);

          if (result.success) {
            // Обновляем статус на completed
            await this.query(`
              UPDATE withdrawal_requests
              SET status = 'completed', transaction_hash = $1, processed_at = NOW()
              WHERE id = $2
            `, [result.txHash, request.id]);

            console.log(`✅ Withdrawal ${request.id} completed successfully. TX: ${result.txHash}`);

          } else {
            // Обновляем статус на failed
            await this.query(`
              UPDATE withdrawal_requests
              SET status = 'failed', error_message = $1, processed_at = NOW()
              WHERE id = $2
            `, [result.error, request.id]);

            console.log(`❌ Withdrawal ${request.id} failed: ${result.error}`);
          }

        } catch (error) {
          console.error(`💥 Error processing withdrawal ${request.id}:`, error.message);

          // Обновляем статус на failed в случае неожиданной ошибки
          try {
            await this.query(`
              UPDATE withdrawal_requests
              SET status = 'failed', error_message = $1, processed_at = NOW()
              WHERE id = $2
            `, [`System error: ${error.message}`, request.id]);
          } catch (dbError) {
            console.error('Failed to update withdrawal status:', dbError.message);
          }
        }
      }

    } catch (error) {
      console.error('💥 Error in withdrawal check cycle:', error.message);
    }
  }

  start() {
    if (this.isRunning) {
      console.log('⚠️  Daemon is already running');
      return;
    }

    console.log('🟢 Starting withdrawal daemon...');
    this.isRunning = true;

    // Запускаем первую проверку сразу
    this.checkAndProcessWithdrawals();

    // Устанавливаем интервал для регулярных проверок
    this.intervalId = setInterval(() => {
      this.checkAndProcessWithdrawals();
    }, this.checkInterval);

    console.log(`✅ Daemon started. Checking every ${this.checkInterval / 1000} seconds.`);
  }

  stop() {
    if (!this.isRunning) {
      console.log('⚠️  Daemon is not running');
      return;
    }

    console.log('🔴 Stopping withdrawal daemon...');
    this.isRunning = false;

    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    console.log('✅ Daemon stopped');
  }

  async getStatus() {
    try {
      const balance = await this.getWalletBalance();

      const pendingResult = await this.query(`
        SELECT COUNT(*) as count FROM withdrawal_requests WHERE status = 'pending'
      `);

      const processingResult = await this.query(`
        SELECT COUNT(*) as count FROM withdrawal_requests WHERE status = 'processing'
      `);

      return {
        isRunning: this.isRunning,
        walletBalance: balance,
        pendingWithdrawals: parseInt(pendingResult.rows[0].count),
        processingWithdrawals: parseInt(processingResult.rows[0].count),
        checkInterval: this.checkInterval / 1000
      };
    } catch (error) {
      return {
        isRunning: this.isRunning,
        error: error.message
      };
    }
  }
}

// Обработка сигналов для graceful shutdown
const daemon = new StandaloneWithdrawalDaemon();

process.on('SIGINT', () => {
  console.log('\n🛑 Received SIGINT signal');
  daemon.stop();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n🛑 Received SIGTERM signal');
  daemon.stop();
  process.exit(0);
});

// CLI команды
const args = process.argv.slice(2);
const command = args[0];

switch (command) {
  case 'start':
    daemon.start();
    break;

  case 'stop':
    daemon.stop();
    break;

  case 'status':
    daemon.getStatus().then(status => {
      console.log('\n📊 Daemon Status:');
      console.log(JSON.stringify(status, null, 2));
      process.exit(0);
    });
    break;

  case 'check':
    daemon.checkAndProcessWithdrawals().then(() => {
      console.log('✅ Manual check completed');
      process.exit(0);
    });
    break;

  default:
    console.log(`
🤖 Standalone TON Withdrawal Daemon

Usage:
  node standalone-withdrawal-daemon.js start   - Start the daemon
  node standalone-withdrawal-daemon.js stop    - Stop the daemon
  node standalone-withdrawal-daemon.js status  - Show daemon status
  node standalone-withdrawal-daemon.js check   - Run one-time check

The daemon will run continuously and check for pending withdrawals every 30 seconds.
Use Ctrl+C to stop the daemon gracefully.
    `);
    process.exit(0);
}
