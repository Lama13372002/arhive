"use client";

import { useState, useEffect } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Star, Loader2, CheckCircle, AlertCircle, Zap, Sparkles, Crown, Gift, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useTelegram } from "@/components/providers/TelegramProvider";
import { StarsTopUpI18nProvider, useStarsTopUpI18n } from "@/components/providers/StarsTopUpI18nProvider";
import { useIOSKeyboard } from "@/hooks/useIOSKeyboard";

interface TelegramWebAppWithInvoice {
  openInvoice?: (url: string, callback?: (status: string) => void) => void;
}

interface StarsTopUpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const STARS_PACKAGES = [
  {
    amount: 100,
    price: "1.00",
    popular: false,
    icon: Star,
    gradient: "from-yellow-400 to-amber-500",
    key: "pkg_start" as const,
  },
  {
    amount: 500,
    price: "5.00",
    popular: true,
    icon: Crown,
    gradient: "from-amber-400 via-yellow-500 to-orange-500",
    key: "pkg_popular" as const,
  },
  {
    amount: 1000,
    price: "10.00",
    popular: false,
    icon: Sparkles,
    gradient: "from-orange-400 to-red-500",
    key: "pkg_value" as const,
  },
  {
    amount: 2500,
    price: "25.00",
    popular: false,
    icon: Gift,
    gradient: "from-purple-400 to-pink-500",
    key: "pkg_premium" as const,
  },
] as const;

const StarsTopUpModalContent = ({ isOpen, onClose }: StarsTopUpModalProps) => {
  const { t } = useStarsTopUpI18n();
  const { user, webApp, isFullscreen } = useTelegram();
  const { inputRef: starsInputRef } = useIOSKeyboard({ enabled: true, delay: 200 });
  const [selectedAmount, setSelectedAmount] = useState(500);
  const [customAmount, setCustomAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleAmountSelect = (amount: number) => {
    setSelectedAmount(amount);
    setCustomAmount("");
    setError("");
  };

  const handleCustomAmountChange = (value: string) => {
    const numValue = Number.parseInt(value);
    if (value === "" || (numValue >= 1 && numValue <= 10000)) {
      setCustomAmount(value);
      setSelectedAmount(numValue || 0);
      setError("");
    }
  };

  const handleTopUp = async () => {
    if (!user?.id) {
      setError(t('error_not_auth'));
      return;
    }

    const amount = customAmount ? Number.parseInt(customAmount) : selectedAmount;

    if (amount < 1) {
      setError(t('error_min'));
      return;
    }

    if (amount > 10000) {
      setError(t('error_max'));
      return;
    }

    setLoading(true);
    setError("");

    try {
      // Создаем invoice
      const response = await fetch('/api/stars/create-invoice', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-telegram-user-id': user.id.toString()
        },
        body: JSON.stringify({ amount })
      });

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || t('error_create_invoice'));
      }

      setLoading(false); // Убираем загрузку перед открытием invoice

      // Открываем invoice в Telegram
      console.log('WebApp object:', webApp);
      console.log('Invoice link:', data.invoiceLink);

      if (webApp && typeof (webApp as TelegramWebAppWithInvoice).openInvoice === 'function') {
        console.log('Using webApp.openInvoice');
        (webApp as unknown as TelegramWebAppWithInvoice).openInvoice!(data.invoiceLink, async (status: string) => {
          console.log('Payment status:', status);

          if (status === 'paid') {
            setLoading(true); // Показываем загрузку при обработке после оплаты

            // Генерируем mock transaction ID (в реальном приложении это должно приходить от бота)
            const transactionId = `txn_${Date.now()}_${Math.floor(Math.random() * 10000)}`;

            try {
              // Записываем успешный платеж
              const paymentResponse = await fetch('/api/stars/payment-success', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'x-telegram-user-id': user.id.toString()
                },
                body: JSON.stringify({
                  amount,
                  transactionId
                })
              });

              if (!paymentResponse.ok) {
                throw new Error('Failed to record payment');
              }

              const result = await paymentResponse.json();
              console.log('Payment recorded successfully:', result);

              setLoading(false);
              setSuccess(true);

              setTimeout(() => {
                setSuccess(false);
                onClose();
                // Обновляем страницу для отображения нового баланса
                window.location.reload();
              }, 2000);

            } catch (e) {
              console.error('Error saving payment:', e);
              setError(t('error_generic'));
              setLoading(false);
            }
          } else if (status === 'cancelled') {
            setLoading(false);
            // Пользователь отменил платеж, не показываем ошибку
            console.log('Payment was cancelled by user');
          } else if (status === 'failed') {
            setLoading(false);
            setError(t('error_payment_failed'));
          } else if (status === 'pending') {
            setLoading(false);
            setError(t('error_payment_pending'));
          } else {
            setLoading(false);
            setError(t('error_unknown_status', { status }))
          }
        });
      } else {
        console.log('webApp.openInvoice not available, using fallback');
        // Fallback - открываем ссылку
        if (data.invoiceLink) {
          window.open(data.invoiceLink, '_blank');
        } else {
          setError(t('error_no_link'));
        }
        setLoading(false);
      }

    } catch (error) {
      console.error('Error creating Stars payment:', error);
      setError(error instanceof Error ? error.message : t('error_generic'));
      setLoading(false);
    }
  };

  // Сброс состояния при закрытии
  useEffect(() => {
    if (!isOpen) {
      setError("");
      setSuccess(false);
      setLoading(false);
      setCustomAmount("");
      setSelectedAmount(500);
    }
  }, [isOpen]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent
        className={`
          ${isFullscreen
            ? 'fixed left-0 right-0 top-24 bottom-32 w-full max-w-none max-h-none m-0 rounded-t-2xl border-none !transform-none [&>button]:hidden'
            : 'sm:max-w-lg'
          }
          bg-gradient-to-br from-slate-900/98 via-slate-800/98 to-slate-900/98 backdrop-blur-xl border border-white/10 shadow-2xl
          ${isFullscreen ? 'p-4' : ''}
        `}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          transition={{ duration: 0.3 }}
          className={`
            ${isFullscreen
              ? 'h-full flex flex-col'
              : 'flex flex-col max-h-[75vh]'
            }
            p-1
          `}
        >
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.1 }}
                className="relative w-10 h-10 bg-gradient-to-br from-yellow-400 via-amber-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg shadow-yellow-500/30"
              >
                <img src="/images/stars.png" alt="Stars" className="h-6 w-6" />
              </motion.div>

              <div>
                <h2 className="text-lg font-bold bg-gradient-to-r from-yellow-400 via-amber-500 to-orange-500 bg-clip-text text-transparent">{t('header_title')}</h2>
                <p className="text-slate-400 text-xs">
                  {t('header_sub')}
                </p>
              </div>
            </div>

            {/* Close button for fullscreen */}
            {isFullscreen && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="w-8 h-8 p-0 rounded-full hover:bg-white/10"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>

          <AnimatePresence>
            {success && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: -10 }}
                className="bg-gradient-to-r from-green-500/20 via-emerald-500/20 to-green-600/20 border border-green-500/30 rounded-xl p-4"
              >
                <div className="flex items-center space-x-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-green-400 text-sm">{t('success_title')}</h3>
                    <p className="text-green-300/80 text-xs">{t('success_desc')}</p>
                  </div>
                </div>
              </motion.div>
            )}

            {error && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: -10 }}
                className="bg-gradient-to-r from-red-500/20 via-rose-500/20 to-red-600/20 border border-red-500/30 rounded-xl p-4"
              >
                <div className="flex items-center space-x-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-red-500 rounded-lg flex items-center justify-center">
                    <AlertCircle className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-red-400 text-sm">{t('error_title')}</h3>
                    <p className="text-red-300/80 text-xs">{error}</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Scrollable content area */}
          <div className={`
            ${isFullscreen ? 'flex-1 overflow-y-auto' : 'flex-1 overflow-y-auto'}
            space-y-4 pr-1 pt-2
          `}
          >
          {!success && (
            <>
              {/* Package Selection */}
              <div className="space-y-3">
                <div className="flex items-center space-x-2 text-slate-300">
                  <Zap className="h-4 w-4 text-yellow-400" />
                  <h3 className="font-semibold text-sm">{t('choose_package')}</h3>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {STARS_PACKAGES.map((pkg, index) => {
                    const IconComponent = pkg.icon;
                    const isSelected = selectedAmount === pkg.amount;

                    return (
                      <motion.div
                        key={pkg.amount}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Card
                          className={`cursor-pointer transition-all duration-300 relative overflow-hidden group ${
                            isSelected
                              ? `border-yellow-500/50 bg-gradient-to-br ${pkg.gradient}/20 shadow-lg shadow-yellow-500/20`
                              : "border-white/10 bg-white/5 hover:bg-white/10 hover:border-white/20"
                          }`}
                          onClick={() => handleAmountSelect(pkg.amount)}
                        >
                          <CardContent className="p-3 relative h-28 flex flex-col justify-center">
                            <div className="text-center space-y-2">
                              <div className={`mx-auto w-8 h-8 bg-gradient-to-br ${pkg.gradient} rounded-lg flex items-center justify-center shadow-md`}>
                                <img src="/images/stars.png" alt="Stars" className="h-4 w-4" />
                              </div>

                              <div>
                                <div className="flex items-center justify-center space-x-1 mb-0.5">
                                  <img src="/images/stars.png" alt="Stars" className="h-3 w-3" />
                                  <span className="font-bold text-base text-white">{pkg.amount.toLocaleString()}</span>
                                </div>
                                <p className="text-sm font-semibold text-slate-300">${pkg.price}</p>
                                <p className="text-[10px] text-slate-500 mt-0.5 h-3">
                                  {t(pkg.key)}
                                </p>
                              </div>
                            </div>

                            {isSelected && (
                              <motion.div
                                initial={{ scale: 0, opacity: 0 }}
                                animate={{ scale: 1, opacity: 1 }}
                                className="absolute top-1 left-1"
                              >
                                <div className="w-4 h-4 bg-yellow-500 rounded-full flex items-center justify-center">
                                  <CheckCircle className="h-3 w-3 text-white" />
                                </div>
                              </motion.div>
                            )}
                          </CardContent>
                        </Card>
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* Custom Amount */}
              <div className="space-y-2">
                <h3 className="font-semibold text-slate-300 text-sm">{t('or_enter_amount')}</h3>
                <div className="space-y-2">
                  <div className="relative">
                    <Input
                      ref={starsInputRef}
                      type="number"
                      inputMode="numeric"
                      step="1"
                      enterKeyHint="done"
                      placeholder={t('amount_placeholder')}
                      value={customAmount}
                      onChange={(e) => handleCustomAmountChange(e.target.value)}
                      min="1"
                      max="10000"
                      className="bg-white/5 border-white/10 focus:border-yellow-500/50 focus:bg-white/10 transition-all duration-200 text-center text-base h-10 rounded-lg pl-8"
                    />
                    <div className="absolute inset-y-0 left-2 flex items-center pointer-events-none">
                      <img src="/images/stars.png" alt="Stars" className="h-4 w-4" />
                    </div>
                  </div>
                  <p className="text-[10px] text-slate-500 text-center">{t('rate_note')}</p>
                </div>
              </div>

              {/* Compact Info Section */}
              <div className="bg-gradient-to-r from-yellow-500/10 via-amber-500/10 to-orange-500/10 border border-yellow-500/20 rounded-xl p-3">
                <div className="flex items-center justify-between text-xs text-slate-300">
                  <div className="flex items-center space-x-1">
                    <div className="w-1.5 h-1.5 bg-green-400 rounded-full"></div>
                    <span>{t('info_instant')}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-1.5 h-1.5 bg-blue-400 rounded-full"></div>
                    <span>{t('info_secure')}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full"></div>
                    <span>{t('info_no_fees')}</span>
                  </div>
                </div>
              </div>


            </>
          )}
          </div>

          {/* Fixed button area - always at bottom */}
          {!success && (
            <div className={`flex-shrink-0 ${isFullscreen ? 'pt-1 pb-1' : 'pt-2 pb-2'}`}>
              {/* Action Button */}
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button
                  onClick={handleTopUp}
                  disabled={loading || selectedAmount < 1}
                  className="w-full h-12 bg-gradient-to-r from-yellow-500 via-amber-500 to-orange-500 hover:from-yellow-600 hover:via-amber-600 hover:to-orange-600 text-white border-none rounded-lg shadow-xl hover:shadow-2xl hover:shadow-yellow-500/25 transition-all duration-300 font-semibold"
                >
                  {loading ? (
                    <div className="flex items-center space-x-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>{t('creating_payment')}</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <img src="/images/stars.png" alt="Stars" className="h-4 w-4" />
                      <span>{t('topup_btn', { amount: customAmount || selectedAmount.toLocaleString() })}</span>
                    </div>
                  )}
                </Button>
              </motion.div>
            </div>
          )}
        </motion.div>
      </DialogContent>
    </Dialog>
  );
};

export const StarsTopUpModal = (props: StarsTopUpModalProps) => (
  <StarsTopUpI18nProvider>
    <StarsTopUpModalContent {...props} />
  </StarsTopUpI18nProvider>
);
