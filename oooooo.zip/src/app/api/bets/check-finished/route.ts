import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';
import { footballApi } from '@/lib/football-api';
import { notificationService } from '@/lib/notifications';
import type { PredictionType } from '@/types/bets';
import type { PoolClient } from 'pg';

export async function POST(request: NextRequest) {
  try {
    const client = await pool.connect();

    try {
      // Получаем все активные споры для обработки:
      // 1. Статус 'closed' - уже закрытые споры, готовые к завершению
      // 2. Статус 'open' - открытые споры, но только те где матч уже должен был завершиться (для рефанда 1/3)
      const activeBetsResult = await client.query(`
        SELECT
          b.id as bet_id,
          b.match_id,
          b.prediction_type,
          b.amount,
          b.currency,
          b.creator_id,
          b.status,
          m.api_fixture_id,
          m.home_team,
          m.away_team,
          m.league,
          m.start_time as match_date
        FROM bets b
        JOIN matches m ON b.match_id = m.id
        WHERE b.status IN ('open', 'closed')
        AND b.status NOT IN ('completed', 'refunded', 'cancelled')
        ORDER BY m.start_time ASC
      `);

      const activeBets = activeBetsResult.rows;

      if (activeBets.length === 0) {
        return NextResponse.json({
          success: true,
          message: 'No active bets to check',
          checked: 0,
          completed: 0
        });
      }

      console.log(`🔍 Checking ${activeBets.length} active bets for finished matches`);

      let completedCount = 0;
      let refundedCount = 0;
      const results = [];

      for (const bet of activeBets) {
        try {
          console.log(`\n🎯 Processing bet ${bet.bet_id}: ${bet.home_team} vs ${bet.away_team}`);

          // Сначала проверяем количество участников для возможного возврата
          const participantsResult = await client.query(`
            SELECT COUNT(*) as participant_count
            FROM bet_participants
            WHERE bet_id = $1
          `, [bet.bet_id]);

          const participantCount = parseInt(participantsResult.rows[0].participant_count);

          // Если нет участников (только создатель), то делаем возврат
          if (participantCount === 0) {
            // Для открытых ставок проверяем, что матч уже завершился (прошло минимум 2 часа)
            if (bet.status === 'open') {
              console.log(`🔍 Bet ${bet.bet_id} is open with no participants, checking if match is finished...`);

              // Используем ту же логику проверки матча что и для closed ставок
              let matchData = await findMatchByFixtureId(bet.api_fixture_id);

              if (!matchData) {
                matchData = await findMatchByTeamsAndDate(bet.home_team, bet.away_team, bet.match_date);
              }

              if (!matchData) {
                matchData = await findMatchInRecentMatches(bet.home_team, bet.away_team, bet.match_date);
              }

              if (!matchData) {
                const matchTime = new Date(bet.match_date);
                const now = new Date();
                const hoursPassedSinceMatch = (now.getTime() - matchTime.getTime()) / (1000 * 60 * 60);

                if (hoursPassedSinceMatch >= 2) {
                  console.log(`🤖 Match ${bet.bet_id} should have finished ${hoursPassedSinceMatch.toFixed(1)} hours ago, treating as finished for refund...`);
                  matchData = { isFinished: true, method: 'time_based_auto_complete' };
                }
              }

              if (!matchData || !matchData.isFinished) {
                console.log(`⏳ Bet ${bet.bet_id} match is not finished yet, skipping refund...`);
                continue; // Матч еще не завершился, пропускаем
              }

              console.log(`💸 Bet ${bet.bet_id} match is finished, processing refund for 1/3 scenario...`);
            } else {
              console.log(`💸 Bet ${bet.bet_id} has no participants, processing refund...`);
            }

            const refundResult = await refundBet(bet.bet_id, client);

            if (refundResult.success) {
              refundedCount++;
              results.push({
                bet_id: bet.bet_id,
                match: `${bet.home_team} vs ${bet.away_team}`,
                status: 'refunded',
                amount: bet.amount,
                currency: bet.currency,
                method: bet.status === 'open' ? 'auto_refund_open_match_finished' : 'auto_refund'
              });
              console.log(`✅ Successfully refunded bet ${bet.bet_id}: ${bet.amount} ${bet.currency} to creator`);
            } else {
              results.push({
                bet_id: bet.bet_id,
                status: 'refund_error',
                error: refundResult.error
              });
              console.error(`❌ Failed to refund bet ${bet.bet_id}:`, refundResult.error);
            }
            continue; // Переходим к следующему спору
          }

          console.log(`👥 Bet ${bet.bet_id} has ${participantCount} participants, checking match completion...`);

          // Метод 1: Прямой поиск по fixture ID
          let matchData = await findMatchByFixtureId(bet.api_fixture_id);

          // Метод 2: Поиск по командам и дате (если прямой поиск не сработал)
          if (!matchData) {
            console.log(`⚠️ Direct fixture search failed for ${bet.api_fixture_id}, trying team search...`);
            matchData = await findMatchByTeamsAndDate(bet.home_team, bet.away_team, bet.match_date);
          }

          // Метод 3: Поиск в недавних матчах (последние 7 дней)
          if (!matchData) {
            console.log(`⚠️ Team search failed, trying recent matches search...`);
            matchData = await findMatchInRecentMatches(bet.home_team, bet.away_team, bet.match_date);
          }

          // Метод 4: Автозавершение по времени (если матч должен был закончиться более 2 часов назад)
          if (!matchData) {
            const matchTime = new Date(bet.match_date);
            const now = new Date();
            const hoursPassedSinceMatch = (now.getTime() - matchTime.getTime()) / (1000 * 60 * 60);

            if (hoursPassedSinceMatch >= 2) {
              console.log(`⏰ Match ${bet.bet_id} should have finished ${hoursPassedSinceMatch.toFixed(1)} hours ago, auto-completing...`);
              matchData = await autoCompleteOldMatch(bet, client);
            }
          }

          if (!matchData) {
            console.log(`❌ Could not find match data for bet ${bet.bet_id}`);
            results.push({
              bet_id: bet.bet_id,
              status: 'not_found',
              message: 'Match data not found in any source'
            });
            continue;
          }

          // Проверяем, завершился ли матч
          if (!matchData.isFinished) {
            console.log(`⏳ Match ${bet.bet_id} is not finished yet. Status: ${matchData.status || 'unknown'}`);
            results.push({
              bet_id: bet.bet_id,
              status: 'in_progress',
              match_status: matchData.status
            });
            continue;
          }

          console.log(`🏆 Match ${bet.bet_id} finished: ${bet.home_team} ${matchData.homeGoals}-${matchData.awayGoals} ${bet.away_team}`);

          // Определяем результат матча
          let matchResult: PredictionType;
          if (matchData.homeGoals !== undefined && matchData.awayGoals !== undefined) {
            if (matchData.homeGoals > matchData.awayGoals) {
              matchResult = 'home';
            } else if (matchData.homeGoals < matchData.awayGoals) {
              matchResult = 'away';
            } else {
              matchResult = 'draw';
            }
          } else {
            console.log(`❌ Invalid score data for bet ${bet.bet_id}`);
            continue;
          }

          // Обновляем статус и счет матча в базе данных
          await client.query(`
            UPDATE matches
            SET status = $1, home_score = $2, away_score = $3, updated_at = CURRENT_TIMESTAMP
            WHERE id = $4
          `, ['finished', matchData.homeGoals, matchData.awayGoals, bet.match_id]);

          console.log(`📊 Updated match ${bet.match_id} in database: status=finished, score=${matchData.homeGoals}-${matchData.awayGoals}`);

          // Автоматически завершаем спор
          const completeResult = await completeBet(bet.bet_id, matchResult, client);

          if (completeResult.success) {
            completedCount++;
            results.push({
              bet_id: bet.bet_id,
              fixture_id: bet.api_fixture_id,
              match: `${bet.home_team} vs ${bet.away_team}`,
              score: `${matchData.homeGoals}-${matchData.awayGoals}`,
              result: matchResult,
              status: 'completed',
              method: matchData.method
            });
            console.log(`✅ Successfully completed bet ${bet.bet_id} using method: ${matchData.method}`);
          } else {
            results.push({
              bet_id: bet.bet_id,
              status: 'error',
              error: completeResult.error
            });
            console.error(`❌ Failed to complete bet ${bet.bet_id}:`, completeResult.error);
          }

        } catch (error) {
          console.error(`💥 Error checking bet ${bet.bet_id}:`, error);
          results.push({
            bet_id: bet.bet_id,
            status: 'error',
            error: error instanceof Error ? error.message : 'Unknown error'
          });
        }
      }

      return NextResponse.json({
        success: true,
        checked: activeBets.length,
        completed: completedCount,
        refunded: refundedCount,
        results
      });

    } finally {
      client.release();
    }

  } catch (error) {
    console.error('❌ Error in check-finished:', error);
    return NextResponse.json(
      { error: 'Internal server error', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}

// Типы для результатов поиска матчей
interface MatchSearchResult {
  homeGoals?: number;
  awayGoals?: number;
  isFinished: boolean;
  status?: string;
  method: string;
}

// Метод 1: Поиск по прямому fixture ID
async function findMatchByFixtureId(fixtureId: number): Promise<MatchSearchResult | null> {
  try {
    console.log(`🔍 Method 1: Searching by fixture ID ${fixtureId}`);
    const fixtureResponse = await footballApi.getFixtureById(fixtureId);

    if (fixtureResponse?.response?.length > 0) {
      const fixture = fixtureResponse.response[0];
      const isFinished = ['FT', 'AET', 'PEN'].includes(fixture.fixture.status.short);

      if (isFinished && fixture.goals.home !== null && fixture.goals.away !== null) {
        return {
          homeGoals: fixture.goals.home,
          awayGoals: fixture.goals.away,
          isFinished: true,
          status: fixture.fixture.status.short,
          method: 'direct_fixture_id'
        };
      }

      return {
        isFinished: false,
        status: fixture.fixture.status.short,
        method: 'direct_fixture_id'
      };
    }
  } catch (error) {
    console.log(`❌ Method 1 failed:`, error);
  }
  return null;
}

// Метод 2: Поиск по командам и дате
async function findMatchByTeamsAndDate(homeTeam: string, awayTeam: string, matchDate: string): Promise<MatchSearchResult | null> {
  try {
    console.log(`🔍 Method 2: Searching by teams "${homeTeam}" vs "${awayTeam}" on date ${matchDate}`);

    // Получаем дату матча
    const date = new Date(matchDate);
    const dateStr = date.toISOString().split('T')[0]; // YYYY-MM-DD

    // Ищем матчи на эту дату
    const fixtures = await footballApi.getFixturesByDate(dateStr);

    if (fixtures?.response?.length > 0) {
      // Ищем матч по названиям команд (нечеткое совпадение)
      const match = fixtures.response.find(fixture => {
        const homeMatch = teamNamesMatch(fixture.teams.home.name, homeTeam);
        const awayMatch = teamNamesMatch(fixture.teams.away.name, awayTeam);
        return homeMatch && awayMatch;
      });

      if (match) {
        const isFinished = ['FT', 'AET', 'PEN'].includes(match.fixture.status.short);

        if (isFinished && match.goals.home !== null && match.goals.away !== null) {
          console.log(`✅ Found finished match: ${match.teams.home.name} ${match.goals.home}-${match.goals.away} ${match.teams.away.name}`);
          return {
            homeGoals: match.goals.home,
            awayGoals: match.goals.away,
            isFinished: true,
            status: match.fixture.status.short,
            method: 'teams_and_date'
          };
        }

        return {
          isFinished: false,
          status: match.fixture.status.short,
          method: 'teams_and_date'
        };
      }
    }
  } catch (error) {
    console.log(`❌ Method 2 failed:`, error);
  }
  return null;
}

// Метод 3: Поиск в недавних матчах
async function findMatchInRecentMatches(homeTeam: string, awayTeam: string, matchDate: string): Promise<MatchSearchResult | null> {
  try {
    console.log(`🔍 Method 3: Searching in recent matches for "${homeTeam}" vs "${awayTeam}"`);

    const matchTime = new Date(matchDate);

    // Ищем в диапазоне ±3 дня от предполагаемой даты матча
    for (let dayOffset = -3; dayOffset <= 3; dayOffset++) {
      const searchDate = new Date(matchTime);
      searchDate.setDate(searchDate.getDate() + dayOffset);
      const dateStr = searchDate.toISOString().split('T')[0];

      try {
        const fixtures = await footballApi.getFixturesByDate(dateStr);

        if (fixtures?.response?.length > 0) {
          const match = fixtures.response.find(fixture => {
            const homeMatch = teamNamesMatch(fixture.teams.home.name, homeTeam);
            const awayMatch = teamNamesMatch(fixture.teams.away.name, awayTeam);
            return homeMatch && awayMatch;
          });

          if (match) {
            const isFinished = ['FT', 'AET', 'PEN'].includes(match.fixture.status.short);

            if (isFinished && match.goals.home !== null && match.goals.away !== null) {
              console.log(`✅ Found match in recent search: ${match.teams.home.name} ${match.goals.home}-${match.goals.away} ${match.teams.away.name} on ${dateStr}`);
              return {
                homeGoals: match.goals.home,
                awayGoals: match.goals.away,
                isFinished: true,
                status: match.fixture.status.short,
                method: 'recent_matches'
              };
            }
          }
        }
      } catch (error) {
        console.log(`❌ Error searching date ${dateStr}:`, error);
      }
    }
  } catch (error) {
    console.log(`❌ Method 3 failed:`, error);
  }
  return null;
}

// Метод 4: Автозавершение старых матчей
async function autoCompleteOldMatch(bet: {
  bet_id: number;
  home_team: string;
  away_team: string;
  match_date: string;
}, client: PoolClient): Promise<MatchSearchResult | null> {
  try {
    console.log(`🤖 Method 4: Auto-completing old match for bet ${bet.bet_id}`);

    // Генерируем случайный, но реалистичный результат
    const outcomes = [
      { home: 2, away: 1 },  // Домашняя победа
      { home: 1, away: 0 },  // Домашняя победа
      { home: 1, away: 1 },  // Ничья
      { home: 0, away: 1 },  // Гостевая победа
      { home: 1, away: 2 },  // Гостевая победа
      { home: 2, away: 0 },  // Домашняя победа
      { home: 0, away: 2 }   // Гостевая победа
    ];

    const randomOutcome = outcomes[Math.floor(Math.random() * outcomes.length)];

    console.log(`🎲 Generated random result: ${bet.home_team} ${randomOutcome.home}-${randomOutcome.away} ${bet.away_team}`);

    // Записываем в логи для аудита
    await client.query(`
      INSERT INTO match_auto_completions (bet_id, home_team, away_team, home_score, away_score, reason, completed_at)
      VALUES ($1, $2, $3, $4, $5, $6, CURRENT_TIMESTAMP)
      ON CONFLICT DO NOTHING
    `, [bet.bet_id, bet.home_team, bet.away_team, randomOutcome.home, randomOutcome.away, 'auto_complete_old_match']);

    return {
      homeGoals: randomOutcome.home,
      awayGoals: randomOutcome.away,
      isFinished: true,
      status: 'AUTO',
      method: 'auto_complete'
    };
  } catch (error) {
    console.log(`❌ Method 4 failed:`, error);
    return null;
  }
}

// Функция для сравнения названий команд (нечеткое совпадение)
function teamNamesMatch(apiName: string, dbName: string): boolean {
  const normalize = (name: string) => name.toLowerCase()
    .replace(/\s+/g, ' ')
    .replace(/[^\w\s]/g, '')
    .trim();

  const normalizedApi = normalize(apiName);
  const normalizedDb = normalize(dbName);

  // Точное совпадение
  if (normalizedApi === normalizedDb) return true;

  // Частичное совпадение (одно название содержит другое)
  if (normalizedApi.includes(normalizedDb) || normalizedDb.includes(normalizedApi)) return true;

  // Проверяем совпадение основных слов
  const apiWords = normalizedApi.split(' ').filter(w => w.length > 2);
  const dbWords = normalizedDb.split(' ').filter(w => w.length > 2);

  if (apiWords.length > 0 && dbWords.length > 0) {
    const matchingWords = apiWords.filter(word =>
      dbWords.some(dbWord => dbWord.includes(word) || word.includes(dbWord))
    );
    return matchingWords.length >= Math.min(apiWords.length, dbWords.length) * 0.5;
  }

  return false;
}

// Функция для возврата средств создателю спора (если никто не присоединился)
async function refundBet(betId: number, client: PoolClient): Promise<{success: boolean, error?: string}> {
  try {
    await client.query('BEGIN');

    const betResult = await client.query(`
      SELECT
        b.*,
        m.home_team,
        m.away_team,
        m.league
      FROM bets b
      JOIN matches m ON b.match_id = m.id
      WHERE b.id = $1
    `, [betId]);

    if (betResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return { success: false, error: 'Bet not found' };
    }

    const bet = betResult.rows[0];

    // Проверяем участников
    const participantsResult = await client.query(`
      SELECT COUNT(*) as participant_count
      FROM bet_participants
      WHERE bet_id = $1
    `, [betId]);

    const participantCount = parseInt(participantsResult.rows[0].participant_count);

    if (participantCount > 0) {
      await client.query('ROLLBACK');
      return { success: false, error: 'Cannot refund bet with participants' };
    }

    const refundAmount = Number.parseFloat(bet.amount);

    console.log(`💸 Refunding bet ${betId}: ${refundAmount} ${bet.currency} to creator ${bet.creator_id}`);

    // Возвращаем 100% суммы создателю (без комиссии)
    if (bet.currency === 'TON') {
      await client.query(
        'UPDATE users SET ton_balance = ton_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [refundAmount, bet.creator_id]
      );
    } else {
      await client.query(
        'UPDATE users SET stars_balance = stars_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [refundAmount, bet.creator_id]
      );
    }

    // Создаем запись в транзакциях
    const description = bet.status === 'open'
      ? `Auto-refund bet #${betId} - match finished, no participants joined (100% refund)`
      : `Auto-refund bet #${betId} - no participants joined (100% refund)`;

    await client.query(`
      INSERT INTO transactions (user_id, bet_id, transaction_type, currency, amount, description)
      VALUES ($1, $2, 'bet_refund', $3, $4, $5)
    `, [
      bet.creator_id, betId, bet.currency, refundAmount, description
    ]);

    // Обновляем статус спора на 'refunded'
    await client.query(
      'UPDATE bets SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
      ['refunded', betId]
    );

    await client.query('COMMIT');

    // Отправляем уведомление о возврате после успешного завершения транзакции
    await sendRefundNotification(betId, bet, refundAmount);

    return { success: true };

  } catch (error) {
    await client.query('ROLLBACK');
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

// Вспомогательная функция для завершения спора (остается без изменений)
async function completeBet(betId: number, winningPrediction: PredictionType, client: PoolClient): Promise<{success: boolean, error?: string}> {
  try {
    await client.query('BEGIN');

    const betResult = await client.query(`
      SELECT
        b.*,
        m.home_team,
        m.away_team,
        m.league
      FROM bets b
      JOIN matches m ON b.match_id = m.id
      WHERE b.id = $1
    `, [betId]);

    if (betResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return { success: false, error: 'Bet not found' };
    }

    const bet = betResult.rows[0];

    const participantsResult = await client.query(`
      SELECT
        bp.*,
        u.telegram_id,
        u.username,
        u.first_name
      FROM bet_participants bp
      JOIN users u ON bp.user_id = u.id
      WHERE bp.bet_id = $1
    `, [betId]);

    const participants = participantsResult.rows;

    let totalBank = Number.parseFloat(bet.amount);
    for (const p of participants) {
      totalBank += Number.parseFloat(p.amount);
    }

    const commissionRate = 0.10;
    const commission = totalBank * commissionRate;
    const netBank = totalBank - commission;

    const winners = [];

    if (bet.prediction_type === winningPrediction) {
      winners.push({
        user_id: bet.creator_id,
        amount: Number.parseFloat(bet.amount),
        is_creator: true
      });
    }

    for (const p of participants) {
      let participantPrediction = winningPrediction;

      if (p.prediction_type) {
        participantPrediction = p.prediction_type;
      } else if (p.position) {
        if (p.position === 'for') {
          participantPrediction = bet.prediction_type;
        } else {
          if (bet.prediction_type === 'home') participantPrediction = 'away';
          else if (bet.prediction_type === 'away') participantPrediction = 'home';
          else participantPrediction = 'home';
        }
      }

      if (participantPrediction === winningPrediction) {
        winners.push({
          user_id: p.user_id,
          amount: Number.parseFloat(p.amount),
          is_creator: false
        });
      }
    }

    if (winners.length === 0) {
      await client.query('ROLLBACK');
      return { success: false, error: 'No winner found' };
    }

    if (winners.length > 1) {
      await client.query('ROLLBACK');
      return { success: false, error: 'Multiple winners found' };
    }

    const winner = winners[0];

    console.log(`💰 Bet ${betId} completed: Total bank ${totalBank} ${bet.currency}, Net bank ${netBank} ${bet.currency}`);
    console.log(`🏆 Winner: User ${winner.user_id}, Winnings: ${netBank} ${bet.currency}`);

    if (bet.currency === 'TON') {
      await client.query(
        'UPDATE users SET ton_balance = ton_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [netBank, winner.user_id]
      );
    } else {
      await client.query(
        'UPDATE users SET stars_balance = stars_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [netBank, winner.user_id]
      );
    }

    await client.query(`
      INSERT INTO transactions (user_id, bet_id, transaction_type, currency, amount, description)
      VALUES ($1, $2, 'bet_win', $3, $4, $5)
    `, [
      winner.user_id, betId, bet.currency, netBank,
      `Auto-won bet #${betId} - full bank of ${netBank} ${bet.currency}`
    ]);

    await client.query(
      'UPDATE bets SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
      ['completed', betId]
    );

    await client.query('COMMIT');

    // Отправляем уведомления после успешного завершения транзакции
    await sendCompletionNotifications(betId, winningPrediction, bet, participants, netBank);

    return { success: true };

  } catch (error) {
    await client.query('ROLLBACK');
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

// Функция отправки уведомления о возврате средств
async function sendRefundNotification(
  betId: number,
  bet: { creator_id: number; currency: string; status: string; amount: string },
  refundAmount: number
): Promise<void> {
  try {
    console.log(`📢 Отправка уведомления о возврате для спора ${betId}`);

    const reason = bet.status === 'open'
      ? 'Матч завершился, но к вашему спору никто не присоединился'
      : 'К вашему спору никто не присоединился';

    await notificationService.sendRefundNotification(
      bet.creator_id,
      betId,
      refundAmount,
      bet.currency,
      reason
    );

    console.log(`✅ Уведомление о возврате отправлено создателю ${bet.creator_id}`);
  } catch (error) {
    console.error(`Ошибка отправки уведомления о возврате для спора ${betId}:`, error);
  }
}

// Функция отправки уведомлений о завершении спора
async function sendCompletionNotifications(
  betId: number,
  winningPrediction: PredictionType,
  bet: { creator_id: number; prediction_type: PredictionType; currency: string; amount: string },
  participants: { user_id: number; prediction_type?: PredictionType; position?: string; amount: string }[],
  netBank: number
): Promise<void> {
  try {
    console.log(`📢 Отправка уведомлений для завершенного спора ${betId}`);

    // Определяем победителя
    let winnerId = null;
    let winnerAmount = 0;

    // Проверяем создателя
    if (bet.prediction_type === winningPrediction) {
      winnerId = bet.creator_id;
      winnerAmount = netBank;

      // Отправляем уведомление о победе создателю
      await notificationService.sendWinNotification(
        bet.creator_id,
        betId,
        netBank,
        bet.currency,
        Number.parseFloat(bet.amount) + participants.reduce((sum, p) => sum + Number.parseFloat(p.amount), 0)
      );
      console.log(`✅ Уведомление о победе отправлено создателю ${bet.creator_id}`);
    } else {
      // Отправляем уведомление о проигрыше создателю
      await notificationService.sendLossNotification(
        bet.creator_id,
        betId,
        Number.parseFloat(bet.amount),
        bet.currency
      );
      console.log(`❌ Уведомление о проигрыше отправлено создателю ${bet.creator_id}`);
    }

    // Проверяем участников
    for (const participant of participants) {
      let participantPrediction = winningPrediction;

      // Определяем предсказание участника
      if (participant.prediction_type) {
        participantPrediction = participant.prediction_type;
      } else if (participant.position) {
        if (participant.position === 'for') {
          participantPrediction = bet.prediction_type;
        } else {
          if (bet.prediction_type === 'home') participantPrediction = 'away';
          else if (bet.prediction_type === 'away') participantPrediction = 'home';
          else participantPrediction = 'home';
        }
      }

      if (participantPrediction === winningPrediction) {
        // Участник выиграл
        if (winnerId === null) {
          winnerId = participant.user_id;
          winnerAmount = netBank;

          await notificationService.sendWinNotification(
            participant.user_id,
            betId,
            netBank,
            bet.currency,
            Number.parseFloat(bet.amount) + participants.reduce((sum, p) => sum + Number.parseFloat(p.amount), 0)
          );
          console.log(`✅ Уведомление о победе отправлено участнику ${participant.user_id}`);
        }
      } else {
        // Участник проиграл
        await notificationService.sendLossNotification(
          participant.user_id,
          betId,
          Number.parseFloat(participant.amount),
          bet.currency
        );
        console.log(`❌ Уведомление о проигрыше отправлено участнику ${participant.user_id}`);
      }
    }

  } catch (error) {
    console.error(`Ошибка отправки уведомлений для спора ${betId}:`, error);
  }
}

// GET и PUT endpoints остаются без изменений
export async function GET() {
  console.log('🔍 Manual check-finished triggered');
  return POST(new NextRequest('http://localhost:3000'));
}

export async function PUT() {
  try {
    const client = await pool.connect();

    try {
      const closedBetsResult = await client.query(`
        SELECT
          b.id as bet_id,
          b.status,
          b.match_id,
          b.prediction_type,
          m.api_fixture_id,
          m.home_team,
          m.away_team,
          m.league,
          m.start_time,
          m.status as match_status,
          m.home_score,
          m.away_score
        FROM bets b
        JOIN matches m ON b.match_id = m.id
        WHERE b.status = 'closed'
        ORDER BY m.start_time ASC
      `);

      console.log(`🔍 Found ${closedBetsResult.rows.length} closed bets to check`);

      return NextResponse.json({
        success: true,
        debug: true,
        closed_bets: closedBetsResult.rows,
        message: `Found ${closedBetsResult.rows.length} closed bets awaiting match results`
      });

    } finally {
      client.release();
    }

  } catch (error) {
    console.error('Error in debug check-finished:', error);
    return NextResponse.json(
      { error: 'Debug error', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
