// import pool from './database'; // Временно отключено
import { footballApi } from './football-api';
import { Fixture, type League, type Team, type MatchEvent, type FixtureApiResponse, type ApiLeagueResponse } from '@/types/football';

// Расширенный список популярных лиг (названия из API)
const POPULAR_LEAGUE_NAMES: string[] = [
  // Топ европейские лиги
  'Premier League',           // England (ID: 39)
  'La Liga',                 // Spain (ID: 140)
  'Serie A',                 // Italy (ID: 135)
  'Bundesliga',              // Germany (ID: 78)
  'Ligue 1',                 // France (ID: 61)
  'UEFA Champions League',    // Europe (ID: 2)
  'UEFA Europa League',      // Europe (ID: 3)
  'UEFA Conference League',  // Europe (ID: 848)

  // Русские лиги и кубки
  'Premier League',          // Russia (ID: 235)
  'Cup',                     // Кубок России (ID: 237)
  'Super Cup',               // Суперкубок России (ID: 663)
  'First League',            // ФНЛ (ID: 236)

  // Кубки топ лиг
  'FA Cup',                  // England (ID: 45)
  'League Cup',              // England (ID: 48)
  'Copa del Rey',            // Spain (ID: 143)
  'Coppa Italia',            // Italy (ID: 137)
  'DFB Pokal',               // Germany (ID: 81)
  'Coupe de France',         // France (ID: 66)
  'Coupe de la Ligue',       // France (ID: 65)
  'Trophée des Champions',   // France (ID: 526)

  // Аргентинские лиги
  'Liga Profesional Argentina', // Argentina (ID: 128)
  'Copa Argentina',          // Argentina (ID: 130)
  'Copa de la Liga Profesional', // Argentina (ID: 1032)

  // Другие важные лиги
  'Eredivisie',              // Netherlands (ID: 88)
  'Primeira Liga',           // Portugal (ID: 94)
  'Championship',            // England 2nd tier (ID: 40)
  'Serie B',                 // Italy 2nd tier (ID: 136)
  '2. Bundesliga',          // Germany 2nd tier (ID: 79)
  'Ligue 2',                // France 2nd tier (ID: 62)
  'Segunda División',        // Spain 2nd tier (ID: 141)

  // Другие топ кубки
  'KNVB Beker',             // Netherlands Cup (ID: 90)
  'Taça de Portugal',       // Portugal Cup (ID: 96)
  'Super Cup',              // Portugal Supercup (ID: 550)
  'Community Shield',       // England (ID: 528)
  'Super Cup',              // Spain (ID: 556)
  'Super Cup',              // Italy (ID: 547)
  'Super Cup',              // Germany (ID: 529)
  'Super Cup',              // Netherlands (ID: 543)
];

// ID популярных лиг (расширенный список)
const POPULAR_LEAGUE_IDS: number[] = [
  // Топ европейские лиги
  39,   // Premier League (England)
  140,  // La Liga (Spain)
  135,  // Serie A (Italy)
  78,   // Bundesliga (Germany)
  61,   // Ligue 1 (France)
  2,    // UEFA Champions League
  3,    // UEFA Europa League
  848,  // UEFA Conference League

  // Русские турниры
  235,  // Premier League (Russia)
  237,  // Cup (Russia)
  663,  // Super Cup (Russia)
  236,  // First League (Russia)

  // Кубки топ лиг
  45,   // FA Cup (England)
  48,   // League Cup (England)
  143,  // Copa del Rey (Spain)
  137,  // Coppa Italia (Italy)
  81,   // DFB Pokal (Germany)
  66,   // Coupe de France
  65,   // Coupe de la Ligue (France)
  526,  // Trophée des Champions (France)

  // Аргентинские турниры
  128,  // Liga Profesional Argentina
  130,  // Copa Argentina
  1032, // Copa de la Liga Profesional

  // Другие важные лиги
  88,   // Eredivisie (Netherlands)
  94,   // Primeira Liga (Portugal)
  40,   // Championship (England)
  136,  // Serie B (Italy)
  79,   // 2. Bundesliga (Germany)
  62,   // Ligue 2 (France)
  141,  // Segunda División (Spain)

  // Другие кубки
  90,   // KNVB Beker (Netherlands)
  96,   // Taça de Portugal
  550,  // Super Cup (Portugal)
  528,  // Community Shield (England)
  556,  // Super Cup (Spain)
  547,  // Super Cup (Italy)
  529,  // Super Cup (Germany)
  543,  // Super Cup (Netherlands)
];

// Расширенная функция проверки популярных лиг
const isPopularLeague = (leagueName: string, countryName?: string): boolean => {
  const normalizedName = leagueName.toLowerCase().trim();
  const country = countryName?.toLowerCase().trim() || '';

  // Популярные лиги с учетом стран
  const popularLeagues = [
    // Топ европейские лиги
    { name: 'premier league', countries: ['england', 'russia'] },
    { name: 'la liga', countries: ['spain'] },
    { name: 'serie a', countries: ['italy'] },
    { name: 'bundesliga', countries: ['germany'] },
    { name: 'ligue 1', countries: ['france'] },
    { name: 'ligue 2', countries: ['france'] },
    { name: 'uefa champions league', countries: ['world'] },
    { name: 'uefa europa league', countries: ['world'] },
    { name: 'uefa conference league', countries: ['world'] },

    // Русские лиги
    { name: 'cup', countries: ['russia'] },
    { name: 'super cup', countries: ['russia', 'spain', 'italy', 'germany', 'netherlands', 'portugal', 'argentina'] },
    { name: 'first league', countries: ['russia'] },

    // Кубки топ лиг
    { name: 'fa cup', countries: ['england'] },
    { name: 'league cup', countries: ['england'] },
    { name: 'copa del rey', countries: ['spain'] },
    { name: 'coppa italia', countries: ['italy'] },
    { name: 'dfb pokal', countries: ['germany'] },
    { name: 'coupe de france', countries: ['france'] },
    { name: 'coupe de la ligue', countries: ['france'] },
    { name: 'trophée des champions', countries: ['france'] },

    // Аргентинские лиги
    { name: 'liga profesional argentina', countries: ['argentina'] },
    { name: 'copa argentina', countries: ['argentina'] },
    { name: 'copa de la liga profesional', countries: ['argentina'] },

    // Другие важные лиги
    { name: 'eredivisie', countries: ['netherlands'] },
    { name: 'primeira liga', countries: ['portugal'] },
    { name: 'championship', countries: ['england'] },
    { name: 'serie b', countries: ['italy'] },
    { name: '2. bundesliga', countries: ['germany'] },
    { name: 'segunda división', countries: ['spain'] },

    // Другие кубки
    { name: 'knvb beker', countries: ['netherlands'] },
    { name: 'taça de portugal', countries: ['portugal'] },
    { name: 'community shield', countries: ['england'] },
  ];

  for (const league of popularLeagues) {
    if (normalizedName === league.name) {
      return league.countries.includes(country) || league.countries.includes('world');
    }
  }

  return false;
};

// Вес популярности лиг по ID
const leaguePopularityWeight = (leagueId?: number): number => {
  if (!leagueId) return 0;

  // Специальные веса для разных типов турниров
  const weights: Record<number, number> = {
    // Европейские турниры - максимальный приоритет
    2: 1000,    // UEFA Champions League
    3: 950,     // UEFA Europa League
    848: 940,   // UEFA Conference League

    // Топ-5 лиг
    39: 900,    // Premier League (England)
    140: 890,   // La Liga (Spain)
    135: 880,   // Serie A (Italy)
    78: 870,    // Bundesliga (Germany)
    61: 860,    // Ligue 1 (France)

    // Русские турниры - высокий приоритет
    235: 900,   // Premier League (Russia)
    237: 785,   // Cup (Russia)
    663: 780,   // Super Cup (Russia)
    236: 775,   // First League (Russia)

    // Кубки топ-5 лиг
    45: 850,    // FA Cup (England)
    143: 840,   // Copa del Rey (Spain)
    137: 830,   // Coppa Italia (Italy)
    81: 820,    // DFB Pokal (Germany)
    66: 810,    // Coupe de France

    // Другие важные лиги
    88: 800,    // Eredivisie (Netherlands)
    94: 790,    // Primeira Liga (Portugal)

    // Аргентинские турниры
    128: 770,   // Liga Profesional Argentina
    130: 760,   // Copa Argentina
    1032: 750,  // Copa de la Liga Profesional

    // Вторые дивизионы
    40: 700,    // Championship (England)
    79: 690,    // 2. Bundesliga (Germany)
    62: 680,    // Ligue 2 (France)
    136: 670,   // Serie B (Italy)
    141: 660,   // Segunda División (Spain)

    // Другие кубки и турниры
    48: 650,    // League Cup (England)
    528: 640,   // Community Shield (England)
    526: 630,   // Trophée des Champions (France)
    90: 620,    // KNVB Beker (Netherlands)
    96: 610,    // Taça de Portugal
    65: 600,    // Coupe de la Ligue (France)
    550: 590,   // Super Cup (Portugal)
    556: 580,   // Super Cup (Spain)
    547: 570,   // Super Cup (Italy)
    529: 560,   // Super Cup (Germany)
    543: 550,   // Super Cup (Netherlands)
  };

  return weights[leagueId] || 50; // Дефолтный вес для непопулярных лиг
};

class FootballService {
  // Простое кэширование в памяти (временно, пока не настроена БД)
  private cache = new Map<string, { data: unknown; expires: number }>();

  private async getCachedData<T>(key: string): Promise<T | null> {
    try {
      const cached = this.cache.get(key);
      if (cached && cached.expires > Date.now()) {
        return cached.data as T;
      }
      return null;
    } catch (error) {
      console.error('Cache read error:', error);
      return null;
    }
  }

  private async setCachedData(key: string, data: unknown, expirationMinutes = 60): Promise<void> {
    try {
      const expires = Date.now() + expirationMinutes * 60 * 1000;
      this.cache.set(key, { data, expires });
    } catch (error) {
      console.error('Cache write error:', error);
    }
  }

  // Получить популярные лиги
  async getPopularLeagues(): Promise<League[]> {
    const cacheKey = 'popular_leagues';
    const cached = await this.getCachedData<League[]>(cacheKey);

    if (cached) {
      return cached;
    }

    try {
      // Получаем все текущие лиги из API
      const response = await footballApi.getLeagues({
        current: true
      });

      // Фильтруем популярные лиги по названиям (более надежно чем по ID)
      const popularLeagues = response.response.filter((leagueItem: ApiLeagueResponse) => {
        const league = leagueItem.league;
        const country = leagueItem.country?.name || '';
        return isPopularLeague(league.name, country);
      }).map((leagueItem: ApiLeagueResponse) => {
        // Возвращаем в стандартном формате League
        const league = leagueItem.league;
        return {
          id: league.id,
          name: league.name,
          type: league.type,
          logo: league.logo,
          country: leagueItem.country?.name || '',
          flag: leagueItem.country?.flag,
          season: new Date().getFullYear(),
          current: true
        } as League;
      });

      // Сортируем по приоритету (топ лиги сначала)
      popularLeagues.sort((a, b) => {
        const aWeight = this.getLeagueWeight(a.name);
        const bWeight = this.getLeagueWeight(b.name);
        return bWeight - aWeight;
      });

      await this.setCachedData(cacheKey, popularLeagues, 1440); // 24 часа
      return popularLeagues;
    } catch (error) {
      console.error('Error fetching popular leagues:', error);
      return [];
    }
  }

  // Приоритет лиг для сортировки (расширенная система)
  private getLeagueWeight(leagueName: string): number {
    const name = leagueName.toLowerCase().trim();

    // Европейские турниры - высший приоритет
    if (name === 'uefa champions league') return 1000;
    if (name === 'uefa europa league') return 950;
    if (name === 'uefa conference league') return 940;

    // Топ-5 европейских лиг
    if (name === 'premier league') return 900; // Англия и Россия
    if (name === 'la liga') return 890;
    if (name === 'serie a') return 880;
    if (name === 'bundesliga') return 870;
    if (name === 'ligue 1') return 860;

    // Кубки топ-5 лиг
    if (name === 'fa cup') return 850;
    if (name === 'copa del rey') return 840;
    if (name === 'coppa italia') return 830;
    if (name === 'dfb pokal') return 820;
    if (name === 'coupe de france') return 810;

    // Другие важные европейские лиги
    if (name === 'eredivisie') return 800;
    if (name === 'primeira liga') return 790;

    // Русские турниры - высокий приоритет для русскоязычной аудитории
    if (name === 'cup') return 785; // Кубок России
    if (name === 'super cup') return 780; // Суперкубки (много стран)
    if (name === 'first league') return 775; // ФНЛ

    // Аргентинские турниры
    if (name === 'liga profesional argentina') return 770;
    if (name === 'copa argentina') return 760;
    if (name === 'copa de la liga profesional') return 750;

    // Вторые дивизионы топовых стран
    if (name === 'championship') return 700;
    if (name === '2. bundesliga') return 690;
    if (name === 'ligue 2') return 680;
    if (name === 'serie b') return 670;
    if (name === 'segunda división') return 660;

    // Другие кубки
    if (name === 'league cup') return 650;
    if (name === 'community shield') return 640;
    if (name === 'trophée des champions') return 630;
    if (name === 'knvb beker') return 620;
    if (name === 'taça de portugal') return 610;
    if (name === 'coupe de la ligue') return 600;

    return 50; // остальные лиги
  }

  // Получить команды лиги
  async getLeagueTeams(leagueId: number, season: number): Promise<Team[]> {
    const cacheKey = `teams_${leagueId}_${season}`;
    const cached = await this.getCachedData<Team[]>(cacheKey);

    if (cached) {
      return cached;
    }

    try {
      const response = await footballApi.getTeams({
        league: leagueId,
        season
      });

      await this.setCachedData(cacheKey, response.response, 1440); // 24 часа
      return response.response;
    } catch (error) {
      console.error('Error fetching league teams:', error);
      return [];
    }
  }

  // Получить ВСЕ live матчи (для поиска и "Только Live")
  async getAllLiveMatches(): Promise<MatchEvent[]> {
    const cacheKey = 'all_live_matches';
    const cached = await this.getCachedData<MatchEvent[]>(cacheKey);

    if (cached) {
      return cached;
    }

    try {
      const response = await footballApi.getLiveFixtures();

      if (!response || !response.response || !Array.isArray(response.response)) {
        return [];
      }

      const liveMatches: MatchEvent[] = response.response.map(item => {
        const matchDate = new Date(item.fixture.date);
        return {
          id: item.fixture.id.toString(),
          homeTeam: item.teams.home.name,
          awayTeam: item.teams.away.name,
          homeTeamLogo: item.teams.home.logo,
          awayTeamLogo: item.teams.away.logo,
          league: item.league.name,
          leagueLogo: item.league.logo,
          startTime: matchDate.toLocaleTimeString('ru-RU', {
            hour: '2-digit',
            minute: '2-digit'
          }),
          date: matchDate.toISOString().split('T')[0],
          fullDateTime: matchDate.toLocaleString('ru-RU', {
            day: '2-digit',
            month: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
          }),
          status: this.mapFixtureStatus(item.fixture.status.short),
          score: item.goals.home !== null && item.goals.away !== null ? {
            home: item.goals.home,
            away: item.goals.away
          } : undefined,
          minute: item.fixture.status.elapsed,
          venue: item.fixture.venue?.name
        };
      });

      await this.setCachedData(cacheKey, liveMatches, 1); // 1 минута для live данных
      return liveMatches;
    } catch (error) {
      console.error('Error fetching all live matches:', error);
      return [];
    }
  }

  // Получить ТОЛЬКО популярные live матчи (для блока "Матчи Live" на главной)
  async getLiveMatches(): Promise<MatchEvent[]> {
    const allLiveMatches = await this.getAllLiveMatches();

    // Фильтруем только популярные лиги
    const popularLiveMatches = allLiveMatches.filter(match => {
      // Определяем страну по league name (можно улучшить через отдельный API запрос)
      let country = 'unknown';
      const leagueName = match.league.toLowerCase();

      if (leagueName.includes('premier league') || leagueName.includes('fa cup') || leagueName.includes('championship') || leagueName.includes('league cup') || leagueName.includes('community shield')) {
        country = leagueName.includes('russia') ? 'russia' : 'england';
      } else if (leagueName.includes('la liga') || leagueName.includes('copa del rey') || leagueName.includes('segunda')) {
        country = 'spain';
      } else if (leagueName.includes('serie a') || leagueName.includes('serie b') || leagueName.includes('coppa italia')) {
        country = 'italy';
      } else if (leagueName.includes('bundesliga') || leagueName.includes('dfb pokal')) {
        country = 'germany';
      } else if (leagueName.includes('ligue') || leagueName.includes('coupe de france') || leagueName.includes('trophée')) {
        country = 'france';
      } else if (leagueName.includes('eredivisie') || leagueName.includes('knvb')) {
        country = 'netherlands';
      } else if (leagueName.includes('primeira liga') || leagueName.includes('taça')) {
        country = 'portugal';
      } else if (leagueName.includes('liga profesional') || leagueName.includes('copa argentina')) {
        country = 'argentina';
      } else if (leagueName.includes('cup') && (leagueName.includes('russia') || leagueName.includes('рпл'))) {
        country = 'russia';
      } else if (leagueName.includes('uefa') || leagueName.includes('champions') || leagueName.includes('europa')) {
        country = 'world';
      }

      return isPopularLeague(match.league, country);
    });

    // Сортируем по популярности
    return popularLiveMatches.sort((a, b) => {
      const aWeight = this.getLeagueWeight(a.league);
      const bWeight = this.getLeagueWeight(b.league);
      return bWeight - aWeight;
    });
  }

  // Helper: filter only today, exclude finished, and sort by popularity and kickoff time
  private filterAndRankTodayMatches(items: FixtureApiResponse[]): MatchEvent[] {
    if (!Array.isArray(items)) return [];
    return items
      .map((item) => {
        const matchDate = new Date(item.fixture.date);
        const status = this.mapFixtureStatus(item.fixture.status.short);
        const ev: MatchEvent = {
          id: item.fixture.id.toString(),
          homeTeam: item.teams.home.name,
          awayTeam: item.teams.away.name,
          homeTeamLogo: item.teams.home.logo,
          awayTeamLogo: item.teams.away.logo,
          league: item.league.name,
          leagueLogo: item.league.logo,
          startTime: matchDate.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }),
          date: matchDate.toISOString().split('T')[0],
          fullDateTime: matchDate.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }),
          status,
          score: item.goals.home !== null && item.goals.away !== null ? { home: item.goals.home, away: item.goals.away } : undefined,
          minute: item.fixture.status.elapsed,
          venue: item.fixture.venue?.name,
        };
        // attach a sort key
        const weight = leaguePopularityWeight(item.league.id);
        return { ev, weight, ts: matchDate.getTime(), leagueId: item.league.id };
      })
      .filter((x) => {
        // only today and not finished
        const today = new Date();
        const d = new Date(x.ts);
        const isSameDay = d.getUTCFullYear() === today.getUTCFullYear() && d.getUTCMonth() === today.getUTCMonth() && d.getUTCDate() === today.getUTCDate();
        return x.ev.status !== 'finished' && isSameDay;
      })
      .sort((a, b) => {
        // primary by popularity weight desc, secondary by kickoff time asc
        if (b.weight !== a.weight) return b.weight - a.weight;
        return a.ts - b.ts;
      })
      .map((x) => x.ev);
  }

  // Получить матчи на сегодня (исключая завершенные)
  async getTodayMatches(): Promise<MatchEvent[]> {
    const today = new Date().toISOString().split('T')[0];
    const cacheKey = `matches_${today}`;
    const cached = await this.getCachedData<MatchEvent[]>(cacheKey);

    if (cached) {
      return cached;
    }

    try {
      const response = await footballApi.getFixturesByDate(today);

      if (!response || !response.response || !Array.isArray(response.response)) {
        return [];
      }

      const todayMatches: MatchEvent[] = this.filterAndRankTodayMatches(response.response);

      await this.setCachedData(cacheKey, todayMatches, 15); // 15 минут
      return todayMatches;
    } catch (error) {
      console.error('Error fetching today matches:', error);
      return [];
    }
  }

  // Мапинг статусов матчей
  private mapFixtureStatus(apiStatus: string): "upcoming" | "live" | "halftime" | "finished" {
    switch (apiStatus) {
      case 'NS':
      case 'TBD':
        return 'upcoming';
      case '1H':
      case '2H':
      case 'ET':
      case 'P':
      case 'LIVE':
        return 'live';
      case 'HT':
        return 'halftime';
      case 'FT':
      case 'AET':
      case 'PEN':
        return 'finished';
      default:
        return 'upcoming';
    }
  }

  // Получить комбинированные данные для главной страницы
  async getHomePageData(): Promise<{
    liveMatches: MatchEvent[];
    todayMatches: MatchEvent[];
    popularLeagues: League[];
  }> {
    try {
      const [liveMatches, todayMatches, popularLeagues] = await Promise.all([
        this.getLiveMatches(),
        this.getTodayMatches(),
        this.getPopularLeagues()
      ]);

      return {
        liveMatches,
        // Ensure todayMatches are sorted by popularity/time already
        todayMatches,
        popularLeagues
      };
    } catch (error) {
      console.error('Error fetching home page data:', error);
      return {
        liveMatches: [],
        todayMatches: [],
        popularLeagues: []
      };
    }
  }

  // Expose popular league ids and helper for external use
  getPopularLeagueIds(): number[] {
    return Array.from(new Set(POPULAR_LEAGUE_IDS));
  }

  // Get interesting matches: today, not finished, sorted by popularity
  async getInterestingMatchesToday(): Promise<MatchEvent[]> {
    const todayMatches = await this.getTodayMatches();
    return todayMatches;
  }

  // Получить логотипы команд по их названиям
  async getTeamLogos(homeTeam: string, awayTeam: string): Promise<{
    homeTeamLogo?: string;
    awayTeamLogo?: string;
  }> {
    const cacheKey = `team_logos_${homeTeam}_${awayTeam}`;
    const cached = await this.getCachedData<{ homeTeamLogo?: string; awayTeamLogo?: string }>(cacheKey);

    if (cached) {
      return cached;
    }

    try {
      // Ищем команды по названию в популярных лигах
      const response = await footballApi.getTeams({ search: homeTeam });
      const awayResponse = await footballApi.getTeams({ search: awayTeam });

      let homeTeamLogo: string | undefined;
      let awayTeamLogo: string | undefined;

      // Находим логотип домашней команды
      if (response.response && response.response.length > 0) {
        const homeTeamMatch = response.response.find(item =>
          item.name.toLowerCase().includes(homeTeam.toLowerCase()) ||
          homeTeam.toLowerCase().includes(item.name.toLowerCase())
        );
        if (homeTeamMatch) {
          homeTeamLogo = homeTeamMatch.logo;
        }
      }

      // Находим логотип гостевой команды
      if (awayResponse.response && awayResponse.response.length > 0) {
        const awayTeamMatch = awayResponse.response.find(item =>
          item.name.toLowerCase().includes(awayTeam.toLowerCase()) ||
          awayTeam.toLowerCase().includes(item.name.toLowerCase())
        );
        if (awayTeamMatch) {
          awayTeamLogo = awayTeamMatch.logo;
        }
      }

      const result = { homeTeamLogo, awayTeamLogo };

      // Кешируем результат на 24 часа
      await this.setCachedData(cacheKey, result, 1440);

      return result;
    } catch (error) {
      console.error('Error fetching team logos:', error);
      return {};
    }
  }
}

export const footballService = new FootballService();
export { POPULAR_LEAGUE_IDS, POPULAR_LEAGUE_NAMES, leaguePopularityWeight, isPopularLeague };
