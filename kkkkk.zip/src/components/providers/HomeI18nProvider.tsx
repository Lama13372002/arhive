"use client";
import React, { createContext, useCallback, useContext, useMemo } from "react";
import { useI18n } from "./I18nProvider";

type Dict = Record<string, string>;

const ru: Dict = {
  title: "Футбольные матчи",
  loading_data: "Загрузка футбольных данных...",
  try_again: "Попробовать снова",
  search_placeholder: "Поиск команд...",
  all_leagues: "Все лиги",
  live_banner: "{count} матчей идут сейчас",
  live_toggle_on: "Только LIVE",
  live_toggle_off: "Показать все",
  interesting: "Самые интересные",
  live_matches: "Матчи LIVE",
  other_matches: "Остальные матчи",
  show_more: "Показать еще ({remaining})",
  reset: "Сбросить",
  show_all_matches: "Показать все матчи",
  not_found: "Событий не найдено",
  search_found: "Поиск по: \"{term}\" - найдено {count} матчей",
  search_min: "Введите минимум 2 символа для поиска",
  error_loading: "Ошибка загрузки данных",
  error_connection: "Ошибка подключения к серверу",
  create_bet: "Создать спор",
  halftime: "Перерыв",
  finished: "Завершен",
  today: "Сегодня",
};

const en: Dict = {
  title: "Football matches",
  loading_data: "Loading football data...",
  try_again: "Try again",
  search_placeholder: "Search teams...",
  all_leagues: "All leagues",
  live_banner: "{count} matches live now",
  live_toggle_on: "Only LIVE",
  live_toggle_off: "Show all",
  interesting: "Most interesting",
  live_matches: "LIVE matches",
  other_matches: "Other matches",
  show_more: "Show more ({remaining})",
  reset: "Reset",
  show_all_matches: "Show all matches",
  not_found: "No events found",
  search_found: "Search: \"{term}\" - {count} matches found",
  search_min: "Enter at least 2 characters to search",
  error_loading: "Error loading data",
  error_connection: "Server connection error",
  create_bet: "Create bet",
  halftime: "Half-time",
  finished: "Finished",
  today: "Today",
};

const dicts = { ru, en };

type Ctx = { t: (key: string, params?: Record<string, string | number>) => string };
const Ctx = createContext<Ctx | undefined>(undefined);

export const HomeI18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useI18n();
  const t = useCallback((key: string, params?: Record<string, string | number>) => {
    const dict = dicts[lang] || en;
    let text = dict[key] ?? key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
      });
    }
    return text;
  }, [lang]);
  const value = useMemo(() => ({ t }), [t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export const useHomeI18n = () => {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useHomeI18n must be used within HomeI18nProvider");
  return ctx;
};
