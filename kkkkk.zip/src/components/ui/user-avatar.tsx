import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useUserPhoto } from '@/hooks/useUserPhoto';
import { cn } from '@/lib/utils';

interface UserAvatarProps {
  userId?: number;
  telegramId?: number;
  userName: string;
  role?: 'admin' | 'moderator';
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'menu';
  showOnlineIndicator?: boolean;
}

const getRoleColor = (role?: string) => {
  switch (role) {
    case "admin":
      return "bg-gradient-to-r from-red-500 to-rose-500";
    case "moderator":
      return "bg-gradient-to-r from-blue-500 to-blue-600";
    default:
      return "bg-gradient-to-br from-blue-500 to-purple-600";
  }
};

const getSizeClasses = (size: 'sm' | 'md' | 'lg' | 'menu') => {
  switch (size) {
    case 'sm':
      return 'h-7 w-7';
    case 'md':
      return 'h-10 w-10';
    case 'lg':
      return 'h-18 w-18';
    case 'menu':
      return 'h-12 w-12';
    default:
      return 'h-10 w-10';
  }
};

const getFallbackTextSize = (size: 'sm' | 'md' | 'lg' | 'menu') => {
  switch (size) {
    case 'sm':
      return 'text-xs';
    case 'md':
      return 'text-sm';
    case 'lg':
      return 'text-xl';
    case 'menu':
      return 'text-base';
    default:
      return 'text-sm';
  }
};

export const UserAvatar: React.FC<UserAvatarProps> = ({
  userId,
  telegramId,
  userName,
  role,
  className,
  size = 'md',
  showOnlineIndicator = false
}) => {
  const { photoUrl, loading } = useUserPhoto(userId, telegramId);

  const firstLetter = userName?.[0]?.toUpperCase() || '?';
  const sizeClasses = getSizeClasses(size);
  const fallbackTextSize = getFallbackTextSize(size);

  return (
    <div className={cn("relative", className)}>
      <Avatar className={cn(sizeClasses, "border-2 border-white/10")}>
        {photoUrl && !loading ? (
          <AvatarImage
            src={photoUrl}
            alt={userName}
            className="object-cover"
            onError={() => {
              // Если изображение не загрузилось, показываем fallback
              console.log('Failed to load avatar image for user:', userName);
            }}
          />
        ) : null}
        <AvatarFallback
          className={cn(
            getRoleColor(role),
            "text-white font-semibold",
            fallbackTextSize,
            loading && "animate-pulse"
          )}
        >
          {loading ? '...' : firstLetter}
        </AvatarFallback>
      </Avatar>

      {showOnlineIndicator && (
        <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-background animate-pulse" />
      )}
    </div>
  );
};
