'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Trophy,
  DollarSign,
  Users,
  AlertTriangle,
  CheckCircle,
  X,
  Loader2,
  Home,
  Plane,
  Handshake
} from 'lucide-react';
import Image from 'next/image';
import { type AvailablePredictionsResponse, AvailablePrediction, type PredictionType, type Currency } from '@/types/bets';
import { useTelegram } from '@/components/providers/TelegramProvider';
import { JoinBetI18nProvider, useJoinBetI18n } from '@/components/providers/JoinBetI18nProvider';

interface JoinBetModalProps {
  isOpen: boolean;
  onClose: () => void;
  betId: number;
  onJoinSuccess: () => void;
}

function JoinBetModalContent({ isOpen, onClose, betId, onJoinSuccess }: JoinBetModalProps) {
  const { t } = useJoinBetI18n();
  const { user } = useTelegram();
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [data, setData] = useState<AvailablePredictionsResponse | null>(null);
  const [selectedPrediction, setSelectedPrediction] = useState<PredictionType | null>(null);
  const [error, setError] = useState<string>('');

  const loadAvailablePredictions = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const response = await fetch(`/api/bets/available-predictions?bet_id=${betId}`);
      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Failed to load bet data');
      }

      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load bet data');
    } finally {
      setLoading(false);
    }
  }, [betId]);

  // Загружаем данные при открытии модального окна
  useEffect(() => {
    if (isOpen && betId) {
      loadAvailablePredictions();
    }
  }, [isOpen, betId, loadAvailablePredictions]);

  const handleJoinBet = async () => {
    console.log('=== JOINING BET ===');
    if (!selectedPrediction || !data) {
      setError(t('error_pick_prediction'));
      return;
    }

    if (!user?.id) {
      setError(t('error_not_auth'));
      return;
    }

    // Используем фиксированную сумму, равную ставке создателя
    const amountNumber = data.bet.creator_amount;

    const requestData = {
      bet_id: betId,
      amount: amountNumber,
      prediction_type: selectedPrediction,
    };

    console.log('Request data:', requestData);
    console.log('User ID:', user.id);
    console.log('Headers will include:', { 'x-telegram-user-id': user.id.toString() });

    setSubmitting(true);
    setError('');

    try {
      const response = await fetch('/api/bets/join', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-telegram-user-id': user.id.toString(),
        },
        body: JSON.stringify(requestData),
      });

      const result = await response.json();
      console.log('API Response:', { status: response.status, result });

      if (!response.ok) {
        console.error('API Error:', result);
        const errorMessage = result.details || result.error || 'Failed to join bet';
        throw new Error(errorMessage);
      }

      console.log('✅ Successfully joined bet');
      onJoinSuccess();
      onClose();
    } catch (err) {
      console.error('❌ Error joining bet:', err);
      setError(err instanceof Error ? err.message : 'Failed to join bet');
    } finally {
      setSubmitting(false);
    }
  };

  const getPredictionIcon = (type: PredictionType) => {
    switch (type) {
      case 'home':
        return <Home className="h-6 w-6 text-blue-600" />;
      case 'draw':
        return <Handshake className="h-6 w-6 text-yellow-600" />;
      case 'away':
        return <Plane className="h-6 w-6 text-green-600" />;
      default:
        return <Trophy className="h-6 w-6 text-gray-600" />;
    }
  };

  const getCurrencyIcon = (currency: Currency, size: 'sm' | 'md' | 'lg' = 'md') => {
    const sizeClasses = {
      sm: 'w-4 h-4',
      md: 'w-6 h-6',
      lg: 'w-8 h-8'
    };

    if (currency === 'TON') {
      return <img src="/images/ton.png" alt="TON" className={`${sizeClasses[size]} inline-block`} />;
    }
    return <img src="/images/stars.png" alt="STARS" className={`${sizeClasses[size]} inline-block`} />;
  };

  const calculatePotentialWinnings = () => {
    if (!data) return 0;
    return Number(data.potential_winnings.net_winnings) + Number(data.bet.creator_amount);
  };

  if (loading) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
            <span className="ml-3 text-gray-600 dark:text-gray-400">{t('loading')}</span>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (error && !data) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <div className="text-center py-8">
            <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400 mb-4">{error}</p>
            <Button onClick={onClose} variant="outline">
              {t('close')}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg max-h-[85vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Trophy className="h-6 w-6 text-yellow-500" />
            {t('title')}
          </DialogTitle>
        </DialogHeader>

        {data && (
          <>
          <div className="max-h-[55vh] overflow-y-auto pr-2 space-y-6 scrollbar-thin scrollbar-track-gray-100 dark:scrollbar-track-gray-800 scrollbar-thumb-gray-300 dark:scrollbar-thumb-gray-600">
            <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 border-blue-200 dark:border-blue-700">
              <CardContent className="p-4">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-4 mb-4">
                    <div className="flex items-center space-x-3">
                      {data.bet.home_team_logo ? (
                        <div className="w-10 h-10 relative">
                          <Image
                            src={data.bet.home_team_logo}
                            alt={data.bet.home_team}
                            fill
                            className="object-contain rounded-full"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.style.display = 'none';
                              target.nextElementSibling?.classList.remove('hidden');
                            }}
                          />
                          <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm hidden">
                            {data.bet.home_team.charAt(0)}
                          </div>
                        </div>
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm">
                          {data.bet.home_team.charAt(0)}
                        </div>
                      )}
                      <span className="font-semibold text-gray-800 dark:text-gray-200">{data.bet.home_team}</span>
                    </div>

                    <span className="text-xl font-bold text-gray-500 dark:text-gray-400">VS</span>

                    <div className="flex items-center space-x-3">
                      <span className="font-semibold text-gray-800 dark:text-gray-200">{data.bet.away_team}</span>
                      {data.bet.away_team_logo ? (
                        <div className="w-10 h-10 relative">
                          <Image
                            src={data.bet.away_team_logo}
                            alt={data.bet.away_team}
                            fill
                            className="object-contain rounded-full"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.style.display = 'none';
                              target.nextElementSibling?.classList.remove('hidden');
                            }}
                          />
                          <div className="w-10 h-10 rounded-full bg-gradient-to-r from-orange-500 to-red-600 flex items-center justify-center text-white font-bold text-sm hidden">
                            {data.bet.away_team.charAt(0)}
                          </div>
                        </div>
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-gradient-to-r from-orange-500 to-red-600 flex items-center justify-center text-white font-bold text-sm">
                          {data.bet.away_team.charAt(0)}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-2 mt-2">
                    <Badge variant="outline" className="bg-white dark:bg-gray-800 dark:border-gray-600">
                      <div className="flex items-center gap-1">
                        {getCurrencyIcon(data.bet.currency, 'sm')} {data.bet.creator_amount} {data.bet.currency}
                      </div>
                    </Badge>
                    <span className="text-gray-500 dark:text-gray-400">•</span>
                    <Badge variant="outline" className="bg-white dark:bg-gray-800 dark:border-gray-600">
                      <Users className="h-4 w-4 mr-1" />
                      {`Bank: ${data.bet.total_bank} ${data.bet.currency}`}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div>
              <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-3 flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-500 dark:text-green-400" />
                {t('select_outcome')}
              </h4>

              <div className="space-y-2">
                {data.available_predictions.map((prediction) => (
                  <Card
                    key={prediction.type}
                    className={`cursor-pointer transition-all duration-200 ${
                      selectedPrediction === prediction.type
                        ? 'ring-2 ring-blue-500 bg-blue-50 dark:bg-blue-900/30 border-blue-300 dark:border-blue-600'
                        : 'hover:bg-gray-50 border-gray-200'
                    }`}
                    onClick={() => setSelectedPrediction(prediction.type)}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-center gap-3">
                        {getPredictionIcon(prediction.type)}
                        <div className="flex-1">
                          <p className="font-medium text-gray-800 dark:text-gray-200">{prediction.text}</p>
                        </div>
                        {selectedPrediction === prediction.type && (
                          <CheckCircle className="h-5 w-5 text-blue-500" />
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {data.available_predictions.length === 0 && (
                <Card className="bg-yellow-50 border-yellow-200">
                  <CardContent className="p-4 text-center">
                    <AlertTriangle className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
                    <p className="text-yellow-800">{t('outcomes_full')}</p>
                  </CardContent>
                </Card>
              )}
            </div>

            {data.available_predictions.length > 0 && (
              <div>
                <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-3 flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-green-500 dark:text-green-400" />
                  {t('stake_amount')}
                </h4>

                <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-center space-x-2">
                      <div className="flex items-center justify-center w-8 h-8">
                        {getCurrencyIcon(data.bet.currency, 'lg')}
                      </div>
                      <span className="text-3xl font-bold text-blue-800">
                        {data.bet.creator_amount}
                      </span>
                      <span className="text-xl font-medium text-blue-600">
                        {data.bet.currency}
                      </span>
                    </div>
                    <p className="text-center text-sm text-blue-600 mt-2">{t('fixed_amount_note')}</p>
                  </CardContent>
                </Card>
              </div>
            )}

            {selectedPrediction && (
              <Card className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-700">
                <CardContent className="p-4">
                  <h4 className="font-semibold text-green-800 dark:text-green-300 mb-3 flex items-center gap-2">
                    <Trophy className="h-5 w-5 text-green-600 dark:text-green-400" />
                    {t('potential_win')}
                  </h4>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">{t('total_bank_after')}</span>
                      <span className="font-medium">
                        {(Number(data.bet.total_bank) + Number(data.bet.creator_amount)).toFixed(2)} {data.bet.currency}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">{t('fee_10')}</span>
                      <span className="font-medium text-red-600">
                        -{((Number(data.bet.total_bank) + Number(data.bet.creator_amount)) * 0.1).toFixed(2)} {data.bet.currency}
                      </span>
                    </div>
                    <Separator />
                    <div className="flex justify-between text-lg">
                      <span className="font-semibold text-green-800 dark:text-green-300">{t('your_win_if')}</span>
                      <span className="font-bold text-green-700 dark:text-green-300">
                        {calculatePotentialWinnings().toFixed(2)} {data.bet.currency}
                      </span>
                    </div>
                  </div>

                  <div className="mt-3 p-2 bg-green-100 dark:bg-green-900/30 rounded text-xs text-green-700 dark:text-green-300 font-medium">
                    💡 {t('tip_net')}
                  </div>
                </CardContent>
              </Card>
            )}

            {error && (
              <Card className="bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-700">
                <CardContent className="p-3">
                  <div className="flex items-center gap-2 text-red-700 dark:text-red-400">
                    <X className="h-5 w-5" />
                    <span>{error}</span>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

            <div className="flex gap-3 pt-4 mt-4 border-t border-gray-200 dark:border-gray-700">
              <Button
                variant="outline"
                onClick={onClose}
                className="flex-1"
                disabled={submitting}
              >
                {t('cancel')}
              </Button>

              {data.available_predictions.length > 0 && (
                <Button
                  onClick={handleJoinBet}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  disabled={!selectedPrediction || submitting}
                >
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      {t('joining')}
                    </>
                  ) : (
                    <>
                      <Trophy className="h-4 w-4 mr-2" />
                      {t('place_bet')}
                    </>
                  )}
                </Button>
              )}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

export function JoinBetModal(props: JoinBetModalProps) {
  return (
    <JoinBetI18nProvider>
      <JoinBetModalContent {...props} />
    </JoinBetI18nProvider>
  );
}
