import { ProxyService } from './proxy-service';

export interface ProxyFetchOptions {
  method?: string;
  headers?: Record<string, string>;
  body?: string;
  timeout?: number;
  userId?: number;
  sessionId?: string;
}

export interface ProxyFetchResponse {
  success: boolean;
  data?: any;
  status?: number;
  error?: string;
  responseTime: number;
  proxyUsed?: {
    id: number;
    ip: string;
    port: number;
  };
}

/**
 * Выполняет HTTP запрос через прокси с автоматическим переключением при ошибках
 */
export async function proxyFetch(
  url: string,
  options: ProxyFetchOptions = {}
): Promise<ProxyFetchResponse> {
  const proxyService = ProxyService.getInstance();
  const startTime = Date.now();
  let lastError: string = '';
  let attempts = 0;
  const maxAttempts = 3;

  while (attempts < maxAttempts) {
    attempts++;

    try {
      // Получаем лучший рабочий прокси
      const proxyAgent = await proxyService.createProxyAgent();

      if (!proxyAgent) {
        return {
          success: false,
          error: 'Нет доступных рабочих прокси',
          responseTime: Date.now() - startTime
        };
      }

      const bestProxy = await proxyService.getBestWorkingProxy();

      if (!bestProxy) {
        return {
          success: false,
          error: 'Не удалось получить информацию о прокси',
          responseTime: Date.now() - startTime
        };
      }

      // Выполняем запрос через прокси
      const requestStartTime = Date.now();
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), options.timeout || 30000);

      const response = await fetch(url, {
        method: options.method || 'GET',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          ...options.headers
        },
        body: options.body,
        // @ts-ignore - HttpsProxyAgent works with fetch
        agent: proxyAgent,
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      const responseTime = Date.now() - requestStartTime;
      const totalTime = Date.now() - startTime;

      // Логируем использование прокси
      if (options.userId && options.sessionId) {
        await proxyService.logProxyUsage(
          bestProxy.id,
          options.userId,
          options.sessionId,
          url,
          responseTime,
          response.status,
          response.ok
        );
      }

      if (response.ok) {
        let data;
        const contentType = response.headers.get('content-type');

        try {
          if (contentType && contentType.includes('application/json')) {
            data = await response.json();
          } else {
            data = await response.text();
          }
        } catch (parseError) {
          data = null;
        }

        return {
          success: true,
          data,
          status: response.status,
          responseTime: totalTime,
          proxyUsed: {
            id: bestProxy.id,
            ip: bestProxy.ip,
            port: bestProxy.port
          }
        };
      } else {
        lastError = `HTTP ${response.status}: ${response.statusText}`;

        // Логируем неудачное использование
        if (options.userId && options.sessionId) {
          await proxyService.logProxyUsage(
            bestProxy.id,
            options.userId,
            options.sessionId,
            url,
            responseTime,
            response.status,
            false,
            lastError
          );
        }
      }

    } catch (error) {
      lastError = error instanceof Error ? error.message : 'Unknown error';
      console.error(`Ошибка запроса через прокси (попытка ${attempts}):`, lastError);
    }

    // Небольшая задержка перед следующей попыткой
    if (attempts < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }

  return {
    success: false,
    error: `Не удалось выполнить запрос после ${maxAttempts} попыток. Последняя ошибка: ${lastError}`,
    responseTime: Date.now() - startTime
  };
}

/**
 * Специальная функция для запросов к OpenAI API
 */
export async function proxyFetchOpenAI(
  endpoint: string,
  body: any,
  apiKey: string,
  options: Omit<ProxyFetchOptions, 'method' | 'headers' | 'body'> = {}
): Promise<ProxyFetchResponse> {
  return proxyFetch(`https://api.openai.com${endpoint}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
    ...options
  });
}

/**
 * Функция для проверки доступности OpenAI API через прокси
 */
export async function checkOpenAIAccess(): Promise<{
  success: boolean;
  error?: string;
  responseTime: number;
  proxyUsed?: { id: number; ip: string; port: number };
}> {
  try {
    const result = await proxyFetch('https://api.openai.com/v1/models', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY || 'test-key'}`,
      },
      timeout: 10000
    });

    return {
      success: result.success,
      error: result.error,
      responseTime: result.responseTime,
      proxyUsed: result.proxyUsed
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      responseTime: 0
    };
  }
}
