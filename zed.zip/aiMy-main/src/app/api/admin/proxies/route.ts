import { NextRequest, NextResponse } from 'next/server';
import { ProxyService } from '@/lib/proxy-service';

const proxyService = ProxyService.getInstance();

// GET - получить список прокси
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') || undefined;
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    const result = await proxyService.getAllProxies(status, limit, offset);

    return NextResponse.json({
      success: true,
      data: result
    });
  } catch (error) {
    console.error('Ошибка получения прокси:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка получения списка прокси' },
      { status: 500 }
    );
  }
}

// POST - добавить прокси пачкой
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { proxiesText } = body;

    if (!proxiesText || typeof proxiesText !== 'string') {
      return NextResponse.json(
        { success: false, error: 'Не указан текст с прокси' },
        { status: 400 }
      );
    }

    const result = await proxyService.addProxiesBatch(proxiesText);

    return NextResponse.json({
      success: true,
      message: `Добавлено прокси: ${result.added}`,
      data: result
    });
  } catch (error) {
    console.error('Ошибка добавления прокси:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка добавления прокси' },
      { status: 500 }
    );
  }
}

// PUT - обновить статус прокси
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { proxyId, status } = body;

    if (!proxyId || !status) {
      return NextResponse.json(
        { success: false, error: 'Не указан ID прокси или статус' },
        { status: 400 }
      );
    }

    const result = await proxyService.updateProxyStatus(proxyId, status);

    if (result) {
      return NextResponse.json({
        success: true,
        message: 'Статус прокси обновлен'
      });
    } else {
      return NextResponse.json(
        { success: false, error: 'Прокси не найден' },
        { status: 404 }
      );
    }
  } catch (error) {
    console.error('Ошибка обновления статуса прокси:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка обновления статуса прокси' },
      { status: 500 }
    );
  }
}

// DELETE - удалить прокси
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const proxyId = searchParams.get('id');

    if (!proxyId) {
      return NextResponse.json(
        { success: false, error: 'Не указан ID прокси' },
        { status: 400 }
      );
    }

    const result = await proxyService.deleteProxy(parseInt(proxyId));

    if (result) {
      return NextResponse.json({
        success: true,
        message: 'Прокси удален'
      });
    } else {
      return NextResponse.json(
        { success: false, error: 'Прокси не найден' },
        { status: 404 }
      );
    }
  } catch (error) {
    console.error('Ошибка удаления прокси:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка удаления прокси' },
      { status: 500 }
    );
  }
}
