import { NextResponse, NextRequest } from 'next/server';
import { createDbConnection } from '@/lib/database';

// Получить историю сообщений пользователя
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const userIdParam = searchParams.get('user_id');
  const limit = parseInt(searchParams.get('limit') || '6');

  if (!userIdParam) {
    return NextResponse.json({ error: 'user_id обязателен' }, { status: 400 });
  }

  const userId = parseInt(userIdParam);
  const client = createDbConnection();

  try {
    await client.connect();

    // Получаем последние сообщения пользователя
    const result = await client.query(`
      SELECT role, content, msg_timestamp
      FROM get_user_conversation_context($1, $2)
      ORDER BY msg_timestamp ASC
    `, [userId, limit]);

    return NextResponse.json({
      success: true,
      messages: result.rows
    });

  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      { error: 'Ошибка получения истории' },
      { status: 500 }
    );
  } finally {
    await client.end();
  }
}

// Сохранить новое сообщение (без обработки через OpenAI)
export async function POST(request: NextRequest) {
  try {
    const { user_id, session_id, message_type, content, audio_duration_seconds } = await request.json();

    if (!user_id || !message_type || !content) {
      return NextResponse.json(
        { error: 'user_id, message_type и content обязательны' },
        { status: 400 }
      );
    }

    const client = createDbConnection();
    await client.connect();

    // Простое сохранение сообщения в базу данных
    const result = await client.query(`
      INSERT INTO conversation_messages (user_id, session_id, message_type, content, audio_duration_seconds)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING id, created_at
    `, [user_id, session_id, message_type, content, audio_duration_seconds || 0]);

    await client.end();

    return NextResponse.json({
      success: true,
      message_id: result.rows[0].id,
      created_at: result.rows[0].created_at
    });

  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      { error: 'Ошибка обработки сообщения' },
      { status: 500 }
    );
  }
}
