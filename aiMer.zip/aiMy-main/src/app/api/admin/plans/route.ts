import { NextRequest, NextResponse } from 'next/server';
import { createDbConnection } from '@/lib/database';

// GET - получить все планы для админки
export async function GET() {
  const client = createDbConnection();

  try {
    await client.connect();

    const result = await client.query(`
      SELECT id, name, description, price, currency, token_amount, features, is_active, created_at
      FROM subscription_plans
      ORDER BY id ASC
    `);

    return NextResponse.json({
      success: true,
      plans: result.rows
    });

  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  } finally {
    await client.end();
  }
}

// POST - создать новый план
export async function POST(request: NextRequest) {
  const client = createDbConnection();

  try {
    const body = await request.json();
    const { name, description, price, currency, token_amount, features, is_active } = body;

    // Валидация
    if (!name || price === undefined || !token_amount) {
      return NextResponse.json(
        { error: 'Обязательные поля: name, price, token_amount' },
        { status: 400 }
      );
    }

    await client.connect();

    const result = await client.query(`
      INSERT INTO subscription_plans (name, description, price, currency, token_amount, features, is_active)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *
    `, [
      name,
      description || null,
      price,
      currency || 'USD',
      token_amount,
      JSON.stringify(features || []),
      is_active !== undefined ? is_active : true
    ]);

    return NextResponse.json({
      success: true,
      plan: result.rows[0]
    });

  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  } finally {
    await client.end();
  }
}

// PUT - обновить план
export async function PUT(request: NextRequest) {
  const client = createDbConnection();

  try {
    const body = await request.json();
    const { id, name, description, price, currency, token_amount, features, is_active } = body;

    if (!id) {
      return NextResponse.json(
        { error: 'ID плана обязателен' },
        { status: 400 }
      );
    }

    await client.connect();

    const result = await client.query(`
      UPDATE subscription_plans
      SET name = $1, description = $2, price = $3, currency = $4,
          token_amount = $5, features = $6, is_active = $7
      WHERE id = $8
      RETURNING *
    `, [
      name,
      description,
      price,
      currency,
      token_amount,
      JSON.stringify(features || []),
      is_active,
      id
    ]);

    if (result.rows.length === 0) {
      return NextResponse.json(
        { error: 'План не найден' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      plan: result.rows[0]
    });

  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  } finally {
    await client.end();
  }
}

// DELETE - удалить план
export async function DELETE(request: NextRequest) {
  const client = createDbConnection();

  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { error: 'ID плана обязателен' },
        { status: 400 }
      );
    }

    await client.connect();

    const result = await client.query(`
      DELETE FROM subscription_plans
      WHERE id = $1
      RETURNING *
    `, [id]);

    if (result.rows.length === 0) {
      return NextResponse.json(
        { error: 'План не найден' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'План успешно удален'
    });

  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  } finally {
    await client.end();
  }
}
