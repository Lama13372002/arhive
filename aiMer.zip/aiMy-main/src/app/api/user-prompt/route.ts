import { NextResponse, NextRequest } from 'next/server';
import { createDbConnection } from '@/lib/database';

// POST - выбрать промпт
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { user_id, prompt_id } = body;

    if (!user_id || !prompt_id) {
      return NextResponse.json(
        { error: 'user_id и prompt_id обязательны' },
        { status: 400 }
      );
    }

    const client = createDbConnection();

    try {
      await client.connect();

      // Проверяем, существует ли промпт и доступен ли он пользователю
      const promptResult = await client.query(`
        SELECT vp.*,
          CASE
            WHEN sp.name = 'Базовый' THEN 1
            WHEN sp.name = 'Премиум' THEN 2
            WHEN sp.name = 'Про' THEN 3
            ELSE 1
          END as user_plan_level
        FROM voice_prompts vp
        LEFT JOIN users u ON u.id = $1
        LEFT JOIN user_subscriptions us ON u.id = us.user_id AND us.status = 'active'
        LEFT JOIN subscription_plans sp ON us.plan_id = sp.id
        WHERE vp.id = $2
          AND vp.is_active = true
          AND (
            vp.user_id = $1 OR
            (vp.is_base = true AND (
              -- Для Про плана доступны ВСЕ базовые промпты
              COALESCE(sp.name, 'Бесплатный план') = 'Про' OR
              -- Для остальных планов - по уровню доступа
              vp.plan_required <= COALESCE(
                CASE
                  WHEN sp.name = 'Базовый' THEN 1
                  WHEN sp.name = 'Премиум' THEN 2
                  WHEN sp.name = 'Про' THEN 3
                  ELSE 1
                END, 1
              )
            ))
          )
      `, [user_id, prompt_id]);

      if (promptResult.rows.length === 0) {
        return NextResponse.json(
          { error: 'Промпт не найден или недоступен' },
          { status: 404 }
        );
      }

      // Обновляем выбранный промпт пользователя
      await client.query(`
        UPDATE users
        SET selected_prompt_id = $1, updated_at = CURRENT_TIMESTAMP
        WHERE id = $2
      `, [prompt_id, user_id]);

      await client.end();

      return NextResponse.json({
        success: true,
        message: 'Промпт успешно выбран'
      });

    } catch (dbError) {
      console.error('Database error:', dbError);
      return NextResponse.json(
        { error: 'Ошибка базы данных' },
        { status: 500 }
      );
    }

  } catch (error) {
    console.error('Error selecting prompt:', error);
    return NextResponse.json(
      { error: 'Ошибка выбора промпта' },
      { status: 500 }
    );
  }
}

// DELETE - удалить пользовательский промпт
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userIdParam = searchParams.get('user_id');
    const promptIdParam = searchParams.get('prompt_id');

    if (!userIdParam || !promptIdParam) {
      return NextResponse.json(
        { error: 'user_id и prompt_id обязательны' },
        { status: 400 }
      );
    }

    const userId = parseInt(userIdParam);
    const promptId = parseInt(promptIdParam);
    const client = createDbConnection();

    try {
      await client.connect();

      // Проверяем, принадлежит ли промпт пользователю и это не базовый промпт
      const promptResult = await client.query(`
        SELECT id, is_base
        FROM voice_prompts
        WHERE id = $1 AND user_id = $2 AND is_base = false
      `, [promptId, userId]);

      if (promptResult.rows.length === 0) {
        return NextResponse.json(
          { error: 'Промпт не найден или не может быть удален' },
          { status: 404 }
        );
      }

      // Проверяем, не выбран ли этот промпт пользователем
      const userResult = await client.query(`
        SELECT selected_prompt_id
        FROM users
        WHERE id = $1
      `, [userId]);

      const isSelected = userResult.rows[0]?.selected_prompt_id === promptId;

      // Если это выбранный промпт, сбрасываем выбор на дефолтный базовый промпт
      if (isSelected) {
        const defaultPromptResult = await client.query(`
          SELECT id
          FROM voice_prompts
          WHERE is_base = true AND plan_required = 1
          ORDER BY id ASC
          LIMIT 1
        `);

        const defaultPromptId = defaultPromptResult.rows[0]?.id;

        await client.query(`
          UPDATE users
          SET selected_prompt_id = $1, updated_at = CURRENT_TIMESTAMP
          WHERE id = $2
        `, [defaultPromptId, userId]);
      }

      // Помечаем промпт как неактивный (мягкое удаление)
      await client.query(`
        UPDATE voice_prompts
        SET is_active = false, updated_at = CURRENT_TIMESTAMP
        WHERE id = $1
      `, [promptId]);

      await client.end();

      return NextResponse.json({
        success: true,
        message: 'Промпт успешно удален',
        wasSelected: isSelected
      });

    } catch (dbError) {
      console.error('Database error:', dbError);
      return NextResponse.json(
        { error: 'Ошибка базы данных' },
        { status: 500 }
      );
    }

  } catch (error) {
    console.error('Error deleting prompt:', error);
    return NextResponse.json(
      { error: 'Ошибка удаления промпта' },
      { status: 500 }
    );
  }
}
