"use client";

import React, { useEffect } from "react";

export function GlobalErrorHandler() {
  useEffect(() => {
    // Обработчик для необработанных ошибок
    const handleError = (event: ErrorEvent) => {
      console.error('TMA: Unhandled error:', event.error);

      // Создаем элемент для показа ошибки
      const errorDiv = document.createElement('div');
      errorDiv.style.cssText = `
        position: fixed;
        top: 20px;
        left: 20px;
        right: 20px;
        background: #ff4444;
        color: white;
        padding: 15px;
        border-radius: 8px;
        z-index: 10000;
        font-family: monospace;
        font-size: 12px;
        max-height: 200px;
        overflow-y: auto;
        border: 2px solid #cc0000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      `;

      errorDiv.innerHTML = `
        <div style="font-weight: bold; margin-bottom: 10px;">❌ Ошибка приложения:</div>
        <div style="margin-bottom: 5px;"><strong>Сообщение:</strong> ${event.error?.message || 'Неизвестная ошибка'}</div>
        <div style="margin-bottom: 5px;"><strong>Файл:</strong> ${event.filename || 'Неизвестно'}</div>
        <div style="margin-bottom: 5px;"><strong>Строка:</strong> ${event.lineno || 'Неизвестно'}</div>
        <details style="margin-top: 10px;">
          <summary style="cursor: pointer;">Подробности (Stack trace)</summary>
          <div style="font-size: 10px; opacity: 0.8; margin-top: 5px; white-space: pre-wrap;">${event.error?.stack || 'Стек недоступен'}</div>
        </details>
        <button onclick="this.parentElement.remove()" style="
          position: absolute;
          top: 5px;
          right: 5px;
          background: none;
          border: none;
          color: white;
          cursor: pointer;
          font-size: 18px;
          width: 24px;
          height: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
        ">×</button>
      `;

      document.body.appendChild(errorDiv);

      // Автоудаление через 15 секунд
      setTimeout(() => {
        if (errorDiv.parentElement) {
          errorDiv.remove();
        }
      }, 15000);
    };

    // Обработчик для необработанных Promise rejection
    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      const reason = event.reason;
      const errorMessage = reason instanceof Error ? reason.message : String(reason);

      // Проверяем, является ли это ошибкой TON Connect при сворачивании приложения
      if (errorMessage.includes('Operation aborted') ||
          errorMessage.includes('TON_CONNECT_SDK_ERROR')) {
        console.warn('TON Connect operation aborted (app state change):', event.reason);
        event.preventDefault(); // Предотвращаем показ этой ошибки
        return;
      }

      console.error('TMA: Unhandled promise rejection:', event.reason);

      const errorDiv = document.createElement('div');
      errorDiv.style.cssText = `
        position: fixed;
        top: 20px;
        left: 20px;
        right: 20px;
        background: #ff6644;
        color: white;
        padding: 15px;
        border-radius: 8px;
        z-index: 10000;
        font-family: monospace;
        font-size: 12px;
        max-height: 200px;
        overflow-y: auto;
        border: 2px solid #cc2200;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      `;

      const errorStack = reason instanceof Error ? reason.stack : '';

      errorDiv.innerHTML = `
        <div style="font-weight: bold; margin-bottom: 10px;">⚠️ Promise rejection:</div>
        <div style="margin-bottom: 5px;"><strong>Причина:</strong> ${errorMessage}</div>
        <details style="margin-top: 10px;">
          <summary style="cursor: pointer;">Подробности (Stack trace)</summary>
          <div style="font-size: 10px; opacity: 0.8; margin-top: 5px; white-space: pre-wrap;">${errorStack || 'Стек недоступен'}</div>
        </details>
        <button onclick="this.parentElement.remove()" style="
          position: absolute;
          top: 5px;
          right: 5px;
          background: none;
          border: none;
          color: white;
          cursor: pointer;
          font-size: 18px;
          width: 24px;
          height: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
        ">×</button>
      `;

      document.body.appendChild(errorDiv);

      setTimeout(() => {
        if (errorDiv.parentElement) {
          errorDiv.remove();
        }
      }, 15000);
    };

    // Обработчик для ошибок React Error Boundary (если нужно)
    const handleReactError = (error: Error, errorInfo: React.ErrorInfo) => {
      console.error('TMA: React error:', error, errorInfo);

      const errorDiv = document.createElement('div');
      errorDiv.style.cssText = `
        position: fixed;
        top: 20px;
        left: 20px;
        right: 20px;
        background: #cc4444;
        color: white;
        padding: 15px;
        border-radius: 8px;
        z-index: 10000;
        font-family: monospace;
        font-size: 12px;
        max-height: 200px;
        overflow-y: auto;
        border: 2px solid #aa0000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      `;

      errorDiv.innerHTML = `
        <div style="font-weight: bold; margin-bottom: 10px;">🔥 React ошибка:</div>
        <div style="margin-bottom: 5px;"><strong>Сообщение:</strong> ${error.message}</div>
        <details style="margin-top: 10px;">
          <summary style="cursor: pointer;">Подробности</summary>
          <div style="font-size: 10px; opacity: 0.8; margin-top: 5px; white-space: pre-wrap;">${error.stack || 'Стек недоступен'}</div>
        </details>
        <button onclick="this.parentElement.remove()" style="
          position: absolute;
          top: 5px;
          right: 5px;
          background: none;
          border: none;
          color: white;
          cursor: pointer;
          font-size: 18px;
          width: 24px;
          height: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
        ">×</button>
      `;

      document.body.appendChild(errorDiv);

      setTimeout(() => {
        if (errorDiv.parentElement) {
          errorDiv.remove();
        }
      }, 15000);
    };

    window.addEventListener('error', handleError);
    window.addEventListener('unhandledrejection', handleUnhandledRejection);

    return () => {
      window.removeEventListener('error', handleError);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
    };
  }, []);

  return null;
}
