"use client";
import React, { createContext, useCallback, useContext, useMemo } from "react";
import { useI18n } from "./I18nProvider";

type Dict = Record<string, string>;

const ru: Dict = {
  title: "Присоединиться к спору",
  loading: "Загрузка данных спора...",
  close: "Закрыть",
  select_outcome: "Выберите исход для ставки:",
  outcomes_full: "Все исходы уже заняты. Нельзя присоединиться к этому спору.",
  stake_amount: "Сумма ставки:",
  fixed_amount_note: "Фиксированная сумма (как у создателя)",
  potential_win: "Потенциальный выигрыш:",
  total_bank_after: "Общий банк после вашей ставки:",
  fee_10: "Комиссия (10%):",
  your_win_if: "Ваш выигрыш при победе:",
  tip_net: "Если ваш исход выиграет, вы получите весь банк за вычетом 10% комиссии",
  error_pick_prediction: "Пожалуйста, выберите прогноз",
  error_not_auth: "Пользователь не авторизован",
  cancel: "Отмена",
  joining: "Присоединяюсь...",
  place_bet: "Сделать ставку",
};

const en: Dict = {
  title: "Join bet",
  loading: "Loading bet data...",
  close: "Close",
  select_outcome: "Choose an outcome:",
  outcomes_full: "All outcomes are already taken. You cannot join this bet.",
  stake_amount: "Stake amount:",
  fixed_amount_note: "Fixed amount (same as creator)",
  potential_win: "Potential winnings:",
  total_bank_after: "Total bank after your stake:",
  fee_10: "Fee (10%):",
  your_win_if: "Your win if you succeed:",
  tip_net: "If your outcome wins, you receive the bank minus 10% fee",
  error_pick_prediction: "Please choose a prediction",
  error_not_auth: "User is not authorized",
  cancel: "Cancel",
  joining: "Joining...",
  place_bet: "Place bet",
};

const dicts = { ru, en };

type Ctx = { t: (key: string, params?: Record<string, string | number>) => string };
const Ctx = createContext<Ctx | undefined>(undefined);

export const JoinBetI18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useI18n();
  const t = useCallback((key: string, params?: Record<string, string | number>) => {
    const dict = dicts[lang] || en;
    let text = dict[key] ?? key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
      });
    }
    return text;
  }, [lang]);
  const value = useMemo(() => ({ t }), [t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export const useJoinBetI18n = () => {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useJoinBetI18n must be used within JoinBetI18nProvider");
  return ctx;
};
