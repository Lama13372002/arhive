import { NextResponse, NextRequest } from 'next/server';
import { proxyFetch } from '@/lib/proxy-fetch';

export async function POST(request: NextRequest) {
  try {
    const apiKey = process.env.OPENAI_API_KEY;

    if (!apiKey) {
      return NextResponse.json(
        { error: 'OpenAI API key не настроен' },
        { status: 500 }
      );
    }

    // Получаем SDP offer от клиента
    const body = await request.text();

    // Получаем параметры из URL
    const { searchParams } = new URL(request.url);
    const model = searchParams.get('model') || 'gpt-realtime';

    console.log(`🎙️ Проксируем WebRTC соединение для модели: ${model}`);

    // Проксируем запрос к OpenAI через наш прокси
    const result = await proxyFetch(`https://api.openai.com/v1/realtime/calls?model=${encodeURIComponent(model)}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/sdp',
      },
      body: body,
      timeout: 30000
    });

    if (!result.success) {
      console.error('OpenAI Realtime API error via proxy:', result.error);
      return NextResponse.json(
        { error: `Ошибка запроса через прокси: ${result.error}` },
        { status: 500 }
      );
    }

    console.log(`✅ Успешно установлено WebRTC соединение через прокси: ${result.proxyUsed?.ip}:${result.proxyUsed?.port} (${result.responseTime}ms)`);

    // Возвращаем SDP answer
    return new NextResponse(result.data as string, {
      status: 200,
      headers: {
        'Content-Type': 'application/sdp',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization'
      }
    });

  } catch (error) {
    console.error("Ошибка при проксировании WebRTC соединения:", error);
    return NextResponse.json(
      { error: "Не удалось установить WebRTC соединение" },
      { status: 500 }
    );
  }
}

// Обработка preflight запросов
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    }
  });
}
