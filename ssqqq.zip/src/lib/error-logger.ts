export interface ErrorLog {
  id: string;
  timestamp: string;
  endpoint: string;
  error_message: string;
  error_stack: string;
  user_id?: string;
  request_params?: Record<string, unknown>;
  request_headers?: Record<string, string>;
}

let errorLogs: ErrorLog[] = [];

export function addErrorLog(
  error: unknown,
  endpoint: string,
  userId?: string,
  requestParams?: Record<string, unknown>,
  requestHeaders?: Record<string, string>
) {
  const log: ErrorLog = {
    id: Date.now().toString(),
    timestamp: new Date().toISOString(),
    endpoint,
    error_message: error instanceof Error ? error.message : String(error),
    error_stack: error instanceof Error ? error.stack || '' : '',
    user_id: userId,
    request_params: requestParams,
    request_headers: requestHeaders
  };

  errorLogs.unshift(log);

  if (errorLogs.length > 100) {
    errorLogs = errorLogs.slice(0, 100);
  }

  console.error('🚨 Error logged:', log);
}

export function getErrorLogs(endpoint?: string, limit = 50) {
  let filteredLogs = errorLogs;

  if (endpoint) {
    filteredLogs = errorLogs.filter(log => log.endpoint.includes(endpoint));
  }

  const results = filteredLogs.slice(0, limit);

  return {
    logs: results,
    total: filteredLogs.length,
    endpoints: [...new Set(errorLogs.map(log => log.endpoint))]
  };
}

export function clearErrorLogs() {
  errorLogs = [];
}
