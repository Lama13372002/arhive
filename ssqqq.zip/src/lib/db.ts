// Реэкспорт функции query из database.ts для совместимости
export { query } from './database';
