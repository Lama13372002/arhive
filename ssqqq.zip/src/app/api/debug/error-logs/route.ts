import { type NextRequest, NextResponse } from 'next/server';
import { getErrorLogs, clearErrorLogs } from '@/lib/error-logger';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const endpoint = searchParams.get('endpoint');
    const limit = Number.parseInt(searchParams.get('limit') || '50');

    const result = getErrorLogs(endpoint || undefined, limit);

    return NextResponse.json({
      success: true,
      ...result
    });

  } catch (error) {
    console.error('Error fetching error logs:', error);
    return NextResponse.json(
      { error: 'Failed to fetch error logs', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}

// Метод для очистки логов
export async function DELETE() {
  try {
    clearErrorLogs();
    return NextResponse.json({ success: true, message: 'Error logs cleared' });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to clear logs' },
      { status: 500 }
    );
  }
}
