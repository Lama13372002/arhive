import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';
import { footballService } from '@/lib/football-service';
import { addErrorLog } from '@/lib/error-logger';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);

    // Получаем пользователя из заголовков
    const telegramId = request.headers.get('x-telegram-user-id');


    if (!telegramId) {

      return NextResponse.json(
        { error: 'User not authenticated' },
        { status: 401 }
      );
    }

    // Параметры фильтрации
    const status = searchParams.get('status') || 'all';
    const type = searchParams.get('type') || 'all'; // 'created', 'joined', 'all'
    const limit = Number.parseInt(searchParams.get('limit') || '20');
    const offset = Number.parseInt(searchParams.get('offset') || '0');

    // Получаем пользователя
    const userResult = await pool.query(
      'SELECT id FROM users WHERE telegram_id = $1',
      [telegramId]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = userResult.rows[0].id;

    const whereConditions: string[] = [];
    const queryParams: unknown[] = [];
    let paramIndex = 1;

    // Фильтр по типу участия
    if (type === 'created') {
      whereConditions.push(`b.creator_id = $${paramIndex}`);
      queryParams.push(userId);
      paramIndex++;
    } else if (type === 'joined') {
      whereConditions.push(`bp.user_id = $${paramIndex} AND b.creator_id != $${paramIndex + 1}`);
      queryParams.push(userId, userId);
      paramIndex += 2;
    } else {
      // Все споры пользователя (созданные или в которых участвует)
      whereConditions.push(`(b.creator_id = $${paramIndex} OR bp.user_id = $${paramIndex + 1})`);
      queryParams.push(userId, userId);
      paramIndex += 2;
    }

    // Фильтр по статусу
    if (status !== 'all' && ['open', 'closed', 'completed', 'cancelled', 'refunded'].includes(status)) {
      whereConditions.push(`b.status = $${paramIndex}`);
      queryParams.push(status);
      paramIndex++;
    }

    const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : '';

    // Основной запрос - используем LEFT JOIN для bet_participants чтобы получить все споры
    const query = `
      SELECT DISTINCT
        b.*,
        creator.username as creator_username,
        creator.first_name as creator_first_name,
        creator.last_name as creator_last_name,
        m.home_team,
        m.away_team,
        m.home_team_logo,
        m.away_team_logo,
        m.league,
        m.league_logo,
        m.start_time as match_start_time,
        m.venue,
        m.status as match_status,
        m.home_score,
        m.away_score,
        (SELECT COUNT(*) FROM bet_participants WHERE bet_id = b.id) as participants_count,
        bp.amount as user_bet_amount,
        bp.position as user_position,
        bp.joined_at as user_joined_at,
        CASE
          WHEN b.creator_id = $${paramIndex} THEN 'creator'
          WHEN bp.user_id = $${paramIndex + 1} THEN 'participant'
          ELSE 'none'
        END as user_role,
        CASE
          WHEN b.expires_at IS NOT NULL THEN
            EXTRACT(EPOCH FROM (b.expires_at - NOW()))
          ELSE
            EXTRACT(EPOCH FROM (m.start_time - NOW() - INTERVAL '15 minutes'))
        END as seconds_left
      FROM bets b
      JOIN users creator ON b.creator_id = creator.id
      JOIN matches m ON b.match_id = m.id
      LEFT JOIN bet_participants bp ON b.id = bp.bet_id AND bp.user_id = $${paramIndex + 2}
      ${whereClause}
      ORDER BY b.created_at DESC
      LIMIT $${paramIndex + 3} OFFSET $${paramIndex + 4}
    `;

    queryParams.push(userId, userId, userId, limit, offset);

    console.log('🔍 Executing query:', query);
    console.log('🔍 Query params:', queryParams);

    const result = await pool.query(query, queryParams);

    // Получаем актуальные данные матчей из внешнего API
    const today = new Date().toISOString().split('T')[0];
    let liveMatches: Array<{
      homeTeam: string;
      awayTeam: string;
      homeTeamLogo?: string;
      awayTeamLogo?: string;
      status: string;
      startTime?: string;
      minute?: number;
    }> = [];
    let todayMatches: Array<{
      homeTeam: string;
      awayTeam: string;
      homeTeamLogo?: string;
      awayTeamLogo?: string;
      status: string;
      startTime?: string;
      minute?: number;
    }> = [];

    try {
      // Получаем актуальные матчи с логотипами
      liveMatches = await footballService.getLiveMatches();
      todayMatches = await footballService.getTodayMatches();
    } catch (error) {
      console.error('Failed to fetch live match data:', error);
    }

    // Объединяем live и today матчи для поиска актуальных данных
    const allCurrentMatches = [...liveMatches, ...todayMatches];

    // Получаем участников для каждого спора
    const betsWithDetails = await Promise.all(
      result.rows.map(async (bet) => {
        // Получаем всех участников спора
        const participantsResult = await pool.query(`
          SELECT
            bp.*,
            u.username,
            u.first_name,
            u.last_name
          FROM bet_participants bp
          JOIN users u ON bp.user_id = u.id
          WHERE bp.bet_id = $1
          ORDER BY bp.joined_at ASC
        `, [bet.id]);

        // Вычисляем время до истечения
        let timeLeft = '';
        if (bet.seconds_left > 0) {
          const hours = Math.floor(bet.seconds_left / 3600);
          const minutes = Math.floor((bet.seconds_left % 3600) / 60);
          if (hours > 0) {
            timeLeft = `${hours}ч ${minutes}м`;
          } else {
            timeLeft = `${minutes}м`;
          }
        } else {
          timeLeft = 'Истекло';
        }

        // Ищем актуальные данные матча из внешнего API
        const currentMatch = allCurrentMatches.find(match =>
          (match.homeTeam.toLowerCase().includes(bet.home_team.toLowerCase()) ||
           bet.home_team.toLowerCase().includes(match.homeTeam.toLowerCase())) &&
          (match.awayTeam.toLowerCase().includes(bet.away_team.toLowerCase()) ||
           bet.away_team.toLowerCase().includes(match.awayTeam.toLowerCase()))
        );

        // Получаем логотипы команд из API или используем fallback из БД
        let homeTeamLogo = bet.home_team_logo || '';
        let awayTeamLogo = bet.away_team_logo || '';

        if (currentMatch) {
          homeTeamLogo = currentMatch.homeTeamLogo || bet.home_team_logo || '';
          awayTeamLogo = currentMatch.awayTeamLogo || bet.away_team_logo || '';
        }

        // Используем данные из БД как приоритетные, особенно для завершенных матчей
        let matchStatus = bet.match_status;
        let matchStartTime = bet.match_start_time;
        let matchMinute = null;

        // Обновляем данными из внешнего API только если матч ещё не завершен в БД
        if (currentMatch && bet.match_status !== 'finished') {
          matchStatus = currentMatch.status;
          matchStartTime = currentMatch.startTime ?
            new Date(`${today}T${currentMatch.startTime}:00.000Z`).toISOString() :
            bet.match_start_time;
          matchMinute = currentMatch.minute;
        }

        // Вычисляем потенциальный выигрыш
        const totalPool = Number.parseFloat(bet.amount) + participantsResult.rows.reduce((sum, p) => sum + Number.parseFloat(p.amount), 0);
        const potentialWinnings = totalPool * Number.parseFloat(bet.odds);

        // Определяем персональный прогноз пользователя в зависимости от его роли
        let userPrediction = bet.prediction_type; // По умолчанию используем прогноз создателя

        if (bet.user_role === 'participant') {
          // Если пользователь - участник, определяем его прогноз
          const userParticipant = participantsResult.rows.find(p => p.user_id === userId);
          if (userParticipant) {
            if (userParticipant.prediction_type) {
              // Новая логика: используем prediction_type если есть
              userPrediction = userParticipant.prediction_type;
            } else if (userParticipant.position) {
              // Старая логика: конвертируем position в prediction_type
              if (userParticipant.position === 'for') {
                userPrediction = bet.prediction_type;
              } else { // position === 'against'
                // Для against выбираем любой другой исход кроме основного
                if (bet.prediction_type === 'home') userPrediction = 'away';
                else if (bet.prediction_type === 'away') userPrediction = 'home';
                else userPrediction = 'home'; // если создатель поставил на draw, участник ставит на home
              }
            }
          }
        }
        // Если пользователь - создатель, используем prediction_type из основной ставки

        // Определяем статус для пользователя
        let userStatus = 'waiting';

        // Если спор помечен как completed в БД, проверяем результат
        if (bet.status === 'completed') {
          // Определяем результат матча
          if (bet.home_score !== null && bet.away_score !== null) {
            let matchResult = 'draw';
            if (bet.home_score > bet.away_score) {
              matchResult = 'home';
            } else if (bet.home_score < bet.away_score) {
              matchResult = 'away';
            }

            // Сравниваем результат с прогнозом
            userStatus = matchResult === userPrediction ? 'won' : 'lost';
          } else {
            userStatus = 'completed';
          }
        } else if (bet.status === 'refunded') {
          userStatus = 'refunded';
        } else if (bet.status === 'cancelled') {
          userStatus = 'cancelled';
        } else if (bet.status === 'closed') {
          userStatus = 'in_progress';
        }

        // Логируем для отладки
        console.log(`🔍 Bet ${bet.id}: status=${bet.status}, match_status=${matchStatus}, user_status=${userStatus}, home_score=${bet.home_score}, away_score=${bet.away_score}`);

        return {
          ...bet,
          // Добавляем логотипы команд в основной объект bet
          home_team_logo: homeTeamLogo,
          away_team_logo: awayTeamLogo,
          creator: {
            id: bet.creator_id,
            username: bet.creator_username,
            first_name: bet.creator_first_name,
            last_name: bet.creator_last_name
          },
          match: {
            id: bet.match_id,
            home_team: bet.home_team,
            away_team: bet.away_team,
            home_team_logo: homeTeamLogo,
            away_team_logo: awayTeamLogo,
            league: bet.league,
            league_logo: bet.league_logo,
            start_time: matchStartTime,
            venue: bet.venue,
            status: matchStatus,
            minute: matchMinute,
            home_score: bet.home_score,
            away_score: bet.away_score
          },
          participants: participantsResult.rows,
          time_left: timeLeft,
          potential_winnings: potentialWinnings,
          user_participation: bet.user_bet_amount ? {
            amount: Number.parseFloat(bet.user_bet_amount),
            position: bet.user_position,
            joined_at: bet.user_joined_at,
            role: bet.user_role
          } : null,
          user_status: userStatus,
          user_prediction: userPrediction,
          amount: Number.parseFloat(bet.amount),
          odds: Number.parseFloat(bet.odds)
        };
      })
    );

    // Получаем общее количество для пагинации
    // Создаем отдельные условия для count запроса
    const countWhereConditions: string[] = [];
    const countQueryParams: unknown[] = [];
    let countParamIndex = 1;

    // Добавляем userId в начало для LEFT JOIN
    countQueryParams.push(userId);
    countParamIndex++;

    // Фильтр по типу участия
    if (type === 'created') {
      countWhereConditions.push(`b.creator_id = $${countParamIndex}`);
      countQueryParams.push(userId);
      countParamIndex++;
    } else if (type === 'joined') {
      countWhereConditions.push(`bp.user_id = $${countParamIndex} AND b.creator_id != $${countParamIndex + 1}`);
      countQueryParams.push(userId, userId);
      countParamIndex += 2;
    } else {
      // Все споры пользователя (созданные или в которых участвует)
      countWhereConditions.push(`(b.creator_id = $${countParamIndex} OR bp.user_id = $${countParamIndex + 1})`);
      countQueryParams.push(userId, userId);
      countParamIndex += 2;
    }

    // Фильтр по статусу
    if (status !== 'all' && ['open', 'closed', 'completed', 'cancelled', 'refunded'].includes(status)) {
      countWhereConditions.push(`b.status = $${countParamIndex}`);
      countQueryParams.push(status);
      countParamIndex++;
    }

    const countWhereClause = countWhereConditions.length > 0 ? `WHERE ${countWhereConditions.join(' AND ')}` : '';

    // Упрощенный count запрос без дополнительных фильтров
    const simpleCountQuery = `
      SELECT COUNT(DISTINCT b.id) as total
      FROM bets b
      LEFT JOIN bet_participants bp ON b.id = bp.bet_id
      JOIN matches m ON b.match_id = m.id
      WHERE (b.creator_id = $1 OR bp.user_id = $1)
    `;


    const countResult = await pool.query(simpleCountQuery, [userId]);
    const total = Number.parseInt(countResult.rows[0].total);

    // Получаем статистику пользователя
    const statsResult = await pool.query(`
      SELECT
        COUNT(CASE WHEN b.creator_id = $1 THEN 1 END) as bets_created,
        COUNT(CASE WHEN bp.user_id = $1 AND b.creator_id != $1 THEN 1 END) as bets_joined,
        COUNT(CASE WHEN b.status = 'open' AND (b.creator_id = $1 OR bp.user_id = $1) THEN 1 END) as active_bets,
        COUNT(CASE WHEN b.status = 'completed' AND (b.creator_id = $1 OR bp.user_id = $1) THEN 1 END) as completed_bets,
        SUM(CASE WHEN b.creator_id = $1 AND b.currency = 'TON' THEN b.amount ELSE 0 END) as ton_created_volume,
        SUM(CASE WHEN b.creator_id = $1 AND b.currency = 'STARS' THEN b.amount ELSE 0 END) as stars_created_volume,
        SUM(CASE WHEN bp.user_id = $1 AND b.currency = 'TON' THEN bp.amount ELSE 0 END) as ton_joined_volume,
        SUM(CASE WHEN bp.user_id = $1 AND b.currency = 'STARS' THEN bp.amount ELSE 0 END) as stars_joined_volume
      FROM bets b
      LEFT JOIN bet_participants bp ON b.id = bp.bet_id
      WHERE b.creator_id = $1 OR bp.user_id = $1
    `, [userId]);

    const stats = statsResult.rows[0];

    return NextResponse.json({
      success: true,
      bets: betsWithDetails,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total
      },
      stats: {
        bets_created: Number.parseInt(stats.bets_created) || 0,
        bets_joined: Number.parseInt(stats.bets_joined) || 0,
        active_bets: Number.parseInt(stats.active_bets) || 0,
        completed_bets: Number.parseInt(stats.completed_bets) || 0,
        total_ton_volume: (Number.parseFloat(stats.ton_created_volume) || 0) + (Number.parseFloat(stats.ton_joined_volume) || 0),
        total_stars_volume: (Number.parseFloat(stats.stars_created_volume) || 0) + (Number.parseFloat(stats.stars_joined_volume) || 0)
      },
      filters: {
        status,
        type
      }
    });

  } catch (error) {
    console.error('Error fetching user bets:', error);

    // Логируем ошибку для просмотра в UI
    addErrorLog(
      error,
      '/api/bets/my',
      request.headers.get('x-telegram-user-id'),
      Object.fromEntries(new URL(request.url).searchParams),
      Object.fromEntries(request.headers.entries())
    );

    return NextResponse.json(
      { error: 'Internal server error', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
