import { type NextRequest, NextResponse } from 'next/server';
import pool, { query } from '@/lib/database';
import { type CreateBetRequest, Currency, PredictionType } from '@/types/bets';
import { notificationService } from '@/lib/notifications';

// Функция для получения актуальных минимальных сумм от админки
async function getMinimumAmounts(): Promise<{ TON: number; STARS: number }> {
  try {
    // Получаем минимальную сумму в USD из админки
    const usdResult = await query(
      `SELECT setting_value FROM app_settings WHERE setting_key = $1`,
      ['minimum_usd_amount']
    );

    const usdMin = usdResult.rows.length > 0 ? parseFloat(usdResult.rows[0].setting_value) : 10;

    // Получаем курс TON/STARS (используем тот же API что и frontend)
    const rateResponse = await fetch(process.env.NEXT_PUBLIC_BASE_URL ?
      `${process.env.NEXT_PUBLIC_BASE_URL}/api/ton-rate` :
      'https://api.coingecko.com/api/v3/simple/price?ids=the-open-network&vs_currencies=usd'
    );

    let tonToUsd = 5.1; // fallback
    let starsToUsd = 0.015; // fallback

    if (rateResponse.ok) {
      const rateData = await rateResponse.json();
      if (rateData.tonToUsd) {
        tonToUsd = rateData.tonToUsd;
        starsToUsd = rateData.starsToUsd || 0.015;
      } else if (rateData['the-open-network']?.usd) {
        tonToUsd = rateData['the-open-network'].usd;
      }
    }

    // Рассчитываем минималки
    const tonMin = Math.max(0, parseFloat((usdMin / tonToUsd).toFixed(3)));
    const starsMin = Math.ceil(usdMin / starsToUsd);

    return { TON: tonMin, STARS: starsMin };
  } catch (error) {
    console.error('Error getting minimum amounts:', error);
    // Возвращаем дефолтные значения если ошибка
    return { TON: 2, STARS: 400 };
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: CreateBetRequest = await request.json();

    // Получаем минимальные суммы из админки
    const minimums = await getMinimumAmounts();

    // Валидация данных
    const validation = validateCreateBetRequest(body, minimums);
    if (!validation.isValid) {
      return NextResponse.json(
        { error: 'Validation failed', details: validation.errors },
        { status: 400 }
      );
    }

    const {
      match_id,
      match_data,
      prediction_type,
      prediction_text,
      amount,
      currency,
      odds = 2.0,
      max_participants = 3, // Всегда 3: создатель + 2 участника
      comment
    } = body;

    // Получаем пользователя из заголовков (в реальном приложении из авторизации)
    const telegramId = request.headers.get('x-telegram-user-id');
    if (!telegramId) {
      return NextResponse.json(
        { error: 'User not authenticated' },
        { status: 401 }
      );
    }

    const client = await pool.connect();

    try {
      await client.query('BEGIN');

      // Получаем пользователя
      const userResult = await client.query(
        'SELECT id, ton_balance, stars_balance FROM users WHERE telegram_id = $1',
        [telegramId]
      );

      if (userResult.rows.length === 0) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'User not found' },
          { status: 404 }
        );
      }

      const user = userResult.rows[0];
      const userId = user.id;

      // Проверяем минимальные суммы перед созданием спора (динамически)
      const minAmount = currency === 'TON' ? minimums.TON : minimums.STARS;
      if (amount < minAmount) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: `Minimum amount for ${currency} is ${minAmount}` },
          { status: 400 }
        );
      }

      // Проверяем баланс
      const currentBalance = currency === 'TON' ? user.ton_balance : user.stars_balance;
      if (currentBalance < amount) {
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Insufficient balance' },
          { status: 400 }
        );
      }

      // Получаем или создаем матч в базе данных
      let matchResult = await client.query(
        'SELECT id, start_time, status FROM matches WHERE id = $1',
        [match_id]
      );

      // Если матч не найден в БД, создаем его
      if (matchResult.rows.length === 0) {
        // Получаем данные матча из body запроса
        const { match_data } = body;

        if (!match_data) {
          await client.query('ROLLBACK');
          return NextResponse.json(
            { error: 'Match not found and no match_data provided to create it' },
            { status: 404 }
          );
        }

        // Создаем новый матч в БД
        // Убеждаемся что время матча в правильном формате
        let matchStartTime: Date;
        try {
          // Если время уже в ISO формате, используем как есть
          if (typeof match_data.start_time === 'string' && match_data.start_time.includes('T')) {
            matchStartTime = new Date(match_data.start_time);
          } else {
            // Если время в другом формате, пробуем его распарсить
            matchStartTime = new Date(match_data.start_time);
          }

          // Проверяем валидность даты
          if (isNaN(matchStartTime.getTime())) {
            throw new Error('Invalid date format');
          }
        } catch (error) {
          console.error('Error parsing match start time:', error, match_data.start_time);
          await client.query('ROLLBACK');
          return NextResponse.json(
            { error: 'Invalid match start time format' },
            { status: 400 }
          );
        }

        console.log('Creating match with start_time:', matchStartTime.toISOString());

        const createMatchResult = await client.query(`
          INSERT INTO matches (
            id, home_team, away_team, home_team_logo, away_team_logo,
            league, league_logo, start_time, status, venue, api_fixture_id
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
          RETURNING id, start_time, status
        `, [
          match_id,
          match_data.home_team,
          match_data.away_team,
          match_data.home_team_logo || null,
          match_data.away_team_logo || null,
          match_data.league,
          match_data.league_logo || null,
          matchStartTime.toISOString(),
          'upcoming',
          match_data.venue || null,
          match_data.fixture_id || match_id // Добавляем api_fixture_id для API
        ]);

        matchResult = createMatchResult;
        console.log('✅ Created new match in database:', match_id);
      }

      const match = matchResult.rows[0];
      const matchStartTime = new Date(match.start_time);
      const now = new Date();

      // Добавляем буфер времени в 5 минут для возможных расхождений
      const timeBuffer = 5 * 60 * 1000; // 5 минут в миллисекундах
      const effectiveStartTime = new Date(matchStartTime.getTime() - timeBuffer);

      // Логируем для отладки
      console.log('Match start time:', matchStartTime.toISOString());
      console.log('Current time:', now.toISOString());
      console.log('Effective start time (with buffer):', effectiveStartTime.toISOString());
      console.log('Match status:', match.status);
      console.log('Time difference (minutes):', (matchStartTime.getTime() - now.getTime()) / (1000 * 60));

      // Проверяем статус матча и время с буфером
      if (match.status !== 'upcoming') {
        console.log('❌ Match status is not upcoming:', match.status);
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Cannot create bet for this match. Match is not upcoming.' },
          { status: 400 }
        );
      }

      if (effectiveStartTime <= now) {
        console.log('❌ Match has already started (with 5 min buffer)');
        await client.query('ROLLBACK');
        return NextResponse.json(
          { error: 'Cannot create bet for this match. Match has already started or is about to start.' },
          { status: 400 }
        );
      }

      // Устанавливаем время окончания приема ставок (за 15 минут до начала матча)
      const expiresAt = new Date(matchStartTime.getTime() - 15 * 60 * 1000);

      // Создаем спор
      const betResult = await client.query(`
        INSERT INTO bets (
          creator_id, match_id, prediction_type, prediction_text,
          amount, currency, odds, max_participants, comment, expires_at, status
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
        RETURNING *
      `, [
        userId, match_id, prediction_type, prediction_text,
        amount, currency, odds, max_participants, comment, expiresAt, 'open'
      ]);

      const bet = betResult.rows[0];

      // Списываем средства с баланса пользователя и записываем транзакцию
      if (currency === 'TON') {
        await client.query(
          'UPDATE users SET ton_balance = ton_balance - $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
          [amount, userId]
        );
      } else {
        await client.query(
          'UPDATE users SET stars_balance = stars_balance - $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
          [amount, userId]
        );
      }

      // Записываем транзакцию
      await client.query(`
        INSERT INTO transactions (user_id, bet_id, transaction_type, currency, amount, description)
        VALUES ($1, $2, 'bet_create', $3, $4, $5)
      `, [
        userId, bet.id, currency, -amount,
        `Created bet #${bet.id} for match: ${match_id}`
      ]);

      // Обрабатываем реферальные комиссии
      try {
        // Проверяем, является ли пользователь рефералом
        const referralCheckResult = await client.query(`
          SELECT
            r.id as referral_id,
            r.referrer_telegram_id,
            r.status,
            u.username as referrer_username,
            u.first_name as referrer_first_name
          FROM referrals r
          JOIN users u ON r.referrer_telegram_id = u.telegram_id
          WHERE r.referred_telegram_id = $1 AND r.status = 'active'
        `, [telegramId]);

        if (referralCheckResult.rows.length > 0) {
          const referral = referralCheckResult.rows[0];

          // Получаем настройки комиссии
          const settingsResult = await client.query(`
            SELECT setting_key, setting_value
            FROM referral_settings
            WHERE setting_key IN ('referral_commission_rate', 'referral_min_bet_amount')
          `);

          const settings: { [key: string]: number } = {};
          settingsResult.rows.forEach(row => {
            settings[row.setting_key] = parseFloat(row.setting_value);
          });

          const commissionRate = settings.referral_commission_rate || 0.05; // 5% по умолчанию
          const minBetAmount = settings.referral_min_bet_amount || 1.0;

          // Проверяем минимальную сумму ставки
          if (amount >= minBetAmount) {
            // Проверяем, что комиссия еще не была начислена за эту ставку
            const existingCommissionResult = await client.query(
              'SELECT id FROM referral_earnings WHERE bet_id = $1 AND referrer_telegram_id = $2',
              [bet.id, referral.referrer_telegram_id]
            );

            if (existingCommissionResult.rows.length === 0) {
              // Рассчитываем комиссию
              const commissionAmount = amount * commissionRate;

              // Записываем начисление комиссии
              await client.query(`
                INSERT INTO referral_earnings (
                  referral_id,
                  referrer_telegram_id,
                  referred_telegram_id,
                  bet_id,
                  earning_type,
                  base_amount,
                  commission_rate,
                  commission_amount,
                  currency,
                  description
                ) VALUES ($1, $2, $3, $4, 'bet_commission', $5, $6, $7, $8, $9)
              `, [
                referral.referral_id,
                referral.referrer_telegram_id,
                telegramId,
                bet.id,
                amount,
                commissionRate,
                commissionAmount,
                currency,
                `Комиссия с ставки реферала на сумму ${amount} ${currency}`
              ]);

              // Начисляем комиссию на баланс реферра
              const balanceColumn = currency === 'TON' ? 'ton_balance' : 'stars_balance';
              await client.query(
                `UPDATE users SET ${balanceColumn} = ${balanceColumn} + $1 WHERE telegram_id = $2`,
                [commissionAmount, referral.referrer_telegram_id]
              );

              // Записываем в историю баланса
              await client.query(`
                INSERT INTO balance_history (
                  telegram_id, type, amount, balance_type, description, bet_id
                ) VALUES ($1, 'referral', $2, $3, $4, $5)
              `, [
                referral.referrer_telegram_id,
                commissionAmount,
                currency.toLowerCase(),
                'Комиссия с ставки реферала',
                bet.id
              ]);

              // Проверяем, первая ли это ставка реферала
              const firstBetCheckResult = await client.query(
                'SELECT first_bet_amount FROM referrals WHERE id = $1',
                [referral.referral_id]
              );

              if (!firstBetCheckResult.rows[0].first_bet_amount) {
                // Обновляем информацию о первой ставке
                await client.query(
                  'UPDATE referrals SET first_bet_amount = $1, first_bet_date = CURRENT_TIMESTAMP, activated_at = CURRENT_TIMESTAMP WHERE id = $2',
                  [amount, referral.referral_id]
                );
              }

              // Обновляем статистику реферра
              await client.query('SELECT update_referral_stats($1)', [referral.referrer_telegram_id]);

              console.log(`✅ Referral commission processed: ${commissionAmount} ${currency} for bet #${bet.id}`);
            }
          }
        }
      } catch (referralError) {
        console.error('Error processing referral commission:', referralError);
        // Не прерываем создание ставки из-за ошибки реферальной системы
      }

      await client.query('COMMIT');

      // Получаем полную информацию о созданном споре
      const fullBetResult = await client.query(`
        SELECT
          b.*,
          u.username as creator_username,
          u.first_name as creator_first_name,
          m.home_team,
          m.away_team,
          m.league,
          m.start_time as match_start_time
        FROM bets b
        JOIN users u ON b.creator_id = u.id
        JOIN matches m ON b.match_id = m.id
        WHERE b.id = $1
      `, [bet.id]);

      const createdBet = fullBetResult.rows[0];

      // Отправляем уведомление о создании спора асинхронно
      setImmediate(async () => {
        try {
          const betMatchInfo = await notificationService.getBetMatchInfo(bet.id);
          if (betMatchInfo) {
            await notificationService.sendNotification({
              user_id: userId,
              telegram_id: Number(telegramId),
              type: 'bet_created',
              bet_id: bet.id,
              amount,
              currency,
              match_info: betMatchInfo.match,
              additional_info: { prediction: prediction_text }
            });
          }
        } catch (error) {
          console.error('Ошибка отправки уведомления о создании спора:', error);
        }
      });

      return NextResponse.json({
        success: true,
        bet: createdBet
      });

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }

  } catch (error) {
    console.error('Error creating bet:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

function validateCreateBetRequest(
  data: unknown,
  minimums: { TON: number; STARS: number }
): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Type guard для проверки что data - это объект
  if (!data || typeof data !== 'object') {
    errors.push('Request data must be an object');
    return { isValid: false, errors };
  }

  const requestData = data as Record<string, unknown>;

  if (!requestData.match_id || typeof requestData.match_id !== 'number') {
    errors.push('match_id is required and must be a number');
  }

  // Если есть match_data, валидируем его
  if (requestData.match_data) {
    const matchData = requestData.match_data as Record<string, unknown>;

    if (!matchData.home_team || typeof matchData.home_team !== 'string') {
      errors.push('match_data.home_team is required and must be a string');
    }

    if (!matchData.away_team || typeof matchData.away_team !== 'string') {
      errors.push('match_data.away_team is required and must be a string');
    }

    if (!matchData.league || typeof matchData.league !== 'string') {
      errors.push('match_data.league is required and must be a string');
    }

    if (!matchData.start_time || typeof matchData.start_time !== 'string') {
      errors.push('match_data.start_time is required and must be a string');
    }
  }

  if (!requestData.prediction_type || !['home', 'draw', 'away'].includes(requestData.prediction_type as string)) {
    errors.push('prediction_type must be one of: home, draw, away');
  }

  if (!requestData.prediction_text || typeof requestData.prediction_text !== 'string' || (requestData.prediction_text as string).trim().length === 0) {
    errors.push('prediction_text is required and must be a non-empty string');
  }

  if (!requestData.amount || typeof requestData.amount !== 'number' || (requestData.amount as number) <= 0) {
    errors.push('amount is required and must be a positive number');
  }

  if (!requestData.currency || !['TON', 'STARS'].includes(requestData.currency as string)) {
    errors.push('currency must be either TON or STARS');
  }

  // Проверяем минимальные суммы (динамически)
  if (requestData.currency === 'TON' && (requestData.amount as number) < minimums.TON) {
    errors.push(`Minimum amount for TON is ${minimums.TON}`);
  }

  if (requestData.currency === 'STARS' && (requestData.amount as number) < minimums.STARS) {
    errors.push(`Minimum amount for STARS is ${minimums.STARS}`);
  }

  if (requestData.odds && (typeof requestData.odds !== 'number' || (requestData.odds as number) <= 1)) {
    errors.push('odds must be a number greater than 1');
  }

  if (requestData.max_participants && (typeof requestData.max_participants !== 'number' || (requestData.max_participants as number) !== 3)) {
    errors.push('max_participants must be exactly 3');
  }

  if (requestData.comment && (typeof requestData.comment !== 'string' || (requestData.comment as string).length > 500)) {
    errors.push('comment must be a string with maximum 500 characters');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}
