import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';

// POST - ручная очистка старых сообщений
export async function POST(request: NextRequest) {
  try {
    const client = await pool.connect();

    try {
      // Используем функцию из setup-chat-cleanup.sql
      const result = await client.query('SELECT cleanup_old_chat_messages()');

      const deletedCount = result.rows[0]?.cleanup_old_chat_messages || 0;

      return NextResponse.json({
        success: true,
        message: `Удалено ${deletedCount} старых сообщений`,
        deletedCount
      });
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error during cleanup:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка очистки сообщений' },
      { status: 500 }
    );
  }
}

// GET - получить статистику по сообщениям
export async function GET(request: NextRequest) {
  try {
    const client = await pool.connect();

    try {
      const stats = await client.query(`
        SELECT
          COUNT(*) as total_messages,
          COUNT(*) FILTER (WHERE created_at > NOW() - INTERVAL '1 day') as messages_last_day,
          COUNT(*) FILTER (WHERE created_at > NOW() - INTERVAL '1 week') as messages_last_week,
          COUNT(*) FILTER (WHERE created_at < NOW() - INTERVAL '3 days' AND is_system = FALSE) as old_messages_to_cleanup,
          MAX(created_at) as latest_message_time,
          MIN(created_at) as oldest_message_time
        FROM chat_messages
      `);

      const roomStats = await client.query(`
        SELECT
          cr.name,
          COUNT(cm.id) as message_count
        FROM chat_rooms cr
        LEFT JOIN chat_messages cm ON cr.id = cm.room_id
        GROUP BY cr.id, cr.name
        ORDER BY message_count DESC
      `);

      return NextResponse.json({
        success: true,
        data: {
          overall: stats.rows[0],
          byRoom: roomStats.rows
        }
      });
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error fetching chat stats:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка получения статистики' },
      { status: 500 }
    );
  }
}
