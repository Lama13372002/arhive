"use client";

import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import {
  Clock,
  CheckCircle,
  XCircle,
  TrendingUp,
  Trophy,
  BarChart3,
  Coins,
  Star,
  Sparkles,
  AlertCircle,
  Zap,
  Copy,
  AlertTriangle
} from "lucide-react";
import { motion } from "framer-motion";
import { useTelegram } from "@/components/providers/TelegramProvider";
import { betsApi, ApiError } from "@/lib/api";
import type { Bet, GetBetsResponse, BetMatch } from "@/types/api";
import { addErrorLog } from "@/lib/error-logger";
import { MyBetsI18nProvider, useMyBetsI18n, translatePrediction } from "@/components/providers/MyBetsI18nProvider";
import { formatMatchDisplayTime } from "@/lib/timezone-utils";

// Функция для правильного отображения времени/статуса матча
const getMatchDisplayTime = (match: BetMatch | undefined, betStatus?: string, userStatus?: string, t?: (key: string) => string): string => {
  if (!match) return t ? t('date_not_specified') : "Дата не указана";

  const status = match.status?.toLowerCase();
  const minute = match.minute;

  // ПРИОРИТЕТ 1: Если спор завершен (есть победитель/проигравший/возврат), показываем соответствующий статус
  if (betStatus === 'won' || betStatus === 'lost' || userStatus === 'won' || userStatus === 'lost') {
    return t ? t('finished') : "Завершен";
  }
  if (betStatus === 'refunded' || userStatus === 'refunded') {
    return ""; // Для рефанда не показываем дату/время
  }

  // ПРИОРИТЕТ 2: Если матч идет прямо сейчас
  if (status === 'live' || status === '1h' || status === '2h' || status === 'ht') {
    if (minute) {
      return t ? `${t('match_live')} ${minute}'` : `Идет ${minute}'`;
    }
    return t ? t('match_in_progress') : "Идет матч";
  }

  // ПРИОРИТЕТ 3: Если матч официально завершен
  if (status === 'finished' || status === 'ft' || status === 'completed') {
    return t ? t('match_finished') : "Матч завершен";
  }

  // ПРИОРИТЕТ 4: Если матч отменен/отложен
  if (status === 'cancelled' || status === 'postponed') {
    return status === 'cancelled'
      ? (t ? t('match_cancelled') : "Отменен")
      : (t ? t('match_postponed') : "Отложен");
  }

  // ПРИОРИТЕТ 5: Показываем время начала матча
  if (match.start_time) {
    try {
      // Используем унифицированную функцию для корректного отображения времени
      const todayText = t ? t('today') : 'Сегодня';
      const formattedTime = formatMatchDisplayTime(match.start_time, todayText);

      if (formattedTime) {
        return formattedTime;
      } else {
        return t ? t('date_not_specified') : "Дата не указана";
      }
    } catch (error) {
      console.warn('Error formatting match time in MyBetsPage:', error);
      return t ? t('date_not_specified') : "Дата не указана";
    }
  }

  return t ? t('date_not_specified') : "Дата не указана";
};

interface MyBet {
  id: string;
  match: {
    homeTeam: string;
    awayTeam: string;
    league: string;
    date: string;
    start_time?: string;
    home_score?: number;
    away_score?: number;
    status?: string;
  };
  prediction: string;
  amount: number;
  currency: "TON" | "STARS";
  status: "active" | "won" | "lost" | "cancelled" | "refunded" | "open" | "closed" | "completed";
  result?: {
    finalScore?: { home: number; away: number };
    payout?: number;
  };
  opponents: string[];
  participantsCount: number;
  created_at?: string;
  user_role?: "creator" | "participant";
  user_status?: string;
}

const getStatusIcon = (status: string, matchStatus?: string) => {
  switch (status) {
    case "won":
      return <CheckCircle className="h-5 w-5 text-green-400" />;
    case "lost":
      return <XCircle className="h-5 w-5 text-red-400" />;
    case "refunded":
      return <AlertCircle className="h-5 w-5 text-orange-400" />;
    case "active":
      const isGameStarted = matchStatus?.toLowerCase() === 'live' ||
                           matchStatus?.toLowerCase() === '1h' ||
                           matchStatus?.toLowerCase() === '2h' ||
                           matchStatus?.toLowerCase() === 'ht' ||
                           matchStatus?.toLowerCase() === 'finished' ||
                           matchStatus?.toLowerCase() === 'ft' ||
                           matchStatus?.toLowerCase() === 'completed';
      return <Clock className={`h-5 w-5 ${isGameStarted ? 'text-red-400' : 'text-blue-400'}`} />;
    case "cancelled":
      return <XCircle className="h-5 w-5 text-foreground/50" />;
    default:
      return <Clock className="h-5 w-5 text-foreground/50" />;
  }
};

const getStatusText = (status: string, t?: (key: string) => string) => {
  switch (status) {
    case "won":
      return t ? t('status_won') : "Выигран";
    case "lost":
      return t ? t('status_lost') : "Проигран";
    case "refunded":
      return t ? t('status_refunded') : "Возврат";
    case "active":
      return t ? t('status_active') : "Активный";
    case "cancelled":
      return t ? t('status_cancelled') : "Отменен";
    default:
      return t ? t('status_unknown') : "Неизвестно";
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case "won":
      return "bg-gradient-to-r from-green-400 to-emerald-500 text-white border-none";
    case "lost":
      return "bg-gradient-to-r from-red-400 to-rose-500 text-white border-none";
    case "refunded":
      return "bg-gradient-to-r from-orange-400 to-amber-500 text-white border-none";
    case "active":
      return "bg-gradient-to-r from-blue-400 to-blue-500 text-white border-none";
    case "cancelled":
      return "bg-foreground/20 text-foreground/60 border-none";
    default:
      return "bg-foreground/20 text-foreground/60 border-none";
  }
};

const MyBetsPageContent = () => {
  const { user } = useTelegram();
  const { t } = useMyBetsI18n();
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [bets, setBets] = useState<MyBet[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [errorDetails, setErrorDetails] = useState<{
    message: string;
    stack?: string;
    endpoint: string;
    timestamp: string;
    requestData?: Record<string, unknown>;
  } | null>(null);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [processedWinnings, setProcessedWinnings] = useState<Set<string>>(new Set());

  const statuses = ["all", "active", "won", "lost", "refunded"];

  // Функция для определения результата матча
  const getMatchResult = (homeScore: number, awayScore: number): "home" | "draw" | "away" => {
    if (homeScore > awayScore) return "home";
    if (homeScore < awayScore) return "away";
    return "draw";
  };

  // Маппинг статусов из API в отображаемые статусы
  const mapApiStatusToDisplayStatus = React.useCallback((bet: Bet): "active" | "won" | "lost" | "cancelled" | "refunded" => {
    // Используем user_status из API, если он есть
    if (bet.user_status) {
      switch (bet.user_status) {
        case "won":
          return "won";
        case "lost":
          return "lost";
        case "refunded":
          return "refunded";
        case "cancelled":
          return "cancelled";
        case "completed":
        case "in_progress":
        case "waiting":
        default:
          return "active";
      }
    }

    // Fallback к старой логике
    const apiStatus = bet.status;

    switch (apiStatus) {
      case "open":
      case "closed":
        return "active";
      case "refunded":
        return "refunded";
      case "completed":
        // Проверяем результат матча
        if (bet.match?.home_score !== undefined && bet.match?.away_score !== undefined) {
          const matchResult = getMatchResult(bet.match.home_score, bet.match.away_score);
          const userPrediction = bet.prediction_type;

          // Определяем, выиграл ли пользователь
          return matchResult === userPrediction ? "won" : "lost";
        }
        return "active"; // Если нет результата матча, считаем активным
      case "cancelled":
        return "cancelled";
      default:
        return "active";
    }
  }, []);

  // Функция для автоматического начисления выигрыша на баланс
  const processWinnings = React.useCallback(async (wonBets: MyBet[]) => {
    if (!user?.id) return;

    const newWinnings = wonBets.filter(bet => !processedWinnings.has(bet.id));

    if (newWinnings.length === 0) return;

    console.log(`Обрабатываем новые выигрыши:`, newWinnings);

    for (const bet of newWinnings) {
      try {
        // Определяем winning_prediction на основе результата матча
        let winningPrediction = 'home';
        if (bet.result?.finalScore) {
          const { home, away } = bet.result.finalScore;
          if (home > away) winningPrediction = 'home';
          else if (home < away) winningPrediction = 'away';
          else winningPrediction = 'draw';
        }

        // Вызываем API для завершения спора и начисления выигрыша
        const response = await fetch('/api/bets/complete', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-telegram-user-id': user.id.toString()
          },
          body: JSON.stringify({
            bet_id: Number(bet.id),
            winning_prediction: winningPrediction
          })
        });

        if (response.ok) {
          const result = await response.json();
          console.log(`🎉 Выигрыш автоматически начислен для спора ${bet.id}:`, result);

          // Отмечаем как обработанный
          setProcessedWinnings(prev => new Set([...prev, bet.id]));

          // Показываем уведомление пользователю
          if (result.results && result.results.length > 0) {
            const winnings = result.results[0].winnings || 0;
            console.log(`💰 На ваш баланс начислено: ${winnings} ${bet.currency}`);
          }
        } else {
          const error = await response.json();
          console.error(`Ошибка при обработке выигрыша для спора ${bet.id}:`, error);
        }
      } catch (error) {
        console.error(`Ошибка при обработке выигрыша для спора ${bet.id}:`, error);
      }
    }
  }, [user?.id, processedWinnings]);

  // Загружаем данные о спорах пользователя
  const fetchUserBets = React.useCallback(async () => {
    if (!user?.id) return;

    try {
      setLoading(true);
      setError(null);

      const response = await betsApi.getMy({}, user.id);

      // Преобразуем данные API в формат, ожидаемый компонентом
      const transformedBets: MyBet[] = response.bets.map((bet: Bet) => ({
        id: bet.id.toString(),
        match: {
          homeTeam: bet.match?.home_team || bet.home_team || "Команда 1",
          awayTeam: bet.match?.away_team || bet.away_team || "Команда 2",
          league: bet.match?.league || bet.league || "Лига",
          date: getMatchDisplayTime(bet.match, mapApiStatusToDisplayStatus(bet), bet.user_status, t),
          start_time: bet.match?.start_time,
          home_score: bet.match?.home_score,
          away_score: bet.match?.away_score,
          status: bet.match?.status
        },
        prediction: bet.user_prediction || bet.prediction_text || bet.prediction_type || "Не указан",
        amount: Number(bet.amount) || 0,
        currency: bet.currency || "TON",
        status: mapApiStatusToDisplayStatus(bet),
        result: bet.match?.home_score !== undefined && bet.match?.away_score !== undefined ? {
          finalScore: {
            home: bet.match.home_score,
            away: bet.match.away_score
          },
          payout: bet.result?.payout
        } : (bet.result ? {
          finalScore: bet.result.finalScore,
          payout: bet.result.payout
        } : undefined),
        opponents: bet.participants?.map((p) => p.username || p.first_name || "Пользователь") || [],
        participantsCount: bet.participants?.length || 0,
        created_at: bet.created_at,
        user_role: bet.user_participation?.role,
        user_status: bet.user_status
      }));

      setBets(transformedBets);

      // Обрабатываем выигрышные споры для автоматического начисления
      const wonBets = transformedBets.filter(bet => bet.status === "won");
      if (wonBets.length > 0) {
        await processWinnings(wonBets);
      }
    } catch (err) {
      console.error('Error fetching user bets:', err);
      const errorMessage = err instanceof ApiError ? err.message : t('error_loading');
      setError(errorMessage);

      // Сохраняем детальную информацию об ошибке
      setErrorDetails({
        message: errorMessage,
        stack: err instanceof Error ? err.stack : undefined,
        endpoint: '/api/bets/my',
        timestamp: new Date().toISOString(),
        requestData: {
          userId: user?.id,
          timestamp: new Date().toISOString()
        }
      });

      // Логируем ошибку для отладки
      addErrorLog(
        err,
        '/api/bets/my',
        user?.id?.toString(),
        { userId: user?.id },
        undefined
      );

      // Автоматически показываем модальное окно с ошибкой
      setShowErrorModal(true);
    } finally {
      setLoading(false);
    }
  }, [user?.id, mapApiStatusToDisplayStatus, processWinnings]);

  useEffect(() => {
    fetchUserBets();
  }, [fetchUserBets]);

  const filteredBets = bets.filter(bet =>
    selectedStatus === "all" || bet.status === selectedStatus
  );

  // Statistics
  const totalBets = bets.length;
  const wonBets = bets.filter(bet => bet.status === "won").length;
  const finishedBets = bets.filter(bet => bet.status === "won" || bet.status === "lost").length; // Исключаем рефанды из расчета winRate
  const winRate = finishedBets > 0 ? Math.round((wonBets / finishedBets) * 100) : 0;
  const totalWinnings = bets
    .filter(bet => bet.status === "won")
    .reduce((sum, bet) => sum + (bet.result?.payout || 0), 0);

  const handleFilterByStatus = (status: string) => {
    setSelectedStatus(status);
  };

  // Показываем индикатор загрузки
  if (loading) {
    return (
      <div className="p-4 space-y-6 pb-24">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-foreground/60">{t('loading_bets')}</p>
        </div>
      </div>
    );
  }

  // Показываем ошибку
  if (error) {
    return (
      <div className="p-4 space-y-6 pb-24">
        <div className="text-center py-12 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10">
          <AlertCircle className="h-12 w-12 text-red-400 mx-auto mb-3" />
          <p className="text-red-400 font-medium mb-4">{error}</p>
          <Button
            onClick={fetchUserBets}
            variant="outline"
            className="rounded-full bg-white/5 backdrop-blur-sm border border-white/10 hover:bg-white/10"
          >
            {t('try_again')}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-6 pb-24">


      {/* Statistics */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="glass-card border-none overflow-hidden relative shadow-md">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-600/10 rounded-xl"></div>
          <CardContent className="p-4 relative z-10">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-md relative overflow-hidden">
                <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full animate-shimmer"></div>
                <BarChart3 className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text">{winRate}%</p>
                <p className="text-sm text-foreground/70">{t('win_rate')}</p>
              </div>
            </div>
            <div className="mt-3 w-full bg-white/10 rounded-full h-2.5 overflow-hidden">
              <div
                className="bg-gradient-to-r from-blue-400 to-purple-500 h-2.5 rounded-full transition-all duration-1000"
                style={{ width: `${winRate}%` }}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-none overflow-hidden relative shadow-md">
          <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-emerald-600/10 rounded-xl"></div>
          <CardContent className="p-4 relative z-10">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center shadow-md relative overflow-hidden">
                <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full animate-shimmer"></div>
                <Trophy className="h-6 w-6 text-white" />
              </div>
              <div>
                <div className="flex items-center space-x-1">
                  <p className="text-2xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 text-transparent bg-clip-text">{wonBets}</p>
                  <Sparkles className="h-4 w-4 text-yellow-400" />
                </div>
                <p className="text-sm text-foreground/70">{t('won_bets_count')}</p>
              </div>
            </div>
            <p className="text-xs text-green-400 mt-2 flex items-center">
              <CheckCircle className="h-3 w-3 mr-1" />
              <span>{finishedBets} {t('out_of_finished')}</span>
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Status Filters */}
      <Card className="glass-card border-none overflow-hidden p-3">
        <CardContent className="p-0 space-y-3">
          <div className="flex space-x-2 overflow-x-auto py-1 no-scrollbar">
            {statuses.map((status) => (
              <Button
                key={status}
                variant={selectedStatus === status ? "default" : "outline"}
                size="sm"
                onClick={() => handleFilterByStatus(status)}
                className={`rounded-full whitespace-nowrap ${
                  selectedStatus === status
                    ? status === "all"
                      ? "bg-gradient-to-r from-blue-400 to-purple-500 text-white border-none shadow-md"
                      : getStatusColor(status)
                    : "bg-white/5 backdrop-blur-sm border border-white/10"
                }`}
              >
                {status !== "all" && getStatusIcon(status)}
                <span className="ml-1">{status === "all" ? t('all') : getStatusText(status, t)}</span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Bets List */}
      <div className="space-y-4">
        {filteredBets.map((bet, index) => (
          <motion.div
            key={bet.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.02, transition: { duration: 0.2 } }}
          >
            <Card className="glass-card border-none overflow-hidden relative">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-purple-500 rounded-t-xl"></div>

              <CardHeader className="pb-2 pt-4 relative z-10">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(bet.status, bet.match.status)}
                    <div>
                      <CardTitle className="text-base font-semibold flex items-center">
                        <span>{bet.match.homeTeam}</span>
                        <span className="mx-1 text-foreground/70">{t('vs')}</span>
                        <span>{bet.match.awayTeam}</span>
                      </CardTitle>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge variant="outline" className="text-xs bg-white/10 border-white/10">
                          {bet.match.league}
                        </Badge>
                        {bet.status !== "refunded" && bet.match.date && (
                          <div className="flex items-center space-x-1 text-xs text-foreground/70">
                            <Clock className={`h-3 w-3 ${
                              bet.match.status?.toLowerCase() === 'live' ||
                              bet.match.status?.toLowerCase() === '1h' ||
                              bet.match.status?.toLowerCase() === '2h' ||
                              bet.match.status?.toLowerCase() === 'ht' ||
                              bet.match.status?.toLowerCase() === 'finished' ||
                              bet.match.status?.toLowerCase() === 'ft' ||
                              bet.match.status?.toLowerCase() === 'completed'
                                ? 'text-red-400'
                                : 'text-blue-400'
                            }`} />
                            <span>{bet.match.date}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <Badge className={getStatusColor(bet.status)}>
                    {getStatusText(bet.status, t)}
                  </Badge>
                </div>
              </CardHeader>

              <CardContent className="pt-0 relative z-10">
                <div className="space-y-3">
                  {/* Bet Details */}
                  <div className="p-3 rounded-xl bg-white/5 backdrop-blur-sm space-y-3">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-foreground/70 text-xs">{t('prediction')}</p>
                        <p className="font-medium flex items-center">
                          <TrendingUp className="h-3.5 w-3.5 mr-1 text-blue-400" />
                          {translatePrediction(bet.prediction, t)}
                        </p>
                      </div>
                      <div>
                        <p className="text-foreground/70 text-xs">{t('amount')}</p>
                        <div className="flex items-center space-x-1">
                          {bet.currency === "TON" ? (
                            <img src="/images/ton.png" alt="TON" className="h-4 w-4" />
                          ) : (
                            <img src="/images/stars.png" alt="Stars" className="h-4 w-4" />
                          )}
                          <span className="font-bold">{bet.amount}</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-foreground/70 text-xs">{t('participants')}</p>
                        <div className="flex items-center space-x-1">
                          <span className="font-medium">{Math.min(bet.participantsCount + 1, 3)}/3</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-foreground/70 text-xs">{t('bet_status')}</p>
                        <p className="font-medium truncate">
                          {bet.status === "active" ? t('status_waiting') : bet.status === "won" ? t('status_won') : bet.status === "lost" ? t('status_lost') : bet.status === "refunded" ? t('status_refund_money') : t('status_completed')}
                        </p>
                      </div>
                    </div>

                    {/* Result - только для не-рефандов */}
                    {bet.result && bet.status !== "refunded" && (
                      <>
                        <Separator className="bg-white/10" />
                        <div className="space-y-2">
                          {bet.result.finalScore && (
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-foreground/70">{t('final_score')}</span>
                              <span className="font-bold bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text">
                                {bet.result.finalScore.home} - {bet.result.finalScore.away}
                              </span>
                            </div>
                          )}
                          {bet.result.payout && (
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-foreground/70">{t('payout')}</span>
                              <div className="flex items-center space-x-1">
                                <Sparkles className="h-4 w-4 text-yellow-400" />
                                <span className="font-bold bg-gradient-to-r from-green-400 to-emerald-500 text-transparent bg-clip-text">
                                  +{bet.result.payout} {bet.currency}
                                </span>
                              </div>
                            </div>
                          )}
                        </div>
                      </>
                    )}

                    {/* Refund Info */}
                    {bet.status === "refunded" && (
                      <>
                        <Separator className="bg-white/10" />
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-foreground/70">{t('refund_amount')}</span>
                            <div className="flex items-center space-x-1">
                              <AlertCircle className="h-4 w-4 text-orange-400" />
                              <span className="font-bold bg-gradient-to-r from-orange-400 to-amber-500 text-transparent bg-clip-text">
                                {bet.amount} {bet.currency}
                              </span>
                            </div>
                          </div>
                          <div className="text-xs text-foreground/60 bg-orange-500/10 p-2 rounded-lg">
                            {t('refund_reason')}
                          </div>
                        </div>
                      </>
                    )}
                  </div>


                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {filteredBets.length === 0 && (
        <div className="text-center py-12 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10">
          <AlertCircle className="h-12 w-12 text-foreground/30 mx-auto mb-3" />
          <p className="text-foreground/60 font-medium">
            {selectedStatus === "all"
              ? t('no_bets')
              : `${t('no_bets_with_status')} "${getStatusText(selectedStatus, t)}"`
            }
          </p>
          {selectedStatus !== "all" && (
            <Button
              variant="outline"
              className="mt-4 rounded-full bg-white/5 backdrop-blur-sm border border-white/10 hover:bg-white/10"
              onClick={() => setSelectedStatus("all")}
            >
              {t('show_all_bets')}
            </Button>
          )}
        </div>
      )}

      {/* Модальное окно с детальной ошибкой */}
      <Dialog open={showErrorModal} onOpenChange={setShowErrorModal}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center text-red-600">
              <AlertTriangle className="h-5 w-5 mr-2" />
              Детали ошибки
            </DialogTitle>
          </DialogHeader>

          {errorDetails && (
            <ScrollArea className="max-h-[60vh]">
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Сообщение об ошибке:</h4>
                  <div className="p-3 bg-red-50 border border-red-200 rounded text-red-800">
                    {errorDetails.message}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Информация:</h4>
                  <div className="text-sm space-y-1 text-gray-600">
                    <p><strong>Время:</strong> {new Date(errorDetails.timestamp).toLocaleString('ru-RU')}</p>
                    <p><strong>Эндпоинт:</strong> {errorDetails.endpoint}</p>
                    <p><strong>Пользователь ID:</strong> {user?.id}</p>
                  </div>
                </div>

                {errorDetails.stack && (
                  <div>
                    <h4 className="font-medium mb-2">Stack Trace:</h4>
                    <Textarea
                      value={errorDetails.stack}
                      readOnly
                      className="h-32 text-xs font-mono"
                    />
                  </div>
                )}

                {errorDetails.requestData && (
                  <div>
                    <h4 className="font-medium mb-2">Данные запроса:</h4>
                    <Textarea
                      value={JSON.stringify(errorDetails.requestData, null, 2)}
                      readOnly
                      className="h-24 text-xs font-mono"
                    />
                  </div>
                )}

                <div className="flex gap-2 pt-4">
                  <Button
                    onClick={() => copyToClipboard(getFullErrorText())}
                    className="flex-1"
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Скопировать всю ошибку
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowErrorModal(false)}
                  >
                    Закрыть
                  </Button>
                </div>
              </div>
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );

  // Функция для копирования текста в буфер обмена
  function copyToClipboard(text: string) {
    navigator.clipboard.writeText(text).catch(err => {
      console.error('Failed to copy: ', err);
    });
  }

  // Форматирование полной информации об ошибке для копирования
  function getFullErrorText(): string {
    if (!errorDetails) return '';

    return `
=== ОШИБКА TMA ===
Время: ${new Date(errorDetails.timestamp).toLocaleString('ru-RU')}
Эндпоинт: ${errorDetails.endpoint}
Сообщение: ${errorDetails.message}

${errorDetails.stack ? `Stack Trace:
${errorDetails.stack}` : ''}

${errorDetails.requestData ? `Данные запроса:
${JSON.stringify(errorDetails.requestData, null, 2)}` : ''}

Пользователь ID: ${user?.id}
Время в Unix: ${Math.floor(new Date(errorDetails.timestamp).getTime() / 1000)}
=================
    `.trim();
  }
};

export const MyBetsPage = () => {
  return (
    <MyBetsI18nProvider>
      <MyBetsPageContent />
    </MyBetsI18nProvider>
  );
};
