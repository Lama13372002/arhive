"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Search,
  Filter,
  Clock,
  MapPin,
  Play,
  Pause,
  MoreHorizontal,
  Trophy,
  RefreshCw
} from "lucide-react";
import type { MatchEvent, League } from "@/types/football";
import { footballService } from "@/lib/football-service";
import { preloadService } from "@/lib/preload-service";
import { parseMatchDateTime } from "@/lib/timezone";
import Image from "next/image";
import { HomeI18nProvider, useHomeI18n } from "@/components/providers/HomeI18nProvider";

interface HomePageProps {
  onPageChange?: (page: "home" | "create-bet" | "open-bets" | "chat" | "my-bets" | "menu") => void;
}

interface HomePageData {
  liveMatches: MatchEvent[];
  todayMatches: MatchEvent[];
  popularLeagues: League[];
}

// Помощник для совпадений матчей
const uniqueByIdAndTeams = (events: MatchEvent[]) => {
  const seen = new Set<string>();
  return events.filter((e) => {
    const key = `${e.id}::${e.homeTeam}::${e.awayTeam}`.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
};

// Обычная карточка матча
const MatchCard = ({ event, onCreateBet, isLive = false }: {
  event: MatchEvent;
  onCreateBet: (eventId: string) => void;
  isLive?: boolean;
}) => {
  const { t } = useHomeI18n();
  return (
    <div className="relative">
      <Card className={`glass-card border-none overflow-hidden ${isLive ? 'ring-2 ring-red-500/50 shadow-lg shadow-red-500/20' : ''}`}>
        <CardHeader className="pb-3 relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="text-xs font-semibold px-2 py-1 bg-white/10 backdrop-blur-md border-white/20">
                {event.league}
              </Badge>
              {getStatusBadge(event.status, event.minute, event.fullDateTime, event.startTime, t)}
            </div>
            {(event.status === "live" || event.status === "halftime" || event.status === "finished") ? (
              <div className="flex items-center space-x-1 text-sm">
                <Clock className="h-4 w-4 mr-1 text-blue-400" />
                <span className="font-medium text-foreground/80">{event.startTime}</span>
              </div>
            ) : null}
          </div>
        </CardHeader>

        <CardContent className="pt-0 relative z-10">
          <div className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {event.homeTeamLogo ? (
                    <div className="w-8 h-8 relative">
                      <Image
                        src={event.homeTeamLogo}
                        alt={event.homeTeam}
                        fill
                        className="object-contain rounded-full"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                          target.nextElementSibling?.classList.remove('hidden');
                        }}
                      />
                      <div className="w-8 h-8 rounded-full bg-gradient-cosmic flex items-center justify-center text-white font-bold text-xs hidden">
                        {event.homeTeam.charAt(0)}
                      </div>
                    </div>
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-gradient-cosmic flex items-center justify-center text-white font-bold text-xs">
                      {event.homeTeam.charAt(0)}
                    </div>
                  )}
                  <span className="font-semibold text-sm">{event.homeTeam}</span>
                </div>
                {event.score && (
                  <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 text-transparent bg-clip-text">
                    {event.score.home}
                  </span>
                )}
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {event.awayTeamLogo ? (
                    <div className="w-8 h-8 relative">
                      <Image
                        src={event.awayTeamLogo}
                        alt={event.awayTeam}
                        fill
                        className="object-contain rounded-full"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                          target.nextElementSibling?.classList.remove('hidden');
                        }}
                      />
                      <div className="w-8 h-8 rounded-full bg-gradient-fire flex items-center justify-center text-white font-bold text-xs hidden">
                        {event.awayTeam.charAt(0)}
                      </div>
                    </div>
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-gradient-fire flex items-center justify-center text-white font-bold text-xs">
                      {event.awayTeam.charAt(0)}
                    </div>
                  )}
                  <span className="font-semibold text-sm">{event.awayTeam}</span>
                </div>
                {event.score && (
                  <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 text-transparent bg-clip-text">
                    {event.score.away}
                  </span>
                )}
              </div>
            </div>

            <Separator className="bg-white/10" />

            <Button
              className="w-full h-11 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 border-none relative overflow-hidden shadow-lg group"
              onClick={() => onCreateBet(event.id)}
            >
              <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-all duration-700"></span>
              <div className="flex items-center justify-center space-x-2">
                <Trophy className="h-4 w-4" />
                <span className="font-medium">{t('create_bet')}</span>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Компактная карточка матча для карусели
const CompactMatchCard = ({ event, onCreateBet, isLive = false }: {
  event: MatchEvent;
  onCreateBet: (eventId: string) => void;
  isLive?: boolean;
}) => {
  const { t } = useHomeI18n();
  return (
    <div className="flex-shrink-0 min-w-72 w-max">
      <Card className={`glass-card border-none overflow-hidden h-full ${isLive ? 'ring-2 ring-red-500/50 shadow-lg shadow-red-500/20' : ''}`}>
        <CardHeader className="pb-2 relative z-10">
          <div className="flex items-center justify-between">
            <Badge variant="outline" className="text-xs font-semibold px-2 py-1 bg-white/10 backdrop-blur-md border-white/20 whitespace-nowrap">
              {event.league}
            </Badge>
            {getStatusBadge(event.status, event.minute, event.fullDateTime)}
          </div>
        </CardHeader>

        <CardContent className="pt-0 relative z-10 pb-3">
          <div className="space-y-3">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 flex-1 min-w-0">
                  {event.homeTeamLogo ? (
                    <div className="w-6 h-6 relative flex-shrink-0">
                      <Image
                        src={event.homeTeamLogo}
                        alt={event.homeTeam}
                        fill
                        className="object-contain rounded-full"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                          target.nextElementSibling?.classList.remove('hidden');
                        }}
                      />
                      <div className="w-6 h-6 rounded-full bg-gradient-cosmic flex items-center justify-center text-white font-bold text-xs hidden">
                        {event.homeTeam.charAt(0)}
                      </div>
                    </div>
                  ) : (
                    <div className="w-6 h-6 rounded-full bg-gradient-cosmic flex items-center justify-center text-white font-bold text-xs flex-shrink-0">
                      {event.homeTeam.charAt(0)}
                    </div>
                  )}
                  <span className="font-semibold text-sm truncate">{event.homeTeam}</span>
                </div>
                {event.score && (
                  <span className="text-lg font-bold bg-gradient-to-r from-blue-400 to-purple-400 text-transparent bg-clip-text ml-2">
                    {event.score.home}
                  </span>
                )}
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 flex-1 min-w-0">
                  {event.awayTeamLogo ? (
                    <div className="w-6 h-6 relative flex-shrink-0">
                      <Image
                        src={event.awayTeamLogo}
                        alt={event.awayTeam}
                        fill
                        className="object-contain rounded-full"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                          target.nextElementSibling?.classList.remove('hidden');
                        }}
                      />
                      <div className="w-6 h-6 rounded-full bg-gradient-fire flex items-center justify-center text-white font-bold text-xs hidden">
                        {event.awayTeam.charAt(0)}
                      </div>
                    </div>
                  ) : (
                    <div className="w-6 h-6 rounded-full bg-gradient-fire flex items-center justify-center text-white font-bold text-xs flex-shrink-0">
                      {event.awayTeam.charAt(0)}
                    </div>
                  )}
                  <span className="font-semibold text-sm truncate">{event.awayTeam}</span>
                </div>
                {event.score && (
                  <span className="text-lg font-bold bg-gradient-to-r from-blue-400 to-purple-400 text-transparent bg-clip-text ml-2">
                    {event.score.away}
                  </span>
                )}
              </div>
            </div>

            <Button
              className="w-full h-9 rounded-lg bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 border-none relative overflow-hidden shadow-lg group text-sm"
              onClick={() => onCreateBet(event.id)}
            >
              <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-all duration-700"></span>
              <div className="flex items-center justify-center space-x-1">
                <Trophy className="h-3 w-3" />
                <span className="font-medium">{t('create_bet')}</span>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const getStatusBadge = (status: string, minute?: number, fullDateTime?: string, startTime?: string, t?: (key: string) => string) => {
  switch (status) {
    case "live":
      return (
        <Badge variant="destructive" className="animate-pulse flex items-center">
          <Play className="h-3 w-3 mr-1" />
          <span>{minute}'</span>
        </Badge>
      );
    case "halftime":
      return (
        <Badge variant="secondary" className="flex items-center">
          <Pause className="h-3 w-3 mr-1" />
          <span>{t ? t('halftime') : 'Перерыв'}</span>
        </Badge>
      );
    case "finished":
      return <Badge variant="outline">{t ? t('finished') : 'Завершен'}</Badge>;
    default:
      // Для upcoming матчей используем утилиты временных зон
      const { formattedDate, formattedTime } = parseMatchDateTime(fullDateTime);

      return (
        <Badge variant="secondary" className="flex items-center">
          <Clock className="h-3 w-3 mr-1" />
          <span>{formattedDate} {formattedTime}</span>
        </Badge>
      );
  }
};

const HomePageContent = ({ onPageChange }: HomePageProps) => {
  const { t } = useHomeI18n();
  const [searchTerm, setSearchTerm] = useState("");
  const [activeSearchTerm, setActiveSearchTerm] = useState("");
  const [selectedLeague, setSelectedLeague] = useState<string>("all");
  const [visibleMatches, setVisibleMatches] = useState(25);
  const [showOnlyLive, setShowOnlyLive] = useState(false);
  const [data, setData] = useState<HomePageData>({
    liveMatches: [],
    todayMatches: [],
    popularLeagues: []
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchHomeData();

    // Обновляем каждые 30 секунд с принудительным обновлением
    const interval = setInterval(() => {
      fetchHomeData(true);
    }, 30000);

    return () => {
      clearInterval(interval);
      setLoading(false);
    };
  }, []);

  const fetchHomeData = async (forceRefresh = false) => {
    try {
      setError(null);

      // Для первой загрузки используем кэш, но для обновлений - всегда свежие данные
      if (!forceRefresh && loading) {
        const cachedData = preloadService.getCachedData('football-home');
        if (cachedData) {
          console.log('📦 Используем предзагруженные данные');
          setData({
            liveMatches: cachedData.liveMatches || [],
            todayMatches: cachedData.todayMatches || [],
            popularLeagues: cachedData.popularLeagues || []
          });
          setLoading(false);
          return;
        }
      }

      // Всегда загружаем свежие данные для обновлений
      console.log('🔄 Загружаем свежие данные через API');
      const response = await fetch('/api/football/home?t=' + Date.now()); // добавляем timestamp чтобы избежать кэша браузера
      const result = await response.json();

      if (result.success) {
        setData(result.data);
      } else {
        setError(result.error || 'Ошибка загрузки данных');
      }
    } catch (err) {
      setError('Ошибка подключения к серверу');
    } finally {
      setLoading(false);
    }
  };

  const liveMatchesRaw = data.liveMatches || [];
  const todayMatchesRaw = data.todayMatches || [];
  const liveMatchesDeduped = uniqueByIdAndTeams(liveMatchesRaw);
  const todayMatchesDeduped = uniqueByIdAndTeams(todayMatchesRaw);

  // Функция для проверки актуальности матча
  const isMatchRelevant = (match: MatchEvent): boolean => {
    // Завершенные матчи не показываем
    if (match.status === 'finished') return false;

    // Live и halftime матчи всегда показываем
    if (match.status === 'live' || match.status === 'halftime') return true;

    // Для upcoming матчей проверяем время с учетом временной зоны
    try {
      const { localDate } = parseMatchDateTime(match.fullDateTime);
      const now = new Date();

      // Не показываем матчи старше 3 часов (возможно уже завершились, но API не обновился)
      const threeHoursAgo = now.getTime() - (3 * 60 * 60 * 1000);
      if (localDate.getTime() < threeHoursAgo) {
        return false;
      }
    } catch (e) {
      console.warn('Ошибка парсинга времени матча:', match.fullDateTime);
    }

    return true;
  };

  // Build union sources for robust league filtering with time validation
  const liveOnly = liveMatchesDeduped.filter(e => (e.status === 'live' || e.status === 'halftime') && isMatchRelevant(e));
  const todayNotFinished = todayMatchesDeduped.filter(e => isMatchRelevant(e));

  // Calculate actual live matches count (including both live and halftime from all sources)
  const allLiveMatches = uniqueByIdAndTeams([...liveMatchesDeduped, ...todayMatchesDeduped])
    .filter(e => (e.status === 'live' || e.status === 'halftime') && isMatchRelevant(e));

  // Build interesting matches: prioritize popular leagues, exclude finished
  const isPopularLeague = (leagueName: string): boolean => {
    // Check against known popular leagues by name
    const popularByName = new Set((data.popularLeagues || []).map(l => l.name));
    return popularByName.has(leagueName);
  };
  const sortedByPopularity = [...todayNotFinished].sort((a, b) => {
    const ap = isPopularLeague(a.league) ? 1 : 0;
    const bp = isPopularLeague(b.league) ? 1 : 0;
    if (bp !== ap) return bp - ap;
    // fallback by time string (HH:MM), parse to minutes where possible
    const toMinutes = (s?: string) => {
      if (!s) return 9999;
      const m = s.match(/(\d{1,2}):(\d{2})/);
      if (!m) return 9999;
      return parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
    };
    return toMinutes(a.startTime) - toMinutes(b.startTime);
  });

  // Build interesting matches: combine popular live matches + upcoming interesting matches
  const popularLiveMatches = allLiveMatches.filter(match => isPopularLeague(match.league)).slice(0, 2);
  const upcomingInterestingMatches = sortedByPopularity
    .filter(match => match.status === 'upcoming') // только предстоящие для этого блока
    .slice(0, 3);

  const interestingMatches = [...popularLiveMatches, ...upcomingInterestingMatches];
  // Исключаем матчи, которые уже попали в блок "Интересные", и показываем только upcoming
  const otherTodayMatches = sortedByPopularity.filter(match =>
    !upcomingInterestingMatches.some(interesting => interesting.id === match.id) &&
    match.status === 'upcoming' // В блоке "Остальные матчи" показываем только предстоящие
  );

  // Live матчи для отдельного блока (исключаем те, что уже в интересных)
  const liveMatches = liveMatchesDeduped.filter(match =>
    !popularLiveMatches.some(popular => popular.id === match.id)
  );
  // For filtering and scroller use union of today(not finished) + live(halftime)
  const allMatches = uniqueByIdAndTeams([...todayNotFinished, ...liveOnly]);

  // Normalization helpers for stable league keys
  const stripDiacritics = (s: string) => s.normalize('NFD').replace(/\p{Diacritic}/gu, '');
  const extractLeagueCoreName = (name: string) => {
    const raw = (name ?? '').toString();
    // Prefer right part if pattern "Country - League" exists, also support ':'
    const splitDash = raw.split(' - ');
    const splitColon = raw.split(': ');
    let core = splitDash.length > 1 ? splitDash.slice(1).join(' - ') : (splitColon.length > 1 ? splitColon.slice(1).join(': ') : raw);
    // Remove common suffixes indicating subgroup levels that break equality across APIs
    core = core.replace(/\b(group\s*\d+)$/i, '').replace(/\bu\d+\b/i, '').replace(/\breserve(s)?\b/i, '').replace(/\bkarla\b/i, '').replace(/\s{2,}/g, ' ').trim();
    return core;
  };
  const normalizeLeague = (name: string) => stripDiacritics(extractLeagueCoreName(name)).toLowerCase().replace(/\s+/g, ' ').trim();
  type LeagueEntry = { key: string; display: string; popular: boolean };
  const popularByName = new Set((data.popularLeagues || []).map(l => l.name));
  // Build map from key -> display
  const leagueMap = new Map<string, LeagueEntry>();
  for (const m of allMatches) {
    const key = normalizeLeague(m.league);
    if (!leagueMap.has(key)) {
      leagueMap.set(key, { key, display: m.league, popular: popularByName.has(m.league) });
    }
  }
  // Order for scroller: popular first, then alphabetical by display
  const orderedLeagueEntries = Array.from(leagueMap.values()).sort((a, b) => {
    if (a.popular !== b.popular) return a.popular ? -1 : 1;
    return a.display.localeCompare(b.display);
  });
  const leagues = ["all", ...orderedLeagueEntries.map(e => e.key)];

  let allFilteredEvents;
  let searchResults = [];

  if (activeSearchTerm.trim() !== "" && activeSearchTerm.trim().length >= 2) {
    const searchLower = activeSearchTerm.toLowerCase().trim();
    searchResults = allMatches.filter(event => {
      const homeTeamLower = event.homeTeam.toLowerCase();
      const awayTeamLower = event.awayTeam.toLowerCase();
      const isNotFinished = event.status !== "finished";
      const matchesSearch = homeTeamLower.includes(searchLower) || awayTeamLower.includes(searchLower);
      return matchesSearch && isNotFinished;
    });
    allFilteredEvents = uniqueByIdAndTeams(searchResults);
  } else {
    allFilteredEvents = allMatches.filter(event => {
      // Primary exact match by normalized core key (strict only)
      const matchesLeague = selectedLeague === "all" || normalizeLeague(event.league) === selectedLeague;
      const isNotFinished = event.status !== "finished";
      // When showOnlyLive, only allow live/halftime
      const matchesLiveFilter = !showOnlyLive ? true : (event.status === "live" || event.status === "halftime");

      return matchesLeague && isNotFinished && matchesLiveFilter;
    });
    allFilteredEvents = uniqueByIdAndTeams(allFilteredEvents);
  }

  const filteredEvents = allFilteredEvents.slice(0, visibleMatches);

  const hasMoreMatches = allFilteredEvents.length > visibleMatches;

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleSearchSubmit = () => {
    setActiveSearchTerm(searchTerm);
    setVisibleMatches(25);
    setShowOnlyLive(false);
  };

  const handleSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSearchSubmit();
    }
  };

  const handleFilterByLeague = (league: string) => {
    setSelectedLeague(league);
    setSearchTerm("");
    setActiveSearchTerm("");
    setVisibleMatches(25);
    setShowOnlyLive(false);
  };

  const handleCreateBet = (eventId: string) => {
    if (onPageChange) {
      const selectedEvent = allMatches.find(event => event.id === eventId);
      if (selectedEvent) {
        localStorage.setItem('selectedEvent', JSON.stringify(selectedEvent));
        localStorage.setItem('navigateBackTo', 'create_bet');
      }
      onPageChange("create-bet");
    }
  };

  const handleViewLiveEvents = () => {
    setShowOnlyLive(!showOnlyLive);
    setSelectedLeague("all");
    setSearchTerm("");
    setActiveSearchTerm("");
    setVisibleMatches(25);
  };

  const handleRefresh = () => {
    setLoading(true);
    fetchHomeData();
  };

  const handleLoadMore = () => {
    setVisibleMatches(prev => prev + 25);
  };

  if (loading && allMatches.length === 0) {
    return (
      <div className="p-4 space-y-4 pb-24">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center space-y-3">
            <RefreshCw className="h-8 w-8 animate-spin mx-auto text-primary" />
            <p className="text-muted-foreground">{t('loading_data')}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4 pb-24">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">{t('title')}</h1>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleRefresh}
          disabled={loading}
          className="text-muted-foreground"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
        </Button>
      </div>

      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <p className="text-red-600 text-sm">{error === 'Ошибка загрузки данных' ? t('error_loading') : t('error_connection')}</p>
            <Button variant="outline" size="sm" onClick={handleRefresh} className="mt-2">
              {t('try_again')}
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={t('search_placeholder')}
            value={searchTerm}
            onChange={handleSearchChange}
            onKeyPress={handleSearchKeyPress}
            className="pl-10 pr-12 border-none shadow-md rounded-full bg-white/10 backdrop-blur-lg"
          />
          <Button
            onClick={handleSearchSubmit}
            size="sm"
            variant="ghost"
            className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0 rounded-full hover:bg-white/20"
          >
            <Search className="h-4 w-4 text-muted-foreground hover:text-foreground" />
          </Button>
        </div>

        <div className="flex space-x-2 overflow-x-auto py-1 pb-2 no-scrollbar">
          {leagues.map((leagueKey) => {
            const entry = leagueKey === 'all' ? null : leagueMap.get(leagueKey);
            const display = entry?.display ?? leagueKey;
            const isSelected = selectedLeague === leagueKey;
            const handleLeagueClick = () => {
              handleFilterByLeague(leagueKey);
            };
            return (
              <Button
                key={leagueKey}
                variant={isSelected ? "default" : "outline"}
                size="sm"
                onClick={handleLeagueClick}
                role="button"
                tabIndex={0}
                className={`whitespace-nowrap rounded-full font-medium
                  ${isSelected
                    ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white border-none shadow-md"
                    : "bg-white/10 backdrop-blur-sm border border-white/20 text-foreground"}`}
              >
                {leagueKey === "all" ? t('all_leagues') : display}
              </Button>
            )
          })}
        </div>
      </div>

      <div className="relative">
        <Card className="glass-card border-none overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-red-500/30 to-orange-500/30 rounded-2xl"></div>
          <CardContent className="p-4 relative">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                <span className="font-semibold text-red-500 dark:text-red-400">
                  {t('live_banner', { count: allLiveMatches.length })}
                </span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-red-500 dark:text-red-400 p-0 h-8"
                onClick={handleViewLiveEvents}
              >
                {showOnlyLive ? t('live_toggle_off') : t('live_toggle_on')}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {activeSearchTerm.trim() !== "" && (
        <div className="flex items-center justify-between p-3 rounded-xl bg-blue-500/10 border border-blue-500/20">
          <div className="flex items-center space-x-2">
            <Search className="h-4 w-4 text-blue-400" />
            <span className="text-sm text-blue-400">
              {activeSearchTerm.trim().length >= 2
                ? t('search_found', { term: activeSearchTerm, count: allFilteredEvents.length })
                : t('search_min')
              }
            </span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setSearchTerm("");
              setActiveSearchTerm("");
              setVisibleMatches(25);
              setShowOnlyLive(false);
            }}
            className="text-blue-400 hover:text-blue-300 h-6 px-2"
          >
            {t('reset')}
          </Button>
        </div>
      )}

      <div className="space-y-4 mt-2">
        {(() => {
          // If a specific league selected, ignore sections and show only filtered list
          if (selectedLeague !== 'all') {
            return (
              <div className="space-y-4">
                {filteredEvents.map((event) => (
                  <MatchCard key={event.id} event={event} onCreateBet={handleCreateBet} isLive={event.status === 'live' || event.status === 'halftime'} />
                ))}
              </div>
            );
          }

          // Search mode
          if (activeSearchTerm.trim() !== "" && activeSearchTerm.trim().length >= 2) {
            return (
              <div className="space-y-4">
                {allFilteredEvents.map((event) => (
                  <MatchCard key={event.id} event={event} onCreateBet={handleCreateBet} isLive={event.status === 'live'} />
                ))}
              </div>
            );
          }

          // All leagues + sectional rendering
          return (
            <div className="space-y-6">
              {(() => {
                let remainingSlots = visibleMatches;
                const components = [] as JSX.Element[];

                if (interestingMatches.length > 0 && remainingSlots > 0 && !showOnlyLive) {
                  const matchesToShow = interestingMatches.slice(0, remainingSlots);
                  remainingSlots -= matchesToShow.length;
                  components.push(
                    <div key="interesting" className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Trophy className="h-5 w-5 text-blue-400" />
                        <h2 className="text-lg font-bold text-blue-400">{t('interesting')}</h2>
                        <div className="flex-1 h-px bg-gradient-to-r from-blue-400/50 to-transparent"></div>
                      </div>
                      <div className="flex overflow-x-auto scrollbar-none pb-2 pr-4" style={{scrollbarWidth: 'none', msOverflowStyle: 'none'}}>
                        <div className="flex gap-4">
                          {matchesToShow.map((event) => (
                            <CompactMatchCard
                              key={event.id}
                              event={event}
                              onCreateBet={handleCreateBet}
                              isLive={event.status === 'live' || event.status === 'halftime'}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                }

                if (liveMatches.length > 0 && remainingSlots > 0 && !showOnlyLive) {
                  const matchesToShow = liveMatches.slice(0, remainingSlots);
                  remainingSlots -= matchesToShow.length;
                  components.push(
                    <div key="live" className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                        <h2 className="text-lg font-bold text-red-500">{t('live_matches')}</h2>
                        <div className="flex-1 h-px bg-gradient-to-r from-red-500/50 to-transparent"></div>
                      </div>
                      <div className="flex overflow-x-auto scrollbar-none pb-2 pr-4" style={{scrollbarWidth: 'none', msOverflowStyle: 'none'}}>
                        <div className="flex gap-4">
                          {matchesToShow.map((event) => (
                            <CompactMatchCard
                              key={event.id}
                              event={event}
                              onCreateBet={handleCreateBet}
                              isLive={true}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                }

                if (otherTodayMatches.length > 0 && remainingSlots > 0 && !showOnlyLive) {
                  const matchesToShow = otherTodayMatches.slice(0, remainingSlots);
                  components.push(
                    <div key="other" className="space-y-4">
                      <div className="flex items-center space-x-2 mb-4">
                        <Clock className="h-5 w-5 text-green-400" />
                        <h2 className="text-lg font-bold text-green-400">{t('other_matches')}</h2>
                        <div className="flex-1 h-px bg-gradient-to-r from-green-400/50 to-transparent"></div>
                      </div>
                      {matchesToShow.map((event) => (
                        <MatchCard
                          key={event.id}
                          event={event}
                          onCreateBet={handleCreateBet}
                          isLive={event.status === 'live' || event.status === 'halftime'}
                        />
                      ))}
                    </div>
                  );
                }

                // If showOnlyLive in all mode, show filtered live list
                if (showOnlyLive) {
                  components.push(
                    <div key="liveonly" className="space-y-4">
                      {filteredEvents.map((event) => (
                        <MatchCard key={event.id} event={event} onCreateBet={handleCreateBet} isLive={event.status === 'live' || event.status === 'halftime'} />
                      ))}
                    </div>
                  );
                }

                return components;
              })()}
            </div>
          );
        })()}
      </div>

      {allFilteredEvents.length === 0 && (
        <div className="text-center py-8">
          <div className="space-y-3">
            <Search className="h-12 w-12 mx-auto text-muted-foreground/50" />
            <p className="text-muted-foreground">
              {activeSearchTerm.trim() !== ""
                ? t('search_found', { term: activeSearchTerm, count: 0 })
                : t('not_found')}
            </p>
            {activeSearchTerm.trim() !== "" && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setSearchTerm("");
                  setVisibleMatches(25);
                }}
                className="rounded-full"
              >
                {t('show_all_matches')}
              </Button>
            )}
          </div>
        </div>
      )}

      {hasMoreMatches && (activeSearchTerm.trim() === "" || activeSearchTerm.trim().length < 2) && selectedLeague === "all" && (
        <div className="flex justify-center pt-6">
          <Button
            onClick={handleLoadMore}
            variant="outline"
            className="w-full max-w-sm h-12 rounded-2xl bg-white/5 backdrop-blur-md border border-white/20 hover:bg-white/10 hover:border-white/30 transition-all duration-300 group relative overflow-hidden"
          >
            <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-all duration-1000"></span>
            <div className="flex items-center justify-center space-x-2 relative z-10">
              <MoreHorizontal className="h-4 w-4 text-foreground/70 group-hover:text-foreground transition-colors" />
              <span className="font-medium text-foreground/80 group-hover:text-foreground transition-colors">
                {t('show_more', { remaining: allFilteredEvents.length - visibleMatches })}
              </span>
            </div>
          </Button>
        </div>
      )}
    </div>
  );
};

export const HomePage = (props: HomePageProps) => (
  <HomeI18nProvider>
    <HomePageContent {...props} />
  </HomeI18nProvider>
);
