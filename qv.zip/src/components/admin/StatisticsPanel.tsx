'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  Target,
  RefreshCw,
  ArrowUpCircle,
  ArrowDownCircle,
  Trophy,
  X,
  Coins,
  Star,
  Activity,
  BarChart3,
  Zap
} from 'lucide-react';

interface StatisticsData {
  deposits: {
    total_count: number;
    total_amount: number;
    stars_conversions: {
      count: number;
      amount: number;
    };
  };
  withdrawals: {
    total_count: number;
    total_amount: number;
  };
  disputes: {
    total_completed: number;
    total_refunded: number;
    won_disputes: number;
    lost_disputes: number;
    unique_winners: number;
    unique_participants: number;
    total_won_amount: number;
    total_bet_amount: number;
    total_refund_amount: number;
    participants_by_position: Array<{
      position: string;
      total_participants: string;
      total_amount: string;
    }>;
    detailed_stats: {
      total_participations: number;
      refunded_participations: number;
      unique_refunded_users: number;
    };
  };
  transactions: Array<{
    transaction_type: string;
    count: string;
    total_amount: string;
  }>;
  summary: {
    net_flow: number;
    total_platform_volume: number;
  };
}

interface StatisticsPanelProps {
  adminPassword: string;
}

export default function StatisticsPanel({ adminPassword }: StatisticsPanelProps) {
  const [statistics, setStatistics] = useState<StatisticsData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const loadStatistics = async () => {
    setLoading(true);
    setError('');

    try {
      const response = await fetch(`/api/admin/statistics?adminPassword=${adminPassword}`);
      const data = await response.json();

      if (data.success) {
        setStatistics(data.statistics);
      } else {
        setError(data.error || 'Ошибка при загрузке статистики');
      }
    } catch (err) {
      setError('Ошибка при загрузке статистики');
      console.error('Ошибка при загрузке статистики:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStatistics();
  }, [adminPassword]);

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('ru-RU', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 6
    }).format(amount);
  };

  if (loading && !statistics) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-center p-12">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-4 animate-pulse">
              <BarChart3 className="w-8 h-8 text-white" />
            </div>
            <RefreshCw className="w-6 h-6 animate-spin text-blue-600 dark:text-blue-400 mx-auto mb-2" />
            <span className="text-slate-600 dark:text-slate-300 font-medium">Загрузка аналитики...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Enhanced Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center shadow-lg">
            <BarChart3 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400 text-transparent bg-clip-text">
              Аналитика платформы
            </h2>
            <p className="text-slate-600 dark:text-slate-400">Детальная статистика операций и активности</p>
          </div>
        </div>
        <Button
          onClick={loadStatistics}
          disabled={loading}
          variant="outline"
          className="bg-white/50 dark:bg-black/20 backdrop-blur-sm border-slate-300 dark:border-slate-600 hover:bg-blue-50 dark:hover:bg-blue-900/20"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Обновить
        </Button>
      </div>

      {error && (
        <Alert className="backdrop-blur-sm border-0 bg-red-500/20 text-red-800 dark:text-red-200">
          <AlertDescription className="font-medium">
            {error}
          </AlertDescription>
        </Alert>
      )}

      {statistics && (
        <>
          {/* Enhanced Main Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {/* Депозиты */}
            <Card className="backdrop-blur-xl bg-gradient-to-br from-green-500/10 to-emerald-500/10 dark:from-green-500/20 dark:to-emerald-500/20 border-green-200/50 dark:border-green-400/30 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center shadow-lg">
                    <ArrowUpCircle className="w-6 h-6 text-white" />
                  </div>
                  <Badge className="bg-green-100 dark:bg-green-900/50 text-green-800 dark:text-green-200 border-green-300 dark:border-green-600">
                    Приход
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-green-700 dark:text-green-400 font-medium mb-1">Депозиты</p>
                  <p className="text-2xl font-bold text-green-800 dark:text-green-200 mb-1">
                    {statistics.deposits.total_count}
                  </p>
                  <p className="text-sm text-green-600 dark:text-green-400">
                    {formatAmount(statistics.deposits.total_amount)} TON
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Выводы */}
            <Card className="backdrop-blur-xl bg-gradient-to-br from-red-500/10 to-pink-500/10 dark:from-red-500/20 dark:to-pink-500/20 border-red-200/50 dark:border-red-400/30 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-pink-500 rounded-xl flex items-center justify-center shadow-lg">
                    <ArrowDownCircle className="w-6 h-6 text-white" />
                  </div>
                  <Badge className="bg-red-100 dark:bg-red-900/50 text-red-800 dark:text-red-200 border-red-300 dark:border-red-600">
                    Расход
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-red-700 dark:text-red-400 font-medium mb-1">Выводы</p>
                  <p className="text-2xl font-bold text-red-800 dark:text-red-200 mb-1">
                    {statistics.withdrawals.total_count}
                  </p>
                  <p className="text-sm text-red-600 dark:text-red-400">
                    {formatAmount(statistics.withdrawals.total_amount)} TON
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Споры */}
            <Card className="backdrop-blur-xl bg-gradient-to-br from-blue-500/10 to-cyan-500/10 dark:from-blue-500/20 dark:to-cyan-500/20 border-blue-200/50 dark:border-blue-400/30 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg">
                    <Target className="w-6 h-6 text-white" />
                  </div>
                  <Badge className="bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-200 border-blue-300 dark:border-blue-600">
                    Споры
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-blue-700 dark:text-blue-400 font-medium mb-1">Исполнено</p>
                  <p className="text-2xl font-bold text-blue-800 dark:text-blue-200 mb-1">
                    {statistics.disputes.total_completed}
                  </p>
                  <p className="text-sm text-blue-600 dark:text-blue-400">
                    Возвращено: {statistics.disputes.total_refunded}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Чистый поток */}
            <Card className={`backdrop-blur-xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 ${
              statistics.summary.net_flow >= 0
                ? 'bg-gradient-to-br from-emerald-500/10 to-green-500/10 dark:from-emerald-500/20 dark:to-green-500/20 border-emerald-200/50 dark:border-emerald-400/30'
                : 'bg-gradient-to-br from-red-500/10 to-orange-500/10 dark:from-red-500/20 dark:to-orange-500/20 border-red-200/50 dark:border-red-400/30'
            }`}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center shadow-lg ${
                    statistics.summary.net_flow >= 0
                      ? 'bg-gradient-to-br from-emerald-500 to-green-500'
                      : 'bg-gradient-to-br from-red-500 to-orange-500'
                  }`}>
                    {statistics.summary.net_flow >= 0 ? (
                      <TrendingUp className="w-6 h-6 text-white" />
                    ) : (
                      <TrendingDown className="w-6 h-6 text-white" />
                    )}
                  </div>
                  <Badge className={
                    statistics.summary.net_flow >= 0
                      ? 'bg-emerald-100 dark:bg-emerald-900/50 text-emerald-800 dark:text-emerald-200 border-emerald-300 dark:border-emerald-600'
                      : 'bg-red-100 dark:bg-red-900/50 text-red-800 dark:text-red-200 border-red-300 dark:border-red-600'
                  }>
                    {statistics.summary.net_flow >= 0 ? 'Прибыль' : 'Убыток'}
                  </Badge>
                </div>
                <div>
                  <p className={`text-sm font-medium mb-1 ${
                    statistics.summary.net_flow >= 0
                      ? 'text-emerald-700 dark:text-emerald-400'
                      : 'text-red-700 dark:text-red-400'
                  }`}>Чистый поток</p>
                  <p className={`text-2xl font-bold mb-1 ${
                    statistics.summary.net_flow >= 0
                      ? 'text-emerald-800 dark:text-emerald-200'
                      : 'text-red-800 dark:text-red-200'
                  }`}>
                    {statistics.summary.net_flow >= 0 ? '+' : ''}{formatAmount(statistics.summary.net_flow)}
                  </p>
                  <p className={`text-sm ${
                    statistics.summary.net_flow >= 0
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-red-600 dark:text-red-400'
                  }`}>TON</p>
                </div>
              </CardContent>
            </Card>

            {/* Объем платформы */}
            <Card className="backdrop-blur-xl bg-gradient-to-br from-purple-500/10 to-indigo-500/10 dark:from-purple-500/20 dark:to-indigo-500/20 border-purple-200/50 dark:border-purple-400/30 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-xl flex items-center justify-center shadow-lg">
                    <DollarSign className="w-6 h-6 text-white" />
                  </div>
                  <Badge className="bg-purple-100 dark:bg-purple-900/50 text-purple-800 dark:text-purple-200 border-purple-300 dark:border-purple-600">
                    Оборот
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-purple-700 dark:text-purple-400 font-medium mb-1">Объем ставок</p>
                  <p className="text-2xl font-bold text-purple-800 dark:text-purple-200 mb-1">
                    {formatAmount(statistics.summary.total_platform_volume)}
                  </p>
                  <p className="text-sm text-purple-600 dark:text-purple-400">TON</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Enhanced Detailed Statistics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Статистика по спорам */}
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-black/40 border-white/50 dark:border-white/10 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-xl">
                  <div className="w-8 h-8 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-lg flex items-center justify-center">
                    <Trophy className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-slate-800 dark:text-slate-200">Результаты споров</span>
                </CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  Детальная статистика участников в исполненных спорах
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Выигрышные споры */}
                  <div className="p-4 bg-gradient-to-r from-green-50/80 to-emerald-50/80 dark:from-green-900/40 dark:to-emerald-900/40 rounded-xl border border-green-200/50 dark:border-green-700/50">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-500 rounded-lg flex items-center justify-center">
                          <Trophy className="w-5 h-5 text-white" />
                        </div>
                        <span className="font-semibold text-green-800 dark:text-green-200">Выигрышные транзакции</span>
                      </div>
                      <Badge className="bg-green-200 dark:bg-green-800 text-green-800 dark:text-green-200">
                        {statistics.disputes.won_disputes}
                      </Badge>
                    </div>
                    <p className="text-sm text-green-700 dark:text-green-300 font-medium">
                      Сумма выигрышей: {formatAmount(statistics.disputes.total_won_amount)} TON
                    </p>
                  </div>

                  {/* Проигрышные споры */}
                  <div className="p-4 bg-gradient-to-r from-red-50/80 to-pink-50/80 dark:from-red-900/40 dark:to-pink-900/40 rounded-xl border border-red-200/50 dark:border-red-700/50">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-pink-500 rounded-lg flex items-center justify-center">
                          <X className="w-5 h-5 text-white" />
                        </div>
                        <span className="font-semibold text-red-800 dark:text-red-200">Проигрышные участия</span>
                      </div>
                      <Badge className="bg-red-200 dark:bg-red-800 text-red-800 dark:text-red-200">
                        {statistics.disputes.lost_disputes}
                      </Badge>
                    </div>
                  </div>

                  {/* Уникальные победители */}
                  <div className="p-4 bg-gradient-to-r from-blue-50/80 to-cyan-50/80 dark:from-blue-900/40 dark:to-cyan-900/40 rounded-xl border border-blue-200/50 dark:border-blue-700/50">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
                          <Users className="w-5 h-5 text-white" />
                        </div>
                        <span className="font-semibold text-blue-800 dark:text-blue-200">Уникальные победители</span>
                      </div>
                      <Badge className="bg-blue-200 dark:bg-blue-800 text-blue-800 dark:text-blue-200">
                        {statistics.disputes.unique_winners}
                      </Badge>
                    </div>
                  </div>

                  {/* Общая статистика */}
                  <div className="pt-4 border-t border-slate-200 dark:border-slate-700">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                        <span className="font-medium text-slate-800 dark:text-slate-200 block">Всего участий:</span>
                        <span className="text-slate-600 dark:text-slate-400">{statistics.disputes.detailed_stats.total_participations}</span>
                      </div>
                      <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                        <span className="font-medium text-slate-800 dark:text-slate-200 block">Участников:</span>
                        <span className="text-slate-600 dark:text-slate-400">{statistics.disputes.unique_participants}</span>
                      </div>
                      <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                        <span className="font-medium text-slate-800 dark:text-slate-200 block">Объем ставок:</span>
                        <span className="text-slate-600 dark:text-slate-400">{formatAmount(statistics.disputes.total_bet_amount)} TON</span>
                      </div>
                      <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                        <span className="font-medium text-slate-800 dark:text-slate-200 block">Возвращено:</span>
                        <span className="text-slate-600 dark:text-slate-400">{formatAmount(statistics.disputes.total_refund_amount)} TON</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Депозиты через Stars */}
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-black/40 border-white/50 dark:border-white/10 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-xl">
                  <div className="w-8 h-8 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-lg flex items-center justify-center">
                    <Star className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-slate-800 dark:text-slate-200">Telegram Stars</span>
                </CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  Статистика конвертации Stars в TON
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 gap-4">
                    <div className="p-4 bg-gradient-to-r from-yellow-50/80 to-orange-50/80 dark:from-yellow-900/40 dark:to-orange-900/40 rounded-xl border border-yellow-200/50 dark:border-yellow-700/50">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-yellow-700 dark:text-yellow-300 font-medium">Количество конвертаций</span>
                        <span className="text-xl font-bold text-yellow-800 dark:text-yellow-200">{statistics.deposits.stars_conversions.count}</span>
                      </div>
                    </div>

                    <div className="p-4 bg-gradient-to-r from-orange-50/80 to-red-50/80 dark:from-orange-900/40 dark:to-red-900/40 rounded-xl border border-orange-200/50 dark:border-orange-700/50">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-orange-700 dark:text-orange-300 font-medium">Общая сумма</span>
                        <span className="text-xl font-bold text-orange-800 dark:text-orange-200">{formatAmount(statistics.deposits.stars_conversions.amount)} TON</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-200 dark:border-slate-700">
                    <div className="p-4 bg-slate-50/80 dark:bg-slate-800/50 rounded-xl">
                      <p className="text-sm text-slate-700 dark:text-slate-300 font-medium">
                        {statistics.deposits.stars_conversions.count > 0
                          ? `Средняя конвертация: ${formatAmount(statistics.deposits.stars_conversions.amount / statistics.deposits.stars_conversions.count)} TON`
                          : 'Конвертаций пока не было'
                        }
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Enhanced Transaction Types */}
          {statistics.transactions && statistics.transactions.length > 0 && (
            <Card className="backdrop-blur-xl bg-white/80 dark:bg-black/40 border-white/50 dark:border-white/10 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-xl">
                  <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-lg flex items-center justify-center">
                    <Activity className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-slate-800 dark:text-slate-200">Типы транзакций</span>
                </CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  Детализация всех операций в системе
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {statistics.transactions.map((transaction, index) => (
                    <div key={index} className="p-4 bg-gradient-to-br from-slate-50/80 to-white/80 dark:from-slate-800/50 dark:to-slate-700/50 rounded-xl border border-slate-200/50 dark:border-slate-600/50 hover:shadow-lg transition-all duration-300 hover:scale-105">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-lg flex items-center justify-center">
                          <Coins className="w-4 h-4 text-white" />
                        </div>
                        <div className="flex-1">
                          <span className="font-medium text-slate-800 dark:text-slate-200 capitalize block">
                            {transaction.transaction_type}
                          </span>
                          <Badge variant="outline" className="bg-indigo-100 dark:bg-indigo-900/50 text-indigo-800 dark:text-indigo-200 border-indigo-300 dark:border-indigo-600">
                            {transaction.count} операций
                          </Badge>
                        </div>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-400 font-medium">
                        Сумма: {formatAmount(parseFloat(transaction.total_amount))} TON
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
