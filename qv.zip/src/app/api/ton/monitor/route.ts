import { NextRequest, NextResponse } from 'next/server';
import { transactionMonitor } from '@/lib/ton-transaction-monitor';

export async function GET() {
  try {
    if (!transactionMonitor) {
      return NextResponse.json({
        error: 'Transaction monitor not configured'
      }, { status: 500 });
    }

    const stats = await transactionMonitor.getStats();

    return NextResponse.json({
      success: true,
      stats,
      isRunning: true // В реальности нужно отслеживать статус
    });

  } catch (error) {
    console.error('Error getting monitor stats:', error);
    return NextResponse.json({
      error: 'Internal server error'
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { action } = await request.json();

    if (!transactionMonitor) {
      return NextResponse.json({
        error: 'Transaction monitor not configured'
      }, { status: 500 });
    }

    switch (action) {
      case 'start':
        transactionMonitor.start();
        return NextResponse.json({
          success: true,
          message: 'Monitor started'
        });

      case 'stop':
        transactionMonitor.stop();
        return NextResponse.json({
          success: true,
          message: 'Monitor stopped'
        });

      default:
        return NextResponse.json({
          error: 'Invalid action'
        }, { status: 400 });
    }

  } catch (error) {
    console.error('Error managing monitor:', error);
    return NextResponse.json({
      error: 'Internal server error'
    }, { status: 500 });
  }
}
