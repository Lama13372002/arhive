/**
 * TON Withdrawal Service
 * Обрабатывает выводы TON через блокчейн
 */

import { TonClient, WalletContractV4, Address, beginCell, toNano, internal } from '@ton/ton';
import { mnemonicToWalletKey } from '@ton/crypto';

interface WithdrawalRequest {
  id: number;
  telegram_id: number;
  amount: number;
  net_amount: number;
  target_wallet: string;
  status: string;
}

class TonWithdrawalService {
  private tonClient: TonClient;
  private walletMnemonic: string;
  private isTestnet: boolean;

  constructor() {
    this.isTestnet = process.env.TON_NETWORK === 'testnet';

    // Используем TonCenter с API ключом
    this.tonClient = new TonClient({
      endpoint: this.isTestnet
        ? 'https://testnet.toncenter.com/api/v2/jsonRPC'
        : 'https://toncenter.com/api/v2/jsonRPC',
      apiKey: process.env.TON_API_KEY
    });

    this.walletMnemonic = process.env.TON_WALLET_MNEMONIC || '';

    if (!this.walletMnemonic) {
      console.warn('TON_WALLET_MNEMONIC not configured. Withdrawal service will not work.');
    }

    console.log('TonWithdrawalService initialized:');
    console.log('- Network:', this.isTestnet ? 'testnet' : 'mainnet');
    console.log('- Endpoint:', this.isTestnet
      ? 'https://testnet.toncenter.com/api/v2/jsonRPC'
      : 'https://toncenter.com/api/v2/jsonRPC');
    console.log('- Mnemonic configured:', !!this.walletMnemonic);
  }

  async processWithdrawal(request: WithdrawalRequest): Promise<{ success: boolean; txHash?: string; error?: string }> {
    try {
      console.log(`Processing withdrawal ${request.id} for ${request.net_amount} TON to ${request.target_wallet}`);

      if (!this.walletMnemonic) {
        throw new Error('Wallet mnemonic not configured');
      }

      // Проверяем валидность адреса получателя
      let destinationAddress: Address;
      try {
        destinationAddress = Address.parse(request.target_wallet);
      } catch (error) {
        throw new Error('Invalid destination wallet address');
      }

      // Создаем кошелек отправителя
      const key = await mnemonicToWalletKey(this.walletMnemonic.split(' '));
      const wallet = WalletContractV4.create({ workchain: 0, publicKey: key.publicKey });
      const contract = this.tonClient.open(wallet);

      // Проверяем баланс кошелька
      const balance = await contract.getBalance();
      const amountToSend = toNano(request.net_amount.toString());
      const minBalance = toNano('0.1'); // Минимальный остаток для комиссий

      console.log('Balance check details:');
      console.log('- Current balance (nanoTON):', balance.toString());
      console.log('- Amount to send (nanoTON):', amountToSend.toString());
      console.log('- Min balance (nanoTON):', minBalance.toString());
      console.log('- Required total (nanoTON):', (amountToSend + minBalance).toString());
      console.log('- Current balance (TON):', parseFloat((Number(balance) / 1000000000).toFixed(9)));
      console.log('- Required total (TON):', parseFloat((Number(amountToSend + minBalance) / 1000000000).toFixed(9)));

      if (balance < amountToSend + minBalance) {
        const currentBalanceTon = parseFloat((Number(balance) / 1000000000).toFixed(9));
        const requiredTotalTon = parseFloat((Number(amountToSend + minBalance) / 1000000000).toFixed(9));
        throw new Error(`Insufficient balance in withdrawal wallet. Available: ${currentBalanceTon} TON, Required: ${requiredTotalTon} TON`);
      }

      // Создаем и отправляем транзакцию
      const seqno = await contract.getSeqno();

      const transfer = await contract.createTransfer({
        seqno,
        secretKey: key.secretKey,
        messages: [internal({
          to: destinationAddress,
          value: amountToSend,
          body: beginCell()
            .storeUint(0, 32)
            .storeStringTail(`Withdrawal #${request.id}`)
            .endCell(),
        })]
      });

      await contract.send(transfer);

      // Ждем подтверждения транзакции
      let currentSeqno = seqno;
      const maxRetries = 30; // Максимум 30 попыток (примерно 5 минут)
      let retries = 0;

      while (currentSeqno == seqno && retries < maxRetries) {
        console.log(`Waiting for transaction confirmation... ${retries + 1}/${maxRetries}`);
        await new Promise(resolve => setTimeout(resolve, 10000)); // Ждем 10 секунд
        currentSeqno = await contract.getSeqno();
        retries++;
      }

      if (currentSeqno == seqno) {
        throw new Error('Transaction confirmation timeout');
      }

      // TODO: Получить хеш транзакции из блокчейна
      // Для упрощения используем временный хеш
      const txHash = `tx_${Date.now()}_${request.id}`;

      console.log(`Withdrawal ${request.id} completed successfully. TX: ${txHash}`);

      return {
        success: true,
        txHash
      };

    } catch (error) {
      console.error(`Error processing withdrawal ${request.id}:`, error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  async validateWalletAddress(address: string): Promise<boolean> {
    try {
      Address.parse(address);
      return true;
    } catch {
      return false;
    }
  }

  async getWalletBalance(): Promise<number> {
    try {
      if (!this.walletMnemonic) {
        console.error('TON_WALLET_MNEMONIC not configured');
        return 0;
      }

      console.log('Getting wallet balance...');
      console.log('Network:', this.isTestnet ? 'testnet' : 'mainnet');

      const key = await mnemonicToWalletKey(this.walletMnemonic.split(' '));
      const wallet = WalletContractV4.create({ workchain: 0, publicKey: key.publicKey });
      const contract = this.tonClient.open(wallet);

      console.log('Wallet address:', wallet.address.toString());

      // Повторные попытки с задержкой
      let balance;
      let attempts = 0;
      const maxAttempts = 3;
      const delayMs = 2000;

      while (attempts < maxAttempts) {
        try {
          attempts++;
          console.log(`Balance check attempt ${attempts}/${maxAttempts}...`);

          balance = await contract.getBalance();
          break; // Успешно получили баланс

        } catch (error) {
          console.log(`Balance check attempt ${attempts} failed:`, error instanceof Error ? error.message : 'Unknown error');

          if (attempts < maxAttempts) {
            console.log(`Waiting ${delayMs}ms before retry...`);
            await new Promise(resolve => setTimeout(resolve, delayMs));
          } else {
            throw error;
          }
        }
      }

      // Проверяем, что баланс был получен
      if (balance === undefined) {
        throw new Error('Failed to get wallet balance after all attempts');
      }

      // Правильная конвертация из nanoTON в TON
      const balanceInTon = parseFloat((Number(balance) / 1000000000).toFixed(9));

      console.log('Raw balance (nanoTON):', balance.toString());
      console.log('Balance in TON:', balanceInTon);

      return balanceInTon;
    } catch (error) {
      console.error('Error getting wallet balance:', error);
      console.error('Error details:', {
        message: error instanceof Error ? error.message : 'Unknown error',
        stack: error instanceof Error ? error.stack : undefined
      });
      return 0;
    }
  }
}

export const tonWithdrawalService = new TonWithdrawalService();
