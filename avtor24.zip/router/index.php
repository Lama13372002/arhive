<?php
session_start();
/*ini_set('error_reporting', E_ALL);*/
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
require_once   '../vendor/autoload.php';
require_once    '../backend/Controller.php';
require_once    '../backend/camelStr.php';
require_once   '../phpQuery/phpQuery.php';
use Controller\Controller;
use camel\camelStr;

$camel = new camelStr();

//echo $url;
$url2 = ((!empty($_SERVER['HTTPS'])) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$url2 = explode('?', $url2);
$url2 = $url2[0];
$parse = parse_url($url2);
$path = $parse['path'];
$pathMethod = str_replace('/panel/','',$path);
$mathMethod = explode('/',$pathMethod);
$nameMethod = str_replace('/','_',$pathMethod);
$camelMethod = $camel->camelCase($nameMethod);
$controller = new Controller($camelMethod);
//$method= $parse[0];
if(method_exists($controller,$camelMethod)){
    $result =  $controller->$camelMethod();
    echo $result;
    exit;
}else{
    echo json_encode(['error'=>'ошибка '.$camelMethod]);
}