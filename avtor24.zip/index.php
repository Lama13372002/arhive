<?php
require_once  __DIR__ . '/header.php';
?>
<style>
    .action_but{
        cursor: pointer;
    }
    .wrap-log-in {
        height: 100%;
    }
    .log-in input {
        padding: 7px;
        font-size: 18px;
        border-radius: 5px;
        margin-bottom: 10px;
    }
    .log-in input[type=submit] {
       cursor: pointer;
    }
    .bet-button {
        padding: 6px;
        border: 2px solid black;
        border-radius: 6px;
        max-width: 276px;
        width: 100%;
        text-align: center;
        background: #29579b;
        color: white;
        margin-bottom: 10px;
        font-size: 16px;
        cursor: pointer;
    }
</style>
<div class="wrap-log-in flex-cen-c">
    <div class="log-in">
        <div class="wrap-logo-form">
                <h2 class="logo-form"></h2>
        </div>
        <a href="/panel">
            <div class="bet-button">
                Панель
            </div>
        </a>
        <form id="submit_form" action="log_in">
            <div class="input-login">
                <input type="text" name="email" required placeholder="логин">
            </div>
            <div class="input-login">
                <input type="text" name="password" required placeholder="пароль">
            </div>
            <input type="submit" class="" value="Войти" >
            <!--<div class="action-but" data-action="common_action" data-action_name="log_in">rrrrrr</div>-->
        </form>


    </div>
</div>

<?php
require_once  'footer.php';
?>
