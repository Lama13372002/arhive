<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Фильтр</title>
</head>
<body>
<style>
    .settings__formBlock  {
        display: flex;
        flex-wrap: wrap;
    }
    .settings__checkboxWrap-all {
        margin-bottom: 10px;

        border: 1px solid black;
        border-radius: 5px;
        padding: 2px;
    }
    .settings__checkboxWrap {
        margin-bottom: 10px;
        margin-right: 70px;
        border: 1px solid black;
        border-radius: 5px;
        padding: 2px;
    }
    .settings__checkboxWrap {
        cursor: pointer;
    }
    .withdraw__item-title {
        margin-bottom: 15px;
    }
    .settings-sub__tabs-content .settings__checkboxWrap-all {
        background: blue;
        color: white;
    }
    .block-setting {
        border: 1px solid black;
        border-radius: 2px;
        padding: 13px;
        margin-right: 25px;
        margin-bottom: 21px;
    }
    .wrap-block-setting {
        display: flex;
        flex-wrap: wrap;
    }
    .save-filter {
        cursor: pointer;
        text-align: center;
        background: #0000ff;
        color: white;
    }
    .flex-cen-c {
        display: flex;
        align-items: center;
    }

</style>
<div class="parent-my_filter">
    <div class="wrap-block-setting">
            <div class=" block-setting styled__DropdownStyled-iqpw5i-1 ccmtwY" style="height: auto;">
            <div class="styled__Header-iqpw5i-2 MAPML">
                <p class="styled__Title-iqpw5i-3 kpugsE">
                    <span>Бюджет, ₽</span> <span class="styled__Counter-sc-53z891-2 dtSrwh"  >0 - 200 000</span></p>
            </div>
            <div class="styled__Content-iqpw5i-0 eLFjxg">
                <div class="styled__Container-cxcpiv-0 dhrgcd">
                    <div class="styled__Controls-cxcpiv-2 cFgbAc">
                        <div class="styled__Container-sc-1vfbom1-2 chIDpt"><span class="styled__Prefix-sc-1vfbom1-0 brjXcb">от</span><input
                                    class="styled__Input-sc-1vfbom1-3 hTcKZz"></div>
                        <div class="styled__Divider-cxcpiv-3 foNjkY">—</div>
                        <div class="styled__Container-sc-1vfbom1-2 chIDpt"><span class="styled__Prefix-sc-1vfbom1-0 brjXcb">до</span><input
                                    class="styled__Input-sc-1vfbom1-3 hTcKZz"></div>
                    </div>
                </div>
            </div>
        </div>

            <div class="block-setting styled__DropdownStyled-iqpw5i-1 ccmtwY" style="height: auto;">
                <div class="styled__Header-iqpw5i-2 MAPML">
                    <p class="styled__Title-iqpw5i-3 kpugsE">
                        <span>Срок сдачи, дни</span><span class="styled__Counter-sc-53z891-2 dtSrwh" >0 - 365</span></p>
                    </div>
                <div class="styled__Content-iqpw5i-0 eLFjxg">
                    <div class="styled__Container-cxcpiv-0 dhrgcd">

                        <div class="styled__Controls-cxcpiv-2 cFgbAc">
                            <div class="styled__Container-sc-1vfbom1-2 chIDpt"><span
                                        class="styled__Prefix-sc-1vfbom1-0 brjXcb">от</span><input
                                        class="styled__Input-sc-1vfbom1-3 hTcKZz"></div>
                            <div class="styled__Divider-cxcpiv-3 foNjkY">—</div>
                            <div class="styled__Container-sc-1vfbom1-2 chIDpt"><span
                                        class="styled__Prefix-sc-1vfbom1-0 brjXcb">до</span><input
                                        class="styled__Input-sc-1vfbom1-3 hTcKZz"></div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="block-setting styled__DropdownStyled-iqpw5i-1 ccmtwY" style="height: auto;">
                <div class="styled__Header-iqpw5i-2 MAPML">
                    <p class="styled__Title-iqpw5i-3 kpugsE">
                        <span>Ставок в заказе</span> <span class="styled__Counter-sc-53z891-2 dtSrwh" >0 -
                            200</span></p>
                    </div>
                <div class="styled__Content-iqpw5i-0 eLFjxg">
                    <div class="styled__Container-sc-97gqik-0 iLylFx">
                        <div>
                            <div class="styled__Container-cxcpiv-0 dhrgcd">

                                <div class="styled__Controls-cxcpiv-2 cFgbAc">
                                    <div class="styled__Container-sc-1vfbom1-2 chIDpt"><span
                                                class="styled__Prefix-sc-1vfbom1-0 brjXcb">от</span><input
                                                class="styled__Input-sc-1vfbom1-3 hTcKZz"></div>
                                    <div class="styled__Divider-cxcpiv-3 foNjkY">—</div>
                                    <div class="styled__Container-sc-1vfbom1-2 chIDpt"><span
                                                class="styled__Prefix-sc-1vfbom1-0 brjXcb">до</span><input
                                                class="styled__Input-sc-1vfbom1-3 hTcKZz"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="block-setting styled__DropdownStyled-iqpw5i-1 ccmtwY" style="height: auto;">
                <div class="styled__Header-iqpw5i-2 MAPML">
                    <p class="styled__Title-iqpw5i-3 kpugsE">

                        <span>Уникальность, %</span> <span class="styled__Counter-sc-53z891-2 dtSrwh" >0 - 100</span></p>
                </div>
                <div class="styled__Content-iqpw5i-0 eLFjxg">
                    <div class="styled__Container-cxcpiv-0 dhrgcd">

                        <div class="styled__Controls-cxcpiv-2 cFgbAc">
                            <div class="styled__Container-sc-1vfbom1-2 chIDpt"><span
                                        class="styled__Prefix-sc-1vfbom1-0 brjXcb">от</span><input
                                        class="styled__Input-sc-1vfbom1-3 hTcKZz"></div>
                            <div class="styled__Divider-cxcpiv-3 foNjkY">—</div>
                            <div class="styled__Container-sc-1vfbom1-2 chIDpt"><span
                                        class="styled__Prefix-sc-1vfbom1-0 brjXcb">до</span><input
                                        class="styled__Input-sc-1vfbom1-3 hTcKZz"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="save-filter block-setting styled__DropdownStyled-iqpw5i-1 ccmtwY flex-cen-c"  >
                <div class="save-filter but-action" data-actio="my_filter"  >
                    Сохранить
                </div>
            </div>
        <div class="message-save ">

        </div>
    </div>


    <div class="wrap-filter-page">
        <div class="withdraw__item" id="workTypesBlock">

            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <input type="hidden" name="is_worktype_form" value="1">

                <div class="withdraw__item-title">Выполняемые типы работы</div><a href="#" name="type_works" id="type_works"></a>
                <div>
                    <div class="settings__tabs-content" id="settings__tabs-1">
                        <div class=" settings__checkboxWrap-all">
                            <!--<div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" data-actiontype="select_block" data-id="worktypeBlock" id="forWorktypeBlock" name="alltype"></div><label for="forWorktypeBlock">Выбрать все типы работ</label></div>-->
                        <div class="settings__formBlock bb" id="worktypeBlock">
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="worktype[]" value="11" checked="checked" id="worktype_11"></div> <label for="worktype_11">Решение задач</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="2" id="worktype_2"></div> <label for="worktype_2">Курсовая работа</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="worktype[]" value="9" checked="checked" id="worktype_9"></div> <label for="worktype_9">Контрольная работа</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="worktype[]" value="21" checked="checked" id="worktype_21"></div> <label for="worktype_21">Другое</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="3" id="worktype_3"></div> <label for="worktype_3">Реферат</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="worktype[]" value="13" checked="checked" id="worktype_13"></div> <label for="worktype_13">Ответы на вопросы</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="worktype[]" value="19" checked="checked" id="worktype_19"></div> <label for="worktype_19">Презентации</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="5" id="worktype_5"></div> <label for="worktype_5">Отчёт по практике</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="worktype[]" value="89" checked="checked" id="worktype_89"></div> <label for="worktype_89">Помощь on-line</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="1" id="worktype_1"></div> <label for="worktype_1">Дипломная работа</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="worktype[]" value="15" checked="checked" id="worktype_15"></div> <label for="worktype_15">Эссе</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="126" id="worktype_126"></div> <label for="worktype_126">Выпускная квалификационная работа</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="7" id="worktype_7"></div> <label for="worktype_7">Доклад</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="6" id="worktype_6"></div> <label for="worktype_6">Статья</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="56" id="worktype_56"></div> <label for="worktype_56">Лабораторная работа</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="14" id="worktype_14"></div> <label for="worktype_14">Творческая работа</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="16" id="worktype_16"></div> <label for="worktype_16">Чертёж</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="worktype[]" value="22" checked="checked" id="worktype_22"></div> <label for="worktype_22">Повышение уникальности текста</label>
                            </div>
                            <div class="settings__checkboxWrap w50" style="pointer-events: none; opacity: 0.3;">
                                <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="worktype[]" value="127"  id="worktype_127"></div> <label for="worktype_127">Задача по программированию</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="worktype[]" value="20" checked="checked" id="worktype_20"></div> <label for="worktype_20">Набор текста</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="worktype[]" value="24" checked="checked" id="worktype_24"></div> <label for="worktype_24">Копирайтинг</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="worktype[]" value="124" checked="checked" id="worktype_124"></div> <label for="worktype_124">Подбор темы работы</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="4" id="worktype_4"></div> <label for="worktype_4">Магистерская диссертация</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="17" id="worktype_17"></div> <label for="worktype_17">Сочинения</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="worktype[]" value="123" checked="checked" id="worktype_123"></div> <label for="worktype_123">Вычитка и рецензирование работ</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="worktype[]" value="18" checked="checked" id="worktype_18"></div> <label for="worktype_18">Перевод</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="8" id="worktype_8"></div> <label for="worktype_8">Рецензия</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="125" id="worktype_125"></div> <label for="worktype_125">Маркетинговое исследование</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="12" id="worktype_12"></div> <label for="worktype_12">Бизнес-план</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="23" id="worktype_23"></div> <label for="worktype_23">Кандидатская диссертация</label>
                            </div>
                            <div class="settings__checkboxWrap w50">
                                <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="worktype[]" value="10" id="worktype_10"></div> <label for="worktype_10">Монография</label>
                            </div>
                        </div>
                        <!--<div class="button-wrapper">
                            <div class="button blue settings__saveButton saveButton2 gray" data-qualification="true">Сохранить</div>
                            <div class="settings__loader"></div>
                        </div>-->
                    </div>
                </div>

            </form>

        </div>
    </div>
    <div class="withdraw__item" id="categoryTypesBlock">

        <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">

            <div class="withdraw__item-title">Выполняемые работы</div>
            <div>
                <div class="settings__tabs-content" id="settings__tabs-2">
                    <div id="settings-sub__tabs" class="ui-tabs ui-widget ui-widget-content ui-corner-all">
                        <!--<ul id="settings-sub__tabs-header" class="ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all" role="tablist">
                            <li class="ui-state-default ui-corner-top ui-tabs-active ui-state-active" role="tab" tabindex="0" aria-controls="settings-sub__tabs-Tehnicheskie" aria-labelledby="ui-id-2" aria-selected="true"><a class="settings-sub__tabs ui-tabs-anchor" href="#settings-sub__tabs-Tehnicheskie" role="presentation" tabindex="-1" id="ui-id-2">Технические</a></li>
                            <li class="ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-controls="settings-sub__tabs-Estestvennye" aria-labelledby="ui-id-3" aria-selected="false"><a class="settings-sub__tabs ui-tabs-anchor" href="#settings-sub__tabs-Estestvennye" role="presentation" tabindex="-1" id="ui-id-3">Естественные</a></li>
                            <li class="ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-controls="settings-sub__tabs-Gumanitarnye" aria-labelledby="ui-id-4" aria-selected="false"><a class="settings-sub__tabs ui-tabs-anchor" href="#settings-sub__tabs-Gumanitarnye" role="presentation" tabindex="-1" id="ui-id-4">Гуманитарные</a></li>
                            <li class="ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-controls="settings-sub__tabs-Ekonomicheskie" aria-labelledby="ui-id-5" aria-selected="false"><a class="settings-sub__tabs ui-tabs-anchor" href="#settings-sub__tabs-Ekonomicheskie" role="presentation" tabindex="-1" id="ui-id-5">Экономические</a></li>
                        </ul>-->
                        <div class="settings-sub__tabs-content ui-tabs-panel ui-widget-content ui-corner-bottom" id="settings-sub__tabs-Tehnicheskie" aria-labelledby="ui-id-2" role="tabpanel" aria-expanded="true" aria-hidden="false">
                            <div class="settings__checkboxWrap-all">
                                Технические
                            </div>
                            <div class="settings__formBlock bb" id="TehnicheskieBlock">
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="97" id="workcategory_97"></div> <label for="workcategory_97">Авиационная и ракетно-космическая техника</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="88" id="workcategory_88"></div> <label for="workcategory_88">Автоматизация технологических процессов</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="100" id="workcategory_100"></div> <label for="workcategory_100">Автоматика и управление</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="34" id="workcategory_34"></div> <label for="workcategory_34">Архитектура и строительство</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="114" id="workcategory_114"></div> <label for="workcategory_114">Базы данных</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="145" id="workcategory_145"></div> <label for="workcategory_145">Военное дело</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="27" id="workcategory_27"></div> <label for="workcategory_27">Высшая математика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="133" id="workcategory_133"></div> <label for="workcategory_133">Геометрия</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="129" id="workcategory_129"></div> <label for="workcategory_129">Гидравлика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="137" id="workcategory_137"></div> <label for="workcategory_137">Детали машин</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="149" id="workcategory_149"></div> <label for="workcategory_149">Железнодорожный транспорт</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="151" id="workcategory_151"></div> <label for="workcategory_151">Инженерные сети и оборудование</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="30" id="workcategory_30"></div> <label for="workcategory_30">Информатика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="89" id="workcategory_89"></div> <label for="workcategory_89">Информационная безопасность</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="86" id="workcategory_86"></div> <label for="workcategory_86">Информационные технологии</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="28" id="workcategory_28"></div> <label for="workcategory_28">Материаловедение</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="29" id="workcategory_29"></div> <label for="workcategory_29">Машиностроение</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="112" id="workcategory_112"></div> <label for="workcategory_112">Металлургия</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="136" id="workcategory_136"></div> <label for="workcategory_136">Метрология</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="31" id="workcategory_31"></div> <label for="workcategory_31">Механика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="153" id="workcategory_153"></div> <label for="workcategory_153">Микропроцессорная техника</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="131" id="workcategory_131"></div> <label for="workcategory_131">Начертательная геометрия</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="198" id="workcategory_198"></div> <label for="workcategory_198">Пожарная безопасность</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="99" id="workcategory_99"></div> <label for="workcategory_99">Приборостроение и оптотехника</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="32" id="workcategory_32"></div> <label for="workcategory_32">Программирование</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="33" id="workcategory_33"></div> <label for="workcategory_33">Процессы и аппараты</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="197" id="workcategory_197"></div> <label for="workcategory_197">Сварка и сварочное производство</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="132" id="workcategory_132"></div> <label for="workcategory_132">Сопротивление материалов</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="148" id="workcategory_148"></div> <label for="workcategory_148">Текстильная промышленность</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="128" id="workcategory_128"></div> <label for="workcategory_128">Теоретическая механика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="135" id="workcategory_135"></div> <label for="workcategory_135">Теория вероятностей</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="199" id="workcategory_199"></div> <label for="workcategory_199">Теория игр</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="41" id="workcategory_41"></div> <label for="workcategory_41">Теория машин и механизмов</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="90" id="workcategory_90"></div> <label for="workcategory_90">Теплоэнергетика и теплотехника</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="95" id="workcategory_95"></div> <label for="workcategory_95">Технологические машины и оборудование</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="101" id="workcategory_101"></div> <label for="workcategory_101">Технология продовольственных продуктов и товаров</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="35" id="workcategory_35"></div> <label for="workcategory_35">Транспортные средства</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="36" id="workcategory_36"></div> <label for="workcategory_36">Физика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="134" id="workcategory_134"></div> <label for="workcategory_134">Черчение</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="37" id="workcategory_37"></div> <label for="workcategory_37">Электроника, электротехника, радиотехника</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="93" id="workcategory_93"></div> <label for="workcategory_93">Энергетическое машиностроение</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="92" id="workcategory_92"></div> <label for="workcategory_92">Ядерные физика и технологии</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="159" id="workcategory_159"></div> <label for="workcategory_159">Другое</label>
                                </div>
                            </div>

                        </div>
                        <div class="settings-sub__tabs-content ui-tabs-panel ui-widget-content ui-corner-bottom"
                             id="settings-sub__tabs-Estestvennye" aria-labelledby="ui-id-3" role="tabpanel" aria-expanded="false" aria-hidden="true"  >
                            <div class="settings__checkboxWrap-all">
                                Естественные
                            </div>
                            <div class="settings__formBlock bb" id="EstestvennyeBlock">
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="200" id="workcategory_200"></div> <label for="workcategory_200">Агрохимия и агропочвоведение</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="18" id="workcategory_18"></div> <label for="workcategory_18">Астрономия</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="109" id="workcategory_109"></div> <label for="workcategory_109">Безопасность жизнедеятельности</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="20" id="workcategory_20"></div> <label for="workcategory_20">Биология</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="126" id="workcategory_126"></div> <label for="workcategory_126">Ветеринария</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="201" id="workcategory_201"></div> <label for="workcategory_201">Водные биоресурсы и аквакультура</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="21" id="workcategory_21"></div> <label for="workcategory_21">География</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="105" id="workcategory_105"></div> <label for="workcategory_105">Геодезия</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="26" id="workcategory_26"></div> <label for="workcategory_26">Геология</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="22" id="workcategory_22"></div> <label for="workcategory_22">Естествознание</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="203" id="workcategory_203"></div> <label for="workcategory_203">Землеустройство и кадастр</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="23" id="workcategory_23"></div> <label for="workcategory_23">Медицина</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="106" id="workcategory_106"></div> <label for="workcategory_106">Нефтегазовое дело</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="202" id="workcategory_202"></div> <label for="workcategory_202">Садоводство</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="152" id="workcategory_152"></div> <label for="workcategory_152">Фармация</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="24" id="workcategory_24"></div> <label for="workcategory_24">Химия</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="125" id="workcategory_125"></div> <label for="workcategory_125">Хирургия</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="25" id="workcategory_25"></div> <label for="workcategory_25">Экология</label>
                                </div>
                            </div>


                        </div>
                        <div class="settings-sub__tabs-content ui-tabs-panel ui-widget-content ui-corner-bottom"
                             id="settings-sub__tabs-Gumanitarnye" aria-labelledby="ui-id-4" role="tabpanel" aria-expanded="false" aria-hidden="true"  >
                            <div class="settings__checkboxWrap-all">
                                Гуманитарные
                            </div>
                            <div class="settings__formBlock bb" id="GumanitarnyeBlock">
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="146" id="workcategory_146"></div> <label for="workcategory_146">Актерское мастерство</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="158" id="workcategory_158"></div> <label for="workcategory_158">Английский язык</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="75" id="workcategory_75"></div> <label for="workcategory_75">Библиотечно-информационная деятельность</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="1" id="workcategory_1"></div> <label for="workcategory_1">Дизайн</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="74" checked="checked" id="workcategory_74"></div> <label for="workcategory_74">Документоведение и архивоведение</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="2" id="workcategory_2"></div> <label for="workcategory_2">Журналистика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="3" id="workcategory_3"></div> <label for="workcategory_3">Искусство</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="4" id="workcategory_4"></div> <label for="workcategory_4">История</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="157" id="workcategory_157"></div> <label for="workcategory_157">Китайский язык</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="73" id="workcategory_73"></div> <label for="workcategory_73">Конфликтология</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="150" id="workcategory_150"></div> <label for="workcategory_150">Краеведение</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="139" id="workcategory_139"></div> <label for="workcategory_139">Криминалистика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="156" id="workcategory_156"></div> <label for="workcategory_156">Кулинария</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="5" id="workcategory_5"></div> <label for="workcategory_5">Культурология</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="6" id="workcategory_6"></div> <label for="workcategory_6">Литература</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="113" id="workcategory_113"></div> <label for="workcategory_113">Логика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="7" checked="checked" id="workcategory_7"></div> <label for="workcategory_7">Международные отношения</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="81" id="workcategory_81"></div> <label for="workcategory_81">Музыка</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="196" id="workcategory_196"></div> <label for="workcategory_196">Немецкий язык</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="147" id="workcategory_147"></div> <label for="workcategory_147">Парикмахерское искусство</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="8" id="workcategory_8"></div> <label for="workcategory_8">Педагогика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="9" id="workcategory_9"></div> <label for="workcategory_9">Политология</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="11" id="workcategory_11"></div> <label for="workcategory_11">Право и юриспруденция</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="10" id="workcategory_10"></div> <label for="workcategory_10">Психология</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="76" id="workcategory_76"></div> <label for="workcategory_76">Режиссура</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="12" checked="checked" id="workcategory_12"></div> <label for="workcategory_12">Реклама и PR</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="138" id="workcategory_138"></div> <label for="workcategory_138">Религия</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="140" id="workcategory_140"></div> <label for="workcategory_140">Русский язык</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="127" checked="checked" id="workcategory_127"></div> <label for="workcategory_127">Связи с общественностью</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="124" id="workcategory_124"></div> <label for="workcategory_124">Социальная работа</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="13" id="workcategory_13"></div> <label for="workcategory_13">Социология</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="79" checked="checked" id="workcategory_79"></div> <label for="workcategory_79">Физическая культура</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="15" id="workcategory_15"></div> <label for="workcategory_15">Философия</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="195" id="workcategory_195"></div> <label for="workcategory_195">Французский язык</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="80" id="workcategory_80"></div> <label for="workcategory_80">Этика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="17" id="workcategory_17"></div> <label for="workcategory_17">Языки (переводы)</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="16" id="workcategory_16"></div> <label for="workcategory_16">Языкознание и филология</label>
                                </div>
                            </div>


                        </div>
                        <div class="settings-sub__tabs-content ui-tabs-panel ui-widget-content ui-corner-bottom"
                             id="settings-sub__tabs-Ekonomicheskie" aria-labelledby="ui-id-5" role="tabpanel" aria-expanded="false" aria-hidden="true"  >
                            <div class="settings__checkboxWrap-all">
                                Экономические
                            </div>
                            <div class="settings__formBlock bb" id="EkonomicheskieBlock">
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="47" checked="checked" id="workcategory_47"></div> <label for="workcategory_47">Анализ хозяйственной деятельности</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="43" checked="checked" id="workcategory_43"></div> <label for="workcategory_43">Антикризисное управление</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="44" checked="checked" id="workcategory_44"></div> <label for="workcategory_44">Банковское дело</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="61" id="workcategory_61"></div> <label for="workcategory_61">Бизнес-планирование</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="45" checked="checked" id="workcategory_45"></div> <label for="workcategory_45">Бухгалтерский учет и аудит</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="62" checked="checked" id="workcategory_62"></div> <label for="workcategory_62">Внешнеэкономическая деятельность</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="65" checked="checked" id="workcategory_65"></div> <label for="workcategory_65">Гостиничное дело</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="48" checked="checked" id="workcategory_48"></div> <label for="workcategory_48">Государственное и муниципальное управление</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="63" checked="checked" id="workcategory_63"></div> <label for="workcategory_63">Деньги</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="115" checked="checked" id="workcategory_115"></div> <label for="workcategory_115">Инвестиции</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="121" checked="checked" id="workcategory_121"></div> <label for="workcategory_121">Инновационный менеджмент</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="64" checked="checked" id="workcategory_64"></div> <label for="workcategory_64">Кредит</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="59" checked="checked" id="workcategory_59"></div> <label for="workcategory_59">Логистика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="50" checked="checked" id="workcategory_50"></div> <label for="workcategory_50">Маркетинг</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="52" checked="checked" id="workcategory_52"></div> <label for="workcategory_52">Менеджмент</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="120" checked="checked" id="workcategory_120"></div> <label for="workcategory_120">Менеджмент организации</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="53" checked="checked" id="workcategory_53"></div> <label for="workcategory_53">Микро-, макроэкономика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="54" checked="checked" id="workcategory_54"></div> <label for="workcategory_54">Налоги</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="67" checked="checked" id="workcategory_67"></div> <label for="workcategory_67">Организационное развитие</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="68" checked="checked" id="workcategory_68"></div> <label for="workcategory_68">Производственный маркетинг и менеджмент</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="141" id="workcategory_141"></div> <label for="workcategory_141">Рынок ценных бумаг</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="55" id="workcategory_55"></div> <label for="workcategory_55">Стандартизация</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="56" id="workcategory_56"></div> <label for="workcategory_56">Статистика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="70" checked="checked" id="workcategory_70"></div> <label for="workcategory_70">Стратегический менеджмент</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="57" checked="checked" id="workcategory_57"></div> <label for="workcategory_57">Страхование</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="60" checked="checked" id="workcategory_60"></div> <label for="workcategory_60">Таможенное дело</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="122" checked="checked" id="workcategory_122"></div> <label for="workcategory_122">Теория управления</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="66" checked="checked" id="workcategory_66"></div> <label for="workcategory_66">Товароведение</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="46" checked="checked" id="workcategory_46"></div> <label for="workcategory_46">Торговое дело</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="83" checked="checked" id="workcategory_83"></div> <label for="workcategory_83">Туризм</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="155" id="workcategory_155"></div> <label for="workcategory_155">Управление качеством</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="58" checked="checked" id="workcategory_58"></div> <label for="workcategory_58">Управление персоналом</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="154" checked="checked" id="workcategory_154"></div> <label for="workcategory_154">Управление проектами</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="118" checked="checked" id="workcategory_118"></div> <label for="workcategory_118">Финансовый менеджмент</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="72" checked="checked" id="workcategory_72"></div> <label for="workcategory_72">Финансы</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="85" checked="checked" id="workcategory_85"></div> <label for="workcategory_85">Ценообразование и оценка бизнеса</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="123" id="workcategory_123"></div> <label for="workcategory_123">Эконометрика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="71" checked="checked" id="workcategory_71"></div> <label for="workcategory_71">Экономика</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="116" checked="checked" id="workcategory_116"></div> <label for="workcategory_116">Экономика предприятия</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="84" checked="checked" id="workcategory_84"></div> <label for="workcategory_84">Экономика труда</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="117" checked="checked" id="workcategory_117"></div> <label for="workcategory_117">Экономическая теория</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="workcategory[]" value="119" checked="checked" id="workcategory_119"></div> <label for="workcategory_119">Экономический анализ</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="194" id="workcategory_194"></div> <label for="workcategory_194">EVIEWS</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="193" id="workcategory_193"></div> <label for="workcategory_193">SPSS</label>
                                </div>
                                <div class="settings__checkboxWrap">
                                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="workcategory[]" value="192" id="workcategory_192"></div> <label for="workcategory_192">STATA</label>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>

        </form>

    </div>
    <div class="withdraw__item settings-sub__tabs-content" id="block6">
        <form action=" " method="post" accept-charset="utf-8" enctype="multipart/form-data">
            <input type="hidden" name="is_languages_form" value="1">
            <div class="withdraw__item-title settings__checkboxWrap-all">Языки</div>
            <!--.settings-sub__tabs-content .settings__checkboxWrap-all-->
            <div class="settings__formBlock checked_languages " id="checked_languages">
                <div class="settings__checkboxWrap w50">
                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="languages[]" value="1" checked="checked" id="checked_languages_1"></div>
                    <label for="checked_languages_1">Русский</label>
                </div>
                <div class="settings__checkboxWrap w50">
                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="languages[]" value="2" id="checked_languages_2"></div>
                    <label for="checked_languages_2">Украинский</label>
                </div>
                <div class="settings__checkboxWrap w50">
                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="languages[]" value="3" id="checked_languages_3"></div>
                    <label for="checked_languages_3">Белорусский</label>
                </div>
                <div class="settings__checkboxWrap w50">
                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="languages[]" value="4" id="checked_languages_4"></div>
                    <label for="checked_languages_4">Казахский</label>
                </div>
                <div class="settings__checkboxWrap w50">
                    <div class="checkbox dynamicallyAddedCheckbox checked"><input type="checkbox" name="languages[]" value="5" checked="checked" id="checked_languages_5"></div>
                    <label for="checked_languages_5">Английский</label>
                </div>
                <div class="settings__checkboxWrap w50">
                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="languages[]" value="6" id="checked_languages_6"></div>
                    <label for="checked_languages_6">Немецкий</label>
                </div>
                <div class="settings__checkboxWrap w50">
                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="languages[]" value="7" id="checked_languages_7"></div>
                    <label for="checked_languages_7">Французский</label>
                </div>
                <div class="settings__checkboxWrap w50">
                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="languages[]" value="8" id="checked_languages_8"></div>
                    <label for="checked_languages_8">Итальянский</label>
                </div>
                <div class="settings__checkboxWrap w50">
                    <div class="checkbox dynamicallyAddedCheckbox"><input type="checkbox" name="languages[]" value="9" id="checked_languages_9"></div>
                    <label for="checked_languages_9">Испанский</label>
                </div>
            </div>

        </form>
    </div>
</div>
<?php
require_once  '../footer.php';
?>
<script>
    $(document).on('click','.settings__checkboxWrap',function (e) {

        let ch = $('input',this).prop('checked');
        if(ch){
            $('input',this).prop('checked', false);
        }else {
            $('input',this).prop('checked', true);
        }
    });
</script>
