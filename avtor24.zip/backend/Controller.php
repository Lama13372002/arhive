<?php
namespace Controller;
use Curl\Curl;
use phpQuery;

class Controller
{
    /**
     * @var false|\mysqli
     */
    private $CONNECT;
    public $cookieTable;
    public $betCount;
    public $betAllId;
    public $getUser;

    public $countRepit = 0;
    function __construct($active) {
        require_once "conetIBD.php";
        $this->CONNECT = mysqli_connect(HOST,USER,PASS,DB);
        if(!$active || $active !='logIn'){
            $this->avtorLoginActive();
        }
    }
    public function logIn(){
        if(!$_POST || !$_POST['email'] || !$_POST['password']) {
            $response['method']=['render_html'];
            $response['render_html']=[
                '.logo-form'=>'Введите данные',
            ];
        }

        if($user = $this->createUser($_POST['email'],$_POST['password'])){
            $response['method']=['render_html'];
            $response['render_html']=[
                '.logo-form'=>$user,
            ];
        }else{
            //успешно
            $response['method']=['redirect_js'];
            $response['redirect_js']='/panel';
        }


        return json_encode($response);
    }
    public function panel(){
        //получить активного пользователя
        if(!$user = $this->selecDataOne('system',['active'=>'1'])){
            return 'Ошибка входа panel <a href="/">Вход</a>   ';

        }
        //получит данные сколько ставок, данные user
        $user['bet'] = $this->queryBetCount();

        if($user['process']){
            $user['logo']='Идет процесс ставок';
        }else{
            $user['logo']='Процесс остановлен';
        }
        if($user['process_message']){
            $user['logo_message']='Бот установлен';
        }else{
            $user['logo_message']='Процесс остановлен';
        }

        //получить все сообщения пользователя
        $getMessageBlock = $this->selecData('telega',['id_user'=>$this->getUser['id']]);

        $user['message'] = $this->viewMessage($getMessageBlock);
        $getMessageBlockBet = $this->selecData('message',['id_user'=>$this->getUser['id']]);
        $user['message_bet'] = $this->viewMessage($getMessageBlockBet,'bet');
        $user['ajax'] = true;

        ob_start();
        include '../admin/index.php';
        $page = ob_get_clean();
        return $page;
    }
    public function filterSet(){
        //получить активного пользователя
        if(!$user = $this->selecDataOne('system',['active'=>'1'])){
            return 'Ошибка входа panel <a href="/">Вход</a>   ';

        }
        $dataPage=[];

        //получит данные сколько ставок, данные user

        //получить все сообщения пользователя
        $getMessageBlock = $this->selecData('telega',['id_user'=>$this->getUser['id']]);

        $user['message'] = $this->viewMessage($getMessageBlock);
        $user['ajax'] = true;

        ob_start();
        include '../page/filter.php';
        $page = ob_get_clean();
        return $page;
    }
    public function startBet(){
        //проверить что есть post данные
        $response['method']=['render_html'];
        if($_POST['preview'] && $_POST['max_bet'] ){
            $systemData =[
                'id'=>$this->getUser['id'],
                'preview'=>$_POST['preview'],
                'process'=>'1',
                'max_bet'=>$_POST['max_bet'],
                //'dawn_bet'=>$_POST['dawn_bet'],
            ];
            $set = $this->inserUpdateData('system',$systemData);

            $response['render_html']=[
                '.message'=>'Идет процесс ставок',
            ];
            if(!$set){
                $response['render_html']=[
                    '.message'=>'Ошибка установки',
                ];
            }
        }else{
            $response['render_html']=[
                '.message'=>'Ошибка данных startBet',
            ];
        }
        return json_encode($response);
    }
    public function stopBet(){
        //проверить что есть post данные
        $response['method']=['render_html'];

        if(!$this->getUser['id']){
            $response['render_html']=[
                '.message'=>'Ошибка установки',
            ];
            return json_encode($response);
        }
        $systemData =[
            'id'=>$this->getUser['id'],
            'process'=>'0',
        ];
        $set = $this->inserUpdateData('system',$systemData);

        $response['render_html']=[
            '.message'=>'Ставки остановлены',
        ];
        if(!$set){
            $response['render_html']=[
                '.message'=>'Ошибка установки',
            ];
        }
        return json_encode($response);

    }
    public function deleteBet(){
        //проверить что есть post данные
        $response['method']=['render_html'];

        if(!$this->getUser['id']){
            $response['render_html']=[
                '.message'=>'Ошибка установки',
            ];
            return json_encode($response);
        }
        $systemData =[
            'id'=>$this->getUser['id'],
            'process'=>'0',
        ];
        $set = $this->inserUpdateData('system',$systemData);

        $response['render_html']=[
            '.message'=>'Ставки остановлены',
        ];
        if(!$set){
            $response['render_html']=[
                '.message'=>'Ошибка установки',
            ];
        }
        return json_encode($response);

    }
    public function startMessage(){
        //проверить что есть post данные
        $response['method']=['render_html'];

        if(!$this->getUser['id']){
            $response['render_html']=[
                '.logo-message'=>'Ошибка установки',
            ];
            return json_encode($response);
        }
        $systemData =[
            'id'=>$this->getUser['id'],
            'process_message'=>'1',
        ];
        $set = $this->inserUpdateData('system',$systemData);

        $response['render_html']=[
            '.logo-message'=>'Бот установлен',
        ];
        if(!$set){
            $response['render_html']=[
                '.logo-message'=>'Ошибка установки',
            ];
        }
        return json_encode($response);
    }
    public function stopMessage(){
        //проверить что есть post данные
        $response['method']=['render_html'];

        if(!$this->getUser['id']){
            $response['render_html']=[
                '.logo-message'=>'Ошибка установки',
            ];
            return json_encode($response);
        }
        $systemData =[
            'id'=>$this->getUser['id'],
            'process_message'=>'0',
        ];
        $set = $this->inserUpdateData('system',$systemData);

        $response['render_html']=[
            '.logo-message'=>'Процесс остановлен',
        ];
        if(!$set){
            $response['render_html']=[
                '.logo-message'=>'Ошибка установки',
            ];
        }
        return json_encode($response);
    }
    public function getBets(){

        //получить активного пользователя
        $response['method']=['render_html'];
        if(!$this->getUser){

            return false;
        }
            $this->queryBetCount();
            $bets = $this->queryBetMy();

            $this->inserUpdateData('system',[
                'id'=>$this->getUser['id'],
                'bets'=>json_encode($bets),
            ]);
            $response['render_html']=[
                '.message'=>'Ускорение установлено',
                '.bets-load'=>'Есть ускорение',
            ];

        return json_encode($response);
    }
    public function setMonitor(){
        //проверить что есть post данные
        $response['method']=['render_html'];

        if(!$this->getUser['id']){
            $response['render_html']=[
                '.message'=>'Ошибка установки',
            ];
            return json_encode($response);
        }

        $getSystem = $this->selecDataOne('system',['id'=>$this->getUser['id']]);

        $ruMon ='';
        if(!$getSystem['page']){
            $getMonitor = 1;
            $ruMon='Последние';
        }else {
            $getMonitor = 0;
            $ruMon='Первые';
        }
        $set = $this->inserUpdateData('system',['id'=>$this->getUser['id'],'page'=>$getMonitor]);
        //получить все сообщения пользователя


        $response['render_html']=[
            '.message'=>'Монитор установлен',
            '.set_monitor'=>$ruMon,
        ];
        if(!$set){
            $response['render_html']=[
                '.message'=>'Ошибка установки',
            ];
        }
        return json_encode($response);

    }

    public function addMessageBet(){
        //проверить что есть post данные
        $response['method']=['render_html'];

        if(!$this->getUser['id']){
            $response['render_html']=[
                '.message'=>'Ошибка установки',
            ];
            return json_encode($response);
        }
        $systemData =[
            'id_user'=>$this->getUser['id'],
        ];

        $set = $this->inserUpdateData('message',$systemData);
        //получить все сообщения пользователя
        $getMessageBlock = $this->selecData('message',['id_user'=>$this->getUser['id']]);

        $vewMessageBlock = $this->viewMessage($getMessageBlock,'bet');

        $response['render_html']=[
            '.message'=>'Сообщение создано',
            '.message_bet'=>$vewMessageBlock,
        ];
        if(!$set){
            $response['render_html']=[
                '.message'=>'Ошибка сообщения',
            ];
        }
        return json_encode($response);

    }
    public function createMessageBet(){
        //проверить что есть post данные
        $response['method']=['render_html'];

        if(!$this->getUser['id']){
            $response['render_html']=[
                '.message'=>'Ошибка установки',
            ];
            return json_encode($response);
        }
        $systemData =[
            'id_user'=>$this->getUser['id'],
        ];
        if($_POST['text']  && $_POST['id']){
            $systemData['text']=$_POST['text'];

            $systemData['id']=$_POST['id'];
        }
        $set = $this->inserUpdateData('message',$systemData);

        //получить все сообщения пользователя
        $getMessageBlock = $this->selecData('message',['id_user'=>$this->getUser['id']]);

        $vewMessageBlock = $this->viewMessage($getMessageBlock,'bet');

        $response['render_html']=[
            '.message'=>'Сообщение создано',
            '.message_bet'=>$vewMessageBlock,
        ];
        if(!$set){
            $response['render_html']=[
                '.message'=>'Ошибка сообщения',
            ];
        }
        return json_encode($response);

    }
    public function deleteMessageBet(){
        //проверить что есть post данные
        $response['method']=['render_html'];

        if(!$this->getUser['id'] || !$_POST['id'] || !$_POST['id_user']){
            $response['render_html']=[
                '.message'=>'Ошибка удаления',
            ];
            return json_encode($response);
        }

        if(!$delete = $this->deleteData('message',['id'=>$_POST['id']])){
            $response['render_html']=[
                '.message'=>'Ошибка удаления',
            ];
            return json_encode($response);
        }

        //получить все сообщения пользователя
        $getMessageBlock = $this->selecData('message',['id_user'=>$this->getUser['id']]);

        $vewMessageBlock = $this->viewMessage($getMessageBlock,'bet');

        $response['render_html']=[
            '.message'=>'Сообщение удалено',
            '.message_bet'=>$vewMessageBlock,
        ];

        return json_encode($response);

    }


    public function addMessage(){
        //проверить что есть post данные
        $response['method']=['render_html'];

        if(!$this->getUser['id']){
            $response['render_html']=[
                '.message'=>'Ошибка установки',
            ];
            return json_encode($response);
        }
        $systemData =[
            'id_user'=>$this->getUser['id'],
        ];

        $set = $this->inserUpdateData('telega',$systemData);
        //получить все сообщения пользователя
        $getMessageBlock = $this->selecData('telega',['id_user'=>$this->getUser['id']]);

        $vewMessageBlock = $this->viewMessage($getMessageBlock);

        $response['render_html']=[
            '.message'=>'Сообщение создано',
            '.bet-telegram-triger'=>$vewMessageBlock,
        ];
        if(!$set){
            $response['render_html']=[
                '.message'=>'Ошибка сообщения',
            ];
        }
        return json_encode($response);

    }
    public function createMessage(){
        //проверить что есть post данные
        $response['method']=['render_html'];

        if(!$this->getUser['id']){
            $response['render_html']=[
                '.message'=>'Ошибка установки',
            ];
            return json_encode($response);
        }
        $systemData =[
            'id_user'=>$this->getUser['id'],
        ];
        if($_POST['text'] && $_POST['triger'] && $_POST['id']){
            $systemData['text']=$_POST['text'];
            $systemData['triger']=$_POST['triger'];
            $systemData['id']=$_POST['id'];
        }
        $set = $this->inserUpdateData('telega',$systemData);

        //получить все сообщения пользователя
        $getMessageBlock = $this->selecData('telega',['id_user'=>$this->getUser['id']]);

        $vewMessageBlock = $this->viewMessage($getMessageBlock);

        $response['render_html']=[
            '.message'=>'Сообщение создано',
            '.bet-telegram-triger'=>$vewMessageBlock,
        ];
        if(!$set){
            $response['render_html']=[
                '.message'=>'Ошибка сообщения',
            ];
        }
        return json_encode($response);

    }
    public function deleteMessage(){
        //проверить что есть post данные
        $response['method']=['render_html'];

        if(!$this->getUser['id'] || !$_POST['id'] || !$_POST['id_user']){
            $response['render_html']=[
                '.message'=>'Ошибка удаления',
            ];
            return json_encode($response);
        }

        if(!$delete = $this->deleteData('telega',['id'=>$_POST['id']])){
            $response['render_html']=[
                '.message'=>'Ошибка удаления',
            ];
            return json_encode($response);
        }

        //получить все сообщения пользователя
        $getMessageBlock = $this->selecData('telega',['id_user'=>$this->getUser['id']]);

        $vewMessageBlock = $this->viewMessage($getMessageBlock);

        $response['render_html']=[
            '.message'=>'Сообщение удалено',
            '.bet-telegram-triger'=>$vewMessageBlock,
        ];

        return json_encode($response);

    }
    public function viewMessage($getMessageBlock,$action='bot'){
        $input='';
        if($action =='bot'){
            $action_name ='delete_message';
            $data_action="create_message";
            $parent_create_message ='parent-create_message ';

        }else{
            $action_name ='delete_message_bet';
            $data_action="create_message_bet";
            $parent_create_message ='parent-create_message_bet ';
        }
        $vewMessageBlock ='';
        if($getMessageBlock){
            foreach ( $getMessageBlock as $item => $oneMessage) {
                if($action =='bot'){
                    $input = '<input class="tel-triger" type="text" required name="triger" placeholder="тригеры" value="'.$oneMessage['triger'].'">';
                }
                $vewMessageBlock.='<div class="parent-delete_message '.$parent_create_message.' one-telegram bet-param " id="'
                    .$oneMessage['id'].'">
                        <form id="submit_action" data-action="'.$data_action.'" data-id="'
                    .$oneMessage['id'].'">
                            <div class="telegram-panel flex-cen-sb">

                                <div class="telegram-eddit">
                                    <input type="submit" class="crate_style" value="Установить" >
                                </div>
                                <div class="telegram-delete action-but crate_style delete_style"
                                     data-action_name="'.$action_name.'"
                                data-action="common_action"
                                     data-id="'.$oneMessage['id'].'" data-id_user="'.$oneMessage['id_user'].'">
                                    Удалить
                                </div>
                            </div>
                            <div>
                            '.$input.'
                              
                                <textarea class="tel-text" name="text" required id="" cols="15" rows="2"
                                          placeholder="введите сообщение">'.$oneMessage['text'].'</textarea>
                            </div>
                        </form>


                    </div>';
            }
        }

        return $vewMessageBlock;
    }


    public function viewBetCount(){

        //проверить что есть post данные
        $response['method']=['render_html','render_just'];

        if(!$this->getUser['id']){
            $response['render_html']=[
                '.message'=>'Ошибка пользователя',
            ];
            return json_encode($response);
        }


        //$crobe = $this->startCronBet();

        //$this->cronMessage();

        $bet = $this->queryBetCount();

        $logoMessage ='Процесс остановлен';
        if($this->getUser['process_message']){
            $logoMessage ='Бот установлен';
        }

        $logoProcess ='Процесс остановлен';
        if($this->getUser['process']){
            $logoProcess ='Идет процесс ставок';
        }

        $response['render_just']=[
            '.info-param.bet-set'=>$bet,
            '.logo-message'=>$logoMessage,
            '.bet-massage .message'=>$logoProcess,
        ];
        if(!$bet){
            $response['render_html']=[
                '.message'=>'Ошибка показа ставок',
            ];
        }
        return json_encode($response);

    }
    public function startCronTest(){
        $fp = fopen('data.txt', 'a+');
        fwrite($fp, '1
');
        fclose($fp);
        return 'ok';
    }

    public function startCronBet(){
        if($this->getUser['process'] && !$this->getUser['page']){
            try {
                $this->start = microtime(true);
                $result = $this->cronBet();
                if(!$result){
                    $this->inserUpdateData('system',[
                        'id'=>$this->getUser['id'],
                        'process'=>'0',
                    ]);

                }
            }catch (\Exception $e){
                $this->inserUpdateData('system',[
                    'id'=>$this->getUser['id'],
                    'process'=>'0',
                ]);
                $result =  false;
            }
            if($result){
                $result='Добавлено';
            }else{
                $result='Ошибка';
            }
        }else{
            $result='Отсановленно';
        }



        return $result;
    }
    public function startCronBetDown(){
        if($this->getUser['process'] && $this->getUser['page']){
            try {
                $this->start = microtime(true);
                $result = $this->cronBet();
                if(!$result){
                    $this->inserUpdateData('system',[
                        'id'=>$this->getUser['id'],
                        'process'=>'0',
                    ]);

                }
            }catch (\Exception $e){
                $this->inserUpdateData('system',[
                    'id'=>$this->getUser['id'],
                    'process'=>'0',
                ]);
                $result =  false;
            }
            if($result){
                $result='Добавлено';
            }else{
                $result='Ошибка';
            }
        }else{
            $result='Отсановленно';
        }



        return $result;
    }

    public function updateFilter(){
        //получить активного пользователя
        $response['method']=['render_html'];
        if(!$this->getUser){

            return false;
        }
        $dataFilter=[
            'operationName' => 'getProfile',
            'variables' => [],
            'query'=>'query getProfile {
  profile {
    __typename
    id
    nickName
    role
    balance
    phone
    avatar(size: size176x176)
    isPhoneConfirmed
    hasAndroidDevice
    isAgency
    countryByPhone
    types {
      id
      name
      __typename
    }
    subjects {
      id
      name
      __typename
    }
    abTestGroups {
      id
      name
      group
      __typename
    }
    commissionDelta
    canSeeExpressOrders
    orderTaxPercent
    isAccreditationCompleted
    isMasterCompleted
    isFirstOfferCompleted
    isQualificationFilled
    chatEnabled
    canTakeOnboardingSurvey
  }
}
'
        ];
        $typesForeach=[];
        $subjectsForeach=[];
        $types=[];
        $subjects=[];
        if($responsePost = $this->queryAvtorPost('https://a24.biz/graphqlapi',$dataFilter)){
            if(isset($responsePost->response->data) && isset($responsePost->response->data->profile->subjects) && isset($responsePost->response->data->profile->types)){

                $typesForeach =  $responsePost->response->data->profile->types;
                if(is_array($typesForeach) ){
                    foreach ($typesForeach as $elm => $vl){
                        $idType =$vl->id;
                        $types[] =$idType;
                    }
                }
                $subjectsForeach =  $responsePost->response->data->profile->subjects;
                if(is_array($subjectsForeach) ){
                    foreach ($subjectsForeach as $elm => $vl){
                        $idsubjict =$vl->id;
                        $subjects[] =$idsubjict;
                    }
                }
            }
            $this->inserUpdateData('system',[
                'id'=>$this->getUser['id'],
                'types'=>json_encode($types),
                'subjects'=>json_encode($subjects),
            ]);
            $response['render_html']=[
                '.message'=>'Фильтр установлен',
                '.action-but[data-action_name="update_filter"]'=>'Фильтр установлен',
            ];
        }else{

            $response['render_html']=[
                '.message'=>'Ошибка установки',
            ];
        }

        return json_encode($response);
    }
    public $pageCicle=1;
    public $start;
    public function cronBet($pageStart=null){
        //получить активного пользователя
        if(!$user = $this->selecDataOne('system',['active'=>'1'])){

            return false;
        }
        //чтобы ставки не были больше max если равно то отсановим ставки
        //$getAllId = $this->queryGetAllId();
        $getAllId =  $this->queryBetCount();
        if($getAllId >= $user['max_bet']){
            $this->inserUpdateData('system',[
                'id'=>$user['id'],
                'process'=>'0',
            ]);
            //отменяем процесс ставок
            return false;
        }

        //обработка вызова только для первой странице
        if($pageStart){
            $pageTo = $pageStart;
        }
        else{
            //уже нет смысла
            $pageStart=1;
            $pageTo = 1;
        }
        $types=[];
        if($user['types']){
            $types = json_decode($user['types']);
        }
        $subjects=[];
        if($user['types']){
            $subjects = json_decode($user['subjects']);
        }
        if(!$user['page']){
            $pageTo = 1;
            $pageStart=1;
        }
        //получит данные сколько ставок, данные user

        $data=[
            'operationName' => 'GetAuctionWithConstraints',// //GetAuction
            'variables' => [
                'filter'=>[
                    'types'=>$types,//$types
                    'categories'=>$subjects,//$subjects
                    'isFastOrder'=>false,
                    'noBids'=>false,
                    'hasFile'=>false,
                    'less3bids'=>false,
                    'customerOnline'=>false,
                    'orderIsPaid'=>false,
                    'contractual'=>true,//true
                    'isFamiliarCustomer'=>false,
                    'withoutMyBids'=>true,
                    'budgetFrom'=>0,//0
                    'budgetTo'=>200000,//200000
                    'deadlineFrom'=>0,
                    'deadlineTo'=>365,
                    'uniqueValueFrom'=>0,
                    'uniqueValueTo'=>100,
                    'bidCountFrom'=>0,
                    'bidCountTo'=>200,
                    'query'=>'',
                    'title'=>'',
                    'categoryName'=>'',
                    'typeName'=>'',
                    'customerName'=>''
                ],
                'limit'=>30,//30
                'pagination'=>['pageTo'=>(int)$pageTo],//$user['page']
            ],
            'query'=>'query GetAuctionWithConstraints($skip: Int, $limit: Int, $filter: AuctionFilterInputType, $pagination: AuctionPaginationInputType) {  auctionFilteredCount(filter: $filter) orders(skip: $skip, limit: $limit, filter: $filter, pagination: $pagination) {    total    paginationCount    captcha    pages   orders {      ...orderDataFragment      __typename    }    __typename  }}fragment orderDataFragment on order {  id  type {    id    name    __typename  }  category {    id    name    __typename  }  customer {    id    isOnline    __typename  }  badges {    id    name    __typename  }  title  description  budget  recommendedBudget  isFavorite  isConsult  isInviteOrder  isPremium  isHidden  isPaid  isRead  creation  deadline  customerFiles {    id    name    path    hash    sizeInMb    readableCreationUnixtime    type    __typename  }  authorFiles {    id    __typename  }  countOffers  isMatchFilter  isMatchQualification  authorHasOffer  isExpressOrder  authorOffer {    id    origin_bid    bid    text    __typename  }  __typename}',

        ];
        if($responseBet = $this->queryAvtorPost('https://a24.biz/graphqlapi',$data)){
            //return false;
            if(isset($responseBet->response) && isset($responseBet->response->errors)) {
                return false;
            }
                //return true;
                //return false;
                $group_id =[];

                if(isset($responseBet->response->data) && isset($responseBet->response->data->orders->orders)){

                    $countAllPages =  count($responseBet->response->data->orders->pages);
                    if($countAllPages==0){
                        $lastPage = $countAllPages;
                    }else{
                        $lastPage = $countAllPages-1;
                    }

                    $pagesMas =  $responseBet->response->data->orders->pages;
                    $allPages =  $pagesMas[$lastPage];

                    $group_id = $responseBet->response->data->orders->orders;
                }


                if($user['bets']){
                    $queryBetMy = json_decode($user['bets']);
                    if(!$queryBetMy){
                        $queryBetMy = $this->queryBetMy();
                    }
                }
                //делаем поиск
                if($group_id){
                    $countGroupId = count($group_id);
                    $startCount =0;
                    $countError =0;
                    foreach ($group_id as $oneId => $vlId){
                        $custoverId = $vlId->customer->id;
                        if(isset($vlId->id)){
                            if(!in_array($vlId->id,$queryBetMy)){
                                //делаем ставку
                                $dataBet = [
                                    'operationName' => 'makeOffer',
                                    'variables' => [
                                        'orderId'=>$vlId->id,
                                        //'bid'=>1000,
                                        'message'=>$user['preview'],
                                        //'expired'=>'2023-06-30T15:00:00.000+03:00',
                                    ],
                                    'query'=>'mutation makeOffer($orderId: ID!, $bid: Int, $message: EscapeString, $expired: String, $scenario:
         RecommendedScenarioEnum) { orderCreateOffer(id: $orderId, bid: $bid, message: $message, expired: $expired, subscribe: false, recommendedScenario: $scenario) {  id   origin_bid    bid    text    expired    countOffersOfOrder   __typename  }} ',
                                ];
                                $queryBetMy[] = $vlId->id;
                                $this->inserUpdateData('system',[
                                    'id'=>$user['id'],
                                    'bets'=>json_encode($queryBetMy),
                                ]);
                                if($responceBet = $this->queryAvtorPost('https://a24.biz/graphqlapi',$dataBet)){
                                    //return false;
                                    $startCount++;
                                    if(isset($responceBet->response) && isset($responceBet->response->errors)){
                                        $countError++;
                                    }else{
                                        //поставили ставку
                                        //написать сообщение
                                        $getMessage = $this->selecData('message',['id_user'=>$user['id']]);
                                        if($getMessage){
                                            foreach ($getMessage as $el =>$vl ){
                                                $result =  $this->querySendComment($vlId->id,$vl['text']);
                                            }
                                        }

                                        $getAllId++;
                                        if(!$user['page']){
                                            $end = microtime(true);
                                            $runtime = round(($end - $this->start), 0);
                                            if($runtime > 45){
                                                return true;
                                            }
                                        }

                                    }
                                    if($getAllId >= $user['max_bet']){
                                        break;

                                    }
                                    sleep(2);
                                }

                            }
                        }

                    }
                    if($getAllId >= $user['max_bet']){
                        return false;

                    }
                    if(!$user['page']){
                        $end = microtime(true);
                        $runtime = round(($end - $this->start), 0);
                        if($runtime > 45){
                            return true;
                        }else{
                            return $this->cronBet($pageStart);
                        }
                    }
                    $end = microtime(true);
                    $runtime = round(($end - $this->start), 0);
                    if($runtime > 200){
                        return true;
                    }

                    if($allPages && $allPages != 0){
                        if($allPages == $pageStart){
                            $pageStart=1;
                            $this->pageCicle++;
                        }else{
                            $pageStart++;
                        }
                        return $this->cronBet($pageStart);
                    }
                    return true;

                }
                return true;
        }
        else{
            return false;
        }

    }

    public function columValuem($dataCreate){
        $column='';
        $param='';
        $update = '';
        foreach ($dataCreate as $item => $vl) {
            $column.='`'.$item.'`,';
            $param.="'".$vl."',";
            $update .='`'.$item.'` = '."'".$vl."',";
        }
        $column = substr($column,0,-1);
        $param = substr($param,0,-1);
        $update = substr($update,0,-1);
        return ['column'=>$column,'val'=>$param,'update'=>$update];
    }
    public function selecData($table,$where,$column=null){
        $selectColumn = '*';
        if($column){
            if(is_array($column)){
                $start =0;
                foreach ($column as $one ){
                    if($start>0){
                        $selectColumn .=' , `'.$one.'`';
                    }else{
                        $selectColumn .='`'.$one.'`';
                    }

                    $start++;

                }
            }else{
                $selectColumn = '`'.$column.'`';
            }
        }
        $selectWhere = 'WHERE ';
        if($where){
            if(is_array($where)){
                $start =0;
                foreach ($where as $one => $vl){
                    if($start>0){
                        $selectWhere .=" AND `".$one."` = '".$vl."'";
                    }else{
                        $selectWhere .="`".$one."` = '".$vl."'";
                    }

                    $start++;
                }
            }else{
                $selectWhere = $where;
            }
        }

        $select   = "SELECT ".$selectColumn." FROM `".$table."` ".$selectWhere;
        $search = mysqli_query($this->CONNECT, $select);
        //$nubor = false;
        $sql=[];
        while($select = mysqli_fetch_assoc($search)){
            //$nubor = true;
            $sql[] = $select;
        }
        if(!$sql){
            return false;
        }
        return $sql;

    }
    public function deleteData($table,$where){
        $selectWhere = 'WHERE ';
        if($where){
            if(is_array($where)){
                $start =0;
                foreach ($where as $one => $vl){
                    if($start>0){
                        $selectWhere .=" AND `".$one."` = '".$vl."'";
                    }else{
                        $selectWhere .="`".$one."` = '".$vl."'";
                    }

                    $start++;
                }
            }else{
                $selectWhere = $where;
            }
        }

        $delete   = "DELETE FROM `".$table."` ".$selectWhere;
        $search = mysqli_query($this->CONNECT, $delete);
        if ($search === FALSE) {
            return false;
        }
        return true;

    }
    public function selecDataOne($table,$where,$column=null){
        $one = $this->selecData($table,$where,$column);
        if($one){
            return $one[0];
        }
        return false;
    }
    public function inserUpdateData($table,$dataCreate)
    {
        $pararm = $this->columValuem($dataCreate);
        $insert_row2 = "INSERT INTO `".$table."` (" . $pararm['column'] . ") VALUES (" . $pararm['val'] . ") ON DUPLICATE KEY UPDATE "
            . $pararm['update'];
        $search = mysqli_query($this->CONNECT, $insert_row2);
        if ($search === FALSE) {
            return false;
        }
        return true;
    }
    public function updateData($table,$set,$where=null)
    {

        $updateSet = 'SET ';
        if($set){
            if(is_array($set)){
                $start =0;
                foreach ($set as $one => $vl){
                    if($start>0){
                        $updateSet .=" , `".$one."` = '".$vl."'";
                    }else{
                        $updateSet .="`".$one."` = '".$vl."'";
                    }

                    $start++;
                }
            }else{
                $updateSet = $set;
            }
        }

        $updateWhere = '';
        if($where){
            $updateWhere = 'WHERE ';
            if(is_array($where)){
                $start =0;
                foreach ($where as $one => $vl){
                    if($start>0){
                        $updateWhere .=" AND `".$one."` = '".$vl."'";
                    }else{
                        $updateWhere .="`".$one."` = '".$vl."'";
                    }

                    $start++;
                }
            }else{
                $updateWhere = $where;
            }
        }

        $insert_row2 = "UPDATE `".$table."` ".$updateSet." ".$updateWhere;

        $search = mysqli_query($this->CONNECT, $insert_row2);
        if ($search === FALSE) {
            return false;
        }
        return true;
    }
    public function createUser($email,$password){
        //проверить есть ли такой логин если ест то перезапишем настройки если нет то создаем его
        if($login = $this->avtorLogin($email,$password)){
            return $login;
        }
        $dataCreate = [
            'email'=>$email,
            'password'=>$password,
            'active'=>'1',
            'cookie'=>json_encode($this->cookieTable),
        ];

        $user = $this->selecDataOne('system',['active'=>'1']);

        if($user){
            //поменять всем active
            if(!$update = $this->updateData('system',['active'=>'0','process'=>'0'])){
                return 'Ошибка бд createUser';
            }
            //$dataCreate['id'] = $user['id'];
        }
        $user = $this->selecDataOne('system',['email'=>$email]);

        if($user){
            //поменять всем active
            if(!$update = $this->updateData('system',['active'=>'0','process'=>'0'])){
                return 'Ошибка бд createUser';
            }
            $dataCreate['id'] = $user['id'];
        }

        $this->inserUpdateData('system',$dataCreate);
        return null;
    }

    public function avtorLogin($email,$password){
        $curl2 = new Curl();
        $curl2->setUserAgent('Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36');
        $curl2->setOpt(CURLOPT_RETURNTRANSFER, TRUE);
        $curl2->setOpt(CURLOPT_SSL_VERIFYPEER, FALSE);
        $curl2->get('https://a24.biz');
        $cookie = $curl2->responseCookies;
        if($_SESSION['a24']){
            $_SESSION['a24']=[];
        }
        if($this->cookieTable){
            $this->cookieTable=[];
        }
        foreach ($cookie as $cookiName => $cookieVal){
            $this->cookieTable[$cookiName] = $cookieVal;
            $_SESSION['a24'][$cookiName] = $cookieVal;
            $curl2->setCookie($cookiName, $cookieVal);
        }

        $ci_csrf_token = $this->avtorGetToken();

        $curl2->post('https://a24.biz/login/', [
            'email' =>$email,// 'strekozaanton@gmail.com',
            'password' =>$password,//'1442150a24',
            'ci_csrf_token' => $ci_csrf_token,//aod5rjii4tso5vm4lbc3ufqoq9ih4hhi
        ]);
        if($curl2->error && $curl2->httpStatusCode !== 200 || $curl2->response !='' ){
            return 'Неверный пользователь';
        }
        //сделать запись кук и поменять актив на 1 также убрать у остальный process и active
        return  null;
    }

    public function avtorGetToken(){
        $curlToken = new Curl();
        $curlToken->setOpt(CURLOPT_RETURNTRANSFER, TRUE);
        $curlToken->setOpt(CURLOPT_SSL_VERIFYPEER, FALSE);
        $curlToken->setHeaders([
            'X-Requested-With'=>'XMLHttpRequest',
            'user-agent'=>'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
            'sec-fetch-site'=>'same-origin',
            'sec-fetch-mode'=>'cors',
            'sec-fetch-dest'=>'empty',
            'sec-ch-ua-platform'=>'"Windows"',
            'sec-ch-ua-mobile'=>'?0',
            'sec-ch-ua'=>'"Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
            'referer'=>'https://a24.biz/login',
            'pragma'=>'no-cache',
            'cache-control'=>'no-cache',
            'accept-language'=>'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
            'accept'=>'*/*',
            'Content-Type'=>'application/json;charset=utf-8',
        ]);
        if($_SESSION['a24']){
            $_SESSION['a24'] =[];
        }

        foreach ($this->cookieTable as $cookiName => $cookieVal){
            $_SESSION['a24'][$cookiName] = $cookieVal;
            $curlToken->setCookie($cookiName, $cookieVal);
        }

        $curlToken->get('https://a24.biz/ajax/getCSRFToken/');

        if($curlToken->response->ci_csrf_token){
            $ci_csrf_token =$curlToken->response->ci_csrf_token;
            return  $ci_csrf_token;
        }

        return  false;
    }

    public function avtorLoginActive(){
        if(!$this->getUser = $this->selecDataOne('system',['active'=>'1'])){
            return 'Ошибка входа avtorLoginActive';
        }
        //проверим куки если плохо то перезапишем
        $this->cookieTable=json_decode($this->getUser['cookie'],true);
        if(!$result = $this->queryAvtor('https://a24.biz/home/myorders')){
            $this->countRepit=0;
            //перезапишет куки и актив
            if($login = $this->createUser($this->getUser['email'],$this->getUser['password'])){
                return $login;
            }
        }
        return $result;

    }


    public function exitAvtor(){
        if(!$this->getUser = $this->selecDataOne('system',['active'=>'1'])){
            return 'Ошибка входа avtorLoginActive';
        }
        $this->queryAvtor('https://a24.biz/logout');
        $this->inserUpdateData('system',['active'=>0,'id'=>$this->getUser['id']]);
    }

    public function queryAvtor($url){

        $curl = new Curl();
        $curl->setUserAgent('Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36');
        $curl->setOpt(CURLOPT_RETURNTRANSFER, TRUE);
        $curl->setOpt(CURLOPT_SSL_VERIFYPEER, FALSE);
        if(!$this->cookieTable){
            if($this->getUser){
                $this->cookieTable = $this->getUser['cookie'];
            }
        }
        foreach ($this->cookieTable as $cookiName => $cookieVal){
            $curl->setCookie($cookiName, $cookieVal);
        }
        $curl->get($url);
        if($curl->error && $curl->httpStatusCode !== 200 ){
            return false;
        }else{

            $responce = $curl->response;
        }

        return $responce;
    }

    public function queryBetCount(){

        $data = [
            'operationName' => 'getOrdersBy',
            'variables' => [
                'active'=> true,
            ],
            'query'=>'query getOrdersBy {
  myAuction {
    amount {
      hidden
      favorite
      withMyBid
      __typename
    }
    __typename
  }
}
',
            ];

        if(!$response = $this->queryAvtorPost('https://a24.biz/graphqlapi',$data)){
            return false;
        }
        if (isset($response->response) && isset($response->response->errors)) {
            return false;
        }
        if(isset($response->response->data->myAuction->amount->withMyBid)){
            $this->betCount = $response->response->data->myAuction->amount->withMyBid;
            return $this->betCount;
        }
        return false;
    }

    public function queryBetMy(){
            $total_records = $this->betCount;
            $records_per_page = 100;
            $current_offset = 0;
            $myBet=[];
            while ($current_offset < $total_records) {
                // Вычислите текущий лимит на основе смещения (offset) и количества записей на странице (limit)
                $current_limit = min($records_per_page, $total_records - $current_offset);

                // Выполните действия с текущими записями, используя текущий лимит и смещение
                // Здесь вы можете выполнить любую нужную вам операцию над записями, например, вывод или обработку
                $data = [
                    'operationName' => 'getWithMyBidOrders',
                    'variables' => [
                        'limit'=> $current_limit,
                        'offset'=>$current_offset
                    ],
                    'query'=>'query getWithMyBidOrders($limit: Int = 0, $offset: Int = 0) {
  myAuction {
    withMyBid(limit: $limit, offset: $offset) {
      ...orderDataFragment
      __typename
    }
    __typename
  }
}

fragment orderDataFragment on order {
  id
  type {
    id
    name
    __typename
  }
  category {
    id
    name
    __typename
  }
  customer {
    id
    isOnline
    __typename
  }
  badges {
    id
    name
    __typename
  }
  title
  description
  budget
  recommendedBudget
  isFavorite
  isConsult
  isInviteOrder
  isPremium
  isHidden
  isPaid
  isRead
  creation
  deadline
  customerFiles {
    id
    name
    path
    hash
    sizeInMb
    readableCreationUnixtime
    type
    __typename
  }
  authorFiles {
    id
    __typename
  }
  countOffers
  isMatchFilter
  isMatchQualification
  authorHasOffer
  isExpressOrder
  authorOffer {
    id
    origin_bid
    bid
    text
    __typename
  }
  __typename
}',
                ];
                if(!$response = $this->queryAvtorPost('https://a24.biz/graphqlapi',$data)){
                    return $myBet;
                }
                if (isset($response->response) && isset($response->response->errors)) {
                    return $myBet;
                }
                if(isset($response->response->data->myAuction->withMyBid)){
                    if(is_array($response->response->data->myAuction->withMyBid) && count
                        ($response->response->data->myAuction->withMyBid)){
                        foreach ($response->response->data->myAuction->withMyBid as $oneBet => $vlBet){
                            $myBet[]=$vlBet->id;
                        }
                    }

                }
                //echo "Обработка записей с " . ($current_offset + 1) . " по " . ($current_offset + $current_limit) .
                // "<br>";

                // Увеличьте смещение на текущий лимит, чтобы перейти к следующей группе записей
                $current_offset += $current_limit;
            }
            return $myBet;
        }

    public function queryGetAllId(){

        if(!$responce = $this->queryAvtor('https://a24.biz/home/myorders')){
            return false;
        }
        $doc = phpQuery::newDocument($responce);
        $this->betId =[];
        $ht =  pq('.orders .orders__item.block',$doc);
        $this->betCount = pq('.m-ordersFilter__item--current .m-ordersFilter__total',$doc)->text();
        foreach ($ht as $oneHt => $vlHt){
            $htId[] =  pq('.orders__item_bottom .orders__item_bottom__messages',$vlHt)->attr('data-id');
        }
        $this->betAllId = $htId;
        return $this->betAllId ;

    }

    public function queryAvtorPost($url='https://a24.biz/graphqlapi',$post){
        $curl = new Curl();
        $curl->setUserAgent('Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36');
        $curl->setOpt(CURLOPT_RETURNTRANSFER, TRUE);
        $curl->setOpt(CURLOPT_SSL_VERIFYPEER, FALSE);
        if($this->cookieTable){
            foreach ($this->cookieTable as $cookiName => $cookieVal){
                $curl->setCookie($cookiName, $cookieVal);
            }
        }else{
            $responce = $this->avtorLoginActive();
            if(!$responce){
                if($this->cookieTable){
                    foreach ($this->cookieTable as $cookiName => $cookieVal){
                        $curl->setCookie($cookiName, $cookieVal);
                    }
                }
            }else{
                return false;
            }
        }

        $curl->setHeaders([
            //'X-Requested-With'=>'XMLHttpRequest',
            'user-agent'=>'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
            'sec-fetch-site'=>'same-origin',
            'sec-fetch-mode'=>'cors',
            'sec-fetch-dest'=>'empty',
            'sec-ch-ua-platform'=>'"Windows"',
            'sec-ch-ua-mobile'=>'?0',
            'sec-ch-ua'=>'"Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
            //'referer'=>'https://a24.biz/order/getoneorder/9942370',
            'Content-Type'=>'application/json;charset=utf-8',
            'pragma'=>'no-cache',
            'cache-control'=>'no-cache',
            'accept-language'=>'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
            //'accept-encoding'=>'gzip, deflate, br',
            'accept'=>'*/*',
            'Accept-Charset'=>'UTF-8',
            'origin'=> 'https://a24.biz',

            //'content-length'=>'570',
        ]);
        $curl->post($url,$post);

        return  $curl;

    }


    public function cronMessage(){
        //проверяем есть ли тригеры
        if($this->getUser['id'] && $this->getUser['process_message']){
            $triggerMassib =[];
            $getMessageBlock = $this->selecData('telega',['id_user'=>$this->getUser['id']]);
            if($getMessageBlock){
                foreach ($getMessageBlock as $oneM => $vlMes){
                    $trExplod = explode('&',$vlMes['triger']);
                    $countExplod= count($trExplod);
                    if($countExplod>0){
                        foreach ($trExplod as $elem){
                            $triggerMassib[$elem]=$vlMes['text'];
                        }
                    }else{
                        $triggerMassib[$trExplod[0]]=$vlMes['text'];
                    }

                }

                $getactiveMessage = $this->getMessageAcvtive();
                if(isset($getactiveMessage->data->chat->dialogs)){
                    $dialog = $getactiveMessage->data->chat->dialogs;
                    if(is_array($dialog)){
                        foreach ($dialog as $oneCa =>$vlCat){
                            //ответим только на не прочитанные
                            if(isset($vlCat->countUnreadMessages) && $vlCat->countUnreadMessages !=0){
                                if(isset($vlCat->lastMessage) && isset($vlCat->lastMessage->text) && isset($vlCat->order->id)){
                                    $text = $vlCat->lastMessage->text;
                                    $orderId = ''.$vlCat->order->id;
                                    $messageId = ''.$vlCat->lastMessage->id;
                                    //проверим с шаблоном
                                    if(array_key_exists($text,$triggerMassib)){
                                        //деаем отправку сообщения если есть не прочитанные

                                        $result =  $this->querySendMessage($orderId,$triggerMassib[$text],$messageId);
                                    }
                                }
                            }


                        }
                    }
                }
            }
        }

    }

    public function getMessageAcvtive(){

        //получить активного пользователя
        if (!$user = $this->selecDataOne('system', ['active' => '1'])) {

            return false;
        }
        $data = [
            'operationName' => 'getDialogs',
            'variables' => [
                'active'=> true,
            ],
            'query'=>'query getDialogs($stage: Int, $active: Boolean, $lastCommentId: ID, $ids: [Int]) {
  chat {
    dialogs(stage: $stage, active: $active, lastCommentId: $lastCommentId, ids: $ids) {
      id
      order {
        id
        title
        isExpressOrder
        isFavorite
        stage {
          id
          name
          __typename
        }
        __typename
      }
      customer {
        id
        avatar(size: size50x50)
        isOnline
        lastVisit
        nickName
        __typename
      }
      countUnreadMessages
      lastCommentId
      lastMessage {
        ...messageFragment
        ...correctionFragment
        ...recommendationFragment
        ...pricerequestFragment
        ...systemFragment
        ...assistantFragment
        __typename
      }
      __typename
    }
    __typename
  }
}

fragment messageFragment on message {
  id
  user_id
  text
  creation
  isAdminComment
  isAutoHidden
  isRead
  watched
  files {
    id
    name
    hash
    type
    path
    sizeInMb
    isFinal
    __typename
  }
  __typename
}

fragment correctionFragment on correction {
  id
  user_id
  text
  creation
  isAdminComment
  isRead
  watched
  files {
    id
    name
    hash
    type
    path
    sizeInMb
    isFinal
    __typename
  }
  __typename
}

fragment recommendationFragment on recommendation {
  id
  user_id
  text
  creation
  isAdminComment
  isRead
  watched
  promoUrl
  isMobile
  __typename
}

fragment pricerequestFragment on pricerequest {
  id
  user_id
  text
  creation
  isAdminComment
  isRead
  watched
  __typename
} fragment systemFragment on system {
  id
  type
  creation
  text
  __typename
} fragment assistantFragment on assistant {
  id
  text
  creation
  isRead
  __typename
}',

        ];
        if (!$response = $this->queryAvtorPost('https://a24.biz/graphqlapi', $data)) {
            return false;
        }

        if (isset($response->response) && isset($response->response->errors)) {
            return false;
        }
        return $response->response;
    }

    public function sendMessage(){


        $message = $this->querySendMessage();
        if($message){
            return 'Отправлено';
        }
        return 'Не отправлено';
    }

    public function querySendMessage($orderId,$text,$messageId){

        //получить активного пользователя
        if (!$user = $this->selecDataOne('system', ['active' => '1'])) {

            return false;
        }

        //сделать сообщение прочитанным
        $data = [
            'operationName' => 'deleteUnreadMessages',
            'variables' => [
                'messageIds'=> (int)$messageId,
            ],
            'query'=>'mutation deleteUnreadMessages($messageIds: [Int]) {
  deleteUnreadMessages(messageIds: $messageIds)
}
',
            ];

        if (!$response = $this->queryAvtorPost('https://a24.biz/graphqlapi', $data)) {
            return false;
        }
        if (isset($response->response) && isset($response->response->errors)) {
            return false;
        }
        //сделать ответ пользователю
        return $this->querySendComment($orderId,$text);
    }
    public function querySendComment($orderId,$text){
        $data2 = [
            'operationName' => 'addComment',
            'variables' => [
                'orderId'=> $orderId,
                'text'=>$text,
            ],
            'query'=>'mutation addComment($orderId: ID!, $text: String!) {  addComment(orderId: $orderId, text: $text) {    __typename    ...messageFragment  }}fragment messageFragment on message {  id  user_id  text  creation  isAdminComment  isAutoHidden  isRead  watched  files {    id    name    hash    type    path    sizeInMb    isFinal    __typename  }  __typename}',

        ];

        if (!$response2 = $this->queryAvtorPost('https://a24.biz/graphqlapi', $data2)) {
            return false;
        }



        if (isset($response2->response) && isset($response2->response->errors)) {
            return false;
        }
        return true;
    }

}