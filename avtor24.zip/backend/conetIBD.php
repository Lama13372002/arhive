<?php
define('HOST','localhost');
/*define('USER','kanapeiz_loan');
define('PASS','Pa8K*LQQ');
define('DB','kanapeiz_loan');*/

define('USER','celler');
define('PASS','1442150');
define('DB','avtor24');