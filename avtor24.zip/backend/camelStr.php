<?php
namespace camel;


class camelStr
{
    public static function camelCase($string, $capitalizeFirstCharacter = false ){
        $str = str_replace(' ', '', ucwords(str_replace('-', ' ', ucwords(str_replace('_', ' ', $string)))));

        if (!$capitalizeFirstCharacter) {
            $str[0] = strtolower($str[0]);
        }

        return $str;
    }
    public static function snakeCase($string, $capitalizeFirstCharacter = false ){
        //$str = str_replace(' ', '', ucwords(str_replace('-', ' ', ucwords(str_replace('_', ' ', $string)))));
        $str = ltrim(strtolower(preg_replace('/[A-Z]([A-Z](?![a-z]))*/', '_$0', $string)), '_');
        /*if (!$capitalizeFirstCharacter) {
            $str[0] = strtolower($str[0]);
        }*/

        return $str;
    }

}