setInterval(function () {
    ajax_send([],'view_bet_count');
},6000);