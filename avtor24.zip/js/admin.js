let console, elmContainer, elmParent,  elm, elmAction, elmAttr = {}, functAdmin = {},globalParam = {},panel={};
//вывод данных в окно
$(document).on('click','.action-but',function (e){
    e.preventDefault();
    if(!$(this).hasClass('bunk-wait')){
        functAdmin.action_but(this);
    }

});
functAdmin.action_but =function(data){
    elm = $(data);
    elmAction = elm.attr('data-action');
    elmContainer  = elm.parents('.container-'+elmAction);
    if(elmContainer.length === 0){
        elmContainer  = elm.parents('.container-page');
    }
    elmParent  = elm.parents('.parent-'+elmAction);
    elmAttr = {};
    elmAttr = elm.data();

    if('action' in elmAttr &&  elmAttr['action'] == 'post_form'){

        elmAttr = {};
    }else {

        for(let at in elmAttr){
            elmAttr[at] = elm.attr('data-'+at);
        }
    }

    if(elmAction in functAdmin){
        functAdmin[elmAction](elmAttr);
    }else {
        functAdmin.error();
    }
};

functAdmin.error = function (data) {
    alert('Неверный вызов');
};
functAdmin.render_error = function (data) {
    alert(data);
};
functAdmin.active_click = function (data) {
    if(!elmParent.hasClass('active')){
        $('.active',elmParent).removeClass('active');
        elm.addClass('active');
    }
};
functAdmin.render_html = function (data) {
    for (let key in data['render_html']) {
        let elHtml =  $(key,elmContainer);
        elHtml.fadeOut(function () {
            elHtml.html(data['render_html'][key]);
            elHtml.fadeIn();
        });

    }
};
functAdmin.set_pag = function(data){

};
$(document).on('keyup','.in-put',function () {
    /*let valr = $(this).val();
    let name = $(this).attr('data-attr');
    let container = $(this).attr('data-container');*/



    /*let attrPanel =  functAdmin.get_panel_attrObject();
    if (typeof attrPanel != 'undefined') {
        attrPanel['loanBack'][attrr_name] = valr;
        functAdmin.set_panel_attr(attrPanel);
    }*/

});
functAdmin.worker_filter = function (data) {
    //получить все фильтра
    data = functAdmin.get_filter(data);

    ajax_send(data,elmAction);
};
functAdmin.get_filter = function (data) {
    //получить все фильтра
    // let parent = $(elm).parents('.wrap-filter',elmContainer);
    let parent = $('.wrap-filter',elmContainer);
    data['search_key'] = $('.filter-search select[name="search_key"]',parent).val();
    data['search_val'] = $('.filter-search input[name="search_val"]',parent).val();

    data['order_key']  = $('.filter-order select[name="order_key"]',parent).val();
    data['order_val']  = $('.filter-order select[name="order_val"]',parent).val();

    data['set_page'] =  $('.filter-page input[name="set_page"]',parent).val();
    return data;
};
let timout_pagin;
$(document).on('keyup','.pagin-in',function () {
    let h = this;
    clearTimeout(timout_pagin);
    timout_pagin = setTimeout(function () {
        functAdmin.action_but(h);
    },500);

});
functAdmin.filter_pagin = function (data) {
    data = functAdmin.get_filter(data);
    let parnt = $(elm).parents('.pagin-cont');
    let page = parseInt($('.wrap-pagin-in input',parnt).val());
    let offset = page;
    if(page >=1){
        if(data['procces'] === 'right') {
            page++;
            offset = page;
            data['offset'] =  parseInt(data['set_page']) * (offset-1);
        }
        if(data['procces'] === 'left') {
            if(page>1){
                page--;
            }
            offset = page;
            data['offset'] =  parseInt(data['set_page']) * (offset-1);
        }
        if(data['procces'] === 'input') {

            data['offset'] =  parseInt(data['set_page']) * (offset-1);
        }
        data['page'] = page;
        $('.wrap-pagin-in input',parnt).val(page)
    }


    ajax_send(data,'worker_filter');
};

functAdmin.render_just = function (data) {
    let dd = data['render_just'];
    for (let key in data['render_just']) {
        let elHtml =  $(key,elmContainer);
        elHtml.html(data['render_just'][key]);

    }
};
functAdmin.delete_html = function (data) {
    if(data){
        for (let key in data['delete_html']) {
            let elHtml =  $(key,elmContainer);
            elHtml.fadeOut(function () {
                elHtml.remove();
            });

        }
    }

};
//аякс отправка для новых пользоателей
function ajax_send(data,url){
    if(data['action'] in globalParam){
        data['global_param'] = globalParam[data['action']];
        /*$.extend(data, globalParam[data['action']]);*/
    }
    var url_action = 'url_action' in data;
    if(url_action && typeof data['url_action'] != "undefined" && data['url_action'] !== '' ){
        url =  data['url_action']+url;
    }
    url = url.replaceAll('_','-');
    $.ajax({
        url: ''+url,
        /*url: 'site/'+url,*/
        type: 'POST',
        dataType:'json',
        data: data,
        success: function(data) {
            if(data){
                let checkError = 'error' in data;
                if(!checkError){
                    for (let method in data['method']){
                        if(data['method'][method] in functAdmin){
                            functAdmin[data['method'][method]](data);
                        }else {
                            functAdmin.error();
                        }
                    }

                }else {
                    functAdmin['render_error'](data['error']);
                }
            }else {
                functAdmin.error();
            }


        }
    });
}
functAdmin.common_action = function (data) {
    functAdmin.active_click(data);
    if('action_name' in data ){
        elmAction = data['action_name'];
        data['action'] = data['action_name'];
        functAdmin.active_click(data);
        ajax_send(data,elmAction);
    }else {
        functAdmin.error();
    }

};

functAdmin.post_form = function (data){
    event.preventDefault();
    setTimeout(function () {
        let form =   $(elm,elmContainer).parents('form');
        if(!$('input',form).hasClass('is-invalid')){
            let dataForm = form.serializeArray();
            let urlAction = form.attr('action');
            //event.preventDefault();
            for( let one in data ){
                dataForm[dataForm.length] = {'name':one,'value':data[one]}
            }
            Object.assign(data, dataForm);
            ajax_send(dataForm,urlAction);
        }
    },1000);


};
functAdmin.confirm_popup = function (data) {
    functAdmin.active_click(data);
    var text = 'text' in data;
    if(!text ){
        data['text'] = elm.text();
    }else if(typeof data['text'] == "undefined" || data['text'] === '' ){
        data['text'] = elm.text();
    }
    //elmAction ='/panel/'+elmAction;
    //тут нет панели такчто ее не используем
    elmAction ='/'+elmAction;
    ajax_send(data,elmAction);
};
functAdmin.ajax_popup = function (data) {
    //let dd = data['popup'];
    for (let key in data['ajax_popup']) {
        // let r = data['popup'][key];
        let elHtml =  $(key).append(data['ajax_popup'][key]);
        let ajax_popup = $('.ajax_popup',elHtml);
        /*let elHtml =  $(data['popup'][key],elmContainer);*/
        ajax_popup.fadeOut(function () {
            /* elHtml.html(data['html'][key]);*/
            ajax_popup.fadeIn();
        });

    }
};
$(document).on('click','.ajax_popup .close-popup',function(){
    let h =  $(this);
    let parnt =  h.parents('.ajax_popup');
    parnt.fadeOut(function () {
        parnt.remove();
    });
});

$(document).on('submit','#submit_form,#form-set', function(e) {
    e.preventDefault();
    submit_form(e);
    return false;
});
function submit_form(htmlForm,dataForm=false,url=false) {
    htmlForm.preventDefault();

    let form = $(htmlForm.currentTarget);//это this это dataForm атрибуты
    let test = $(htmlForm.currentTarget).attr('action');
    // var data = form.serialize();
    //let formData = new FormData();
    let data = form.serializeArray();
    /* for(let el in data){
         let valIn = data[el]['value'];

         /!*if(data[el]['name'] == 'NewLoan[path_doc]' || data[el]['name'] == 'NewFiz[path_photo]' || data[el]['name'] == 'NewFiz[path_prop]' || data[el]['name'] == 'NewLoan[path_ogrn_inn]' || data[el]['name'] == 'NewLoan[path_director]' || data[el]['name'] == 'NewLoan[path_deposit]'){
             if(valIn == ''){
                 valIn = 'empty';
             }
         }*!/

         formData.append(data[el]['name'], valIn);
     }*/
    /*$.each(dataFiles,function(key, input){
        for(let f_key in input){
            let nm = key+'['+f_key+']';
            formData.append(nm, input[f_key]);
        }

    });*/
    let act = form.attr('action');
    // отправляем данные на сервер
    $.ajax({
        url: ''+form.attr('action'),
        type: 'POST',
        data: data,
        dataType:'json',
        success: function(data) {
            load_ajax = true;
            if (data) {
                let checkError = 'error' in data;
                if (!checkError) {
                    if (data.html_replace) {
                        functAdmin['html_replace'](data);
                    }

                    for (let method in data['method']) {
                        if (data['method'][method] in functAdmin) {
                            functAdmin[data['method'][method]](data);
                        } else {
                            functAdmin.error();
                        }
                    }

                } else {
                    functAdmin['render_error'](data['error']);
                }
            } else {
                functAdmin.error();
            }

        }

    });
}
functAdmin.redirect_js = function (data) {
    window.location.href = data['redirect_js'];
};

$(document).on('submit','#submit_action', function(e) {
    e.preventDefault();
    if(!$(this).hasClass('bunk-wait')){
        functAdmin.action_but(this);
    }
});
functAdmin.start_bet =function(data){

    data['max_bet'] = $('input[name="max_bet"]',elmParent).val();
    data['dawn_bet'] = $('input[name="dawn_bet"]',elmParent).val();
    data['preview'] = $('textarea[name="preview"]',elmParent).val();
    ajax_send(data,elmAction);
};

functAdmin.create_message =function(data){

    data['triger'] = $('input[name="triger"]',elmParent).val();
    data['text'] = $('textarea[name="text"]',elmParent).val();
    ajax_send(data,elmAction);
};
functAdmin.create_message_bet =function(data){
    data['text'] = $('textarea[name="text"]',elmParent).val();
    ajax_send(data,elmAction);
};
functAdmin.my_filter =function(data){
    data['type']=[];
    data['subjects']=[];
     $('.worktypeBlock input',elmParent).prop('checked').each(function (index,element) {

         data['type'].push = $(element).val();
    });
   /* $('.checked_languages input',elmParent).prop('checked').each(function (index,element) {

        data['type'].push = $(element).val();
    });*/

    $('.checked_languages input',elmParent).prop('checked').each(function (index,element) {

        data['subjects'].push = $(element).val();
    });

    $('.checked_languages input',elmParent).prop('checked').each(function (index,element) {

        data['subjects'].push = $(element).val();
    });

    $('.GumanitarnyeBlock input',elmParent).prop('checked').each(function (index,element) {

        data['subjects'].push = $(element).val();
    });

    $('.EkonomicheskieBlock input',elmParent).prop('checked').each(function (index,element) {

        data['subjects'].push = $(element).val();
    });

    $('input[name="max_bet"]',elmParent).val();

    /*'budgetFrom'=>0,//0
        'budgetTo'=>200000,//200000
        'deadlineFrom'=>0,
        'deadlineTo'=>365,
        'uniqueValueFrom'=>0,
        'uniqueValueTo'=>100,
        'bidCountFrom'=>0,
        'bidCountTo'=>200,*/


    data['dawn_bet'] = $('input[name="dawn_bet"]',elmParent).val();
    data['preview'] = $('textarea[name="preview"]',elmParent).val();
    ajax_send(data,elmAction);
};

