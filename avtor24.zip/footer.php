</body>
<script src="js/jquery-3.2.0.min.js"></script>
<script src="js/admin.js?ver=1.1"></script>
<?php
if($user['ajax']){?>
    <script src="js/ajax_bet.js?ver=1.1"></script>
<?php    } ?>
</html>
