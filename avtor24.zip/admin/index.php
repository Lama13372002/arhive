<?php require_once   '../header.php'; ?>
    <style>
        .bet-button {
            padding: 6px;
            border: 2px solid black;
            border-radius: 6px;
            max-width: 276px;
            width: 100%;
            text-align: center;
            background: #29579b;
            color: white;
            margin-bottom: 10px;
            font-size: 16px;
            cursor: pointer;
        }
        .bet-button.but-red {
            background: red;
        }
        .but-black {
            background: black!important;
        }
       .bet-telegram-triger .bet-param {
            max-width: 259px;
            width: 100%;
            margin-bottom: 11px;
        }
        .bet-param {
            max-width: 276px;
            width: 100%;
            margin-bottom: 11px;
        }
        .bet-param input {
            font-size: 18px;
            padding: 6px;
            border: 2px solid #1c1a1a;
            border-radius: 6px;
            /*max-width: 241px;*/
            width: 100%;
        }
        .bet-previe textarea {
            padding: 10px;
            border-radius: 16px;
            margin-bottom: 10px;
        }
        .bet-info {
            margin-left: 13px;
        }
        .info-logo {
            font-size: 16px;
            margin-bottom: 5px;
        }
        .info-param {
            text-align: right;
            width: 100%;
        }
        .info-one {
            margin-bottom: 6px;
        }
        .bet-massage {
            margin: 10px 0px;
            min-height: 24px;
            width: 100%;
            text-align: center;
            border-bottom: 2px solid black;
            padding-bottom: 9px;
            margin-bottom: 17px;
        }
        .message {
            font-size: 20px;
        }
        .bet-telegram {
            margin-right: 10px;
            width: 100%;
            min-width: 278px;
        }
        .tel-triger {
            margin-bottom: 3px;
        }
        .tel-text {
            font-size: 18px;
            padding: 6px;
            border: 2px solid #1c1a1a;
            border-radius: 6px;
            /* max-width: 241px; */
            width: 100%;

        }
        .parent-start_bet  .tel-text {
            min-width: 371px;
        }
        .but-black.action-but:hover {
            box-shadow: inset 0px 0px 6px rgb(245 245 245);
        }
        .submt-but:hover {
            box-shadow: inset 0px 0px 6px rgb(0 0 0);
        }
        .bet-telegram-triger,.bet-telegram-triger_message {
            max-height: 350px;
            overflow-y: auto;
            margin-bottom: 14px;
            border-radius: 7px;
            border: 2px solid black;
            padding: 4px;
        }
        /*.bet-info .info-one:not(:last-child) {
            margin-right: 10px;
        }*/
        .crate_style,.delete_style,input.crate_style {
            padding: 1px 5px;
            border: 2px solid #000000;
            border-radius: 6px;
            max-width: fit-content;
            width: 100%;
            font-size: 14px;
            margin-bottom: 2px;
            cursor: pointer;
            background: #29579b;
            color: white;
        }
        .delete_style{
            background: #ff0000!important;
        }
        .crate_style:hover {
            box-shadow: inset 0px 0px 6px rgb(0 0 0);
        }
        .logo-message {
            text-align: center;
            margin-block: 5px;
        }
        .filter-a a,.filter-a  {
            width: 100%;
        }

    </style>
<div class="panel-bet">
    <div class="panel-container flex-cen-c flex-col-cen">
        <div class="bet-massage">
            <h2 class="message"><?php
                if($user && $user['logo']){
                    echo $user['logo'];

                }else{
                    echo 'Ставки';
                }
                ?></h2>
        </div>
        <div class="wrap-bet-info flex-start-start">
            <div class="bet-telegram">
                <div class="wrap-logo-message">
                    <h2 class="logo-message"><?php
                        if($user && $user['logo_message']){
                            echo $user['logo_message'];

                        }else{
                            echo 'Бот сообщения';
                        }
                        ?></h2>
                </div>
                <div class="bet-button action-but but-black" data-action="common_action" data-action_name="add_message">
                    Message Bot
                </div>
                <div class="bet-telegram-triger">
                    <?php
                    if($user && $user['message']){
                        echo $user['message'];
                    }else{
                        echo 'нет паттернов';
                    }?>

                </div>


                <div class="bet-button action-but action-but" data-action_name="start_message"
                     data-action="common_action">
                    Установить бота
                </div>
                <div class="bet-button action-but but-red action-but" data-action_name="stop_message"
                     data-action="common_action">
                    Остановить бота
                </div>
            </div>
            <div class="parent-start_bet ">
                <form id="submit_action" data-action="start_bet">
                    <div class="bet-preview">
                        <textarea name="preview" required class="tel-text" id="" cols="30" rows="10"><?php
                            if($user && $user['preview']){
                            echo $user['preview'];

                            }else{
                                echo 'Добрый день, приятно познакомится.';
                            }
                            ?></textarea>
                    </div>

                    <div class="flex-col-cen">

                            <div class="bet-param">
                                <h3>максимум</h3>
                                <input type="number" name="max_bet" placeholder="максимум ставок"  required value="<?php
                                if($user && $user['max_bet']){
                                    echo $user['max_bet'];
                                }else{
                                    echo '100';
                                }?>">
                            </div>
                            <!--<div class="bet-param">
                                <h3>глубина</h3>
                                <input type="number" name="dawn_bet" placeholder="глубина ставок"  required value="<?php
/*                                if($user && $user['dawn_bet']){
                                    echo $user['dawn_bet'];
                                }else{
                                    echo '0';
                                }*/?>">
                            </div>-->
                            <input type='submit' class="bet-button submt-but" value=" Сделать ставки">
                            <!--<div class="bet-button action-but" data-action="start_bet">
                                Сделать ставки
                            </div>-->


                        <div class="bet-button action-but but-red action-but" data-action_name="stop_bet"
                        data-action="common_action">
                            Остановить ставки
                        </div>





                            <!--<div class="bet-button action-but but-black action-but" data-action_name="delete_bet"
                                 data-action="common_action">
                                Отменить ставки
                            </div>-->
                    </div>
                </form>
            </div>

            <div class="bet-info flex-col-cen">
                <div class="info-one flex-col-start">
                    <div class="info-logo"></div>
                    <a href="/"><div class="bet-button  ">
                            <?php
                            if($user && $user['email']){
                                echo $user['email'];
                            }else{
                                echo 'Нет пользователя';
                            }?>
                    </div></a>
                </div>
                <div class="info-one flex-col-start filter-a">
                    <div class="info-logo"></div>
                    <div class="bet-button  action-but" data-action_name="update_filter"
                                               data-action="common_action">
                            <?php
                            if($user && $user['types'] || $user['objects']){
                                echo 'Фильтр установлен';
                            }else{
                                echo 'Нет фильтра';
                            }?>
                        </div>
                </div>
                <div class="info-one flex-col-start filter-a">
                    <div class="info-logo"></div>
                    <div class="bet-button  action-but bets-load but-black" data-action_name="get_bets"
                         data-action="common_action">
                        <?php
                        if($user && $user['bets'] ){
                            echo ' Есть ускорение';
                        }else{
                            echo 'Нет ускарения';
                        }?>
                    </div>
                </div>
                <div class="info-one flex-col-start filter-a">
                    <div class="info-logo"></div>

                    <div class="bet-button  action-but bets-load2 set_monitor" data-action_name="set_monitor"
                         data-action="common_action">
                        <?php
                        if($user && $user['page'] ){
                            echo 'Последние';
                        }else{
                            echo 'Первые';
                        }?>
                    </div>
                </div>
                <div class="info-one flex-col-start">
                    <div class="info-logo">Ставок сделано</div>
                    <div class="info-param bet-set"><?php
                            if($user && $user['bet']){
                                 echo $user['bet'];
                                //echo '0';
                            }else{
                                echo '0';
                            }?></div>
                </div>
                <div class="info-one flex-col-start">
                    <div class="bet-telegram">
                        <style>
                            .but-green {
                                background: #00b716!important;
                            }
                        </style>
                        <div class="bet-button action-but but-green" data-action="common_action"
                             data-action_name="add_message_bet">
                            Message
                        </div>
                        <div class="bet-telegram-triger_message message_bet">
                            <?php
                            if($user && $user['message_bet']){
                                echo $user['message_bet'];
                            }else{
                                echo 'нет паттернов';
                            }?>

                        </div>
                    </div>
                </div>

            </div>

            </div>
    </div>

</div>
<?php
require_once  '../footer.php';