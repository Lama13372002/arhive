/**
 * Утилиты для работы с временными зонами
 * Московское время: UTC+3
 */

// Московская временная зона
const MOSCOW_TIMEZONE = 'Europe/Moscow';
const MOSCOW_UTC_OFFSET = 3; // UTC+3

/**
 * Получить текущее московское время
 */
export function getMoscowTime(): Date {
  return new Date(new Date().toLocaleString("en-US", { timeZone: MOSCOW_TIMEZONE }));
}

/**
 * Получить московское время из строки даты
 */
export function getMoscowTimeFromString(dateString: string): Date {
  const date = new Date(dateString);
  return new Date(date.toLocaleString("en-US", { timeZone: MOSCOW_TIMEZONE }));
}

/**
 * Конвертировать время в московское
 */
export function convertToMoscowTime(date: Date): Date {
  return new Date(date.toLocaleString("en-US", { timeZone: MOSCOW_TIMEZONE }));
}

/**
 * Проверить, прошло ли указанное количество часов с момента матча (в московском времени)
 */
export function hasMatchTimePassedMoscow(matchDate: string | Date, hoursThreshold: number = 2): boolean {
  try {
    const matchTime = typeof matchDate === 'string' ? new Date(matchDate) : matchDate;
    const moscowNow = getMoscowTime();

    // Если время матча указано в UTC или другом часовом поясе, приводим к московскому
    const matchTimeMoscow = convertToMoscowTime(matchTime);

    const hoursPassedSinceMatch = (moscowNow.getTime() - matchTimeMoscow.getTime()) / (1000 * 60 * 60);

    console.log(`🕒 Время матча (МСК): ${matchTimeMoscow.toLocaleString('ru-RU', { timeZone: MOSCOW_TIMEZONE })}`);
    console.log(`🕒 Текущее время (МСК): ${moscowNow.toLocaleString('ru-RU', { timeZone: MOSCOW_TIMEZONE })}`);
    console.log(`🕒 Прошло часов: ${hoursPassedSinceMatch.toFixed(1)}`);

    return hoursPassedSinceMatch >= hoursThreshold;
  } catch (error) {
    console.error('Ошибка при проверке времени матча:', error);
    return false;
  }
}

/**
 * Проверить, является ли матч старым (более 4 часов от московского времени)
 */
export function isMatchOldMoscow(matchDate: string | Date): boolean {
  return hasMatchTimePassedMoscow(matchDate, 4);
}

/**
 * Получить форматированное московское время
 */
export function formatMoscowTime(date: Date, format: 'full' | 'time' | 'date' = 'full'): string {
  const moscowTime = convertToMoscowTime(date);

  const options: Intl.DateTimeFormatOptions = {
    timeZone: MOSCOW_TIMEZONE,
    ...(format === 'full' && {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }),
    ...(format === 'time' && {
      hour: '2-digit',
      minute: '2-digit'
    }),
    ...(format === 'date' && {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    })
  };

  return moscowTime.toLocaleString('ru-RU', options);
}

/**
 * Логирование с московским временем
 */
export function logWithMoscowTime(message: string, level: 'info' | 'error' | 'warn' = 'info'): void {
  const timestamp = formatMoscowTime(new Date(), 'full');
  const logMessage = `[${timestamp} МСК] ${message}`;

  switch (level) {
    case 'error':
      console.error(logMessage);
      break;
    case 'warn':
      console.warn(logMessage);
      break;
    default:
      console.log(logMessage);
  }
}

/**
 * Получить разницу в часах между московским временем и UTC
 */
export function getMoscowUtcOffset(): number {
  return MOSCOW_UTC_OFFSET;
}

/**
 * Проверить, находится ли время в пределах игрового дня (с учетом московского времени)
 */
export function isWithinGameDayMoscow(matchDate: string | Date): boolean {
  try {
    const matchTime = typeof matchDate === 'string' ? new Date(matchDate) : matchDate;
    const moscowNow = getMoscowTime();
    const matchTimeMoscow = convertToMoscowTime(matchTime);

    // Матч считается актуальным если он:
    // 1. Еще не начался (будущее время)
    // 2. Начался, но прошло менее 3 часов (время игры + дополнительное время)
    const timeDiffHours = (moscowNow.getTime() - matchTimeMoscow.getTime()) / (1000 * 60 * 60);

    return timeDiffHours <= 3; // 3 часа - максимальная продолжительность футбольного матча
  } catch (error) {
    console.error('Ошибка при проверке игрового дня:', error);
    return false;
  }
}
