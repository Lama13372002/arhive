import { NextResponse } from 'next/server';
import { createDbConnection, type RawSubscriptionPlan } from '@/lib/database';

export async function GET() {
  const client = createDbConnection();

  try {
    await client.connect();

    const result = await client.query(
      `SELECT id, name, description, price, currency, token_amount, features, is_active
       FROM subscription_plans
       WHERE is_active = true
       ORDER BY price ASC`
    );

    const plans = result.rows.map((plan: RawSubscriptionPlan) => ({
      id: plan.id,
      name: plan.name,
      description: plan.description,
      price: parseFloat(plan.price),
      currency: plan.currency,
      token_amount: plan.token_amount,
      features: plan.features,
      is_active: plan.is_active
    }));

    return NextResponse.json({
      success: true,
      plans
    });

  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  } finally {
    await client.end();
  }
}
