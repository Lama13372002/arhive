import { NextRequest, NextResponse } from 'next/server';
import { createDbConnection } from '@/lib/database';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const userId = searchParams.get('user_id');

  if (!userId) {
    return NextResponse.json(
      { success: false, error: 'User ID is required' },
      { status: 400 }
    );
  }

  const client = createDbConnection();

  try {
    await client.connect();

    // Получаем активные планы пользователя
    const activeSubscriptionsQuery = `
      SELECT
        us.id,
        us.start_date,
        us.end_date,
        us.status,
        sp.name as plan_name,
        sp.token_amount,
        sp.features,
        COALESCE(SUM(tu.cost_tokens), 0) as tokens_used
      FROM user_subscriptions us
      JOIN subscription_plans sp ON us.plan_id = sp.id
      LEFT JOIN token_usage tu ON tu.user_id = us.user_id
        AND tu.created_at >= us.start_date
        AND (us.end_date IS NULL OR tu.created_at <= us.end_date)
      WHERE us.user_id = $1 AND us.status = 'active'
      GROUP BY us.id, us.start_date, us.end_date, us.status, sp.name, sp.token_amount, sp.features
      ORDER BY us.created_at DESC
    `;

    // Получаем завершенные планы пользователя
    const closedSubscriptionsQuery = `
      SELECT
        us.id,
        us.start_date,
        us.end_date,
        us.status,
        sp.name as plan_name,
        sp.token_amount,
        sp.features,
        COALESCE(SUM(tu.cost_tokens), 0) as tokens_used
      FROM user_subscriptions us
      JOIN subscription_plans sp ON us.plan_id = sp.id
      LEFT JOIN token_usage tu ON tu.user_id = us.user_id
        AND tu.created_at >= us.start_date
        AND (us.end_date IS NULL OR tu.created_at <= us.end_date)
      WHERE us.user_id = $1 AND us.status IN ('expired', 'cancelled')
      GROUP BY us.id, us.start_date, us.end_date, us.status, sp.name, sp.token_amount, sp.features
      ORDER BY us.end_date DESC NULLS LAST
    `;

    const [activeResult, closedResult] = await Promise.all([
      client.query(activeSubscriptionsQuery, [userId]),
      client.query(closedSubscriptionsQuery, [userId])
    ]);

    // Обрабатываем активные планы
    const activePlans = activeResult.rows.map(row => ({
      id: row.id,
      plan_name: row.plan_name,
      token_amount: row.token_amount,
      tokens_used: parseInt(row.tokens_used),
      tokens_remaining: row.token_amount - parseInt(row.tokens_used),
      start_date: row.start_date,
      end_date: row.end_date,
      status: row.status,
      features: row.features || []
    }));

    // Обрабатываем завершенные планы
    const closedPlans = closedResult.rows.map(row => ({
      id: row.id,
      plan_name: row.plan_name,
      token_amount: row.token_amount,
      tokens_used: parseInt(row.tokens_used),
      tokens_remaining: Math.max(0, row.token_amount - parseInt(row.tokens_used)),
      start_date: row.start_date,
      end_date: row.end_date,
      status: row.status,
      features: row.features || []
    }));

    return NextResponse.json({
      success: true,
      active_plans: activePlans,
      closed_plans: closedPlans
    });

  } catch (error) {
    console.error('Error fetching user plans:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch user plans' },
      { status: 500 }
    );
  } finally {
    await client.end();
  }
}

// Создание нового плана для пользователя (при покупке)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { user_id, plan_id, payment_id } = body;

    if (!user_id || !plan_id) {
      return NextResponse.json(
        { success: false, error: 'User ID and Plan ID are required' },
        { status: 400 }
      );
    }

    const client = createDbConnection();
    await client.connect();

    // Проверяем, есть ли у пользователя активные подписки
    const existingActiveSubscriptionsQuery = `
      SELECT us.id, sp.name as plan_name, us.start_date,
             sp.token_amount,
             COALESCE(SUM(tu.cost_tokens), 0) as tokens_used
      FROM user_subscriptions us
      JOIN subscription_plans sp ON us.plan_id = sp.id
      LEFT JOIN token_usage tu ON tu.user_id = us.user_id
        AND tu.created_at >= us.start_date
        AND (us.end_date IS NULL OR tu.created_at <= us.end_date)
      WHERE us.user_id = $1 AND us.status = 'active'
      GROUP BY us.id, sp.name, us.start_date, sp.token_amount
    `;

    const existingResult = await client.query(existingActiveSubscriptionsQuery, [user_id]);

    if (existingResult.rows.length > 0) {
      const activeSubscription = existingResult.rows[0];
      const tokensRemaining = activeSubscription.token_amount - parseInt(activeSubscription.tokens_used);

      await client.end();
      return NextResponse.json({
        success: false,
        error: `У вас уже есть активная подписка "${activeSubscription.plan_name}" с ${tokensRemaining} неиспользованными токенами. Сначала используйте текущую подписку.`,
        existing_subscription: {
          plan_name: activeSubscription.plan_name,
          tokens_remaining: tokensRemaining,
          start_date: activeSubscription.start_date
        }
      }, { status: 400 });
    }

    // Получаем информацию о плане
    const planQuery = 'SELECT * FROM subscription_plans WHERE id = $1 AND is_active = true';
    const planResult = await client.query(planQuery, [plan_id]);

    if (planResult.rows.length === 0) {
      await client.end();
      return NextResponse.json(
        { success: false, error: 'Plan not found or inactive' },
        { status: 404 }
      );
    }

    const plan = planResult.rows[0];

    // Создаем новую подписку
    const insertQuery = `
      INSERT INTO user_subscriptions (user_id, plan_id, start_date, end_date, status, payment_id)
      VALUES ($1, $2, NOW(), NULL, 'active', $3)
      RETURNING *
    `;

    const insertResult = await client.query(insertQuery, [user_id, plan_id, payment_id]);
    const newSubscription = insertResult.rows[0];

    // Добавляем токены к балансу пользователя
    const updateTokensQuery = `
      UPDATE users
      SET token_balance = token_balance + $1, updated_at = NOW()
      WHERE id = $2
      RETURNING token_balance
    `;

    const tokensResult = await client.query(updateTokensQuery, [plan.token_amount, user_id]);

    await client.end();

    return NextResponse.json({
      success: true,
      subscription: newSubscription,
      new_token_balance: tokensResult.rows[0].token_balance,
      tokens_added: plan.token_amount
    });

  } catch (error) {
    console.error('Error creating user subscription:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create subscription' },
      { status: 500 }
    );
  }
}
