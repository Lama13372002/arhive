import { NextResponse, NextRequest } from 'next/server';
import { checkOpenAIAccess, proxyFetchOpenAI } from '@/lib/proxy-fetch';

export async function POST(request: NextRequest) {
  try {
    const { endpoint = '/v1/models' } = await request.json();

    console.log(`🔍 Тестируем OpenAI API endpoint: ${endpoint}`);

    // Проверяем доступность OpenAI API через прокси
    if (endpoint === '/v1/models') {
      const result = await checkOpenAIAccess();

      console.log('✅ Результат тестирования OpenAI API:', result);

      return NextResponse.json({
        success: result.success,
        error: result.error,
        responseTime: result.responseTime,
        proxyUsed: result.proxyUsed,
        endpoint: endpoint,
        timestamp: new Date().toISOString()
      });
    } else {
      // Для других endpoints используем проксированный запрос
      const apiKey = process.env.OPENAI_API_KEY;

      if (!apiKey) {
        return NextResponse.json({
          success: false,
          error: 'OPENAI_API_KEY не установлен',
          responseTime: 0,
          endpoint: endpoint,
          timestamp: new Date().toISOString()
        });
      }

      const result = await proxyFetchOpenAI(
        endpoint,
        {},
        apiKey,
        { timeout: 15000 }
      );

      console.log(`✅ Результат тестирования ${endpoint}:`, result);

      return NextResponse.json({
        success: result.success,
        error: result.error,
        responseTime: result.responseTime,
        proxyUsed: result.proxyUsed,
        endpoint: endpoint,
        status: result.status,
        timestamp: new Date().toISOString()
      });
    }

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('❌ Критическая ошибка тестирования OpenAI API:', error);

    return NextResponse.json({
      success: false,
      error: `Критическая ошибка: ${errorMessage}`,
      responseTime: 0,
      timestamp: new Date().toISOString(),
      stack: error instanceof Error ? error.stack : undefined
    }, { status: 500 });
  }
}
