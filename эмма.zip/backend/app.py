from flask import Flask, request, jsonify, Response, stream_with_context
from flask_cors import CORS
import requests
import json
import os
from datetime import datetime
import uuid

app = Flask(__name__)
CORS(app)

# OpenRouter configuration
OPENROUTER_API_KEY = os.environ.get('OPENROUTER_API_KEY', '')
OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions'

# In-memory storage (в продакшене использовать базу данных)
user_sessions = {}
user_progress = {}

# Story arc definitions
STORY_ARCS = {
    "arc1": {
        "id": "arc1",
        "title": "Знакомство",
        "description": "Первая встреча с Эммой",
        "scenes": [
            {
                "id": "scene1",
                "title": "Случайная встреча",
                "context": "Вы случайно столкнулись с Эммой в кофейне. Она уронила свой ноутбук, и вы помогли ей его поднять.",
                "objectives": ["Познакомиться", "Узнать что-то о ней", "Предложить встретиться снова"],
                "next_scenes": ["scene2"]
            },
            {
                "id": "scene2",
                "title": "Первое свидание",
                "context": "Эмма согласилась встретиться с вами в парке. Она кажется немного нервной, но рада видеть вас.",
                "objectives": ["Узнать её интересы", "Рассказать о себе", "Создать комфортную атмосферу"],
                "next_scenes": ["scene3_romantic", "scene3_friendly"]
            },
            {
                "id": "scene3_romantic",
                "title": "Романтический момент",
                "context": "Солнце садится, и вы гуляете по парку. Эмма случайно касается вашей руки.",
                "objectives": ["Проявить романтический интерес", "Быть искренним"],
                "next_scenes": ["ending_romantic"]
            },
            {
                "id": "scene3_friendly",
                "title": "Дружеская беседа",
                "context": "Вы обсуждаете общие интересы и много смеётесь.",
                "objectives": ["Углубить дружбу", "Узнать больше"],
                "next_scenes": ["ending_friendship"]
            },
            {
                "id": "ending_romantic",
                "title": "Романтическая концовка",
                "context": "Вы держитесь за руки и договариваетесь о следующем свидании.",
                "objectives": ["Завершить арку"],
                "is_ending": True,
                "ending_type": "romantic"
            },
            {
                "id": "ending_friendship",
                "title": "Дружеская концовка",
                "context": "Вы становитесь хорошими друзьями и обмениваетесь номерами.",
                "objectives": ["Завершить арку"],
                "is_ending": True,
                "ending_type": "friendship"
            }
        ]
    },
    "arc2": {
        "id": "arc2",
        "title": "Развитие отношений",
        "description": "Отношения с Эммой становятся глубже",
        "locked": True,
        "unlock_condition": "arc1_completed"
    }
}

# Emma's character definition
EMMA_CHARACTER = {
    "name": "Эмма",
    "age": 24,
    "personality": "Умная, немного застенчивая, любит книги и искусство. Работает дизайнером. Ценит искренность и чувство юмора. Иногда нервничает в новых ситуациях, но быстро раскрывается с теми, кому доверяет.",
    "interests": ["чтение", "живопись", "кофе", "инди-музыка", "путешествия"],
    "background": "Недавно переехала в этот город. Работает в небольшой дизайн-студии. Любит исследовать новые места и встречать интересных людей."
}

def create_system_prompt(mode="story", scene_data=None, relationship_context=None):
    """Create system prompt for Emma based on mode"""
    base_prompt = f"""Ты - Эмма: {EMMA_CHARACTER['personality']}

Твои интересы: {', '.join(EMMA_CHARACTER['interests'])}.
О тебе: {EMMA_CHARACTER['background']}

ВАЖНЫЕ ПРАВИЛА:
1. Отвечай от первого лица как Эмма
2. Будь естественной и живой в диалоге
3. Используй эмоции и реакции (*улыбается*, *смущается*, *задумывается*)
4. Помни контекст предыдущих сообщений
5. Не выходи из роли
6. Отвечай на русском языке
7. Будь последовательной в характере
"""

    if mode == "story" and scene_data:
        base_prompt += f"""
СЮЖЕТНЫЙ РЕЖИМ - Сцена: {scene_data['title']}
Контекст: {scene_data['context']}
Цели сцены: {', '.join(scene_data['objectives'])}

Веди диалог согласно этой сцене. Помогай развивать сюжет естественно."""

    elif mode == "free":
        base_prompt += f"""
СВОБОДНЫЙ РЕЖИМ - Непринужденное общение
Просто общайся естественно, без сюжетных ограничений.
"""

    if relationship_context:
        base_prompt += f"\nВаши отношения: {relationship_context}"

    return base_prompt

@app.route('/api/chat', methods=['POST'])
def chat():
    """Main chat endpoint with streaming support"""
    data = request.json
    message = data.get('message')
    session_id = data.get('session_id', str(uuid.uuid4()))
    mode = data.get('mode', 'free')  # 'story' or 'free'
    scene_id = data.get('scene_id')
    stream = data.get('stream', True)

    if not message:
        return jsonify({'error': 'Message is required'}), 400

    # Get or create session
    if session_id not in user_sessions:
        user_sessions[session_id] = {
            'messages': [],
            'created_at': datetime.now().isoformat(),
            'relationship_level': 0
        }

    session = user_sessions[session_id]

    # Get scene data if in story mode
    scene_data = None
    if mode == 'story' and scene_id:
        scene_data = next((s for arc in STORY_ARCS.values()
                          if not arc.get('locked', False)
                          for s in arc.get('scenes', [])
                          if s['id'] == scene_id), None)

    # Build conversation history
    system_prompt = create_system_prompt(
        mode=mode,
        scene_data=scene_data,
        relationship_context=f"Уровень близости: {session['relationship_level']}/100"
    )

    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(session['messages'][-10:])  # Last 10 messages for context
    messages.append({"role": "user", "content": message})

    # Add user message to history
    session['messages'].append({"role": "user", "content": message})

    # Prepare OpenRouter request
    openrouter_request = {
        "model": "anthropic/claude-3.5-sonnet",
        "messages": messages,
        "stream": stream,
        "temperature": 0.8,
        "max_tokens": 500
    }

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "HTTP-Referer": "https://emma-ai.app",
        "X-Title": "Emma AI Companion",
        "Content-Type": "application/json"
    }

    if stream:
        def generate():
            try:
                response = requests.post(
                    OPENROUTER_API_URL,
                    headers=headers,
                    json=openrouter_request,
                    stream=True
                )

                full_response = ""

                for line in response.iter_lines():
                    if line:
                        line_text = line.decode('utf-8')
                        if line_text.startswith('data: '):
                            data_str = line_text[6:]
                            if data_str == '[DONE]':
                                break

                            try:
                                chunk_data = json.loads(data_str)
                                if 'choices' in chunk_data and len(chunk_data['choices']) > 0:
                                    delta = chunk_data['choices'][0].get('delta', {})
                                    content = delta.get('content', '')
                                    if content:
                                        full_response += content
                                        yield f"data: {json.dumps({'content': content, 'session_id': session_id})}\n\n"
                            except json.JSONDecodeError:
                                pass

                # Save assistant response to history
                if full_response:
                    session['messages'].append({"role": "assistant", "content": full_response})

                yield f"data: {json.dumps({'done': True, 'session_id': session_id})}\n\n"

            except Exception as e:
                yield f"data: {json.dumps({'error': str(e)})}\n\n"

        return Response(stream_with_context(generate()), mimetype='text/event-stream')

    else:
        # Non-streaming response
        try:
            response = requests.post(
                OPENROUTER_API_URL,
                headers=headers,
                json=openrouter_request
            )
            response_data = response.json()

            if 'error' in response_data:
                return jsonify({'error': response_data['error']}), 500

            assistant_message = response_data['choices'][0]['message']['content']
            session['messages'].append({"role": "assistant", "content": assistant_message})

            return jsonify({
                'response': assistant_message,
                'session_id': session_id
            })

        except Exception as e:
            return jsonify({'error': str(e)}), 500

@app.route('/api/story/arcs', methods=['GET'])
def get_story_arcs():
    """Get all story arcs with progress"""
    session_id = request.args.get('session_id')

    arcs_data = []
    for arc_id, arc in STORY_ARCS.items():
        arc_info = {
            'id': arc_id,
            'title': arc['title'],
            'description': arc['description'],
            'locked': arc.get('locked', False),
            'progress': 0,
            'completed': False
        }

        if session_id and session_id in user_progress:
            progress = user_progress[session_id].get(arc_id, {})
            arc_info['progress'] = progress.get('progress', 0)
            arc_info['completed'] = progress.get('completed', False)
            arc_info['current_scene'] = progress.get('current_scene')

        arcs_data.append(arc_info)

    return jsonify({'arcs': arcs_data})

@app.route('/api/story/scene/<scene_id>', methods=['GET'])
def get_scene(scene_id):
    """Get specific scene data"""
    for arc in STORY_ARCS.values():
        if 'scenes' in arc:
            scene = next((s for s in arc['scenes'] if s['id'] == scene_id), None)
            if scene:
                return jsonify(scene)

    return jsonify({'error': 'Scene not found'}), 404

@app.route('/api/story/progress', methods=['POST'])
def update_progress():
    """Update story progress"""
    data = request.json
    session_id = data.get('session_id')
    arc_id = data.get('arc_id')
    scene_id = data.get('scene_id')
    completed = data.get('completed', False)

    if not session_id:
        return jsonify({'error': 'Session ID required'}), 400

    if session_id not in user_progress:
        user_progress[session_id] = {}

    if arc_id not in user_progress[session_id]:
        user_progress[session_id][arc_id] = {
            'progress': 0,
            'completed': False,
            'current_scene': None
        }

    user_progress[session_id][arc_id]['current_scene'] = scene_id
    user_progress[session_id][arc_id]['completed'] = completed

    # Calculate progress
    if arc_id in STORY_ARCS and 'scenes' in STORY_ARCS[arc_id]:
        total_scenes = len(STORY_ARCS[arc_id]['scenes'])
        scene_index = next((i for i, s in enumerate(STORY_ARCS[arc_id]['scenes'])
                          if s['id'] == scene_id), 0)
        user_progress[session_id][arc_id]['progress'] = int((scene_index + 1) / total_scenes * 100)

    return jsonify({'success': True, 'progress': user_progress[session_id][arc_id]})

@app.route('/api/session/create', methods=['POST'])
def create_session():
    """Create new session"""
    session_id = str(uuid.uuid4())
    user_sessions[session_id] = {
        'messages': [],
        'created_at': datetime.now().isoformat(),
        'relationship_level': 0
    }
    return jsonify({'session_id': session_id})

@app.route('/api/health', methods=['GET'])
def health():
    """Health check"""
    return jsonify({
        'status': 'ok',
        'api_key_configured': bool(OPENROUTER_API_KEY)
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
