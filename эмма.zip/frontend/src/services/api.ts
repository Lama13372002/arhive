import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

export interface ChatMessage {
  message: string
  session_id: string
  mode: 'story' | 'free'
  scene_id?: string
  stream: boolean
}

export interface StoryArc {
  id: string
  title: string
  description: string
  locked: boolean
  progress: number
  completed: boolean
  current_scene?: string
}

export interface Scene {
  id: string
  title: string
  context: string
  objectives: string[]
  next_scenes?: string[]
  is_ending?: boolean
  ending_type?: string
}

export interface SessionResponse {
  session_id: string
}

export interface ArcsResponse {
  arcs: StoryArc[]
}

export interface ProgressUpdate {
  session_id: string
  arc_id: string
  scene_id: string
  completed: boolean
}

export const apiService = {
  // Session management
  async createSession(): Promise<SessionResponse> {
    const { data } = await api.post<SessionResponse>('/session/create')
    return data
  },

  // Chat
  async sendMessage(payload: ChatMessage): Promise<Response> {
    const response = await fetch(`${API_BASE_URL}/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    })
    return response
  },

  // Story arcs
  async getStoryArcs(sessionId: string): Promise<ArcsResponse> {
    const { data } = await api.get<ArcsResponse>(`/story/arcs?session_id=${sessionId}`)
    return data
  },

  async getScene(sceneId: string): Promise<Scene> {
    const { data } = await api.get<Scene>(`/story/scene/${sceneId}`)
    return data
  },

  async updateProgress(payload: ProgressUpdate) {
    const { data } = await api.post('/story/progress', payload)
    return data
  },

  // Health check
  async healthCheck() {
    const { data } = await api.get('/health')
    return data
  },
}
