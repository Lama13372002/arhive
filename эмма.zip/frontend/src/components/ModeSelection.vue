<template>
  <div class="mode-selection">
    <div class="mode-card card">
      <h2 class="mode-title">💕 Что хотите сделать?</h2>

      <!-- Story Mode -->
      <div class="mode-section">
        <div class="section-header">
          <h3>📖 Продолжить историю</h3>
          <p class="section-description">Следуйте сюжетным аркам и развивайте отношения</p>
        </div>

        <div v-if="storyStore.loading" class="loading">
          <div class="spinner" />
          <span>Загрузка...</span>
        </div>

        <div v-else class="arcs-grid">
          <StoryArcCard
            v-for="arc in storyStore.arcs"
            :key="arc.id"
            :arc="arc"
            @select="handleSelectArc"
          />
        </div>
      </div>

      <!-- Free Mode -->
      <div class="mode-section">
        <div class="section-header">
          <h3>💬 Свободное общение</h3>
          <p class="section-description">Просто провести время с Эммой</p>
        </div>

        <LocationSelector v-model="selectedLocation" />

        <button
          class="btn-primary"
          :disabled="!selectedLocation"
          @click="handleStartFreeMode"
        >
          <span class="btn-icon">💭</span>
          Начать общение
        </button>
      </div>

      <div class="info-box">
        <span class="info-icon">ℹ️</span>
        <p>В свободном режиме нет обязательных событий - просто наслаждайтесь общением!</p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useChatStore } from '@/stores/chat'
import { useStoryStore } from '@/stores/story'
import StoryArcCard from './StoryArcCard.vue'
import LocationSelector from './LocationSelector.vue'
import type { StoryArc } from '@/services/api'

const emit = defineEmits<{
  startChat: []
}>()

const chatStore = useChatStore()
const storyStore = useStoryStore()
const selectedLocation = ref<string | null>(null)

async function handleSelectArc(arc: StoryArc) {
  if (arc.locked) return

  chatStore.setMode('story')
  chatStore.setArc(arc.id)

  // Get first scene or current scene
  const sceneId = arc.current_scene || 'scene1'
  chatStore.setScene(sceneId)

  await storyStore.loadScene(sceneId)
  emit('startChat')
}

function handleStartFreeMode() {
  if (!selectedLocation.value) return

  chatStore.setMode('free')
  chatStore.setLocation(selectedLocation.value)
  emit('startChat')
}
</script>

<style scoped>
.mode-selection {
  animation: fadeIn 0.5s ease;
}

.mode-card {
  padding: 2.5rem;
  max-width: 900px;
  margin: 0 auto;
}

.mode-title {
  text-align: center;
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 3rem;
  color: var(--text-primary);
}

.mode-section {
  margin-bottom: 3rem;
  padding: 2rem;
  background: var(--bg-tertiary);
  border-radius: var(--radius-md);
  border: 1px solid var(--border-subtle);
  transition: all 0.3s ease;
}

.mode-section:hover {
  border-color: var(--border-color);
  box-shadow: var(--shadow-sm);
}

.section-header {
  margin-bottom: 1.5rem;
}

.section-header h3 {
  font-size: 1.25rem;
  font-weight: 600;
  color: var(--accent-pink);
  margin-bottom: 0.5rem;
}

.section-description {
  color: var(--text-secondary);
  font-size: 0.9rem;
}

.loading {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  padding: 3rem;
  color: var(--text-secondary);
}

.spinner {
  width: 24px;
  height: 24px;
  border: 3px solid var(--bg-secondary);
  border-top-color: var(--accent-purple);
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.arcs-grid {
  display: grid;
  gap: 1rem;
}

.btn-primary {
  width: 100%;
  padding: 1rem 1.5rem;
  background: var(--gradient-primary);
  border: none;
  border-radius: var(--radius-md);
  color: var(--text-primary);
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  margin-top: 1.5rem;
  box-shadow: 0 4px 16px rgba(255, 107, 157, 0.3);
}

.btn-primary:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(255, 107, 157, 0.4);
}

.btn-primary:active:not(:disabled) {
  transform: translateY(0);
}

.btn-primary:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  transform: none;
}

.btn-icon {
  font-size: 1.25rem;
}

.info-box {
  background: rgba(96, 165, 250, 0.1);
  border: 1px solid rgba(96, 165, 250, 0.3);
  border-radius: var(--radius-md);
  padding: 1.25rem;
  display: flex;
  align-items: center;
  gap: 1rem;
  color: var(--accent-blue);
  font-size: 0.9rem;
}

.info-icon {
  font-size: 1.5rem;
  flex-shrink: 0;
}

@media (max-width: 768px) {
  .mode-card {
    padding: 1.5rem;
  }

  .mode-title {
    font-size: 1.5rem;
    margin-bottom: 2rem;
  }

  .mode-section {
    padding: 1.5rem;
    margin-bottom: 2rem;
  }
}

@media (max-width: 480px) {
  .mode-card {
    padding: 1rem;
  }

  .mode-section {
    padding: 1rem;
  }

  .info-box {
    flex-direction: column;
    text-align: center;
  }
}
</style>
