<template>
  <div
    class="arc-card"
    :class="{ locked: arc.locked, unlocked: !arc.locked }"
    @click="handleClick"
  >
    <div class="arc-header">
      <div class="arc-title">{{ arc.title }}</div>
      <div class="arc-status">
        <span class="status-icon">{{ statusIcon }}</span>
        <span class="status-text">{{ statusText }}</span>
      </div>
    </div>

    <p class="arc-description">{{ arc.description }}</p>

    <div v-if="!arc.locked" class="arc-progress">
      <div class="progress-bar">
        <div class="progress-fill" :style="{ width: `${arc.progress}%` }" />
        <div class="progress-glow" :style="{ width: `${arc.progress}%` }" />
      </div>
      <span class="progress-text">{{ arc.progress }}%</span>
    </div>

    <div v-if="!arc.locked && arc.current_scene" class="current-scene">
      <span class="scene-label">Текущая сцена:</span>
      <span class="scene-id">{{ arc.current_scene }}</span>
    </div>

    <button
      v-if="!arc.locked"
      class="arc-button"
      @click.stop="$emit('select', arc)"
    >
      <span>{{ arc.progress > 0 ? '▶️ Продолжить' : '▶️ Начать' }}</span>
    </button>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { StoryArc } from '@/services/api'

const props = defineProps<{
  arc: StoryArc
}>()

const emit = defineEmits<{
  select: [arc: StoryArc]
}>()

const statusIcon = computed(() => {
  if (props.arc.completed) return '✅'
  if (props.arc.locked) return '🔒'
  return '▶️'
})

const statusText = computed(() => {
  if (props.arc.completed) return 'Пройдена'
  if (props.arc.locked) return 'Заблокирована'
  return 'Доступна'
})

function handleClick() {
  if (!props.arc.locked) {
    emit('select', props.arc)
  }
}
</script>

<style scoped>
.arc-card {
  background: var(--bg-secondary);
  border-radius: var(--radius-md);
  padding: 1.5rem;
  border: 1px solid var(--border-color);
  transition: all 0.3s ease;
  cursor: pointer;
}

.arc-card.locked {
  opacity: 0.6;
  cursor: not-allowed;
}

.arc-card.unlocked:hover {
  border-color: var(--accent-purple);
  transform: translateX(4px);
  box-shadow: var(--shadow-md);
}

.arc-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 1rem;
  margin-bottom: 1rem;
}

.arc-title {
  font-size: 1.125rem;
  font-weight: 600;
  color: var(--text-primary);
  flex: 1;
}

.arc-status {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.875rem;
  color: var(--text-secondary);
  white-space: nowrap;
}

.status-icon {
  font-size: 1rem;
}

.arc-description {
  color: var(--text-secondary);
  font-size: 0.9rem;
  line-height: 1.5;
  margin-bottom: 1rem;
}

.arc-progress {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  margin-bottom: 1rem;
}

.progress-bar {
  position: relative;
  flex: 1;
  height: 8px;
  background: var(--bg-primary);
  border-radius: 100px;
  overflow: hidden;
}

.progress-fill {
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  background: var(--gradient-primary);
  border-radius: 100px;
  transition: width 0.5s ease;
}

.progress-glow {
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  background: var(--gradient-primary);
  border-radius: 100px;
  filter: blur(4px);
  opacity: 0.5;
  transition: width 0.5s ease;
}

.progress-text {
  font-size: 0.875rem;
  color: var(--text-muted);
  font-weight: 500;
  min-width: 40px;
  text-align: right;
  font-variant-numeric: tabular-nums;
}

.current-scene {
  padding: 0.75rem 1rem;
  background: var(--bg-primary);
  border-radius: var(--radius-sm);
  font-size: 0.875rem;
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.scene-label {
  color: var(--text-muted);
}

.scene-id {
  color: var(--accent-purple);
  font-weight: 500;
}

.arc-button {
  width: 100%;
  padding: 0.75rem 1rem;
  background: var(--bg-tertiary);
  border: 1px solid var(--accent-purple);
  border-radius: var(--radius-sm);
  color: var(--text-primary);
  font-size: 0.9rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.arc-button:hover {
  background: linear-gradient(135deg, rgba(255, 107, 157, 0.2), rgba(168, 85, 247, 0.2));
  border-color: var(--accent-pink);
  transform: translateY(-1px);
}

.arc-button:active {
  transform: translateY(0);
}

@media (max-width: 480px) {
  .arc-card {
    padding: 1rem;
  }

  .arc-header {
    flex-direction: column;
    gap: 0.5rem;
  }

  .arc-status {
    width: 100%;
  }
}
</style>
