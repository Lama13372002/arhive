<template>
  <div class="location-selector">
    <label class="selector-label">Где встретиться?</label>
    <div class="location-grid">
      <button
        v-for="location in locations"
        :key="location.id"
        class="location-button"
        :class="{ selected: modelValue === location.id }"
        @click="handleSelect(location.id)"
      >
        <span class="location-icon">{{ location.icon }}</span>
        <span class="location-name">{{ location.name }}</span>
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
const props = defineProps<{
  modelValue: string | null
}>()

const emit = defineEmits<{
  'update:modelValue': [value: string]
}>()

const locations = [
  { id: 'cafe', icon: '☕', name: 'В кофейне' },
  { id: 'park', icon: '🌳', name: 'В парке' },
  { id: 'home', icon: '🏠', name: 'У неё дома' },
  { id: 'video', icon: '💻', name: 'Видеозвонок' },
]

function handleSelect(locationId: string) {
  emit('update:modelValue', locationId)
}
</script>

<style scoped>
.location-selector {
  margin-bottom: 1rem;
}

.selector-label {
  display: block;
  margin-bottom: 1rem;
  color: var(--text-primary);
  font-weight: 500;
  font-size: 0.95rem;
}

.location-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
  gap: 0.75rem;
}

.location-button {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  padding: 1.25rem 1rem;
  background: var(--bg-secondary);
  border: 2px solid var(--border-color);
  border-radius: var(--radius-md);
  color: var(--text-primary);
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 0.9rem;
}

.location-button:hover {
  border-color: var(--accent-purple);
  background: var(--bg-primary);
  transform: translateY(-2px);
  box-shadow: var(--shadow-sm);
}

.location-button.selected {
  border-color: var(--accent-pink);
  background: linear-gradient(135deg, rgba(255, 107, 157, 0.15), rgba(168, 85, 247, 0.15));
  box-shadow: 0 0 20px rgba(255, 107, 157, 0.3);
}

.location-icon {
  font-size: 2rem;
}

.location-name {
  font-weight: 500;
}

@media (max-width: 480px) {
  .location-grid {
    grid-template-columns: repeat(2, 1fr);
  }

  .location-button {
    padding: 1rem 0.75rem;
  }

  .location-icon {
    font-size: 1.75rem;
  }

  .location-name {
    font-size: 0.85rem;
  }
}
</style>
