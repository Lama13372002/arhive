import { defineStore } from 'pinia'
import { ref } from 'vue'
import { apiService } from '@/services/api'

export const useSessionStore = defineStore('session', () => {
  const sessionId = ref<string | null>(null)
  const relationshipLevel = ref(0)

  // Initialize session from localStorage or create new
  async function initSession() {
    const savedSessionId = localStorage.getItem('emma_session_id')
    const savedRelationship = localStorage.getItem('emma_relationship_level')

    if (savedSessionId) {
      sessionId.value = savedSessionId
    } else {
      await createNewSession()
    }

    if (savedRelationship) {
      relationshipLevel.value = parseInt(savedRelationship, 10)
    }
  }

  async function createNewSession() {
    try {
      const data = await apiService.createSession()
      sessionId.value = data.session_id
      localStorage.setItem('emma_session_id', data.session_id)
    } catch (error) {
      console.error('Failed to create session:', error)
    }
  }

  function updateRelationship(increase: number) {
    relationshipLevel.value = Math.min(100, relationshipLevel.value + increase)
    localStorage.setItem('emma_relationship_level', relationshipLevel.value.toString())
  }

  function resetSession() {
    sessionId.value = null
    relationshipLevel.value = 0
    localStorage.removeItem('emma_session_id')
    localStorage.removeItem('emma_relationship_level')
    createNewSession()
  }

  return {
    sessionId,
    relationshipLevel,
    initSession,
    createNewSession,
    updateRelationship,
    resetSession,
  }
})
