// Configuration
const CONFIG = {
    apiUrl: 'http://localhost:5000/api',
    sessionId: null,
    currentMode: null,
    currentScene: null,
    currentArc: null,
    selectedLocation: null
};

// State
let arcsData = [];
let relationshipLevel = 0;
let chatHistory = [];

// DOM Elements
const elements = {
    modeSelection: document.getElementById('modeSelection'),
    chatInterface: document.getElementById('chatInterface'),
    arcContainer: document.getElementById('arcContainer'),
    chatMessages: document.getElementById('chatMessages'),
    messageInput: document.getElementById('messageInput'),
    btnSend: document.getElementById('btnSend'),
    btnBack: document.getElementById('btnBack'),
    startFreeMode: document.getElementById('startFreeMode'),
    chatTitle: document.getElementById('chatTitle'),
    chatSubtitle: document.getElementById('chatSubtitle'),
    modeBadge: document.getElementById('modeBadge'),
    typingIndicator: document.getElementById('typingIndicator'),
    objectivesPanel: document.getElementById('objectivesPanel'),
    objectivesList: document.getElementById('objectivesList'),
    relationshipFill: document.getElementById('relationshipFill'),
    relationshipValue: document.getElementById('relationshipValue'),
    configModal: document.getElementById('configModal'),
    apiKeyInput: document.getElementById('apiKeyInput'),
    saveConfig: document.getElementById('saveConfig')
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

async function initializeApp() {
    // Check if API key is configured
    const savedApiKey = localStorage.getItem('openrouter_api_key');
    if (!savedApiKey) {
        // For development, we'll use backend's API key
        console.log('Using backend API key configuration');
    }

    // Create or restore session
    CONFIG.sessionId = localStorage.getItem('session_id');
    if (!CONFIG.sessionId) {
        await createSession();
    }

    // Load story arcs
    await loadStoryArcs();

    // Setup event listeners
    setupEventListeners();

    // Update UI
    updateRelationshipBar();
}

function setupEventListeners() {
    // Send message
    elements.btnSend.addEventListener('click', sendMessage);
    elements.messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    // Auto-resize textarea
    elements.messageInput.addEventListener('input', () => {
        elements.messageInput.style.height = 'auto';
        elements.messageInput.style.height = elements.messageInput.scrollHeight + 'px';
    });

    // Back button
    elements.btnBack.addEventListener('click', () => {
        showModeSelection();
    });

    // Free mode
    elements.startFreeMode.addEventListener('click', startFreeMode);

    // Location selection
    document.querySelectorAll('.location-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.location-btn').forEach(b => b.classList.remove('selected'));
            btn.classList.add('selected');
            CONFIG.selectedLocation = btn.dataset.location;
        });
    });

    // Config
    elements.saveConfig.addEventListener('click', saveConfiguration);
}

async function createSession() {
    try {
        const response = await fetch(`${CONFIG.apiUrl}/session/create`, {
            method: 'POST'
        });
        const data = await response.json();
        CONFIG.sessionId = data.session_id;
        localStorage.setItem('session_id', CONFIG.sessionId);
    } catch (error) {
        console.error('Error creating session:', error);
    }
}

async function loadStoryArcs() {
    try {
        const response = await fetch(`${CONFIG.apiUrl}/story/arcs?session_id=${CONFIG.sessionId}`);
        const data = await response.json();
        arcsData = data.arcs;
        renderArcs();
    } catch (error) {
        console.error('Error loading arcs:', error);
    }
}

function renderArcs() {
    elements.arcContainer.innerHTML = '';

    arcsData.forEach(arc => {
        const arcElement = document.createElement('div');
        arcElement.className = `arc-item ${arc.locked ? 'locked' : 'unlocked'}`;

        const statusIcon = arc.completed ? '✅' : arc.locked ? '🔒' : '▶️';
        const statusText = arc.completed ? 'Пройдена' : arc.locked ? 'Заблокирована' : 'Доступна';

        arcElement.innerHTML = `
            <div class="arc-header">
                <div class="arc-title">${arc.title}</div>
                <div class="arc-status">${statusIcon} ${statusText}</div>
            </div>
            <div class="arc-description">${arc.description}</div>
            ${!arc.locked ? `
                <div class="arc-progress">
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${arc.progress}%"></div>
                    </div>
                    <div class="progress-text">Прогресс: ${arc.progress}%</div>
                </div>
                ${arc.current_scene ? `
                    <div class="arc-scene-info">
                        Текущая сцена: ${arc.current_scene}
                    </div>
                ` : ''}
                <button class="btn-primary" style="margin-top: 12px;" onclick="startStoryMode('${arc.id}')">
                    ${arc.progress > 0 ? '▶️ Продолжить' : '▶️ Начать'}
                </button>
            ` : ''}
        `;

        elements.arcContainer.appendChild(arcElement);
    });
}

function startStoryMode(arcId) {
    CONFIG.currentMode = 'story';
    CONFIG.currentArc = arcId;

    // Get first scene of the arc
    const arc = arcsData.find(a => a.id === arcId);
    if (arc && arc.progress === 0) {
        CONFIG.currentScene = 'scene1'; // Start from first scene
    } else if (arc && arc.current_scene) {
        CONFIG.currentScene = arc.current_scene;
    }

    showChatInterface();
    loadScene(CONFIG.currentScene);
}

function startFreeMode() {
    if (!CONFIG.selectedLocation) {
        alert('Пожалуйста, выберите место встречи');
        return;
    }

    CONFIG.currentMode = 'free';
    CONFIG.currentScene = null;

    showChatInterface();

    // Send initial context message
    const locationNames = {
        cafe: 'кофейне',
        park: 'парке',
        home: 'её дома',
        video: 'видеозвонке'
    };

    const locationEmojis = {
        cafe: '☕',
        park: '🌳',
        home: '🏠',
        video: '💻'
    };

    const location = locationNames[CONFIG.selectedLocation];
    const emoji = locationEmojis[CONFIG.selectedLocation];

    elements.chatTitle.textContent = `${emoji} Встреча в ${location}`;
    elements.chatSubtitle.textContent = 'Свободное общение';
    elements.modeBadge.textContent = 'Свободный режим';

    addSystemMessage(`Вы встретились с Эммой в ${location}. Она улыбается вам и выглядит рада встрече.`);
}

async function loadScene(sceneId) {
    try {
        const response = await fetch(`${CONFIG.apiUrl}/story/scene/${sceneId}`);
        const scene = await response.json();

        elements.chatTitle.textContent = `📖 ${scene.title}`;
        elements.chatSubtitle.textContent = scene.context;
        elements.modeBadge.textContent = 'Сюжетный режим';

        // Show objectives
        if (scene.objectives) {
            elements.objectivesPanel.style.display = 'block';
            elements.objectivesList.innerHTML = '';
            scene.objectives.forEach(obj => {
                const li = document.createElement('li');
                li.textContent = obj;
                elements.objectivesList.appendChild(li);
            });
        }

        // Add scene context as system message
        addSystemMessage(scene.context);

    } catch (error) {
        console.error('Error loading scene:', error);
    }
}

function showChatInterface() {
    elements.modeSelection.style.display = 'none';
    elements.chatInterface.style.display = 'flex';
    elements.chatMessages.innerHTML = '';
    chatHistory = [];
    elements.messageInput.value = '';
    elements.messageInput.focus();
}

function showModeSelection() {
    elements.chatInterface.style.display = 'none';
    elements.modeSelection.style.display = 'block';
    elements.objectivesPanel.style.display = 'none';
    CONFIG.currentMode = null;
    CONFIG.currentScene = null;
    loadStoryArcs();
}

function addSystemMessage(text) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message system';
    messageDiv.innerHTML = `
        <div class="message-content" style="background: rgba(96, 165, 250, 0.1); border: 1px solid rgba(96, 165, 250, 0.3); max-width: 100%; text-align: center;">
            ${text}
        </div>
    `;
    elements.chatMessages.appendChild(messageDiv);
    scrollToBottom();
}

function addMessage(text, isUser = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isUser ? 'user' : 'assistant'}`;

    const avatar = isUser ? '👤' : '💕';
    const time = new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });

    messageDiv.innerHTML = `
        <div class="message-avatar">${avatar}</div>
        <div class="message-content">
            ${text}
            <div class="message-time">${time}</div>
        </div>
    `;

    elements.chatMessages.appendChild(messageDiv);
    scrollToBottom();

    // Save to history
    chatHistory.push({ role: isUser ? 'user' : 'assistant', content: text, time });
}

async function sendMessage() {
    const message = elements.messageInput.value.trim();
    if (!message) return;

    // Add user message
    addMessage(message, true);
    elements.messageInput.value = '';
    elements.messageInput.style.height = 'auto';

    // Show typing indicator
    elements.typingIndicator.style.display = 'flex';
    elements.btnSend.disabled = true;

    try {
        const response = await fetch(`${CONFIG.apiUrl}/chat`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: message,
                session_id: CONFIG.sessionId,
                mode: CONFIG.currentMode,
                scene_id: CONFIG.currentScene,
                stream: true
            })
        });

        // Handle streaming response
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let assistantMessage = '';
        let messageElement = null;

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value);
            const lines = chunk.split('\n');

            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    try {
                        const data = JSON.parse(line.slice(6));

                        if (data.content) {
                            assistantMessage += data.content;

                            // Create or update message element
                            if (!messageElement) {
                                elements.typingIndicator.style.display = 'none';
                                const messageDiv = document.createElement('div');
                                messageDiv.className = 'message assistant';
                                const time = new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
                                messageDiv.innerHTML = `
                                    <div class="message-avatar">💕</div>
                                    <div class="message-content">
                                        <span class="message-text"></span>
                                        <div class="message-time">${time}</div>
                                    </div>
                                `;
                                elements.chatMessages.appendChild(messageDiv);
                                messageElement = messageDiv.querySelector('.message-text');
                            }

                            messageElement.textContent = assistantMessage;
                            scrollToBottom();
                        }

                        if (data.done) {
                            // Update relationship level
                            relationshipLevel = Math.min(100, relationshipLevel + Math.random() * 5);
                            updateRelationshipBar();

                            // Save to history
                            chatHistory.push({ role: 'assistant', content: assistantMessage });
                        }
                    } catch (e) {
                        // Ignore parse errors
                    }
                }
            }
        }

    } catch (error) {
        console.error('Error sending message:', error);
        addSystemMessage('Произошла ошибка при отправке сообщения. Проверьте настройки API.');
    } finally {
        elements.typingIndicator.style.display = 'none';
        elements.btnSend.disabled = false;
        elements.messageInput.focus();
    }
}

function scrollToBottom() {
    elements.chatMessages.scrollTop = elements.chatMessages.scrollHeight;
}

function updateRelationshipBar() {
    elements.relationshipFill.style.width = `${relationshipLevel}%`;
    elements.relationshipValue.textContent = `${Math.round(relationshipLevel)}%`;

    // Save to localStorage
    localStorage.setItem('relationship_level', relationshipLevel);
}

function saveConfiguration() {
    const apiKey = elements.apiKeyInput.value.trim();
    if (apiKey) {
        localStorage.setItem('openrouter_api_key', apiKey);
        elements.configModal.classList.remove('active');
        alert('Настройки сохранены!');
    }
}

// Global functions for inline onclick
window.startStoryMode = startStoryMode;
