/**
 * Утилиты для работы с часовыми поясами в футбольном приложении
 */

/**
 * Получить часовой пояс пользователя
 */
export const getUserTimezone = (): string => {
  return Intl.DateTimeFormat().resolvedOptions().timeZone;
};

/**
 * Форматировать время матча для отображения в локальном времени пользователя
 */
export const formatMatchTime = (apiDateString: string): string => {
  if (!apiDateString) return '';

  const matchDate = new Date(apiDateString);
  if (isNaN(matchDate.getTime())) {
    console.warn('Invalid date string:', apiDateString);
    return '';
  }

  const userTimezone = getUserTimezone();

  return matchDate.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    timeZone: userTimezone
  });
};

/**
 * Форматировать полную дату и время матча
 */
export const formatMatchDateTime = (apiDateString: string, locale: string = 'ru-RU'): string => {
  if (!apiDateString) return '';

  const matchDate = new Date(apiDateString);
  if (isNaN(matchDate.getTime())) {
    console.warn('Invalid date string:', apiDateString);
    return '';
  }

  const userTimezone = getUserTimezone();

  return matchDate.toLocaleString([], {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: userTimezone
  });
};

/**
 * Проверить, является ли матч сегодняшним в локальном времени пользователя
 */
export const isMatchToday = (apiDateString: string): boolean => {
  if (!apiDateString) return false;

  const matchDate = new Date(apiDateString);
  if (isNaN(matchDate.getTime())) {
    console.warn('Invalid date string:', apiDateString);
    return false;
  }

  const today = new Date();

  // Получаем даты в локальном времени пользователя
  const userTimezone = getUserTimezone();

  try {
    // Создаем новые даты, применяя смещение часового пояса
    const matchInUserTz = new Date(matchDate.toLocaleString('sv-SE', { timeZone: userTimezone }));
    const todayInUserTz = new Date(today.toLocaleString('sv-SE', { timeZone: userTimezone }));

    return matchInUserTz.getDate() === todayInUserTz.getDate() &&
           matchInUserTz.getMonth() === todayInUserTz.getMonth() &&
           matchInUserTz.getFullYear() === todayInUserTz.getFullYear();
  } catch (error) {
    console.warn('Error comparing dates:', error);
    return false;
  }
};

/**
 * Получить статус матча относительно текущего времени
 */
export const getMatchTimeStatus = (apiDateString: string): 'past' | 'live' | 'upcoming' => {
  if (!apiDateString) return 'upcoming';

  const matchDate = new Date(apiDateString);
  if (isNaN(matchDate.getTime())) {
    console.warn('Invalid date string:', apiDateString);
    return 'upcoming';
  }

  const now = new Date();

  const timeDiffMinutes = (matchDate.getTime() - now.getTime()) / (1000 * 60);

  if (timeDiffMinutes < -120) { // Прошло больше 2 часов
    return 'past';
  } else if (timeDiffMinutes < 120) { // В диапазоне ±2 часа
    return 'live';
  } else {
    return 'upcoming';
  }
};

/**
 * Форматировать время для отображения в карточке матча
 * Показывает "Сегодня HH:MM" или полную дату
 */
export const formatMatchDisplayTime = (
  apiDateString: string,
  todayText: string = 'Сегодня'
): string => {
  if (!apiDateString) return '';

  // Проверяем валидность даты сразу
  const testDate = new Date(apiDateString);
  if (isNaN(testDate.getTime())) {
    console.warn('Invalid date string:', apiDateString);
    return '';
  }

  if (isMatchToday(apiDateString)) {
    const timeStr = formatMatchTime(apiDateString);
    return timeStr ? `${todayText} ${timeStr}` : '';
  } else {
    return formatMatchDateTime(apiDateString);
  }
};
