"use client";
import React, { createContext, useCallback, useContext, useMemo } from "react";
import { useI18n } from "./I18nProvider";

type Dict = Record<string, string>;

const ru: Dict = {
  connected: "Подключен",
  wallet_address: "Адрес кошелька:",
  connect_title: "Подключить TON кошелек",
  connect_sub: "Для пополнения баланса через TON",
};

const en: Dict = {
  connected: "Connected",
  wallet_address: "Wallet address:",
  connect_title: "Connect TON wallet",
  connect_sub: "To top up balance via TON",
};

const dicts = { ru, en };

type Ctx = { t: (key: string, params?: Record<string, string | number>) => string };
const Ctx = createContext<Ctx | undefined>(undefined);

export const TonWalletI18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useI18n();
  const t = useCallback((key: string, params?: Record<string, string | number>) => {
    const dict = dicts[lang] || en;
    let text = dict[key] ?? key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\{${k}\}`, 'g'), String(v));
      });
    }
    return text;
  }, [lang]);
  const value = useMemo(() => ({ t }), [t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export const useTonWalletI18n = () => {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useTonWalletI18n must be used within TonWalletI18nProvider");
  return ctx;
};
