import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Добавляем детальное логирование
    console.log('Stars webhook received:', JSON.stringify(body, null, 2));

    // Проверяем, что это update от Telegram
    if (!body.update_id) {
      return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
    }

    // Обрабатываем pre_checkout_query
    if (body.pre_checkout_query) {
      const preCheckoutQuery = body.pre_checkout_query;
      const botToken = process.env.TELEGRAM_BOT_TOKEN;

      console.log('Processing pre_checkout_query:', preCheckoutQuery);

      // Отвечаем OK на pre-checkout query
      const response = await fetch(`https://api.telegram.org/bot${botToken}/answerPreCheckoutQuery`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          pre_checkout_query_id: preCheckoutQuery.id,
          ok: true
        })
      });

      const responseData = await response.json();
      console.log('answerPreCheckoutQuery response:', responseData);

      if (!response.ok || !responseData.ok) {
        console.error('Failed to answer pre-checkout query:', responseData);
        return NextResponse.json({ error: 'Failed to answer pre-checkout query' }, { status: 500 });
      }

      return NextResponse.json({ success: true });
    }

    // Обрабатываем successful_payment
    if (body.message && body.message.successful_payment) {
      const payment = body.message.successful_payment;
      console.log('Processing successful_payment:', payment);

      let payload;
      try {
        payload = JSON.parse(payment.invoice_payload);
        console.log('Parsed payload:', payload);
      } catch (error) {
        console.error('Failed to parse payload:', payment.invoice_payload, error);
        return NextResponse.json({ error: 'Invalid payload format' }, { status: 400 });
      }

      const { user_id, telegram_id, amount, currency } = payload;

      if (currency !== 'STARS') {
        console.error('Invalid currency in payment:', currency);
        return NextResponse.json({ error: 'Invalid currency' }, { status: 400 });
      }

      // Валидируем типы данных
      if (!user_id || !telegram_id || !amount) {
        console.error('Missing required fields in payload:', { user_id, telegram_id, amount });
        return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
      }

      // Начинаем транзакцию
      const client = await pool.connect();

      try {
        await client.query('BEGIN');

        // Проверяем, что пользователь существует
        const userCheck = await client.query('SELECT id FROM users WHERE id = $1', [user_id]);
        if (userCheck.rows.length === 0) {
          console.error('User not found:', user_id);
          return NextResponse.json({ error: 'User not found' }, { status: 404 });
        }

        // Обновляем баланс пользователя
        const balanceUpdate = await client.query(
          'UPDATE users SET stars_balance = stars_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING stars_balance',
          [amount, user_id]
        );

        console.log('Balance updated:', balanceUpdate.rows[0]);

        // Записываем транзакцию
        const transactionResult = await client.query(`
          INSERT INTO transactions (user_id, transaction_type, currency, amount, description, telegram_payment_id, created_at)
          VALUES ($1, 'deposit', 'STARS', $2, $3, $4, CURRENT_TIMESTAMP)
          RETURNING id
        `, [
          user_id,
          amount,
          `Пополнение баланса Stars через Telegram`,
          payment.telegram_payment_charge_id
        ]);

        console.log('Transaction recorded successfully with ID:', transactionResult.rows[0].id);

        await client.query('COMMIT');

        console.log(`Stars payment processed: ${amount} STARS for user ${telegram_id}`);

        return NextResponse.json({ success: true });

      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally {
        client.release();
      }
    }

    return NextResponse.json({ success: true });

  } catch (error) {
    console.error('Error processing Stars payment:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
