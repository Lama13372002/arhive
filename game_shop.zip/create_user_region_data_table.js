import pg from 'pg';

const { Client } = pg;

const client = new Client({
	host: '193.17.92.132',
	port: 5432,
	database: 'game_shop_db',
	user: 'nkarasyov',
	password: 'pAssW_ord123',
});

async function createUserRegionDataTable() {
	try {
		await client.connect();
		console.log('Connected to database');

		// Создаем таблицу UserRegionData
		const createTableQuery = `
			CREATE TABLE IF NOT EXISTS "UserRegionData" (
				"id" SERIAL PRIMARY KEY,
				"userId" INTEGER NOT NULL,
				"currencyId" INTEGER NOT NULL,
				"psStoreLogin" VARCHAR(255),
				"psStorePassword" VARCHAR(255),
				"psBackupCodes" TEXT,
				"email" VARCHAR(255),
				"createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
				"updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
				CONSTRAINT "UserRegionData_userId_fkey" FOREIGN KEY ("userId")
					REFERENCES "Users"("id") ON UPDATE CASCADE ON DELETE CASCADE,
				CONSTRAINT "UserRegionData_currencyId_fkey" FOREIGN KEY ("currencyId")
					REFERENCES "Currencies"("id") ON UPDATE CASCADE ON DELETE CASCADE,
				CONSTRAINT "UserRegionData_userId_currencyId_unique" UNIQUE ("userId", "currencyId")
			);
		`;

		await client.query(createTableQuery);
		console.log('Table UserRegionData created successfully');

		// Создаем индекс для быстрого поиска
		const createIndexQuery = `
			CREATE INDEX IF NOT EXISTS "UserRegionData_userId_currencyId_idx"
			ON "UserRegionData" ("userId", "currencyId");
		`;

		await client.query(createIndexQuery);
		console.log('Index created successfully');

	} catch (error) {
		console.error('Error creating table:', error);
		throw error;
	} finally {
		await client.end();
		console.log('Database connection closed');
	}
}

createUserRegionDataTable()
	.then(() => {
		console.log('Script completed successfully');
		process.exit(0);
	})
	.catch((error) => {
		console.error('Script failed:', error);
		process.exit(1);
	});
