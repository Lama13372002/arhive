import pkg from 'pg';
const { Client } = pkg;

const client = new Client({
  host: '193.17.92.132',
  port: 5432,
  database: 'game_shop_db',
  user: 'nkarasyov',
  password: 'pAssW_ord123',
});

async function fixMigration() {
  try {
    await client.connect();
    console.log('✓ Connected to database\n');

    // Удаляем колонку если она есть
    console.log('Dropping currencyId column...');
    await client.query('ALTER TABLE "UsedPromos" DROP COLUMN IF EXISTS "currencyId"');
    console.log('✓ Column dropped\n');

    // Добавляем колонку с правильным DEFAULT (2 вместо 1)
    console.log('Adding currencyId column with DEFAULT 2...');
    await client.query('ALTER TABLE "UsedPromos" ADD COLUMN "currencyId" INTEGER NOT NULL DEFAULT 2');
    console.log('✓ Column added\n');

    // Добавляем внешний ключ
    console.log('Adding foreign key...');
    await client.query('ALTER TABLE "UsedPromos" ADD CONSTRAINT "UsedPromos_currencyId_fkey" FOREIGN KEY ("currencyId") REFERENCES "Currencies"(id) ON UPDATE CASCADE ON DELETE CASCADE');
    console.log('✓ Foreign key added\n');

    // Удаляем старый индекс
    console.log('Dropping old index...');
    await client.query('DROP INDEX IF EXISTS "used_promos_user_id_promo_id"');
    console.log('✓ Old index dropped\n');

    // Создаем новый уникальный индекс
    console.log('Creating new unique index...');
    await client.query('CREATE UNIQUE INDEX IF NOT EXISTS "used_promos_user_id_promo_id_currency_id" ON "UsedPromos" ("userId", "promoId", "currencyId")');
    console.log('✓ New index created\n');

    console.log('✅ Migration completed successfully!');
  } catch (error) {
    console.error('❌ Error:', error.message);
    console.error(error);
  } finally {
    await client.end();
    console.log('\n✓ Disconnected from database');
  }
}

fixMigration();
