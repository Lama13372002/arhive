import asyncio
import aiohttp
from json import dumps, loads
from random import choice
import asyncpg
from dotenv import load_dotenv
from datetime import datetime
import os, sys
from time import sleep


def get_params(url: str):
    product_type, sku = url.split("/")[-2:]
    queries = {
        "concept": {
                "operationName": "conceptRetrieveForCtasWithPrice",
                "variables": dumps({"conceptId": sku}),
                "extensions": dumps({
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "eab9d873f90d4ad98fd55f07b6a0a606e6b3925f2d03b70477234b79c1df30b5"
                    }
                })
            }
        ,
        "product": [
            {
                "operationName": "productRetrieveForCtasWithPrice",
                "variables": dumps({"productId": sku}),
                "extensions": dumps({
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "8872b0419dcab2fea5916ef698544c237b1096f9e76acc6aacf629551adee8cd"
                    }
                })
            },
            {
                "operationName": "productRetrieveForUpsellWithCtas",
                "variables": dumps({"productId": sku}),
                "extensions": dumps({
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "fb0bfa0af4d8dc42b28fa5c077ed715543e7fb8a3deff8117a50b99864d246f1"
                    }
                })
            }
        ]
    }
    return queries[product_type]


header=lambda: choice([
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15'
                ])


json_headers = lambda x: {
    "Accept": "application/json",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "en-US",
    "apollographql-client-name": "@sie-private/web-commerce-anywhere",
    "apollographql-client-version": "3.23.0",
    "Cache-Control": "no-cache",
    "Content-Type": "application/json",
    "disable_query_whitelist": "false",
    "Origin": "https://store.playstation.com",
    "Pragma": "no-cache",
    "Priority": "u=1, i",
    "Referer": "https://store.playstation.com/",
    "sec-ch-ua": '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "User-Agent": header(),
    "x-psn-app-ver": "@sie-private/web-commerce-anywhere/3.23.0-d3947b39a30477ef83ad9e5fc7f3f6a72e17bb6b",
    "x-psn-store-locale-override": x.split("/")[-3]
}

async def update_price(session: aiohttp.ClientSession, pool: asyncpg.Pool, ID: str, db_data: dict):
    ua_url = f"https://store.playstation.com/ru-ua/product/{ID}"
    tr_url = f"https://store.playstation.com/en-tr/product/{ID}"

    params, _ = get_params(ua_url)

    ua = None
    tr = None
    counter = 0

    while (not ua and not tr) and counter < 3:
        try:
            async with session.get("https://web.np.playstation.com/api/graphql/v1/op", params=params, headers=json_headers(ua_url)) as resp:
                ua = await resp.text()
                ua = loads(ua)
                if "errors" in ua:
                    return
                ua = ua["data"]["productRetrieve"]
            
            async with session.get("https://web.np.playstation.com/api/graphql/v1/op", params=params, headers=json_headers(tr_url)) as resp:
                tr = await resp.text()
                tr = loads(tr)
                tr = tr["data"]["productRetrieve"]
            counter += 1
        except (asyncio.CancelledError, KeyboardInterrupt):
            return
        except:
            counter += 1
            await asyncio.sleep(5)

    uah_price = None
    uah_old_price = None
    discount_end = None
    trl_price = None
    trl_old_price = None
    ps_price_ua = None
    ea_price_ua = None
    ps_price_tr = None
    ea_price_tr = None

    if ua:
        if ua["webctas"]:
            for price in ua["webctas"]:
                if price["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] or ("UPSELL" in price["type"] and ("EA_ACCESS" in price["type"] or "PS_PLUS" in price["type"]) and "TRIAL" not in price["type"]):
                    if price["price"]["discountedPrice"] and price["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] and not uah_price:
                        uah_price = price["price"]["discountedValue"]/100
                    if price["price"]["basePrice"] and price["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] and not uah_old_price:
                        uah_old_price = price["price"]["basePriceValue"]/100
                    if "UPSELL_PS_PLUS_DISCOUNT" == price["type"]:
                        ps_price_ua = price["price"]["discountedValue"]/100
                    if "UPSELL_EA_ACCESS_DISCOUNT" == price["type"]:
                        ea_price_ua = price["price"]["discountedValue"]/100
                    if price["price"]["endTime"] and price["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"]:
                        discount_end = datetime.fromtimestamp(int(price["price"]["endTime"])//1000)


    if tr:
        for trl in tr["webctas"]:
            if trl["type"] in ["ADD_TO_CART", "PREORDER"] or ("UPSELL" in trl["type"] and ("EA_ACCESS" in trl["type"] or "PS_PLUS" in trl["type"]) and "TRIAL" not in trl["type"]):
                # if trl["type"] in ["ADD_TO_CART", "PREORDER"] or "UPSELL" in trl["type"]:
                    if trl["price"]["discountedPrice"] and trl["type"] in ["ADD_TO_CART", "PREORDER"] and not trl_price:
                        trl_price = trl["price"]["discountedValue"]/100
                    if trl["price"]["basePrice"] and trl["type"] in ["ADD_TO_CART", "PREORDER"] and not trl_old_price:
                        trl_old_price = trl["price"]["basePriceValue"]/100
                    if "UPSELL_PS_PLUS_DISCOUNT" == trl["type"]:
                        ps_price_tr = trl["price"]["discountedValue"]/100
                    if "UPSELL_EA_ACCESS_DISCOUNT" == trl["type"]:
                        ea_price_tr = trl["price"]["discountedValue"]/100

    if 3 in db_data and uah_price:
        async with pool.acquire(timeout=600) as conn:
            await conn.execute("""
                                    UPDATE "Editions"
                                    SET
                                        price = $2,
                                        discount_amount = $3,
                                        ea_play_price = $4,
                                        ps_plus_price = $5,
                                        promotion_end_date = $6,
                                        updated_at = $7
                                    WHERE id = $1
                                """, db_data[3], uah_old_price, uah_price if uah_price != uah_old_price else None, ea_price_ua, ps_price_ua, discount_end, datetime.now())

    if 2 in db_data and trl_price:
        async with pool.acquire(timeout=600) as conn:
            await conn.execute("""
                                    UPDATE "Editions"
                                    SET
                                        price = $2,
                                        discount_amount = $3,
                                        ea_play_price = $4,
                                        ps_plus_price = $5,
                                        promotion_end_date = $6,
                                        updated_at = $7
                                    WHERE id = $1
                                """, db_data[2], trl_old_price, trl_price if trl_price != trl_old_price else None, ea_price_tr, ps_price_tr, discount_end, datetime.now())


async def main():
    load_dotenv()
    
    timeout = -1

    if len(sys.argv) == 2:
        timeout = int(sys.argv[1])
    elif len(sys.argv) > 2:
        print(f"[?] Usage: ./{sys.argv[0]} 10")
        return
    
    while True:
        try:
            async with asyncpg.create_pool(
                                        user=os.getenv("DB_USER"),
                                        password=os.getenv("DB_PASSWORD"),
                                        database=os.getenv("DB_NAME"),
                                        host="193.17.92.132",
                                        port=5432
                                        ) as pool:

                products = [[p["id"], p["edition_id"], p["currency"]] for p in await pool.fetch('SELECT * FROM "update_info"')]
                _products = {}

                for p in products:
                    if p[0] not in _products:
                        _products[p[0]] = {}
                    _products[p[0]][p[2]] = p[1]

                products = _products

                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(120)) as session:
                    tasks = [update_price(session, pool, ID, products[ID]) for ID in products]

                    shift = 500
                    print("Updating data...", end="", flush=True)

                    for i in range(0, len(products), shift):
                        await asyncio.gather(*tasks[i:i+shift])
                        await asyncio.sleep(5)
                        print("\r"+" "*40+f"\rUpdating data: {(min(len(products), i+shift))*100/len(products):.2f}%", end="")
                    print("\r"+" "*40+"\rUpdating data: done")
                    print("[*] Data updated:", datetime.now())
                if not timeout:
                    break
            sleep(timeout)
        except asyncio.CancelledError:
            return
        except KeyboardInterrupt:
            return


if __name__ == "__main__":
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(main())
    except KeyboardInterrupt:
        pass
    finally:
        print("\nGoodbye")