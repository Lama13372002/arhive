import pg from 'pg';
const { Client } = pg;

const client = new Client({
  host: '193.17.92.132',
  port: 5432,
  database: 'game_shop_db',
  user: 'nkarasyov',
  password: 'pAssW_ord123'
});

async function addRatingToEditions() {
  try {
    await client.connect();
    console.log('✅ Подключение к базе данных успешно!\n');

    // Шаг 1: Проверяем, есть ли уже поле rating в Editions
    console.log('🔍 Проверяем наличие поля rating в таблице Editions...');
    const hasRating = await client.query(`
      SELECT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'Editions' AND column_name = 'rating'
      ) as has_rating;
    `);

    if (hasRating.rows[0].has_rating) {
      console.log('⚠️  Поле rating уже существует в таблице Editions');
    } else {
      // Шаг 2: Добавляем колонку rating в таблицу Editions
      console.log('📝 Добавляем поле rating в таблицу Editions...');
      await client.query(`
        ALTER TABLE "Editions"
        ADD COLUMN rating DOUBLE PRECISION;
      `);
      console.log('✅ Поле rating успешно добавлено!\n');
    }

    // Шаг 3: Копируем значения rating из ProductCards в Editions
    console.log('📋 Копируем значения rating из ProductCards в Editions...');
    const updateResult = await client.query(`
      UPDATE "Editions" e
      SET rating = pc.rating
      FROM "ProductCards" pc
      WHERE e.product_card_id = pc.id;
    `);
    console.log(`✅ Обновлено записей: ${updateResult.rowCount}\n`);

    // Шаг 4: Проверяем результат
    console.log('📊 Проверяем результат - примеры Editions с rating:');
    const samples = await client.query(`
      SELECT
        e.id,
        e.product_card_id,
        e.rating as edition_rating,
        pc.name as product_name,
        pc.rating as product_rating
      FROM "Editions" e
      JOIN "ProductCards" pc ON e.product_card_id = pc.id
      LIMIT 10;
    `);
    console.table(samples.rows);

    // Шаг 5: Статистика
    console.log('\n📈 Статистика:');
    const stats = await client.query(`
      SELECT
        COUNT(*) as total_editions,
        COUNT(rating) as editions_with_rating,
        AVG(rating) as avg_rating,
        MIN(rating) as min_rating,
        MAX(rating) as max_rating
      FROM "Editions";
    `);
    console.table(stats.rows);

    console.log('\n🎉 Миграция успешно завершена!');

  } catch (error) {
    console.error('❌ Ошибка:', error.message);
    console.error(error);
  } finally {
    await client.end();
    console.log('\n✅ Соединение закрыто');
  }
}

addRatingToEditions();
