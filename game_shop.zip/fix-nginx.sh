#!/bin/bash

echo "=== Останавливаем системный nginx ==="
sudo systemctl stop nginx
sudo systemctl disable nginx

echo "=== Проверяем, что порты свободны ==="
sudo lsof -i :80
sudo lsof -i :443

echo "=== Готово! Теперь можно запустить Docker nginx ==="
echo "Выполните: docker-compose down && docker-compose up -d"
