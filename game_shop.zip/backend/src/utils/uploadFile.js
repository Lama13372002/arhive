import fs from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

const UPLOAD_DIR = path.join(process.cwd(), 'uploads');

export const ensureUploadDir = async () => {
	try {
		await fs.access(UPLOAD_DIR);
		const stats = await fs.stat(UPLOAD_DIR);
		console.log('Upload directory permissions:', stats.mode);
	} catch {
		console.log('Creating upload directory...');
		await fs.mkdir(UPLOAD_DIR, { recursive: true });
	}
};

export const uploadFile = async (file, directory = '') => {
    console.log('Upload file called with:', {
        fileObject: {
            name: file.name,
            size: file.size,
            type: file.type || 'image/png',
            hasFile: !!file.file
        },
        directory,
    });

    await ensureUploadDir();

    const targetDir = path.join(UPLOAD_DIR, directory);
    await fs.mkdir(targetDir, { recursive: true });

    if (!file || !file.file) {
        throw new Error('Invalid file data');
    }

    // Извлекаем base64 данные
    const base64Data = file.file.split(';base64,').pop();
    if (!base64Data) {
        throw new Error('Invalid base64 data');
    }

    // Создаем имя файла с сохранением расширения
    const ext = path.extname(file.name) || '.png';
    const filename = `${uuidv4()}${ext}`;
    const targetPath = path.join(targetDir, filename);

    try {
        // Сразу записываем файл в нужную директорию
        await fs.writeFile(targetPath, base64Data, 'base64');
        return path.join(directory, filename);
    } catch (error) {
        console.error('Error saving file:', error);
        throw new Error('Failed to save file: ' + error.message);
    }
};
