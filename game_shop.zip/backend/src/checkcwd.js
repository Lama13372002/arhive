import fs from 'fs';
import path from 'path';

console.log('Current working directory:', process.cwd());
console.log(
	'Public directory exists:',
	fs.existsSync(path.join(process.cwd(), 'public'))
);
console.log(
	'Upload.html exists:',
	fs.existsSync(path.join(process.cwd(), 'public', 'upload.html'))
);
