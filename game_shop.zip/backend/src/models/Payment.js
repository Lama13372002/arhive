import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Payment = sequelize.define(
	'Payment',
	{
		id: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
		},
		orderId: {
			type: DataTypes.STRING,
			allowNull: false,
			unique: true,
		},
		lifepayNumber: {
			type: DataTypes.STRING,
			allowNull: true,
			comment: 'Номер транзакции в системе Life-Pay',
		},
		telegramUsername: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		telegramId: {
			type: DataTypes.STRING,
			allowNull: true,
			comment: 'Telegram User ID',
		},
		checkoutWithoutAccount: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
			defaultValue: false,
			comment: 'Флаг оформления заказа без аккаунта PS Store',
		},
		amount: {
			type: DataTypes.DECIMAL(10, 2),
			allowNull: false,
			validate: {
				min: 0,
			},
		},
		status: {
			type: DataTypes.ENUM(
				'pending',
				'paid',
				'failed',
				'processing',
				'completed'
			),
			defaultValue: 'pending',
		},
		lifepayStatus: {
			type: DataTypes.STRING,
			allowNull: true,
			comment: 'Статус транзакции в системе Life-Pay',
		},
		psLogin: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		psPassword: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		psBackupCodes: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		firstName: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		lastName: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		customerEmail: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		birthDate: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		email: {
			type: DataTypes.STRING,
			allowNull: false,
			validate: {
				isEmail: true,
			},
		},
		gameInfo: {
			type: DataTypes.JSONB,
			allowNull: false,
			validate: {
				isValidGameInfo(value) {
					if (!Array.isArray(value)) {
						throw new Error('gameInfo must be an array');
					}
					if (value.length === 0) {
						throw new Error('gameInfo cannot be empty');
					}
					value.forEach((game, index) => {
						if (!game.id)
							throw new Error(
								`Game at index ${index} must have an id`
							);
						if (!game.title)
							throw new Error(
								`Game at index ${index} must have a title`
							);
						if (!game.price)
							throw new Error(
								`Game at index ${index} must have a price`
							);
					});
				},
			},
		},
		paymentSystem: {
			type: DataTypes.STRING,
			defaultValue: 'life-pay',
		},
		currency: {
			type: DataTypes.JSON,
			allowNull: true,
			comment: 'Информация о валюте платежа',
		},
		promoCode: {
			type: DataTypes.STRING,
			allowNull: true,
			comment: 'Примененный промокод',
		},
		paymentMethod: {
			type: DataTypes.STRING,
			allowNull: true,
			comment:
				'Метод оплаты (card, cash, recurrent, internetAcquiring, mobileInternetAcquiring)',
		},
		paymentUrl: {
			type: DataTypes.STRING,
		},
		notificationSent: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		errorMessage: {
			type: DataTypes.TEXT,
		},
		completedAt: {
			type: DataTypes.DATE,
		},
		lastWebhookAt: {
			type: DataTypes.DATE,
			allowNull: true,
			comment: 'Время последнего полученного вебхука',
		},
	},
	{
		timestamps: true,
		indexes: [
			{
				fields: ['orderId'],
			},
			{
				fields: ['lifepayNumber'],
				unique: true,
				name: 'payments_lifepay_number_unique',
			},
			{
				fields: ['telegramUsername'],
			},
			{
				fields: ['status'],
			},
		],
	}
);

export default Payment;
