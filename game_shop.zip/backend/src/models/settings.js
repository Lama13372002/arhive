import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

export default class Settings extends Model {
	static init(sequelize) {
		super.init(
			{
				id: {
					type: DataTypes.INTEGER,
					primaryKey: true,
					autoIncrement: true,
				},
				welcomeMessage: {
					type: DataTypes.TEXT,
					allowNull: false,
					defaultValue:
						'Добро пожаловать! Нажмите кнопку ниже, чтобы открыть мини-приложение.',
					field: 'welcome_message'
				},
			},
			{
				sequelize,
				modelName: 'Settings',
				tableName: 'Settings',
				underscored: true,
				timestamps: true
			}
		);
		return this;
	}
}

Settings.init(sequelize);
