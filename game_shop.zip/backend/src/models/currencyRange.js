import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

export default class CurrencyRange extends Model {
    static init(sequelize) {
        super.init(
            {
                id: {
                    type: DataTypes.INTEGER,
                    primaryKey: true,
                    autoIncrement: true,
                },
                currencyId: {
                    type: DataTypes.INTEGER,
                    allowNull: false,
                },
                amountFrom: {
                    type: DataTypes.DECIMAL(20, 8),
                    allowNull: false,
                    validate: {
                        min: 0
                    }
                },
                amountTo: {
                    type: DataTypes.DECIMAL(20, 8),
                    allowNull: false,
                    validate: {
                        min: 0
                    }
                },
                rate_multiplier: {
                    type: DataTypes.DECIMAL(10, 4),
                    allowNull: false,
                    defaultValue: 1.0,
                    comment: 'Множитель базового курса валюты для данного диапазона'
                }
            },
            {
                sequelize,
                modelName: 'CurrencyRange',
                timestamps: true,
                validate: {
                    amountRangeValid() {
                        if (this.amountFrom >= this.amountTo) {
                            throw new Error('Начальная сумма должна быть меньше конечной');
                        }
                    }
                }
            }
        );
        return this;
    }

    static associate(models) {
        this.belongsTo(models.Currency, {
            foreignKey: 'currencyId',
            as: 'currency'
        });
    }
}

CurrencyRange.init(sequelize);
