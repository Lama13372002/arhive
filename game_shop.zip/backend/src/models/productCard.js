import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

export default class ProductCard extends Model {
	static associate(models) {
		ProductCard.belongsToMany(models.Genre, {
			through: 'ProductCardGenres',
			foreignKey: 'product_card_id',
			otherKey: 'genre_id',
			as: 'genres',
		});
		// Связь с коллекциями
		ProductCard.belongsToMany(models.ProductCollection, {
			through: 'ProductCollectionCards',
			foreignKey: 'product_card_id',
			otherKey: 'product_collection_id',
			as: 'collections',
		});
		ProductCard.hasMany(models.Edition, {
			foreignKey: 'product_card_id',
			as: 'editions',
			sourceKey: 'id',
		});
	}

	static init(sequelize) {
		super.init(
			{
				id: {
					type: DataTypes.INTEGER,
					primaryKey: true,
					autoIncrement: true,
				},
				name: {
					type: DataTypes.STRING,
					allowNull: false,
				},
				image_url: {
					type: DataTypes.STRING,
					allowNull: false,
				},
				free_with_ea_play: {
					type: DataTypes.BOOLEAN,
					defaultValue: false,
				},
				free_with_ps_plus_essential: {
					type: DataTypes.BOOLEAN,
					defaultValue: false,
				},
				free_with_ps_plus_extra: {
					type: DataTypes.BOOLEAN,
					defaultValue: false,
				},
				free_with_ps_plus_deluxe: {
					type: DataTypes.BOOLEAN,
					defaultValue: false,
				},
				rating: {
					type: DataTypes.FLOAT,
					allowNull: true,
				},
				edition_type: {
					type: DataTypes.STRING,
					allowNull: true,
				},
				tags: {
					type: DataTypes.ARRAY(DataTypes.STRING),
					allowNull: true,
					defaultValue: [],
				},
			},
			{
				sequelize,
				modelName: 'ProductCard',
				tableName: 'ProductCards',
				timestamps: true,
				underscored: true,
			}
		);
		return this;
	}
}

ProductCard.init(sequelize);
