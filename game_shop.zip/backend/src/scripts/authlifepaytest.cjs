const axios = require('axios');
let data = JSON.stringify({
	service_id: 90134,
	api_key: '9e3fb9c103',
});

let config = {
	method: 'post',
	maxBodyLength: Infinity,
	url: 'https://api-ecom.life-pay.ru/v1/auth',
	headers: {
		'Content-Type': 'application/json',
		Accept: 'application/json',
	},
	data: data,
};

axios
	.request(config)
	.then(response => {
		console.log(JSON.stringify(response.data));
	})
	.catch(error => {
		console.log(error);
	});
