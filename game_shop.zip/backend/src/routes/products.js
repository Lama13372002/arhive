import { Router } from 'express';
import { Op } from 'sequelize';
import sequelize from '../config/database.js';
import db from '../models/index.js';

const router = Router();

router.get('/', async (req, res) => {
	try {
		const { currency_id } = req.query;

		const products = await db.ProductCard.findAll({
			include: [
				{
					model: db.Genre,
					through: { attributes: [] },
					as: 'genres',
				},
				{
					model: db.Platform,
					as: 'platforms',
					through: { attributes: [] },
				},
				{
					model: db.Edition,
					as: 'editions',
					where: currency_id
						? {
								display_currency_id: currency_id,
						  }
						: {},
					required: currency_id ? true : false,
					attributes: [
						'id',
						'description',
						'price',
						'discount_amount',
						'ea_play_price',
						'ps_plus_price',
						'promotion_end_date',
					],
					include: [
						{
							model: db.EditionName,
							as: 'editionName',
							attributes: ['id', 'name'],
						},
						{
							model: db.Currency,
							as: 'displayCurrency',
							attributes: ['id', 'code', 'symbol'],
						},
						{
							model: db.Localization,
							as: 'localizations',
							through: { attributes: [] },
						},
						{
							model: db.Platform,
							as: 'platforms',
							through: { attributes: [] },
						},
					],
				},
			],
			order: [['id', 'DESC']],
			attributes: [
				'id',
				'name',
				'image_url',
				'rating',
				'edition_type',
				'tags',
				'created_at',
				'updated_at',
			],
			group: currency_id
				? [
						'ProductCard.id',
						'genres.id',
						'platforms.id',
						'editions.id',
						'editions->editionName.id',
						'editions->displayCurrency.id',
						'editions->localizations.id',
						'editions->platforms.id',
				  ]
				: undefined,
		});

		res.json(products);
	} catch (error) {
		console.error('Error fetching products:', error);
		res.status(500).json({ error: 'Internal server error' });
	}
});

router.get('/search', async (req, res) => {
	try {
		// Включаем детальное логирование SQL-запросов
		const originalLogging = sequelize.options.logging;
		sequelize.options.logging = console.log;

		const { query, genres, priceFrom, priceTo, rating, currency_id } =
			req.query;
		console.log('Search params:', {
			query,
			genres,
			priceFrom,
			priceTo,
			rating,
			currency_id,
		});

		// Получаем валюту пользователя
		let userCurrency;
		if (currency_id) {
			userCurrency = await db.Currency.findByPk(currency_id);
		} else {
			// Если валюта не указана, используем валюту по умолчанию
			userCurrency = await db.Currency.findOne({
				where: { is_default: true },
			});
		}

		if (!userCurrency) {
			return res.status(400).json({ error: 'Currency not found' });
		}

		// Получаем диапазоны валют для конвертации
		const currencyRanges = await db.CurrencyRange.findAll({
			where: {
				currencyId: userCurrency.id,
			},
			order: [['amountFrom', 'ASC']],
		});

		// Функция для получения множителя курса на основе диапазона
		const getRateMultiplier = amount => {
			if (!currencyRanges || currencyRanges.length === 0) return 1.0;

			const numericAmount = Number(amount);
			if (isNaN(numericAmount)) return 1.0;

			const range = currencyRanges.find(
				range =>
					numericAmount >= Number(range.amountFrom) &&
					numericAmount <= Number(range.amountTo)
			);

			return range ? Number(range.rate_multiplier) : 1.0;
		};

		const whereConditions = {};
		const editionWhereConditions = {};

		// Фильтр по валюте
		if (currency_id) {
			editionWhereConditions.display_currency_id = currency_id;
		}

		// Фильтр по цене
		if (priceFrom || priceTo) {
			console.log('Применяем фильтр по цене:', { priceFrom, priceTo });

			// Преобразуем значения в числа, если они определены
			const numericPriceFrom = priceFrom
				? parseFloat(priceFrom)
				: undefined;
			const numericPriceTo = priceTo ? parseFloat(priceTo) : undefined;

			// Проверяем, что значения валидные числа
			const validPriceFrom =
				numericPriceFrom !== undefined && !isNaN(numericPriceFrom);
			const validPriceTo =
				numericPriceTo !== undefined && !isNaN(numericPriceTo);

			console.log('Валидация цены:', {
				numericPriceFrom,
				numericPriceTo,
				validPriceFrom,
				validPriceTo,
			});

			// Для корректной работы с ценами со скидкой используем сложные условия
			const priceConditions = [];

			// Условие 1: Если есть скидка - используем её для сравнения
			if (validPriceFrom && validPriceTo) {
				// С мин. и макс. ценой
				priceConditions.push({
					[Op.and]: [
						{ discount_amount: { [Op.ne]: null } },
						{ discount_amount: { [Op.gte]: numericPriceFrom } },
						{ discount_amount: { [Op.lte]: numericPriceTo } },
					],
				});
			} else if (validPriceFrom) {
				// Только с мин. ценой
				priceConditions.push({
					[Op.and]: [
						{ discount_amount: { [Op.ne]: null } },
						{ discount_amount: { [Op.gte]: numericPriceFrom } },
					],
				});
			} else if (validPriceTo) {
				// Только с макс. ценой
				priceConditions.push({
					[Op.and]: [
						{ discount_amount: { [Op.ne]: null } },
						{ discount_amount: { [Op.lte]: numericPriceTo } },
					],
				});
			}

			// Условие 2: Если скидки нет - используем обычную цену
			if (validPriceFrom && validPriceTo) {
				// С мин. и макс. ценой
				priceConditions.push({
					[Op.and]: [
						{ discount_amount: null },
						{ price: { [Op.gte]: numericPriceFrom } },
						{ price: { [Op.lte]: numericPriceTo } },
					],
				});
			} else if (validPriceFrom) {
				// Только с мин. ценой
				priceConditions.push({
					[Op.and]: [
						{ discount_amount: null },
						{ price: { [Op.gte]: numericPriceFrom } },
					],
				});
			} else if (validPriceTo) {
				// Только с макс. ценой
				priceConditions.push({
					[Op.and]: [
						{ discount_amount: null },
						{ price: { [Op.lte]: numericPriceTo } },
					],
				});
			}

			// Объединяем условия с OR
			editionWhereConditions[Op.or] = priceConditions;

			console.log(
				'Построено условие фильтрации по цене:',
				JSON.stringify(editionWhereConditions[Op.or], null, 2)
			);
		}

		// Фильтр по поисковому запросу
		if (query) {
			// Экранируем спецсимволы в запросе для предотвращения SQL-инъекций
			const safeQuery = query.replace(/[%_'"\\\x00-\x1F\x7F]/g, '');
			console.log('Экранированный запрос:', safeQuery);

			// Преобразуем запрос в массив для поиска по тегам
			const searchTerms = safeQuery
				.split(/\s+/)
				.filter(term => term.length > 0);

			const conditions = [
				// 1. Поиск по названию игры (стандартный)
				{ name: { [Op.iLike]: `%${safeQuery}%` } },
			];

			// 2. Прямой поиск по массиву тегов, если поле tags существует и является массивом
			try {
				conditions.push(
					sequelize.literal(`
						CASE WHEN "ProductCard"."tags" IS NOT NULL AND array_length("ProductCard"."tags", 1) > 0
						THEN EXISTS (
							SELECT 1 FROM unnest("ProductCard"."tags") AS tag
							WHERE tag ILIKE '%${safeQuery}%'
						)
						ELSE false
						END
					`)
				);

				// 3. Поиск конкретных тегов (точное совпадение с элементами массива)
				conditions.push({
					tags: {
						[Op.overlap]: searchTerms,
					},
				});
			} catch (error) {
				console.error(
					'Ошибка при создании условия для поиска по тегам:',
					error
				);
			}

			whereConditions[Op.or] = conditions;

			console.log('Поиск по названию и тегам:', {
				safeQuery,
				searchTerms,
				conditionsCount: conditions.length,
			});
		}

		// Фильтр по рейтингу
		if (rating) {
			whereConditions.rating = {
				[Op.gte]: rating,
			};
		}

		const products = await db.ProductCard.findAll({
			where: whereConditions,
			include: [
				{
					model: db.Genre,
					through: { attributes: [] },
					as: 'genres',
					...(genres && {
						where: {
							id: {
								[Op.in]: genres.split(',').map(Number),
							},
						},
						required: true,
					}),
				},
				{
					model: db.Edition,
					as: 'editions',
					where: editionWhereConditions,
					required: Object.keys(editionWhereConditions).length > 0,
					attributes: [
						'id',
						'description',
						'price',
						'discount_amount',
						'ea_play_price',
						'ps_plus_price',
						'promotion_end_date',
						'display_currency_id',
					],
					include: [
						{
							model: db.EditionName,
							as: 'editionName',
							attributes: ['id', 'name'],
						},
						{
							model: db.Currency,
							as: 'currency',
							attributes: ['id', 'code', 'exchange_rate'],
						},
						{
							model: db.Localization,
							as: 'localizations',
							through: { attributes: [] },
						},
						{
							model: db.Platform,
							as: 'platforms',
							through: { attributes: [] },
						},
					],
				},
			],
			attributes: [
				'id',
				'name',
				'image_url',
				'rating',
				'edition_type',
				'tags',
				'created_at',
				'updated_at',
			],
			order: [['id', 'DESC']],
		});

		// Фильтруем по цене и конвертируем цены
		const filteredProducts = products
			.map(product => {
				const productJson = product.toJSON();

				// Логируем найденный продукт и его теги для отладки
				console.log(`Найден продукт: ${productJson.name}`, {
					id: productJson.id,
					tags: productJson.tags || 'Отсутствуют',
					hasTagsField: 'tags' in productJson,
				});

				if (productJson.editions) {
					productJson.editions = productJson.editions.map(edition => {
						if (edition.price && edition.currency) {
							// Сохраняем оригинальные цены
							edition.original_price = edition.price;
							edition.original_discount_price =
								edition.discount_amount;
							edition.original_eaplay_price =
								edition.ea_play_price;
							edition.original_psplus_price =
								edition.ps_plus_price;

							// Конвертируем цену из валюты издания в валюту пользователя
							const exchangeRate = edition.currency.exchange_rate;

							// Конвертируем основную цену
							const convertedPrice = edition.price * exchangeRate;
							const baseMultiplier =
								getRateMultiplier(convertedPrice);
							edition.convertedPrice =
								convertedPrice * baseMultiplier;

							// Для цены со скидкой (если есть)
							if (edition.discount_amount) {
								// Проверяем, что скидка действительная
								const originalPrice = parseFloat(edition.price);
								const discountAmount = parseFloat(
									edition.discount_amount
								);

								if (
									!isNaN(originalPrice) &&
									!isNaN(discountAmount) &&
									discountAmount < originalPrice
								) {
									// Вычисляем скидку в процентах от оригинальной цены
									const discountPercent =
										((originalPrice - discountAmount) /
											originalPrice) *
										100;

									// Рассчитываем конвертированную цену со скидкой
									const rawDiscountAmount =
										discountAmount * exchangeRate;

									// Получаем множитель для цены со скидкой на основе её величины
									const discountMultiplier =
										getRateMultiplier(rawDiscountAmount);

									// Применяем множитель к цене со скидкой
									const convertedDiscountAmount =
										rawDiscountAmount * discountMultiplier;

									// Устанавливаем конвертированную цену со скидкой
									edition.discount_amount =
										convertedDiscountAmount;
								} else {
									console.log(
										`Invalid discount for edition ${edition.id}, clearing discount amount`
									);
									edition.discount_amount = null;
								}
							}

							// Для PS Plus цены (если есть)
							if (edition.ps_plus_price) {
								// Проверяем, что PS Plus цена действительно меньше обычной
								const originalPrice = parseFloat(edition.price);
								const psPlusPrice = parseFloat(
									edition.ps_plus_price
								);

								if (
									!isNaN(originalPrice) &&
									!isNaN(psPlusPrice) &&
									psPlusPrice < originalPrice
								) {
									const convertedPsPlusPrice =
										edition.ps_plus_price * exchangeRate;
									const psPlusMultiplier =
										getRateMultiplier(convertedPsPlusPrice);
									edition.ps_plus_price =
										convertedPsPlusPrice * psPlusMultiplier;
								} else {
									console.log(
										`Invalid PS Plus price for edition ${edition.id}, clearing PS Plus price`
									);
									edition.ps_plus_price = null;
								}
							}

							// Для EA Play цены (если есть)
							if (edition.ea_play_price) {
								// Проверяем, что EA Play цена действительно меньше обычной
								const originalPrice = parseFloat(edition.price);
								const eaPlayPrice = parseFloat(
									edition.ea_play_price
								);

								if (
									!isNaN(originalPrice) &&
									!isNaN(eaPlayPrice) &&
									eaPlayPrice < originalPrice
								) {
									const convertedEaPlayPrice =
										edition.ea_play_price * exchangeRate;
									const eaPlayMultiplier =
										getRateMultiplier(convertedEaPlayPrice);
									edition.ea_play_price =
										convertedEaPlayPrice * eaPlayMultiplier;
								} else {
									console.log(
										`Invalid EA Play price for edition ${edition.id}, clearing EA Play price`
									);
									edition.ea_play_price = null;
								}
							}
						}
						return edition;
					});

					// Фильтруем по цене после конвертации для дополнительной проверки
					const beforeFilter = productJson.editions
						? productJson.editions.length
						: 0;

					if (priceFrom || priceTo) {
						productJson.editions = productJson.editions.filter(
							edition => {
								// Определяем цену: со скидкой, если есть, иначе обычную
								const price =
									edition.discount_amount !== null
										? edition.discount_amount
										: edition.convertedPrice;

								// Преобразуем значения в числа для сравнения
								const numericPriceFrom = priceFrom
									? parseFloat(priceFrom)
									: undefined;
								const numericPriceTo = priceTo
									? parseFloat(priceTo)
									: undefined;

								// Проверяем валидность преобразованных значений
								const validPriceFrom =
									numericPriceFrom !== undefined &&
									!isNaN(numericPriceFrom);
								const validPriceTo =
									numericPriceTo !== undefined &&
									!isNaN(numericPriceTo);

								// Проверяем условия фильтрации
								const matchesMin =
									!validPriceFrom ||
									price >= numericPriceFrom;
								const matchesMax =
									!validPriceTo || price <= numericPriceTo;

								// Дополнительное логирование для отладки
								if (!matchesMin || !matchesMax) {
									console.log(
										`Издание ${edition.id} не прошло фильтр по цене:`,
										{
											фактическаяЦена: price,
											минЦена: validPriceFrom
												? numericPriceFrom
												: 'не задана',
											максЦена: validPriceTo
												? numericPriceTo
												: 'не задана',
											соответствуетМин: matchesMin,
											соответствуетМакс: matchesMax,
										}
									);
								}

								return matchesMin && matchesMax;
							}
						);

						const afterFilter = productJson.editions
							? productJson.editions.length
							: 0;
						if (beforeFilter !== afterFilter) {
							console.log(
								`Вторичная фильтрация изменила количество изданий для продукта ${productJson.id}: ${beforeFilter} -> ${afterFilter}`
							);
						}
					}
				}

				return {
					...productJson,
					title: productJson.name,
				};
			})
			.filter(product => product.editions?.length > 0);

		// Восстанавливаем исходное значение логирования
		sequelize.options.logging = originalLogging;

		console.log(`Found ${filteredProducts.length} products`);
		res.json(filteredProducts);
	} catch (error) {
		console.error('Search error:', error);
		res.status(500).json({
			error: 'Internal server error',
			details: error.message,
		});
	}
});

// Роут для получения игр с EA Play - должен быть перед роутом с :id
router.get('/subscription/ea-play', async (req, res) => {
	try {
		console.log('EA Play route called with query:', req.query);
		const { currency_id } = req.query;

		// Получаем валюту пользователя
		let userCurrency;
		if (currency_id) {
			userCurrency = await db.Currency.findByPk(currency_id);
		} else {
			// Если валюта не указана, используем валюту по умолчанию
			userCurrency = await db.Currency.findOne({
				where: { is_default: true },
			});
		}

		if (!userCurrency) {
			return res.status(400).json({ error: 'Currency not found' });
		}

		// Получаем диапазоны валют для конвертации
		const currencyRanges = await db.CurrencyRange.findAll({
			where: {
				currencyId: userCurrency.id,
			},
			order: [['amountFrom', 'ASC']],
		});

		// Функция для получения множителя курса на основе диапазона
		const getRateMultiplier = amount => {
			if (!currencyRanges || currencyRanges.length === 0) return 1.0;

			const numericAmount = Number(amount);
			if (isNaN(numericAmount)) return 1.0;

			const range = currencyRanges.find(
				range =>
					numericAmount >= Number(range.amountFrom) &&
					numericAmount <= Number(range.amountTo)
			);

			return range ? Number(range.rate_multiplier) : 1.0;
		};

		const products = await db.ProductCard.findAll({
			where: {
				free_with_ea_play: true,
			},
			include: [
				{
					model: db.Genre,
					through: { attributes: [] },
					as: 'genres',
				},
				{
					model: db.Edition,
					as: 'editions',
					where: currency_id
						? {
								display_currency_id: currency_id,
						  }
						: {},
					required: currency_id ? true : false,
					attributes: [
						'id',
						'description',
						'price',
						'discount_amount',
						'ea_play_price',
						'ps_plus_price',
						'promotion_end_date',
					],
					include: [
						{
							model: db.EditionName,
							as: 'editionName',
							attributes: ['id', 'name'],
						},
						{
							model: db.Currency,
							as: 'currency',
							attributes: [
								'id',
								'code',
								'symbol',
								'exchange_rate',
							],
						},
						{
							model: db.Platform,
							as: 'platforms',
							through: { attributes: [] },
						},
					],
				},
			],
			attributes: [
				'id',
				'name',
				'image_url',
				'rating',
				'edition_type',
				'created_at',
				'updated_at',
			],
		});

		// Конвертируем цены для каждого продукта и его изданий
		const productsWithConvertedPrices = products.map(product => {
			const productJson = product.toJSON();

			if (productJson.editions) {
				productJson.editions = productJson.editions.map(edition => {
					if (edition.price && edition.currency) {
						// Сохраняем оригинальные цены
						edition.original_price = edition.price;
						edition.original_discount_price =
							edition.discount_amount;
						edition.original_eaplay_price = edition.ea_play_price;
						edition.original_psplus_price = edition.ps_plus_price;

						// Конвертируем цену из валюты издания в валюту пользователя
						const exchangeRate = edition.currency.exchange_rate;

						// ИСПРАВЛЕННАЯ ЛОГИКА: Всегда конвертируем базовую цену отдельно
						const basePrice = Number(edition.price) * exchangeRate;
						const baseMultiplier = getRateMultiplier(basePrice);
						edition.convertedPrice = basePrice * baseMultiplier;

						// Для цены со скидкой (если есть)
						if (edition.discount_amount) {
							const discountPrice =
								Number(edition.discount_amount) * exchangeRate;
							const discountMultiplier =
								getRateMultiplier(discountPrice);
							edition.discount_amount =
								discountPrice * discountMultiplier;

							console.log(
								`Converted prices for edition ${edition.id}:`,
								{
									original: edition.original_price,
									discounted: edition.original_discount_price,
									convertedBase: edition.convertedPrice,
									convertedDiscount: edition.discount_amount,
								}
							);
						}

						// Для PS Plus цены (если есть)
						if (edition.ps_plus_price) {
							const psPlusPrice =
								Number(edition.ps_plus_price) * exchangeRate;
							const psPlusMultiplier =
								getRateMultiplier(psPlusPrice);
							edition.ps_plus_price =
								psPlusPrice * psPlusMultiplier;
						}

						// Для EA Play цены (если есть)
						if (edition.ea_play_price) {
							const eaPlayPrice =
								Number(edition.ea_play_price) * exchangeRate;
							const eaPlayMultiplier =
								getRateMultiplier(eaPlayPrice);
							edition.ea_play_price =
								eaPlayPrice * eaPlayMultiplier;
						}

						// Добавляем информацию о валюте пользователя
						edition.displayCurrency = {
							code: userCurrency.code,
							id: userCurrency.id,
							symbol: userCurrency.symbol,
						};
					}
					return edition;
				});
			}

			return productJson;
		});

		res.json({ data: productsWithConvertedPrices });
	} catch (error) {
		console.error('Error fetching EA Play games:', error);
		res.status(500).json({
			error: 'Internal server error',
			details: error.message,
		});
	}
});

router.get('/subscription/ps-plus-essential', async (req, res) => {
	try {
		console.log('PS Plus Essential route called with query:', req.query);
		const { currency_id } = req.query;

		// Получаем валюту пользователя
		let userCurrency;
		if (currency_id) {
			userCurrency = await db.Currency.findByPk(currency_id);
		} else {
			// Если валюта не указана, используем валюту по умолчанию
			userCurrency = await db.Currency.findOne({
				where: { is_default: true },
			});
		}

		if (!userCurrency) {
			return res.status(400).json({ error: 'Currency not found' });
		}

		// Получаем диапазоны валют для конвертации
		const currencyRanges = await db.CurrencyRange.findAll({
			where: {
				currencyId: userCurrency.id,
			},
			order: [['amountFrom', 'ASC']],
		});

		// Функция для получения множителя курса на основе диапазона
		const getRateMultiplier = amount => {
			if (!currencyRanges || currencyRanges.length === 0) return 1.0;

			const numericAmount = Number(amount);
			if (isNaN(numericAmount)) return 1.0;

			const range = currencyRanges.find(
				range =>
					numericAmount >= Number(range.amountFrom) &&
					numericAmount <= Number(range.amountTo)
			);

			return range ? Number(range.rate_multiplier) : 1.0;
		};

		const products = await db.ProductCard.findAll({
			where: {
				free_with_ps_plus_essential: true,
			},
			include: [
				{
					model: db.Genre,
					through: { attributes: [] },
					as: 'genres',
				},
				{
					model: db.Edition,
					as: 'editions',
					where: currency_id
						? {
								display_currency_id: currency_id,
						  }
						: {},
					required: currency_id ? true : false,
					attributes: [
						'id',
						'description',
						'price',
						'discount_amount',
						'ea_play_price',
						'ps_plus_price',
						'promotion_end_date',
					],
					include: [
						{
							model: db.EditionName,
							as: 'editionName',
							attributes: ['id', 'name'],
						},
						{
							model: db.Currency,
							as: 'currency',
							attributes: [
								'id',
								'code',
								'symbol',
								'exchange_rate',
							],
						},
						{
							model: db.Platform,
							as: 'platforms',
							through: { attributes: [] },
						},
					],
				},
			],
			attributes: [
				'id',
				'name',
				'image_url',
				'rating',
				'edition_type',
				'created_at',
				'updated_at',
			],
		});

		// Конвертируем цены для каждого продукта и его изданий
		const productsWithConvertedPrices = products.map(product => {
			const productJson = product.toJSON();

			if (productJson.editions) {
				productJson.editions = productJson.editions.map(edition => {
					if (edition.price && edition.currency) {
						// Сохраняем оригинальные цены
						edition.original_price = edition.price;
						edition.original_discount_price =
							edition.discount_amount;
						edition.original_eaplay_price = edition.ea_play_price;
						edition.original_psplus_price = edition.ps_plus_price;

						// Конвертируем цену из валюты издания в валюту пользователя
						const exchangeRate = edition.currency.exchange_rate;

						// ИСПРАВЛЕННАЯ ЛОГИКА: Всегда конвертируем базовую цену отдельно
						const basePrice = Number(edition.price) * exchangeRate;
						const baseMultiplier = getRateMultiplier(basePrice);
						edition.convertedPrice = basePrice * baseMultiplier;

						// Для цены со скидкой (если есть)
						if (edition.discount_amount) {
							const discountPrice =
								Number(edition.discount_amount) * exchangeRate;
							const discountMultiplier =
								getRateMultiplier(discountPrice);
							edition.discount_amount =
								discountPrice * discountMultiplier;

							console.log(
								`Converted prices for edition ${edition.id}:`,
								{
									original: edition.original_price,
									discounted: edition.original_discount_price,
									convertedBase: edition.convertedPrice,
									convertedDiscount: edition.discount_amount,
								}
							);
						}

						// Для PS Plus цены (если есть)
						if (edition.ps_plus_price) {
							const psPlusPrice =
								Number(edition.ps_plus_price) * exchangeRate;
							const psPlusMultiplier =
								getRateMultiplier(psPlusPrice);
							edition.ps_plus_price =
								psPlusPrice * psPlusMultiplier;
						}

						// Для EA Play цены (если есть)
						if (edition.ea_play_price) {
							const eaPlayPrice =
								Number(edition.ea_play_price) * exchangeRate;
							const eaPlayMultiplier =
								getRateMultiplier(eaPlayPrice);
							edition.ea_play_price =
								eaPlayPrice * eaPlayMultiplier;
						}

						// Добавляем информацию о валюте пользователя
						edition.displayCurrency = {
							code: userCurrency.code,
							id: userCurrency.id,
							symbol: userCurrency.symbol,
						};
					}
					return edition;
				});
			}

			return productJson;
		});

		res.json({ data: productsWithConvertedPrices });
	} catch (error) {
		console.error('Error fetching PS Plus Essential games:', error);
		res.status(500).json({
			error: 'Internal server error',
			details: error.message,
		});
	}
});

router.get('/subscription/ps-plus-extra', async (req, res) => {
	try {
		console.log('PS Plus Extra route called with query:', req.query);
		const { currency_id } = req.query;

		// Получаем валюту пользователя
		let userCurrency;
		if (currency_id) {
			userCurrency = await db.Currency.findByPk(currency_id);
		} else {
			// Если валюта не указана, используем валюту по умолчанию
			userCurrency = await db.Currency.findOne({
				where: { is_default: true },
			});
		}

		if (!userCurrency) {
			return res.status(400).json({ error: 'Currency not found' });
		}

		// Получаем диапазоны валют для конвертации
		const currencyRanges = await db.CurrencyRange.findAll({
			where: {
				currencyId: userCurrency.id,
			},
			order: [['amountFrom', 'ASC']],
		});

		// Функция для получения множителя курса на основе диапазона
		const getRateMultiplier = amount => {
			if (!currencyRanges || currencyRanges.length === 0) return 1.0;

			const numericAmount = Number(amount);
			if (isNaN(numericAmount)) return 1.0;

			const range = currencyRanges.find(
				range =>
					numericAmount >= Number(range.amountFrom) &&
					numericAmount <= Number(range.amountTo)
			);

			return range ? Number(range.rate_multiplier) : 1.0;
		};

		const products = await db.ProductCard.findAll({
			where: {
				free_with_ps_plus_extra: true,
			},
			include: [
				{
					model: db.Genre,
					through: { attributes: [] },
					as: 'genres',
				},
				{
					model: db.Edition,
					as: 'editions',
					where: currency_id
						? {
								display_currency_id: currency_id,
						  }
						: {},
					required: currency_id ? true : false,
					attributes: [
						'id',
						'description',
						'price',
						'discount_amount',
						'ea_play_price',
						'ps_plus_price',
						'promotion_end_date',
					],
					include: [
						{
							model: db.EditionName,
							as: 'editionName',
							attributes: ['id', 'name'],
						},
						{
							model: db.Currency,
							as: 'currency',
							attributes: [
								'id',
								'code',
								'symbol',
								'exchange_rate',
							],
						},
						{
							model: db.Platform,
							as: 'platforms',
							through: { attributes: [] },
						},
					],
				},
			],
			attributes: [
				'id',
				'name',
				'image_url',
				'rating',
				'edition_type',
				'created_at',
				'updated_at',
			],
		});

		// Конвертируем цены для каждого продукта и его изданий
		const productsWithConvertedPrices = products.map(product => {
			const productJson = product.toJSON();

			if (productJson.editions) {
				productJson.editions = productJson.editions.map(edition => {
					if (edition.price && edition.currency) {
						// Сохраняем оригинальные цены
						edition.original_price = edition.price;
						edition.original_discount_price =
							edition.discount_amount;
						edition.original_eaplay_price = edition.ea_play_price;
						edition.original_psplus_price = edition.ps_plus_price;

						// Конвертируем цену из валюты издания в валюту пользователя
						const exchangeRate = edition.currency.exchange_rate;

						// ИСПРАВЛЕННАЯ ЛОГИКА: Всегда конвертируем базовую цену отдельно
						const basePrice = Number(edition.price) * exchangeRate;
						const baseMultiplier = getRateMultiplier(basePrice);
						edition.convertedPrice = basePrice * baseMultiplier;

						// Для цены со скидкой (если есть)
						if (edition.discount_amount) {
							const discountPrice =
								Number(edition.discount_amount) * exchangeRate;
							const discountMultiplier =
								getRateMultiplier(discountPrice);
							edition.discount_amount =
								discountPrice * discountMultiplier;

							console.log(
								`Converted prices for edition ${edition.id}:`,
								{
									original: edition.original_price,
									discounted: edition.original_discount_price,
									convertedBase: edition.convertedPrice,
									convertedDiscount: edition.discount_amount,
								}
							);
						}

						// Для PS Plus цены (если есть)
						if (edition.ps_plus_price) {
							const psPlusPrice =
								Number(edition.ps_plus_price) * exchangeRate;
							const psPlusMultiplier =
								getRateMultiplier(psPlusPrice);
							edition.ps_plus_price =
								psPlusPrice * psPlusMultiplier;
						}

						// Для EA Play цены (если есть)
						if (edition.ea_play_price) {
							const eaPlayPrice =
								Number(edition.ea_play_price) * exchangeRate;
							const eaPlayMultiplier =
								getRateMultiplier(eaPlayPrice);
							edition.ea_play_price =
								eaPlayPrice * eaPlayMultiplier;
						}

						// Добавляем информацию о валюте пользователя
						edition.displayCurrency = {
							code: userCurrency.code,
							id: userCurrency.id,
							symbol: userCurrency.symbol,
						};
					}
					return edition;
				});
			}

			return productJson;
		});

		res.json({ data: productsWithConvertedPrices });
	} catch (error) {
		console.error('Error fetching PS Plus Extra games:', error);
		res.status(500).json({
			error: 'Internal server error',
			details: error.message,
		});
	}
});

router.get('/subscription/ps-plus-deluxe', async (req, res) => {
	try {
		console.log('PS Plus Deluxe route called with query:', req.query);
		const { currency_id } = req.query;

		// Получаем валюту пользователя
		let userCurrency;
		if (currency_id) {
			userCurrency = await db.Currency.findByPk(currency_id);
		} else {
			// Если валюта не указана, используем валюту по умолчанию
			userCurrency = await db.Currency.findOne({
				where: { is_default: true },
			});
		}

		if (!userCurrency) {
			return res.status(400).json({ error: 'Currency not found' });
		}

		// Получаем диапазоны валют для конвертации
		const currencyRanges = await db.CurrencyRange.findAll({
			where: {
				currencyId: userCurrency.id,
			},
			order: [['amountFrom', 'ASC']],
		});

		// Функция для получения множителя курса на основе диапазона
		const getRateMultiplier = amount => {
			if (!currencyRanges || currencyRanges.length === 0) return 1.0;

			const numericAmount = Number(amount);
			if (isNaN(numericAmount)) return 1.0;

			const range = currencyRanges.find(
				range =>
					numericAmount >= Number(range.amountFrom) &&
					numericAmount <= Number(range.amountTo)
			);

			return range ? Number(range.rate_multiplier) : 1.0;
		};

		const products = await db.ProductCard.findAll({
			where: {
				free_with_ps_plus_deluxe: true,
			},
			include: [
				{
					model: db.Genre,
					through: { attributes: [] },
					as: 'genres',
				},
				{
					model: db.Edition,
					as: 'editions',
					where: currency_id
						? {
								display_currency_id: currency_id,
						  }
						: {},
					required: currency_id ? true : false,
					attributes: [
						'id',
						'description',
						'price',
						'discount_amount',
						'ea_play_price',
						'ps_plus_price',
						'promotion_end_date',
					],
					include: [
						{
							model: db.EditionName,
							as: 'editionName',
							attributes: ['id', 'name'],
						},
						{
							model: db.Currency,
							as: 'currency',
							attributes: [
								'id',
								'code',
								'symbol',
								'exchange_rate',
							],
						},
						{
							model: db.Platform,
							as: 'platforms',
							through: { attributes: [] },
						},
					],
				},
			],
			attributes: [
				'id',
				'name',
				'image_url',
				'rating',
				'edition_type',
				'created_at',
				'updated_at',
			],
		});

		// Конвертируем цены для каждого продукта и его изданий
		const productsWithConvertedPrices = products.map(product => {
			const productJson = product.toJSON();

			if (productJson.editions) {
				productJson.editions = productJson.editions.map(edition => {
					if (edition.price && edition.currency) {
						// Сохраняем оригинальные цены
						edition.original_price = edition.price;
						edition.original_discount_price =
							edition.discount_amount;
						edition.original_eaplay_price = edition.ea_play_price;
						edition.original_psplus_price = edition.ps_plus_price;

						// Конвертируем цену из валюты издания в валюту пользователя
						const exchangeRate = edition.currency.exchange_rate;

						// ИСПРАВЛЕННАЯ ЛОГИКА: Всегда конвертируем базовую цену отдельно
						const basePrice = Number(edition.price) * exchangeRate;
						const baseMultiplier = getRateMultiplier(basePrice);
						edition.convertedPrice = basePrice * baseMultiplier;

						// Для цены со скидкой (если есть)
						if (edition.discount_amount) {
							const discountPrice =
								Number(edition.discount_amount) * exchangeRate;
							const discountMultiplier =
								getRateMultiplier(discountPrice);
							edition.discount_amount =
								discountPrice * discountMultiplier;

							console.log(
								`Converted prices for edition ${edition.id}:`,
								{
									original: edition.original_price,
									discounted: edition.original_discount_price,
									convertedBase: edition.convertedPrice,
									convertedDiscount: edition.discount_amount,
								}
							);
						}

						// Для PS Plus цены (если есть)
						if (edition.ps_plus_price) {
							const psPlusPrice =
								Number(edition.ps_plus_price) * exchangeRate;
							const psPlusMultiplier =
								getRateMultiplier(psPlusPrice);
							edition.ps_plus_price =
								psPlusPrice * psPlusMultiplier;
						}

						// Для EA Play цены (если есть)
						if (edition.ea_play_price) {
							const eaPlayPrice =
								Number(edition.ea_play_price) * exchangeRate;
							const eaPlayMultiplier =
								getRateMultiplier(eaPlayPrice);
							edition.ea_play_price =
								eaPlayPrice * eaPlayMultiplier;
						}

						// Добавляем информацию о валюте пользователя
						edition.displayCurrency = {
							code: userCurrency.code,
							id: userCurrency.id,
							symbol: userCurrency.symbol,
						};
					}
					return edition;
				});
			}

			return productJson;
		});

		res.json({ data: productsWithConvertedPrices });
	} catch (error) {
		console.error('Error fetching PS Plus Deluxe games:', error);
		res.status(500).json({
			error: 'Internal server error',
			details: error.message,
		});
	}
});

// Calculate cart total with currency range and promo code
router.post('/calculate-cart-total', async (req, res) => {
	try {
		const {
			editionIds,
			selectedCurrencyId,
			currentTotal,
			priceTypes,
			promoCode,
		} = req.body;
		console.log('Calculate cart total called with raw body:', req.body);
		console.log('Calculate cart total called with parsed params:', {
			editionIds,
			selectedCurrencyId,
			currentTotal,
			priceTypes,
			promoCode,
		});

		if (
			!editionIds ||
			!Array.isArray(editionIds) ||
			!selectedCurrencyId ||
			currentTotal === undefined
		) {
			console.log('Invalid request parameters:', {
				hasEditionIds: !!editionIds,
				isArray: Array.isArray(editionIds),
				selectedCurrencyId,
				hasCurrentTotal: currentTotal !== undefined,
			});
			return res.status(400).json({
				success: false,
				error: 'editionIds array, selectedCurrencyId and currentTotal are required',
			});
		}

		// Получаем издания
		const editions = await db.Edition.findAll({
			where: {
				id: {
					[Op.in]: editionIds,
				},
			},
			include: [
				{
					model: db.Currency,
					as: 'currency',
					attributes: ['id', 'code', 'exchange_rate'],
				},
			],
		});

		console.log(
			'Found editions:',
			editions.map(e => ({
				id: e.id,
				price: e.price,
				discount_amount: e.discount_amount,
				currency: e.currency,
			}))
		);

		// Получаем диапазоны для выбранной валюты
		const currencyRanges = await db.CurrencyRange.findAll({
			where: {
				currencyId: selectedCurrencyId,
			},
			order: [['amountFrom', 'ASC']],
		});

		console.log('Currency ranges:', currencyRanges);

		// Для отображения в логах
		let itemPrices = [];

		// Общая сумма в оригинальной валюте (до применения диапазона)
		let totalInOriginalCurrency = 0;

		// Обрабатываем каждое издание для получения конвертированных цен
		editions.forEach(edition => {
			const editionId = edition.id;
			const priceType = priceTypes && priceTypes[editionId];
			const exchangeRate = edition.currency?.exchange_rate || 1.0;

			console.log(
				`Processing edition ${editionId} with price type: ${priceType}`
			);

			// ИСПРАВЛЕНО: Определяем базовую цену с учетом скидок
			// Используем discount_amount, если она существует и меньше обычной цены
			let basePrice = edition.price;
			if (edition.discount_amount) {
				basePrice = edition.discount_amount;
				console.log(
					`Using discounted price for edition ${editionId}: ${edition.discount_amount}`
				);
			}

			// Определяем финальную цену с учетом типа цены (PS Plus, EA Play и т.д.)
			let finalPrice = basePrice;
			if (priceType === 'ps_plus' && edition.ps_plus_price !== null) {
				finalPrice = edition.ps_plus_price;
				console.log(
					`Using PS Plus price for edition ${editionId}: ${finalPrice}`
				);
			} else if (
				priceType === 'ea_play' &&
				edition.ea_play_price !== null
			) {
				finalPrice = edition.ea_play_price;
				console.log(
					`Using EA Play price for edition ${editionId}: ${finalPrice}`
				);
			} else {
				// УДАЛЕНО: Не применяем автоматически EA Play и PS Plus цены, если они не выбраны явно
				// Оставляем только цену со скидкой (discount_amount)
				console.log(
					`Using base price with discount for edition ${editionId}: ${finalPrice}`
				);
			}

			// Конвертируем цену в валюту пользователя
			const convertedPrice = finalPrice * exchangeRate;

			// Добавляем конвертированную цену к общей сумме
			totalInOriginalCurrency += convertedPrice;

			// Сохраняем подробности для логов
			itemPrices.push({
				editionId,
				originalPrice: edition.price,
				discountedPrice: edition.discount_amount,
				finalPriceBeforeConversion: finalPrice,
				convertedPrice,
				exchangeRate,
			});

			console.log(
				`Processed edition ${editionId}: original=${edition.price}, discounted=${edition.discount_amount}, final=${finalPrice}, converted=${convertedPrice}`
			);
		});

		console.log(
			'Total in original currency before range application:',
			totalInOriginalCurrency
		);

		// Находим подходящий диапазон для общей суммы
		const range = currencyRanges.find(
			range =>
				totalInOriginalCurrency >= Number(range.amountFrom) &&
				totalInOriginalCurrency <= Number(range.amountTo)
		);

		// Применяем множитель диапазона к общей сумме
		const multiplier = range ? Number(range.rate_multiplier) : 1.0;
		// Вычисляем итоговую цену после применения множителя
		const finalTotalWithMultiplier = totalInOriginalCurrency * multiplier;

		// ИСПРАВЛЕНИЕ: Всегда используем цену с множителем, не выбираем минимум между ними
		// Это соответствует логике скидок при больших покупках
		let finalTotal = finalTotalWithMultiplier;

		// Применяем промокод, если он указан
		let promoDiscount = 0;
		let appliedPromo = null;

		if (promoCode) {
			try {
				// Получаем ID пользователя из заголовков Telegram
				const userId = req.headers['x-telegram-user-id'];

				if (!userId) {
					console.log(
						'No user ID provided for promo code application'
					);
				} else {
					// Проверяем промокод
					const promo = await db.Promo.findOne({
						where: {
							name: promoCode,
							isActive: true,
						},
					});

					if (promo) {
						// Проверяем, использовал ли пользователь этот промокод
						const usedPromo = await db.UsedPromo.findOne({
							where: {
								userId: userId,
								promoId: promo.id,
							},
						});

						if (!usedPromo) {
							// Применяем скидку по промокоду
							promoDiscount = promo.discount;
							finalTotal = finalTotal * (1 - promoDiscount / 100);
							appliedPromo = {
								id: promo.id,
								name: promo.name,
								discount: promo.discount,
							};

							console.log(
								`Applied promo code ${promoCode} with discount ${promoDiscount}%`
							);
						} else {
							console.log(
								`Promo code ${promoCode} already used by user ${userId}`
							);
						}
					} else {
						console.log(
							`Promo code ${promoCode} not found or inactive`
						);
					}
				}
			} catch (error) {
				console.error('Error applying promo code:', error);
			}
		}

		console.log('Applied range multiplier to total:', {
			totalInOriginalCurrency,
			range: range
				? {
						from: range.amountFrom,
						to: range.amountTo,
						multiplier: range.rate_multiplier,
				  }
				: 'No range found',
			multiplier,
			finalTotalWithMultiplier,
			promoDiscount,
			finalTotal,
		});

		// Обновляем информацию о ценах товаров с учетом примененного диапазона
		itemPrices = itemPrices.map(item => ({
			...item,
			range: range
				? {
						from: range.amountFrom,
						to: range.amountTo,
						multiplier: range.rate_multiplier,
				  }
				: null,
			// ИСПРАВЛЕНИЕ: Также всегда применяем множитель к отдельным товарам
			finalPrice: item.convertedPrice * multiplier,
		}));

		return res.json({
			success: true,
			originalTotal: totalInOriginalCurrency,
			total: finalTotal,
			itemPrices,
			appliedRange: range
				? {
						amountFrom: range.amountFrom,
						amountTo: range.amountTo,
						multiplier: range.rate_multiplier,
				  }
				: null,
			appliedPromo: appliedPromo,
		});
	} catch (error) {
		console.error('Error calculating cart total:', error);
		return res.status(500).json({
			success: false,
			error: 'Failed to calculate cart total',
			details: error.message,
		});
	}
});

// Роут для получения конкретной игры по id
router.get('/:id', async (req, res) => {
	try {
		const { currency_id, priceFrom, priceTo } = req.query;
		console.log(
			'Fetching product with id:',
			req.params.id,
			'currency_id:',
			currency_id,
			'price filters:',
			{ priceFrom, priceTo }
		);

		// Получаем валюту по умолчанию
		const defaultCurrency = await db.Currency.findOne({
			where: { is_default: true },
		});

		if (!defaultCurrency) {
			throw new Error('Default currency not found');
		}

		// Получаем выбранную пользователем валюту
		const userCurrency = currency_id
			? await db.Currency.findByPk(currency_id)
			: defaultCurrency;

		if (!userCurrency) {
			throw new Error('Selected currency not found');
		}

		console.log(
			'Using currency:',
			userCurrency.code,
			'id:',
			userCurrency.id
		);

		// Получаем диапазоны для валюты пользователя
		const currencyRanges = await db.CurrencyRange.findAll({
			where: {
				currencyId: userCurrency.id,
			},
			order: [['amountFrom', 'ASC']],
		});

		console.log('Found currency ranges:', currencyRanges.length);

		// Функция для получения множителя курса на основе диапазона
		const getRateMultiplier = amount => {
			if (!currencyRanges || currencyRanges.length === 0) return 1.0;

			const numericAmount = Number(amount);
			if (isNaN(numericAmount)) return 1.0;

			const range = currencyRanges.find(
				range =>
					numericAmount >= Number(range.amountFrom) &&
					numericAmount <= Number(range.amountTo)
			);

			return range ? Number(range.rate_multiplier) : 1.0;
		};

		// Сначала проверим, есть ли такой продукт
		const productExists = await db.ProductCard.findByPk(req.params.id);
		console.log('Product exists:', !!productExists);

		// Проверим, есть ли издания для этого продукта
		const editions = await db.Edition.findAll({
			where: { product_card_id: req.params.id },
		});
		console.log('Found editions:', editions.length);

		const product = await db.ProductCard.findByPk(req.params.id, {
			include: [
				{
					model: db.Genre,
					through: { attributes: [] },
					as: 'genres',
				},
				{
					model: db.Edition,
					as: 'editions',
					include: [
						{
							model: db.EditionName,
							as: 'editionName',
							attributes: ['id', 'name'],
						},
						{
							model: db.Currency,
							as: 'currency',
							attributes: ['id', 'code', 'exchange_rate'],
						},
						{
							model: db.Platform,
							as: 'platforms',
							through: { attributes: [] },
						},
						{
							model: db.Localization,
							as: 'localizations',
							through: { attributes: [] },
						},
					],
				},
			],
		});

		if (!product) {
			return res.status(404).json({ error: 'Product not found' });
		}

		const productJson = product.toJSON();

		// Конвертируем цены для каждого издания
		if (productJson.editions) {
			productJson.editions = productJson.editions.map(edition => {
				if (edition.price && edition.currency) {
					console.log(`Processing edition ${edition.id} prices:`, {
						original_price: edition.price,
						discount_amount: edition.discount_amount,
						ps_plus_price: edition.ps_plus_price,
						ea_play_price: edition.ea_play_price,
					});

					// Сохраняем оригинальные цены
					edition.original_price = edition.price;
					edition.original_discount_price = edition.discount_amount;
					edition.original_eaplay_price = edition.ea_play_price;
					edition.original_psplus_price = edition.ps_plus_price;

					// Конвертируем цену из валюты издания в валюту пользователя
					const exchangeRate = edition.currency.exchange_rate;
					console.log(
						`Exchange rate for edition ${edition.id}:`,
						exchangeRate
					);

					// Конвертируем основную цену
					const convertedPrice = edition.price * exchangeRate;
					const baseMultiplier = getRateMultiplier(convertedPrice);
					edition.convertedPrice = convertedPrice * baseMultiplier;

					console.log(`Price conversion for edition ${edition.id}:`, {
						basePrice: edition.price,
						exchangeRate,
						convertedPrice,
						baseMultiplier,
						finalPrice: edition.convertedPrice,
						is_discounted: !!edition.discount_amount,
						diff_percent: edition.discount_amount
							? Math.round(
									((edition.price - edition.discount_amount) /
										edition.price) *
										100
							  )
							: 0,
					});

					// Для цены со скидкой (если есть)
					if (edition.discount_amount) {
						// Проверяем, что скидка действительная
						const originalPrice = parseFloat(edition.price);
						const discountAmount = parseFloat(
							edition.discount_amount
						);

						if (
							!isNaN(originalPrice) &&
							!isNaN(discountAmount) &&
							discountAmount < originalPrice
						) {
							// Вычисляем скидку в процентах от оригинальной цены
							const discountPercent =
								((originalPrice - discountAmount) /
									originalPrice) *
								100;
							console.log(
								`Скидка в процентах для издания ${
									edition.id
								}: ${discountPercent.toFixed(2)}%`
							);

							// Рассчитываем конвертированную цену со скидкой
							const rawDiscountAmount =
								discountAmount * exchangeRate;

							// Получаем множитель для цены со скидкой на основе её величины
							const discountMultiplier =
								getRateMultiplier(rawDiscountAmount);

							// Применяем множитель к цене со скидкой
							const convertedDiscountAmount =
								rawDiscountAmount * discountMultiplier;

							console.log(
								`Конвертированные цены для издания ${edition.id}:`,
								{
									original: edition.convertedPrice,
									rawDiscountAmount,
									discountMultiplier,
									withDiscount: convertedDiscountAmount,
									difference:
										edition.convertedPrice -
										convertedDiscountAmount,
									percent: discountPercent,
								}
							);

							// Устанавливаем конвертированную цену со скидкой
							edition.discount_amount = convertedDiscountAmount;

							console.log(
								`Discount amount conversion for edition ${edition.id}:`,
								{
									original: edition.original_discount_price,
									originalPrice: edition.price,
									exchangeRate,
									discountPercent:
										discountPercent.toFixed(2) + '%',
									final: edition.discount_amount,
									difference:
										edition.convertedPrice -
										edition.discount_amount,
								}
							);
						} else {
							console.log(
								`Invalid discount for edition ${edition.id}, clearing discount amount`
							);
							edition.discount_amount = null;
						}
					}

					// Для PS Plus цены (если есть)
					if (edition.ps_plus_price) {
						// Проверяем, что PS Plus цена действительно меньше обычной
						const originalPrice = parseFloat(edition.price);
						const psPlusPrice = parseFloat(edition.ps_plus_price);

						if (
							!isNaN(originalPrice) &&
							!isNaN(psPlusPrice) &&
							psPlusPrice < originalPrice
						) {
							const convertedPsPlusPrice =
								edition.ps_plus_price * exchangeRate;
							const psPlusMultiplier =
								getRateMultiplier(convertedPsPlusPrice);
							edition.ps_plus_price =
								convertedPsPlusPrice * psPlusMultiplier;

							console.log(
								`PS Plus price conversion for edition ${edition.id}:`,
								{
									original: edition.original_psplus_price,
									exchangeRate,
									psPlusMultiplier,
									final: edition.ps_plus_price,
									discount:
										Math.round(
											((originalPrice - psPlusPrice) /
												originalPrice) *
												100
										) + '%',
								}
							);
						} else {
							console.log(
								`Invalid PS Plus price for edition ${edition.id}, clearing PS Plus price`
							);
							edition.ps_plus_price = null;
						}
					}

					// Для EA Play цены (если есть)
					if (edition.ea_play_price) {
						// Проверяем, что EA Play цена действительно меньше обычной
						const originalPrice = parseFloat(edition.price);
						const eaPlayPrice = parseFloat(edition.ea_play_price);

						if (
							!isNaN(originalPrice) &&
							!isNaN(eaPlayPrice) &&
							eaPlayPrice < originalPrice
						) {
							const convertedEaPlayPrice =
								edition.ea_play_price * exchangeRate;
							const eaPlayMultiplier =
								getRateMultiplier(convertedEaPlayPrice);
							edition.ea_play_price =
								convertedEaPlayPrice * eaPlayMultiplier;

							console.log(
								`EA Play price conversion for edition ${edition.id}:`,
								{
									original: edition.original_eaplay_price,
									exchangeRate,
									eaPlayMultiplier,
									final: edition.ea_play_price,
									discount:
										Math.round(
											((originalPrice - eaPlayPrice) /
												originalPrice) *
												100
										) + '%',
								}
							);
						} else {
							console.log(
								`Invalid EA Play price for edition ${edition.id}, clearing EA Play price`
							);
							edition.ea_play_price = null;
						}
					}
				}
				return edition;
			});

			// Выводим итоговую структуру изданий с ценами
			console.log(
				'Final editions structure:',
				productJson.editions.map(edition => ({
					id: edition.id,
					name: edition.editionName?.name,
					price: edition.price,
					convertedPrice: edition.convertedPrice,
					discount_amount: edition.discount_amount,
					original_price: edition.original_price,
					is_discount_valid:
						edition.price &&
						edition.discount_amount &&
						parseFloat(edition.price) >
							parseFloat(edition.discount_amount),
				}))
			);
		}

		// Фильтруем по цене после конвертации для дополнительной проверки
		const beforeFilter = productJson.editions
			? productJson.editions.length
			: 0;

		// Проверяем, что параметры фильтрации цены переданы и имеют значения
		const hasPriceFromFilter =
			priceFrom !== undefined && priceFrom !== null && priceFrom !== '';
		const hasPriceToFilter =
			priceTo !== undefined && priceTo !== null && priceTo !== '';

		if (hasPriceFromFilter || hasPriceToFilter) {
			// Преобразуем значения в числа, если они определены
			const numericPriceFrom = hasPriceFromFilter
				? parseFloat(priceFrom)
				: undefined;
			const numericPriceTo = hasPriceToFilter
				? parseFloat(priceTo)
				: undefined;

			// Проверяем, что значения валидные числа
			const validPriceFrom =
				numericPriceFrom !== undefined && !isNaN(numericPriceFrom);
			const validPriceTo =
				numericPriceTo !== undefined && !isNaN(numericPriceTo);

			console.log('Валидация цены:', {
				numericPriceFrom,
				numericPriceTo,
				validPriceFrom,
				validPriceTo,
			});

			// Для корректной работы с ценами со скидкой используем сложные условия
			const priceConditions = [];

			if (validPriceFrom) {
				priceConditions.push(edition => {
					const price =
						edition.discount_amount !== null
							? edition.discount_amount
							: edition.convertedPrice;
					return price >= numericPriceFrom;
				});
			}

			if (validPriceTo) {
				priceConditions.push(edition => {
					const price =
						edition.discount_amount !== null
							? edition.discount_amount
							: edition.convertedPrice;
					return price <= numericPriceTo;
				});
			}

			productJson.editions = productJson.editions.filter(edition =>
				priceConditions.every(condition => condition(edition))
			);

			const afterFilter = productJson.editions
				? productJson.editions.length
				: 0;
			if (beforeFilter !== afterFilter) {
				console.log(
					`Вторичная фильтрация изменила количество изданий для продукта ${productJson.id}: ${beforeFilter} -> ${afterFilter}`
				);
			}
		}

		res.json({ data: productJson });
	} catch (error) {
		console.error('Error fetching product:', error);
		res.status(500).json({ error: error.message });
	}
});

export default router;
