import express from 'express';
import Settings from '../models/settings.js';

const router = express.Router();

// GET / - Получить настройки
router.get('/', async (req, res) => {
    try {
        const settings = await Settings.findOne();
        if (settings) {
            res.json(settings);
        } else {
            // Если настройки не найдены, создаем дефолтные
            const defaultSettings = await Settings.create({
                welcomeMessage: 'Добро пожаловать! Нажмите кнопку ниже, чтобы открыть мини-приложение.',
            });
            res.json(defaultSettings);
        }
    } catch (error) {
        console.error('Error fetching settings:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// PUT / - Обновить настройки
router.put('/', async (req, res) => {
    try {
        let settings = await Settings.findOne();
        if (settings) {
            settings = await settings.update(req.body);
        } else {
            settings = await Settings.create(req.body);
        }
        res.json(settings);
    } catch (error) {
        console.error('Error updating settings:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// GET /maintenance-status - Получить статус режима техработ
router.get('/maintenance-status', async (req, res) => {
    try {
        const settings = await Settings.findOne();

        if (!settings) {
            return res.json({
                maintenanceMode: false,
                maintenanceMessage: '',
            });
        }

        res.json({
            maintenanceMode: settings.maintenanceMode,
            maintenanceMessage: settings.maintenanceMessage,
        });
    } catch (error) {
        console.error('Error fetching maintenance status:', error);
        res.status(500).json({
            error: 'Failed to fetch maintenance status',
        });
    }
});

export default router;
