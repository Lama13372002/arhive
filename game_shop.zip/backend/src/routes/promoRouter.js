// backend/src/routes/promoRouter.js
import { Router } from 'express';
import db from '../models/index.js';

const router = Router();

// GET / - Получить все активные промокоды
router.get('/', async (req, res) => {
	try {
		const promos = await db.Promo.findAll({
			where: { isActive: true },
			attributes: ['id', 'name', 'discount'],
			order: [['name', 'ASC']],
		});
		res.json(promos);
	} catch (error) {
		console.error('Error fetching promos:', error);
		res.status(500).json({ error: 'Internal server error' });
	}
});

// GET /:name - Проверить промокод по названию
router.get('/:name', async (req, res) => {
	try {
		// Получаем userId из Telegram WebApp
		const userId = req.headers['x-telegram-user-id'];

		if (!userId) {
			return res.status(401).json({
				error: 'Unauthorized: User ID not provided',
			});
		}

		const promo = await db.Promo.findOne({
			where: {
				name: req.params.name,
				isActive: true,
			},
		});

		if (!promo) {
			return res.status(404).json({
				error: 'Промокод не найден или неактивен',
			});
		}

		// Проверяем, использовал ли пользователь этот промокод
		const usedPromo = await db.UsedPromo.findOne({
			where: {
				userId: userId,
				promoId: promo.id,
			},
		});

		if (usedPromo) {
			return res.status(400).json({
				error: 'Вы уже использовали этот промокод',
			});
		}

		// Если промокод не использован, создаем запись
		await db.UsedPromo.create({
			userId: userId,
			promoId: promo.id,
		});

		res.json({
			id: promo.id,
			name: promo.name,
			discount: promo.discount,
		});
	} catch (error) {
		console.error('Error checking promo:', error);
		res.status(500).json({ error: 'Internal server error' });
	}
});

export default router;
