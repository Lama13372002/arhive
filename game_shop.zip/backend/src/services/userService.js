import User from '../models/user.js';

export const getUserByTelegramId = async (telegramId) => {
  try {
    console.log('Searching for user with telegramId:', telegramId);
    const user = await User.findOne({ 
      where: { telegramId } 
    });
    console.log('Found user:', user);
    return user;
  } catch (error) {
    console.error('Error in getUserByTelegramId:', error);
    throw error;
  }
};

export const updateUser = async (telegramId, updateData) => {
  try {
    console.log('Updating user with telegramId:', telegramId);
    console.log('Update data:', updateData);
    
    const [count, updatedUsers] = await User.update(updateData, {
      where: { telegramId },
      returning: true
    });

    if (count === 0) {
      console.log('No user found to update');
      return null;
    }

    // Получаем обновленного пользователя
    const updatedUser = await User.findOne({
      where: { telegramId }
    });
    
    console.log('Updated user:', updatedUser);
    return updatedUser;
  } catch (error) {
    console.error('Error in updateUser:', error);
    throw error;
  }
};

export const createUser = async (userData) => {
  try {
    console.log('Creating new user:', userData);
    const user = await User.create(userData);
    console.log('Created user:', user);
    return user;
  } catch (error) {
    console.error('Error in createUser:', error);
    throw error;
  }
};
