'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.addColumn('Payments', 'currency', {
      type: Sequelize.JSON,
      allowNull: true,
      comment: 'Информация о валюте платежа'
    });
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.removeColumn('Payments', 'currency');
  }
};
