'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
	async up(queryInterface, Sequelize) {
		const transaction = await queryInterface.sequelize.transaction();
		try {
			// Проверяем, существуют ли уже колонки
			const tableInfo = await queryInterface.describeTable('Payments', {
				transaction,
			});

			// Добавляем колонки, только если они не существуют
			const columnsToAdd = [];

			if (!tableInfo.psPassword) {
				columnsToAdd.push(
					queryInterface.addColumn(
						'Payments',
						'psPassword',
						{
							type: Sequelize.STRING,
							allowNull: true,
						},
						{ transaction }
					)
				);
			}

			if (!tableInfo.psBackupCodes) {
				columnsToAdd.push(
					queryInterface.addColumn(
						'Payments',
						'psBackupCodes',
						{
							type: Sequelize.STRING,
							allowNull: true,
						},
						{ transaction }
					)
				);
			}

			if (!tableInfo.firstName) {
				columnsToAdd.push(
					queryInterface.addColumn(
						'Payments',
						'firstName',
						{
							type: Sequelize.STRING,
							allowNull: true,
						},
						{ transaction }
					)
				);
			}

			if (!tableInfo.lastName) {
				columnsToAdd.push(
					queryInterface.addColumn(
						'Payments',
						'lastName',
						{
							type: Sequelize.STRING,
							allowNull: true,
						},
						{ transaction }
					)
				);
			}

			if (!tableInfo.customerEmail) {
				columnsToAdd.push(
					queryInterface.addColumn(
						'Payments',
						'customerEmail',
						{
							type: Sequelize.STRING,
							allowNull: true,
						},
						{ transaction }
					)
				);
			}

			if (!tableInfo.birthDate) {
				columnsToAdd.push(
					queryInterface.addColumn(
						'Payments',
						'birthDate',
						{
							type: Sequelize.STRING,
							allowNull: true,
						},
						{ transaction }
					)
				);
			}

			if (!tableInfo.checkoutWithoutAccount) {
				columnsToAdd.push(
					queryInterface.addColumn(
						'Payments',
						'checkoutWithoutAccount',
						{
							type: Sequelize.BOOLEAN,
							allowNull: true,
							defaultValue: false,
							comment:
								'Флаг оформления заказа без аккаунта PS Store',
						},
						{ transaction }
					)
				);
			}

			// Выполняем все операции добавления колонок
			if (columnsToAdd.length > 0) {
				await Promise.all(columnsToAdd);
			}

			await transaction.commit();
			console.log('Migration completed successfully');
		} catch (error) {
			await transaction.rollback();
			console.error('Migration failed:', error);
			throw error;
		}
	},

	async down(queryInterface, Sequelize) {
		const transaction = await queryInterface.sequelize.transaction();
		try {
			// Удаляем добавленные колонки
			await Promise.all([
				queryInterface.removeColumn('Payments', 'psPassword', {
					transaction,
				}),
				queryInterface.removeColumn('Payments', 'psBackupCodes', {
					transaction,
				}),
				queryInterface.removeColumn('Payments', 'firstName', {
					transaction,
				}),
				queryInterface.removeColumn('Payments', 'lastName', {
					transaction,
				}),
				queryInterface.removeColumn('Payments', 'customerEmail', {
					transaction,
				}),
				queryInterface.removeColumn('Payments', 'birthDate', {
					transaction,
				}),
				queryInterface.removeColumn(
					'Payments',
					'checkoutWithoutAccount',
					{ transaction }
				),
			]);

			await transaction.commit();
		} catch (error) {
			await transaction.rollback();
			throw error;
		}
	},
};
