import User from '../../models/user.js';
import { beforeCreateHook, beforeUpdateHook } from '../hooks.js';

export const userResource = {
    resource: User,
    options: {
        id: 'Users',
        navigation: {
            name: 'Пользователи',
            icon: 'User',
        },
        properties: {
            telegramId: {
                isTitle: true,
                label: 'Telegram ID',
            },
            telegramUsername: {
                label: 'Имя пользователя Telegram',
            },
            psStoreLogin: {
                label: 'Email PS Store',
                isVisible: {
                    list: false,
                    filter: true,
                    show: true,
                    edit: true,
                },
            },
            psStorePassword: {
                label: 'Пароль PS Store',
                isVisible: {
                    list: false,
                    filter: false,
                    show: false,
                    edit: true,
                },
                type: 'password',
            },
            psBackupCodes: {
                label: 'Резервные коды PS Store',
                isVisible: {
                    list: false,
                    filter: false,
                    show: true,
                    edit: true,
                },
            },
            email: {
                label: 'Email для чека',
            },
            currencyId: {
                label: 'Валюта',
                type: 'reference',
                reference: 'Currencies',
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: true,
                },
            },
            'Currency.code': {
                label: 'Код валюты',
                isVisible: {
                    list: true,
                    filter: false,
                    show: true,
                    edit: false,
                },
            },
            'Currency.symbol': {
                label: 'Символ валюты',
                isVisible: {
                    list: true,
                    filter: false,
                    show: true,
                    edit: false,
                },
            },
            createdAt: {
                label: 'Дата регистрации',
                type: 'datetime',
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: false,
                },
            },
            updatedAt: {
                label: 'Дата обновления',
                type: 'datetime',
                isVisible: {
                    list: false,
                    filter: true,
                    show: true,
                    edit: false,
                },
            },
        },
        actions: {
            new: {
                before: [beforeCreateHook],
            },
            edit: {
                before: [beforeUpdateHook],
            },
        },
        listProperties: [
            'telegramId',
            'telegramUsername',
            'email',
            'currencyId',
            'Currency.code',
            'Currency.symbol',
            'createdAt',
        ],
        filterProperties: [
            'telegramId',
            'telegramUsername',
            'email',
            'currencyId',
            'createdAt',
        ],
        editProperties: [
            'telegramId',
            'telegramUsername',
            'psStoreLogin',
            'psStorePassword',
            'psBackupCodes',
            'email',
            'currencyId',
        ],
        showProperties: [
            'telegramId',
            'telegramUsername',
            'psStoreLogin',
            'psBackupCodes',
            'email',
            'currencyId',
            'Currency.code',
            'Currency.symbol',
            'createdAt',
            'updatedAt',
        ],
        sort: {
            sortBy: 'createdAt',
            direction: 'desc',
        },
    },
};
