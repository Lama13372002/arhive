import CurrencyRange from '../../models/currencyRange.js';
import { Op } from 'sequelize';

export const currencyRangeResource = {
  resource: CurrencyRange,
  options: {
    navigation: {
      name: 'Диапазоны валют',
      icon: 'Price',
    },
    properties: {
      id: {
        position: 1,
      },
      currencyId: {
        position: 2,
        reference: 'Currencies',
        isRequired: true,
      },
      amountFrom: {
        position: 3,
        type: 'float',
        isRequired: true,
        props: {
          step: '0.00000001',
          precision: 8
        },
        description: 'Начальная сумма диапазона в рублях (поддерживаются дробные числа)'
      },
      amountTo: {
        position: 4,
        type: 'float',
        isRequired: true,
        props: {
          step: '0.00000001',
          precision: 8
        },
        description: 'Конечная сумма диапазона в рублях (поддерживаются дробные числа)'
      },
      rate_multiplier: {
        position: 5,
        type: 'number',
        isRequired: true,
        description: 'Множитель базового курса валюты (например, 1.1 для увеличения на 10%)'
      },
      createdAt: {
        position: 6,
        isVisible: { list: true, filter: true, show: true, edit: false },
      },
      updatedAt: {
        position: 7,
        isVisible: { list: true, filter: true, show: true, edit: false },
      },
    },
    actions: {
      new: {
        isAccessible: true,
        before: async (request) => {
          // Проверяем, нет ли пересечения диапазонов для той же валюты
          const existingRanges = await CurrencyRange.findAll({
            where: { currencyId: request.payload.currencyId }
          });

          const newFrom = Number(request.payload.amountFrom);
          const newTo = Number(request.payload.amountTo);

          for (const range of existingRanges) {
            if (
              (newFrom >= range.amountFrom && newFrom <= range.amountTo) ||
              (newTo >= range.amountFrom && newTo <= range.amountTo) ||
              (newFrom <= range.amountFrom && newTo >= range.amountTo)
            ) {
              throw new Error('Диапазон пересекается с существующим диапазоном для этой валюты');
            }
          }

          return request;
        }
      },
      edit: {
        isAccessible: true,
        before: async (request, context) => {
          const currentId = context.record.param('id');
          const existingRanges = await CurrencyRange.findAll({
            where: { 
              currencyId: request.payload.currencyId,
              id: { [Op.ne]: currentId }
            }
          });

          const newFrom = Number(request.payload.amountFrom);
          const newTo = Number(request.payload.amountTo);

          for (const range of existingRanges) {
            if (
              (newFrom >= range.amountFrom && newFrom <= range.amountTo) ||
              (newTo >= range.amountFrom && newTo <= range.amountTo) ||
              (newFrom <= range.amountFrom && newTo >= range.amountTo)
            ) {
              throw new Error('Диапазон пересекается с существующим диапазоном для этой валюты');
            }
          }

          return request;
        }
      },
      delete: {
        isAccessible: true,
      },
    },
  },
};
