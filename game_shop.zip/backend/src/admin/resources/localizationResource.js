import Localization from '../../models/localization.js';
import { uploadFile } from '../../utils/uploadFile.js';
import { createBaseResource } from './baseResource.js';

const baseResource = createBaseResource(Localization);

export const localizationResource = {
	...baseResource,
	options: {
		...baseResource.options,
		navigation: {
			name: 'Локализации',
			icon: 'Globe',
		},
		properties: {
			id: {
				position: 1,
			},
			name: {
				position: 2,
				isTitle: true,
				isRequired: true,
			},
			image_url: {
				position: 3,
				isRequired: false,
				components: {
					edit: 'ImageUpload',
					show: 'ImagePreview',
					list: 'ImagePreview',
				},
				isVisible: {
					list: true,
					filter: false,
					show: true,
					edit: true,
				},
			},
			created_at: {
				position: 4,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
			},
			updated_at: {
				position: 5,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
			},
		},
		actions: {
			...baseResource.options.actions,
			new: {
				...baseResource.options.actions.new,
				before: async request => {
					const { payload } = request;

					console.log('New localization payload:', payload);

					// Validate required fields
					if (!payload.name) {
						throw new Error('Название локализации обязательно');
					}

					// Handle file upload
					if (payload['image_url.file']) {
						try {
							const fileData = {
								name: payload['image_url.name'],
								size: payload['image_url.size'],
								type: payload['image_url.mime'],
								file: payload['image_url.file'],
							};
							console.log('Trying to upload file:', fileData);
							const uploadPath = await uploadFile(
								fileData,
								'localizations'
							);

							delete payload['image_url.name'];
							delete payload['image_url.size'];
							delete payload['image_url.mime'];
							delete payload['image_url.file'];
							payload.image_url = uploadPath;
						} catch (error) {
							console.error('Error uploading file:', error);
							throw new Error('Ошибка при загрузке файла');
						}
					}

					return request;
				},
			},
			edit: {
				...baseResource.options.actions.edit,
				before: async request => {
					const { payload } = request;

					console.log('Edit localization payload:', payload);

					if (!payload.name) {
						throw new Error('Название локализации обязательно');
					}

					// Handle file upload
					if (payload['image_url.file']) {
						// Если это новый файл
						if (payload['image_url.path']) {
							try {
								const fileData = {
									name: payload['image_url.name'],
									size: payload['image_url.size'],
									type: payload['image_url.mime'],
									file: payload['image_url.file'],
								};
								console.log('Trying to upload file:', fileData);
								const uploadPath = await uploadFile(
									fileData,
									'localizations'
								);

								delete payload['image_url.name'];
								delete payload['image_url.size'];
								delete payload['image_url.mime'];
								delete payload['image_url.file'];
								payload.image_url = uploadPath;
							} catch (error) {
								console.error('Error uploading file:', error);
								throw new Error('Ошибка при загрузке файла');
							}
						}
						// Если это строка с URL, оставляем как есть
						else if (typeof payload['image_url'] === 'string') {
							payload.image_url = payload['image_url'];
						}
						// Если что-то другое, очищаем
						else {
							payload.image_url = null;
						}
					}

					return request;
				},
			},
		},
	},
};
