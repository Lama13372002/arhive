import sequelize from '../../config/database.js';
import Edition from '../../models/edition.js';
import ProductCollection from '../../models/productCollection.js';
import ImageShow from '../components/ImageShow.jsx';
import { beforeCreateHook, beforeUpdateHook } from '../hooks.js';

const debugLog = (message, data) => {
	console.log(`[ProductCollection Resource] ${message}`, data || '');
};

const handleEditions = async (response, request, context) => {
	try {
		const { record } = context;

		// Собираем все editions.* поля в массив
		const editions = Object.entries(record.params)
			.filter(([key]) => key.startsWith('editions.'))
			.map(([_, value]) => parseInt(value))
			.filter(id => !isNaN(id));

		debugLog('HandleEditions started with editions:', editions);
		debugLog('Record params:', record.params);

		if (!editions.length) {
			debugLog('No editions provided, returning early');
			return response;
		}

		// Для новых коллекций ID еще не существует
		const collection = record.params.id 
			? await ProductCollection.findByPk(record.params.id)
			: response.record.resource;

		if (!collection) {
			debugLog('Collection not found:', record.params.id);
			throw new Error(`Collection not found`);
		}

		debugLog('Processed edition IDs:', editions);

		// Используем транзакцию для атомарной операции
		await sequelize.transaction(async t => {
			debugLog('Starting transaction to set editions');
			await collection.setEditions(editions, { transaction: t });
			debugLog('Editions set successfully');
		});

		// Проверяем результат
		const updatedCollection = await ProductCollection.findByPk(
			record.params.id,
			{
				include: [
					{
						model: Edition,
						as: 'editions',
						through: { attributes: [] },
					},
				],
			}
		);

		// Обновляем не только ID, но и полную информацию об изданиях
		response.record.params.editions = updatedCollection.editions;
		
		debugLog(
			'Updated collection editions:',
			updatedCollection.editions.map(e => e.id)
		);

		return response;
	} catch (error) {
		debugLog('Error in handleEditions:', error);
		console.error('Error in handleEditions:', error);
		throw error;
	}
};

export const productCollectionResource = {
	resource: ProductCollection,
	options: {
		navigation: {
			name: 'Коллекции',
			icon: 'Catalog',
		},
		properties: {
			id: {
				position: 1,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
			},
			name: {
				position: 2,
				isTitle: true,
				isRequired: true,
			},
			description: {
				position: 3,
				type: 'textarea',
			},
			editions: {
				position: 4,
				type: 'reference',
				reference: 'Editions',
				isArray: true,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: true,
				},
				description: 'Издания в коллекции',
				properties: {
					name: 'name',
					value: 'id',
				},
			},
			image_url: {
				position: 5,
				components: {
					show: ImageShow,
				},
			},
			is_active: {
				position: 6,
				type: 'boolean',
			},
			created_at: {
				position: 7,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
			},
			updated_at: {
				position: 8,
				isVisible: {
					list: false,
					filter: false,
					show: true,
					edit: false,
				},
			},
		},
		actions: {
			new: {
				before: [beforeCreateHook],
				after: handleEditions,
			},
			edit: {
				before: async (request, context) => {
					try {
						if (request.method === 'get') {
							const collectionId = context.record.params.id;
							const collection = await ProductCollection.findByPk(
								collectionId,
								{
									include: [
										{
											model: Edition,
											as: 'editions',
											through: { attributes: [] },
										},
									],
								}
							);

							if (collection && collection.editions) {
								// Устанавливаем только ID изданий
								context.record.params.editions =
									collection.editions.map(
										edition => edition.id
									);
								debugLog(
									'Loaded edition IDs:',
									context.record.params.editions
								);
							}
						}
						return beforeUpdateHook(request, context);
					} catch (error) {
						console.error('Error in edit.before hook:', error);
						throw error;
					}
				},
				after: handleEditions,
			},
			list: {
				before: async (request, context) => {
					context.query = {
						...context.query,
						include: ['editions'],
					};
					return request;
				},
				after: async (response, request, context) => {
					return response;
				},
			},
			show: {
				before: async (request, context) => {
					context.query = {
						...context.query,
						include: ['editions'],
					};
					return request;
				},
				after: async (response, request, context) => {
					return response;
				},
			},
		},
		listProperties: ['id', 'name', 'image_url', 'is_active', 'created_at'],
		filterProperties: ['name', 'is_active', 'editions', 'created_at'],
		editProperties: [
			'name',
			'description',
			'editions',
			'image_url',
			'is_active',
		],
		showProperties: [
			'id',
			'name',
			'description',
			'editions',
			'image_url',
			'is_active',
			'created_at',
			'updated_at',
		],
	},
};
