import sequelize from '../../config/database.js';
import ProductCard from '../../models/productCard.js';
import ProductCardGenre from '../../models/productCardGenre.js';
import { uploadFile } from '../../utils/uploadFile.js';
import { createBaseResource } from './baseResource.js';

const baseResource = createBaseResource(ProductCard);

const handleGenres = async (response, request, context) => {
	try {
		const { record } = context;
		let genreIds = [];

		console.log('Весь объект record:', JSON.stringify(record, null, 2));

		// Проверяем, есть ли genres как массив
		if (record.params.genres && Array.isArray(record.params.genres)) {
			genreIds = record.params.genres;
			console.log('Найден массив genres:', genreIds);
		} else {
			// Пробуем найти в формате genres.X
			for (const key in record.params) {
				if (key.startsWith('genres.')) {
					genreIds.push(record.params[key]);
				}
			}
			console.log('Собраны жанры из genres.X:', genreIds);
		}

		// Проверяем, есть ли genres как строка (может быть в формате JSON)
		if (typeof record.params.genres === 'string') {
			try {
				const parsedGenres = JSON.parse(record.params.genres);
				if (Array.isArray(parsedGenres)) {
					genreIds = parsedGenres;
					console.log('Распарсены жанры из строки JSON:', genreIds);
				}
			} catch (e) {
				console.log(
					'Не удалось распарсить genres как JSON:',
					e.message
				);
			}
		}

		console.log('Итоговый список ID жанров для добавления:', genreIds);

		const productCard = await ProductCard.findByPk(record.params.id);
		if (productCard) {
			// Преобразуем строки в числа, если необходимо
			const numericGenreIds = genreIds
				.map(id => (typeof id === 'string' ? parseInt(id, 10) : id))
				.filter(id => !isNaN(id));

			console.log('Преобразованные ID жанров:', numericGenreIds);

			// Используем транзакцию для гарантии атомарности операции
			await sequelize.transaction(async t => {
				// Сначала удаляем старые связи
				await ProductCardGenre.destroy({
					where: {
						product_card_id: record.params.id,
					},
					transaction: t,
				});

				// Затем создаем новые связи
				if (numericGenreIds.length > 0) {
					const genresToAdd = numericGenreIds.map(genreId => ({
						product_card_id: record.params.id,
						genre_id: genreId,
					}));

					await ProductCardGenre.bulkCreate(genresToAdd, {
						transaction: t,
						ignoreDuplicates: true,
					});
				}
			});

			console.log(
				numericGenreIds.length > 0
					? 'Жанры успешно установлены через прямое добавление в таблицу ProductCardGenre:'
					: 'Жанры очищены',
				numericGenreIds
			);
		} else {
			console.warn('ProductCard не найден для ID:', record.params.id);
		}

		return response;
	} catch (error) {
		console.error('Ошибка в handleGenres:', error);
		// Не пробрасываем ошибку дальше, но логируем для отладки
		return response;
	}
};

export const productCardResource = {
	...baseResource,
	options: {
		...baseResource.options,
		navigation: {
			name: 'Игры',
			icon: 'Game',
		},
		properties: {
			id: {
				position: 1,
			},
			name: {
				position: 2,
				isTitle: true,
				isRequired: true,
			},
			image_url: {
				position: 3,
				isRequired: false,
				components: {
					edit: 'ImageUpload',
					show: 'ImagePreview',
					list: 'ImagePreview',
				},
				isVisible: {
					list: true,
					filter: false,
					show: true,
					edit: true,
				},
			},
			rating: {
				position: 4,
				type: 'float',
			},
			edition_type: {
				position: 5,
				type: 'string',
				isRequired: true,
			},
			genres: {
				position: 6,
				type: 'reference',
				reference: 'Genres',
				isArray: true,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: true,
				},
				description: 'Выберите жанры для игры',
			},
			tags: {
				position: 8,
				type: 'array',
				isArray: true,
				subType: 'string',
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: true,
				},
				description: 'Добавьте теги для игры',
			},
			free_with_ea_play: {
				position: 9,
				type: 'boolean',
			},
			free_with_ps_plus_essential: {
				position: 10,
				type: 'boolean',
				description: 'Доступно с подпиской PS Plus Essential',
			},
			free_with_ps_plus_extra: {
				position: 11,
				type: 'boolean',
				description: 'Доступно с подпиской PS Plus Extra',
			},
			free_with_ps_plus_deluxe: {
				position: 12,
				type: 'boolean',
				description: 'Доступно с подпиской PS Plus Deluxe',
			},
			created_at: {
				position: 13,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
			},
			updated_at: {
				position: 14,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
			},
			source: {
				position: 15,
				type: 'string',
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
				description: 'Источник добавления: parser или manual',
			},
		},
		actions: {
			new: {
				after: [handleGenres],
				before: async request => {
					const { payload } = request;

					console.log(
						'New product card payload:',
						JSON.stringify(payload, null, 2)
					);

					// Устанавливаем source='manual' для записей, создаваемых через админку
					payload.source = 'manual';

					// Проверяем жанры в payload
					if (payload.genres) {
						console.log('Жанры в new.before:', payload.genres);
						if (typeof payload.genres === 'string') {
							try {
								console.log(
									'Попытка распарсить жанры из строки:',
									payload.genres
								);
								const parsedGenres = JSON.parse(payload.genres);
								console.log(
									'Распарсенные жанры:',
									parsedGenres
								);
							} catch (e) {
								console.log(
									'Ошибка парсинга жанров:',
									e.message
								);
							}
						}
					}

					if (payload['image_url.file']) {
						try {
							const fileData = {
								name: payload['image_url.name'],
								size: payload['image_url.size'],
								type: payload['image_url.mime'],
								file: payload['image_url.file'],
							};
							console.log('Trying to upload file:', fileData);
							const uploadPath = await uploadFile(
								fileData,
								'products'
							);

							delete payload['image_url.name'];
							delete payload['image_url.size'];
							delete payload['image_url.mime'];
							delete payload['image_url.file'];
							payload.image_url = uploadPath;
						} catch (error) {
							console.error('Error uploading file:', error);
							throw new Error('Ошибка при загрузке файла');
						}
					}

					return request;
				},
			},
			edit: {
				after: [handleGenres],
				before: async request => {
					try {
						console.log(
							'Edit product card - payload:',
							JSON.stringify(request.payload, null, 2)
						);
						console.log(
							'Edit product card - params:',
							JSON.stringify(request.params, null, 2)
						);

						// Проверяем жанры в payload при редактировании
						if (request.payload.genres) {
							console.log(
								'Жанры при редактировании:',
								request.payload.genres
							);
							if (typeof request.payload.genres === 'string') {
								try {
									console.log(
										'Попытка распарсить жанры из строки при редактировании:',
										request.payload.genres
									);
									const parsedGenres = JSON.parse(
										request.payload.genres
									);
									console.log(
										'Распарсенные жанры при редактировании:',
										parsedGenres
									);
								} catch (e) {
									console.log(
										'Ошибка парсинга жанров при редактировании:',
										e.message
									);
								}
							}
						}

						// Проверяем, что edition_type присутствует в payload
						if (
							request.payload &&
							typeof request.payload.edition_type !== 'undefined'
						) {
							console.log(
								'Edition type in payload:',
								request.payload.edition_type
							);
						} else {
							console.log('Edition type not found in payload');
						}

						// Обработка загрузки изображения при редактировании
						if (request.payload['image_url.file']) {
							try {
								const fileData = {
									name: request.payload['image_url.name'],
									size: request.payload['image_url.size'],
									type: request.payload['image_url.mime'],
									file: request.payload['image_url.file'],
								};
								console.log('Trying to upload file during edit:', fileData);
								const uploadPath = await uploadFile(
									fileData,
									'products'
								);

								delete request.payload['image_url.name'];
								delete request.payload['image_url.size'];
								delete request.payload['image_url.mime'];
								delete request.payload['image_url.file'];
								request.payload.image_url = uploadPath;
								console.log('File uploaded successfully during edit, new path:', uploadPath);
							} catch (error) {
								console.error('Error uploading file during edit:', error);
								throw new Error('Ошибка при загрузке файла');
							}
						} else {
							console.log('No new image file detected during edit');
						}

						return request;
					} catch (error) {
						console.error('Error in edit before handler:', error);
						// Продолжаем выполнение, чтобы не блокировать редактирование
						return request;
					}
				},
			},
		},
	},
};
