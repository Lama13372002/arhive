import Payment from '../../models/Payment.js';
import { createBaseResource } from './baseResource.js';

const baseResource = createBaseResource(Payment);

export const paymentResource = {
	...baseResource,
	options: {
		...baseResource.options,
		navigation: {
			name: 'Финансы',
			icon: 'Currency',
		},
		properties: {
			id: {
				position: 1,
				isTitle: true,
			},
			orderId: {
				position: 2,
				isTitle: false,
			},
			lifepayNumber: {
				position: 3,
			},
			telegramUsername: {
				position: 4,
			},
			amount: {
				position: 5,
				type: 'number',
			},
			status: {
				position: 6,
				availableValues: [
					{ value: 'pending', label: 'Ожидает оплаты' },
					{ value: 'paid', label: 'Оплачен' },
					{ value: 'failed', label: 'Ошибка' },
					{ value: 'processing', label: 'Обрабатывается' },
					{ value: 'completed', label: 'Завершён' },
				],
			},
			lifepayStatus: {
				position: 7,
			},
			psLogin: {
				position: 8,
			},
			email: {
				position: 9,
			},
			gameInfo: {
				position: 10,
				type: 'mixed',
				isVisible: {
					list: false,
					edit: true,
					filter: false,
					show: true,
				},
			},
			paymentSystem: {
				position: 11,
			},
			createdAt: {
				position: 12,
				isVisible: {
					list: true,
					edit: false,
					filter: true,
					show: true,
				},
			},
			updatedAt: {
				position: 13,
				isVisible: {
					list: false,
					edit: false,
					filter: true,
					show: true,
				},
			},
		},
		actions: {
			edit: {
				isAccessible: false,
			},
			delete: {
				isAccessible: false,
			},
			new: {
				isAccessible: false,
			},
		},
		sort: {
			sortBy: 'createdAt',
			direction: 'desc',
		},
		filterProperties: [
			'status',
			'telegramUsername',
			'orderId',
			'lifepayNumber',
			'createdAt',
			'amount',
		],
	},
};
