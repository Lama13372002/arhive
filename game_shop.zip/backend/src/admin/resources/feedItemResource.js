// backend/src/admin/resources/feedItemResource.js
import FeedItem from '../../models/feedItem.js';
import ProductCollection from '../../models/productCollection.js';

export const feedItemResource = {
	resource: FeedItem,
	options: {
		navigation: {
			name: 'Лента товаров',
			icon: 'List',
		},
		properties: {
			id: {
				position: 0,
				isTitle: true,
			},
			type: {
				position: 1,
				type: 'enum',
				availableValues: [
					{ value: 'banner', label: 'Banner' },
					{ value: 'list', label: 'List' },
				],
			},
			collections: {
				position: 2,
				type: 'reference',
				reference: 'ProductCollections',
				isArray: true,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: true,
				},
			},
			position: {
				position: 3,
			},
			title: {
				position: 4,
			},
		},
		listProperties: ['id', 'type', 'position', 'title', 'collections'],
		filterProperties: ['id', 'type', 'position', 'title', 'collections'],
		editProperties: ['type', 'position', 'title', 'collections'],
		showProperties: ['id', 'type', 'position', 'title', 'collections'],
		actions: {
			new: {
				before: async request => {
					console.log('Before new FeedItem:', request.payload);
					const { collections } = request.payload;
					if (collections && collections.length > 0) {
						const collection = await ProductCollection.findByPk(collections[0]);
						if (collection) {
							request.payload.title = collection.name;
						}
					}
					return request;
				},
				after: async (response, request) => {
					console.log('After new FeedItem - Request:', request.payload);
					console.log('After new FeedItem - Response:', response);

					// Собираем ID коллекций из объекта
					const collectionIds = Object.keys(request.payload)
						.filter(key => key.startsWith('collections.'))
						.map(key => request.payload[key]);

					if (collectionIds.length > 0) {
						console.log('Setting collections:', collectionIds);
						const feedItem = await FeedItem.findByPk(response.record.id);
						console.log('Found feedItem:', feedItem);
						if (feedItem) {
							try {
								await feedItem.setCollections(collectionIds);
								console.log('Collections set successfully');
							} catch (error) {
								console.error('Error setting collections:', error);
							}
						}
					}
					return response;
				}
			},
			edit: {
				before: async request => {
					console.log('Before edit FeedItem:', request.payload);
					const { collections } = request.payload;
					if (collections && collections.length > 0) {
						const collection = await ProductCollection.findByPk(collections[0]);
						if (collection) {
							request.payload.title = collection.name;
						}
					}
					return request;
				},
				after: async (response, request) => {
					console.log('After edit FeedItem - Request:', request.payload);
					console.log('After edit FeedItem - Response:', response);

					// Собираем ID коллекций из объекта
					const collectionIds = Object.keys(request.payload)
						.filter(key => key.startsWith('collections.'))
						.map(key => request.payload[key]);

					if (collectionIds.length > 0) {
						console.log('Setting collections:', collectionIds);
						const feedItem = await FeedItem.findByPk(response.record.id);
						console.log('Found feedItem:', feedItem);
						if (feedItem) {
							try {
								await feedItem.setCollections(collectionIds);
								console.log('Collections set successfully');
							} catch (error) {
								console.error('Error setting collections:', error);
							}
						}
					}
					return response;
				}
			},
			list: {
				before: async (request, context) => {
					if (!context.query) {
						context.query = {};
					}
					context.query.attributes = ['id', 'type', 'position', 'title', 'created_at', 'updated_at'];
					context.query.include = [{
						model: ProductCollection,
						as: 'collections',
						through: { attributes: [] },
					}];
					return request;
				},
			},
		},
	},
};
