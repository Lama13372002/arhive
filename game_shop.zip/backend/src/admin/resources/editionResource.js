import { Op } from 'sequelize';
import Edition from '../../models/edition.js';

// Функция для расчета процента скидки
const calculateDiscountPercentage = (price, discountAmount) => {
	if (!price || !discountAmount) return 0;
	// Если discount_amount - это цена со скидкой, то процент скидки рассчитывается иначе
	return Math.round(((price - discountAmount) / price) * 100);
};

const handleLocalizations = async (response, request, context) => {
	try {
		const { record } = context;

		const localizationIds = Object.entries(record.params)
			.filter(([key]) => key.startsWith('localizations.'))
			.map(([_, value]) => value)
			.filter(Boolean);

		console.log('handleLocalizations called with:', {
			recordId: record.params.id,
			recordParams: record.params,
			localizationIds,
		});

		if (localizationIds.length > 0) {
			const edition = await Edition.findByPk(record.params.id, {
				include: [
					{
						association: 'localizations',
						through: { attributes: [] },
					},
				],
			});

			if (edition) {
				console.log('Setting localizations:', {
					editionId: edition.id,
					localizationIds,
				});

				// Используем raw query для отладки
				const sequelize = Edition.sequelize;
				const [results] = await sequelize.query(
					`SELECT * FROM edition_localizations WHERE edition_id = ${edition.id}`
				);
				console.log('Current edition_localizations:', results);

				// Сначала удаляем все существующие связи
				await sequelize.query(
					`DELETE FROM edition_localizations WHERE edition_id = ${edition.id}`
				);

				// Добавляем новые связи с правильными полями
				for (const localizationId of localizationIds) {
					await sequelize.query(
						`INSERT INTO edition_localizations
						(edition_id, localization_id, "createdAt", "updatedAt")
						VALUES (${edition.id}, ${localizationId}, NOW(), NOW())`
					);
				}

				const updatedEdition = await Edition.findByPk(
					record.params.id,
					{
						include: [
							{
								association: 'localizations',
								through: { attributes: [] },
							},
						],
					}
				);

				console.log('Updated edition localizations:', {
					editionId: updatedEdition.id,
					localizations: updatedEdition.localizations,
				});
			} else {
				console.error('Edition not found:', record.params.id);
			}
		} else {
			console.log('No localizations provided in params:', record.params);
		}
		return response;
	} catch (error) {
		console.error('Error in handleLocalizations:', error);
		// Не пробрасываем ошибку дальше, а возвращаем оригинальный ответ
		// Это предотвратит отображение ошибки в AdminJS, но запись все равно будет создана
		return response;
	}
};

const handleCollections = async (response, request, context) => {
	try {
		const { record } = context;

		// Собираем все коллекции из параметров
		const collectionIds = Object.entries(record.params)
			.filter(([key]) => key.startsWith('collections.'))
			.map(([_, value]) => value)
			.filter(Boolean);

		console.log('handleCollections called with:', {
			recordId: record.params.id,
			recordParams: record.params,
			collectionIds,
		});

		if (collectionIds.length > 0) {
			const edition = await Edition.findByPk(record.params.id, {
				include: ['collections'],
			});

			if (edition) {
				console.log('Setting collections:', {
					editionId: edition.id,
					collectionIds,
				});

				await edition.setCollections(collectionIds);

				// Проверяем, что коллекции были установлены
				const updatedEdition = await Edition.findByPk(
					record.params.id,
					{
						include: ['collections'],
					}
				);

				console.log('Updated edition collections:', {
					editionId: updatedEdition.id,
					collections: updatedEdition.collections,
				});
			} else {
				console.error('Edition not found:', record.params.id);
			}
		} else {
			console.log('No collections provided in params:', record.params);
		}
		return response;
	} catch (error) {
		console.error('Error in handleCollections:', error);
		// Не пробрасываем ошибку дальше, а возвращаем оригинальный ответ
		// Это предотвратит отображение ошибки в AdminJS, но запись все равно будет создана
		return response;
	}
};

const handlePlatforms = async (response, request, context) => {
	try {
		const { record } = context;

		// Собираем все платформы из параметров
		const platformIds = Object.entries(record.params)
			.filter(([key]) => key.startsWith('platforms.'))
			.map(([_, value]) => value)
			.filter(Boolean);

		console.log('handlePlatforms called with:', {
			recordId: record.params.id,
			recordParams: record.params,
			platformIds,
		});

		if (platformIds.length > 0) {
			const edition = await Edition.findByPk(record.params.id, {
				include: ['platforms'],
			});

			if (edition) {
				console.log('Setting platforms:', {
					editionId: edition.id,
					platformIds,
				});

				await edition.setPlatforms(platformIds, {
					ignoreDuplicates: true,
				});

				// Проверяем, что платформы были установлены
				const updatedEdition = await Edition.findByPk(
					record.params.id,
					{
						include: ['platforms'],
					}
				);

				console.log('Updated edition platforms:', {
					editionId: updatedEdition.id,
					platforms: updatedEdition.platforms,
				});
			} else {
				console.error('Edition not found:', record.params.id);
			}
		} else {
			console.log('No platforms provided in params:', record.params);
		}
		return response;
	} catch (error) {
		console.error('Error in handlePlatforms:', error);
		// Не пробрасываем ошибку дальше, а возвращаем оригинальный ответ
		// Это предотвратит отображение ошибки в AdminJS, но запись все равно будет создана
		return response;
	}
};

export const editionResource = {
	resource: Edition,
	options: {
		navigation: {
			name: 'Издания',
			icon: 'Box',
		},
		properties: {
			id: {
				position: 1,
			},
			edition_name_id: {
				position: 2,
				isRequired: true,
				type: 'reference',
				reference: 'EditionNames',
			},
			description: {
				position: 3,
				type: 'textarea',
				isRequired: true,
				custom: {
					rows: 10,
					placeholder:
						'Введите описание издания...\nПример форматирования:\n\nПервый абзац\n\nВторой абзац\n\nТретий абзац',
				},
				description:
					'Используйте двойной Enter между абзацами для лучшей читаемости текста на странице игры.',
				isTitle: false,
			},
			product_card_id: {
				position: 4,
				isRequired: true,
				type: 'reference',
				reference: 'ProductCards',
			},
			price: {
				position: 5,
				type: 'number',
				isRequired: true,
			},
			platforms: {
				position: 6,
				type: 'reference',
				reference: 'Platforms',
				isArray: true,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: true,
				},
				description: 'Выберите платформы для издания',
			},
			localizations: {
				position: 7,
				type: 'reference',
				reference: 'Localizations',
				isArray: true,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: true,
				},
				description: 'Выберите локализации для издания',
			},
			display_currency_id: {
				position: 8,
				type: 'reference',
				reference: 'Currencies',
			},
			collections: {
				position: 9,
				type: 'reference',
				reference: 'ProductCollections',
				isArray: true,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: true,
				},
				description: 'Коллекции, в которых участвует издание',
			},
			discount_amount: {
				position: 10,
				type: 'number',
				description:
					'Цена со скидкой (финальная цена товара с учетом скидки)',
			},
			discount_percentage: {
				position: 11,
				type: 'number',
				isVisible: {
					list: false,
					filter: false,
					show: false,
					edit: true,
				},
				description:
					'Процент скидки (например, 20 для скидки в 20%). При заполнении автоматически рассчитает цену со скидкой.',
			},
			ea_play_price: {
				position: 12,
				type: 'number',
			},
			ps_plus_price: {
				position: 13,
				type: 'number',
			},
			promotion_end_date: {
				position: 14,
				type: 'datetime',
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: true,
				},
				description: 'Дата окончания акции',
			},
			created_at: {
				position: 15,
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
			},
			updated_at: {
				position: 16,
				isVisible: {
					list: false,
					filter: false,
					show: true,
					edit: false,
				},
			},
			source: {
				position: 17,
				type: 'string',
				isVisible: {
					list: true,
					filter: true,
					show: true,
					edit: false,
				},
				description: 'Источник добавления: parser или manual',
			},
			final_price: {
				position: 17,
				type: 'number',
				isVisible: {
					list: true,
					filter: false,
					show: true,
					edit: false,
				},
				description: 'Финальная цена с учетом скидки',
				isVirtual: true,
				components: {
					list: admin => {
						const { record } = admin;
						const price = parseFloat(record.params.price) || 0;
						const discountAmount =
							parseFloat(record.params.discount_amount) || 0;

						// Если есть discount_amount, возвращаем его, иначе возвращаем обычную цену
						return discountAmount > 0
							? discountAmount.toFixed(2)
							: price.toFixed(2);
					},
					show: admin => {
						const { record } = admin;
						const price = parseFloat(record.params.price) || 0;
						const discountAmount =
							parseFloat(record.params.discount_amount) || 0;

						// Если есть discount_amount, возвращаем его, иначе возвращаем обычную цену
						return discountAmount > 0
							? discountAmount.toFixed(2)
							: price.toFixed(2);
					},
				},
			},
		},
		actions: {
			new: {
				after: [
					handleLocalizations,
					handleCollections,
					handlePlatforms,
					async (response, request, context) => {
						// Если есть цена и цена со скидкой, рассчитываем процент скидки для отображения
						if (response.record && response.record.params) {
							const price = parseFloat(
								response.record.params.price
							);
							const discountAmount = parseFloat(
								response.record.params.discount_amount
							);

							if (
								!isNaN(price) &&
								!isNaN(discountAmount) &&
								price > 0 &&
								discountAmount > 0 &&
								discountAmount < price // Цена со скидкой должна быть меньше обычной цены
							) {
								// Рассчитываем процент скидки
								const discountPercentage = Math.round(
									((price - discountAmount) / price) * 100
								);
								response.record.params.discount_percentage =
									discountPercentage;

								console.log(
									'Рассчитан процент скидки для новой записи:',
									{
										originalPrice: price,
										discountedPrice: discountAmount,
										discountPercentage,
									}
								);
							}
						}

						return response;
					},
				],
				before: async (request, context) => {
					console.log('Edition new - payload:', request.payload);

					// Устанавливаем source='manual' для записей, создаваемых через админку
					request.payload.source = 'manual';

					// Проверяем и обрабатываем цену со скидкой
					if (request.payload.price !== undefined) {
						const price = parseFloat(request.payload.price);

						// Если указан процент скидки, рассчитываем цену со скидкой
						if (
							request.payload.discount_percentage !== undefined &&
							request.payload.discount_percentage !== ''
						) {
							const discountPercentage = parseFloat(
								request.payload.discount_percentage
							);
							if (
								!isNaN(discountPercentage) &&
								discountPercentage > 0
							) {
								// Рассчитываем цену со скидкой
								const discountAmount =
									price * (1 - discountPercentage / 100);
								request.payload.discount_amount =
									discountAmount.toFixed(2);
								console.log(
									'Рассчитана цена со скидкой по проценту:',
									{
										originalPrice: price,
										discountPercentage,
										discountedPrice:
											request.payload.discount_amount,
									}
								);
							} else if (
								discountPercentage === 0 ||
								request.payload.discount_percentage === ''
							) {
								// Если процент скидки равен 0 или пустой, удаляем скидку
								request.payload.discount_amount = null;
								console.log(
									'Скидка удалена, так как процент скидки равен 0 или пустой'
								);
							}
						}

						// Если указана цена со скидкой, проверяем её корректность
						if (request.payload.discount_amount !== undefined) {
							// Проверяем на пустую строку или null и устанавливаем null
							if (
								request.payload.discount_amount === '' ||
								request.payload.discount_amount === null
							) {
								request.payload.discount_amount = null;
								console.log(
									'Скидка удалена, так как цена со скидкой пустая'
								);
							} else {
								const discountAmount = parseFloat(
									request.payload.discount_amount
								);

								// Проверяем, что цена со скидкой не больше обычной цены
								if (discountAmount > price) {
									request.payload.discount_amount = price;
									console.log(
										'Цена со скидкой была больше обычной цены, установлена равной обычной цене:',
										price
									);
								}

								console.log('Установлена цена со скидкой:', {
									originalPrice: price,
									discountedPrice:
										request.payload.discount_amount,
								});
							}
						}
					}

					// Если дата окончания акции пустая или null, удаляем скидку
					if (
						request.payload.promotion_end_date === '' ||
						request.payload.promotion_end_date === null
					) {
						request.payload.discount_amount = null;
						console.log(
							'Скидка удалена, так как дата окончания акции пустая'
						);
					}

					// Очищаем поля ea_play_price и ps_plus_price, если они пустые или null
					if (
						request.payload.ea_play_price === '' ||
						request.payload.ea_play_price === null
					) {
						request.payload.ea_play_price = null;
						console.log(
							'EA Play цена очищена, так как поле пустое'
						);
					}

					if (
						request.payload.ps_plus_price === '' ||
						request.payload.ps_plus_price === null
					) {
						request.payload.ps_plus_price = null;
						console.log(
							'PS Plus цена очищена, так как поле пустое'
						);
					}

					return request;
				},
			},
			edit: {
				after: [
					handleLocalizations,
					handleCollections,
					handlePlatforms,
					async (response, request, context) => {
						// Если есть цена и цена со скидкой, рассчитываем процент скидки для отображения
						if (response.record && response.record.params) {
							const price = parseFloat(
								response.record.params.price
							);
							const discountAmount = parseFloat(
								response.record.params.discount_amount
							);

							if (
								!isNaN(price) &&
								!isNaN(discountAmount) &&
								price > 0 &&
								discountAmount > 0 &&
								discountAmount < price // Цена со скидкой должна быть меньше обычной цены
							) {
								// Рассчитываем процент скидки
								const discountPercentage = Math.round(
									((price - discountAmount) / price) * 100
								);
								response.record.params.discount_percentage =
									discountPercentage;

								console.log(
									'Рассчитан процент скидки для формы редактирования:',
									{
										originalPrice: price,
										discountedPrice: discountAmount,
										discountPercentage,
									}
								);
							}
						}

						return response;
					},
				],
				before: async (request, context) => {
					console.log('Edition edit - payload:', request.payload);
					console.log('Edition edit - params:', request.params);

					// При редактировании через админку НЕ меняем source, так как можем редактировать и записи парсера

					// Проверяем и обрабатываем цену со скидкой
					if (request.payload.price !== undefined) {
						const price = parseFloat(request.payload.price);

						// Если указан процент скидки, рассчитываем цену со скидкой
						if (
							request.payload.discount_percentage !== undefined &&
							request.payload.discount_percentage !== ''
						) {
							const discountPercentage = parseFloat(
								request.payload.discount_percentage
							);
							if (
								!isNaN(discountPercentage) &&
								discountPercentage > 0
							) {
								// Рассчитываем цену со скидкой
								const discountAmount =
									price * (1 - discountPercentage / 100);
								request.payload.discount_amount =
									discountAmount.toFixed(2);
								console.log(
									'Рассчитана цена со скидкой по проценту:',
									{
										originalPrice: price,
										discountPercentage,
										discountedPrice:
											request.payload.discount_amount,
									}
								);
							} else if (
								discountPercentage === 0 ||
								request.payload.discount_percentage === ''
							) {
								// Если процент скидки равен 0 или пустой, удаляем скидку
								request.payload.discount_amount = null;
								console.log(
									'Скидка удалена, так как процент скидки равен 0 или пустой'
								);
							}
						}

						// Если указана цена со скидкой, проверяем её корректность
						if (request.payload.discount_amount !== undefined) {
							// Проверяем на пустую строку или null и устанавливаем null
							if (
								request.payload.discount_amount === '' ||
								request.payload.discount_amount === null
							) {
								request.payload.discount_amount = null;
								console.log(
									'Скидка удалена, так как цена со скидкой пустая'
								);
							} else {
								const discountAmount = parseFloat(
									request.payload.discount_amount
								);

								// Проверяем, что цена со скидкой не больше обычной цены
								if (discountAmount > price) {
									request.payload.discount_amount = price;
									console.log(
										'Цена со скидкой была больше обычной цены, установлена равной обычной цене:',
										price
									);
								}

								console.log('Обновлена цена со скидкой:', {
									originalPrice: price,
									discountedPrice:
										request.payload.discount_amount,
								});
							}
						}
					}

					// Если дата окончания акции пустая или null, удаляем скидку
					if (
						request.payload.promotion_end_date === '' ||
						request.payload.promotion_end_date === null
					) {
						request.payload.discount_amount = null;
						console.log(
							'Скидка удалена, так как дата окончания акции пустая'
						);
					}

					// Очищаем поля ea_play_price и ps_plus_price, если они пустые или null
					if (
						request.payload.ea_play_price === '' ||
						request.payload.ea_play_price === null
					) {
						request.payload.ea_play_price = null;
						console.log(
							'EA Play цена очищена, так как поле пустое'
						);
					}

					if (
						request.payload.ps_plus_price === '' ||
						request.payload.ps_plus_price === null
					) {
						request.payload.ps_plus_price = null;
						console.log(
							'PS Plus цена очищена, так как поле пустое'
						);
					}

					// Проверяем наличие данных о связанных сущностях
					const platformKeys = Object.keys(request.payload).filter(
						key => key.startsWith('platforms.')
					);
					const localizationKeys = Object.keys(
						request.payload
					).filter(key => key.startsWith('localizations.'));
					const collectionKeys = Object.keys(request.payload).filter(
						key => key.startsWith('collections.')
					);

					console.log('Platform keys in payload:', platformKeys);
					console.log(
						'Localization keys in payload:',
						localizationKeys
					);
					console.log('Collection keys in payload:', collectionKeys);

					return request;
				},
			},
			list: {
				before: async (request, context) => {
					const { query = {} } = request;
					const { filters = {} } = query;

					if (filters.description) {
						filters.description = {
							$iLike: `%${filters.description}%`,
						};
					}

					context.query = {
						...context.query,
						include: ['collections', 'localizations', 'platforms'],
					};
					return request;
				},
				after: async (response, request, context) => {
					// Добавляем информацию о процентах скидки для каждой записи
					if (response.records && response.records.length > 0) {
						response.records.forEach(record => {
							if (record.params) {
								const price = parseFloat(record.params.price);
								const discountAmount = parseFloat(
									record.params.discount_amount
								);

								if (
									!isNaN(price) &&
									!isNaN(discountAmount) &&
									price > 0 &&
									discountAmount > 0 &&
									discountAmount < price // Цена со скидкой должна быть меньше обычной цены
								) {
									// Рассчитываем процент скидки
									const discountPercentage = Math.round(
										((price - discountAmount) / price) * 100
									);
									record.params.discount_percentage =
										discountPercentage;
								}
							}
						});
					}

					return response;
				},
			},
			show: {
				before: async (request, context) => {
					context.query = {
						...context.query,
						include: ['collections', 'localizations', 'platforms'],
					};
					return request;
				},
				after: async (response, request, context) => {
					// Если есть цена и цена со скидкой, рассчитываем процент скидки для отображения
					if (response.record && response.record.params) {
						const price = parseFloat(response.record.params.price);
						const discountAmount = parseFloat(
							response.record.params.discount_amount
						);

						if (
							!isNaN(price) &&
							!isNaN(discountAmount) &&
							price > 0 &&
							discountAmount > 0 &&
							discountAmount < price // Цена со скидкой должна быть меньше обычной цены
						) {
							// Рассчитываем процент скидки
							const discountPercentage = Math.round(
								((price - discountAmount) / price) * 100
							);
							response.record.params.discount_percentage =
								discountPercentage;

							console.log(
								'Рассчитан процент скидки для отображения:',
								{
									originalPrice: price,
									discountedPrice: discountAmount,
									discountPercentage,
								}
							);
						}
					}

					return response;
				},
			},
			delete: {
				isAccessible: true,
			},
			checkExpiredDiscounts: {
				actionType: 'resource',
				icon: 'Clock',
				component: false,
				handler: async (request, response, context) => {
					try {
						const currentDate = new Date();

						// Находим издания с истекшими скидками
						const expiredEditions = await Edition.findAll({
							where: {
								discount_amount: { [Op.ne]: null, [Op.gt]: 0 },
								promotion_end_date: { [Op.lt]: currentDate },
							},
							attributes: [
								'id',
								'price',
								'discount_amount',
								'promotion_end_date',
							],
						});

						if (expiredEditions.length === 0) {
							return {
								notice: {
									message: 'Истекших акций не найдено',
									type: 'success',
								},
							};
						}

						// Обновляем издания с истекшими скидками
						const [updatedCount] = await Edition.update(
							{ discount_amount: null },
							{
								where: {
									discount_amount: {
										[Op.ne]: null,
										[Op.gt]: 0,
									},
									promotion_end_date: {
										[Op.lt]: currentDate,
									},
								},
							}
						);

						return {
							notice: {
								message: `Обновлено ${updatedCount} изданий с истекшими акциями`,
								type: 'success',
							},
						};
					} catch (error) {
						console.error(
							'Ошибка при проверке истекших скидок:',
							error
						);
						return {
							notice: {
								message: `Ошибка при проверке истекших скидок: ${error.message}`,
								type: 'error',
							},
						};
					}
				},
			},
		},
		listProperties: [
			'id',
			'edition_name_id',
			'product_card_id',
			'price',
			'discount_amount',
			'final_price',
			'platforms',
			'collections',
			'promotion_end_date',
			'source',
			'created_at',
		],
		filterProperties: [
			'edition_name_id',
			'description',
			'product_card_id',
			'price',
			'platforms',
			'collections',
			'promotion_end_date',
			'source',
			'created_at',
		],
		editProperties: [
			'edition_name_id',
			'description',
			'product_card_id',
			'price',
			'display_currency_id',
			'discount_amount',
			'discount_percentage',
			'ea_play_price',
			'ps_plus_price',
			'promotion_end_date',
			'platforms',
			'collections',
			'localizations',
		],
		showProperties: [
			'id',
			'edition_name_id',
			'description',
			'product_card_id',
			'price',
			'display_currency_id',
			'discount_amount',
			'discount_percentage',
			'final_price',
			'ea_play_price',
			'ps_plus_price',
			'promotion_end_date',
			'platforms',
			'collections',
			'localizations',
			'source',
			'created_at',
			'updated_at',
		],
	},
};
