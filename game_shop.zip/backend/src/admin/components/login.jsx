import React from 'react';
import styled from 'styled-components';
import ruLocale from '../locales/ruLocale.js';

const Container = styled.div`
	display: flex;
	justify-content: center;
	align-items: center;
	height: 100vh;
	background-color: #f5f5f7;
	font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto',
		'Helvetica', 'Arial', sans-serif;
`;

const LoginBox = styled.div`
	background-color: #ffffff;
	border-radius: 18px;
	padding: 40px;
	width: 100%;
	max-width: 400px;
	box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
`;

const Title = styled.h1`
	font-size: 28px;
	font-weight: 600;
	color: #1d1d1f;
	margin-bottom: 10px;
	text-align: center;
	letter-spacing: -0.5px;
`;

const Subtitle = styled.p`
	font-size: 17px;
	color: #86868b;
	margin-bottom: 30px;
	text-align: center;
	letter-spacing: -0.2px;
`;

const Input = styled.input`
	width: 100%;
	padding: 15px;
	margin-bottom: 20px;
	border: 1px solid #d2d2d7;
	border-radius: 12px;
	font-size: 17px;
	outline: none;
	transition: all 0.3s ease;

	&:focus {
		border-color: #0071e3;
		box-shadow: 0 0 0 4px rgba(0, 113, 227, 0.1);
	}
`;

const Button = styled.button`
	display: block;
	width: auto;
	min-width: 200px;
	padding: 15px 30px;
	margin: 0 auto;
	background-color: #0071e3;
	color: white;
	border: none;
	border-radius: 12px;
	font-size: 17px;
	font-weight: 600;
	cursor: pointer;
	transition: all 0.3s ease;

	&:hover {
		background-color: #0077ed;
	}

	&:active {
		transform: scale(0.98);
	}
`;

const ErrorMessage = styled.div`
	color: #ff3b30;
	font-size: 14px;
	margin-bottom: 15px;
	text-align: center;
`;

const Form = styled.form`
	display: flex;
	flex-direction: column;
	align-items: center;
`;

const Login = props => {
	const { action, message } = props;

	return (
		<Container>
			<LoginBox>
				<Title>{ruLocale.labels.loginWelcome}</Title>
				<Form action={action} method='POST'>
					<Input
						name='email'
						type='email'
						placeholder={ruLocale.components.login.emailPlaceholder}
					/>
					<Input
						type='password'
						name='password'
						placeholder={
							ruLocale.components.login.passwordPlaceholder
						}
					/>
					{message && <ErrorMessage>{message}</ErrorMessage>}
					<Button type='submit'>
						{ruLocale.components.login.loginButton}
					</Button>
				</Form>
			</LoginBox>
		</Container>
	);
};

export default Login;
