import React, { useState, useEffect } from 'react';

const BulkCollectionModal = ({ selectedRecords, onClose, onSuccess }) => {
	const [collections, setCollections] = useState([]);
	const [selectedCollectionId, setSelectedCollectionId] = useState('');
	const [loading, setLoading] = useState(false);
	const [preview, setPreview] = useState(null);
	const [showPreview, setShowPreview] = useState(false);

	console.log('BulkCollectionModal loaded with records:', selectedRecords);

	useEffect(() => {
		fetchCollections();
	}, []);

	const fetchCollections = async () => {
		try {
			const response = await fetch('/api/editions/collections');
			const data = await response.json();
			setCollections(data);
		} catch (error) {
			console.error('Error fetching collections:', error);
		}
	};

	const fetchPreview = async () => {
		if (!selectedCollectionId || !selectedRecords.length) return;

		try {
			setLoading(true);
			const editionIds = selectedRecords.map(record => record.params?.id || record.id);

			const response = await fetch('/api/editions/preview-for-collection', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({
					editionIds,
					collectionId: parseInt(selectedCollectionId)
				})
			});

			const data = await response.json();
			setPreview(data);
			setShowPreview(true);
		} catch (error) {
			console.error('Error fetching preview:', error);
		} finally {
			setLoading(false);
		}
	};

	const handleSubmit = async () => {
		if (!selectedCollectionId || !selectedRecords.length) return;

		try {
			setLoading(true);
			const editionIds = selectedRecords.map(record => record.params?.id || record.id);

			const response = await fetch('/api/editions/bulk-add-to-collection', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({
					editionIds,
					collectionId: parseInt(selectedCollectionId)
				})
			});

			const result = await response.json();

			if (response.ok) {
				onSuccess(result);
			} else {
				alert(`Ошибка: ${result.error}`);
			}
		} catch (error) {
			console.error('Error adding to collection:', error);
			alert('Произошла ошибка при добавлении в коллекцию');
		} finally {
			setLoading(false);
		}
	};

	const modalStyles = {
		overlay: {
			position: 'fixed',
			top: 0,
			left: 0,
			right: 0,
			bottom: 0,
			backgroundColor: 'rgba(0, 0, 0, 0.7)',
			display: 'flex',
			justifyContent: 'center',
			alignItems: 'center',
			zIndex: 1000
		},
		modal: {
			backgroundColor: 'white',
			padding: '30px',
			borderRadius: '12px',
			maxWidth: '700px',
			width: '95%',
			maxHeight: '85vh',
			overflowY: 'auto',
			boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3)'
		},
		header: {
			fontSize: '24px',
			fontWeight: 'bold',
			marginBottom: '20px',
			color: '#333'
		},
		info: {
			backgroundColor: '#f8f9fa',
			padding: '15px',
			borderRadius: '8px',
			marginBottom: '20px',
			border: '1px solid #e9ecef'
		},
		select: {
			width: '100%',
			padding: '12px',
			border: '2px solid #ddd',
			borderRadius: '8px',
			fontSize: '16px',
			marginBottom: '15px'
		},
		button: {
			padding: '12px 24px',
			border: 'none',
			borderRadius: '8px',
			fontSize: '16px',
			cursor: 'pointer',
			marginRight: '10px'
		},
		primaryButton: {
			backgroundColor: '#007cba',
			color: 'white'
		},
		secondaryButton: {
			backgroundColor: '#6c757d',
			color: 'white'
		},
		previewButton: {
			backgroundColor: '#17a2b8',
			color: 'white'
		},
		preview: {
			backgroundColor: '#e7f3ff',
			padding: '15px',
			borderRadius: '8px',
			marginTop: '15px',
			border: '1px solid #b3d7ff'
		},
		statItem: {
			display: 'inline-block',
			margin: '5px 15px 5px 0',
			fontWeight: 'bold'
		}
	};

	return (
		<div style={modalStyles.overlay} onClick={onClose}>
			<div style={modalStyles.modal} onClick={e => e.stopPropagation()}>
				<div style={modalStyles.header}>
					Добавить издания в коллекцию
				</div>

				<div style={modalStyles.info}>
					<strong>Выбрано изданий: {selectedRecords.length}</strong>
					<br />
					<small>
						ID изданий: {selectedRecords.map(record => record.params?.id || record.id).join(', ')}
					</small>
				</div>

				<div>
					<label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
						Выберите коллекцию:
					</label>
					<select
						style={modalStyles.select}
						value={selectedCollectionId}
						onChange={(e) => setSelectedCollectionId(e.target.value)}
					>
						<option value="">-- Выберите коллекцию --</option>
						{collections.map(collection => (
							<option key={collection.id} value={collection.id}>
								{collection.name}
								{collection.description && ` - ${collection.description}`}
							</option>
						))}
					</select>
				</div>

				{selectedCollectionId && (
					<button
						style={{...modalStyles.button, ...modalStyles.previewButton}}
						onClick={fetchPreview}
						disabled={loading}
					>
						{loading ? 'Загрузка...' : 'Предварительный просмотр'}
					</button>
				)}

				{showPreview && preview && (
					<div style={modalStyles.preview}>
						<h4>Предварительный просмотр:</h4>
						<div style={modalStyles.statItem}>
							📦 Всего изданий: {preview.totalEditions}
						</div>
						<div style={modalStyles.statItem}>
							➕ Новых: {preview.newEditions}
						</div>
						<div style={modalStyles.statItem}>
							✅ Уже в коллекции: {preview.alreadyInCollection}
						</div>
						<div style={modalStyles.statItem}>
							🏷️ С активными скидками: {preview.activeDiscounts}
						</div>
						<div style={modalStyles.statItem}>
							⏰ Скидки истекают скоро: {preview.expiringSoon}
						</div>
					</div>
				)}

				<div style={{ marginTop: '25px', textAlign: 'right' }}>
					<button
						style={{...modalStyles.button, ...modalStyles.secondaryButton}}
						onClick={onClose}
						disabled={loading}
					>
						Отмена
					</button>
					<button
						style={{...modalStyles.button, ...modalStyles.primaryButton}}
						onClick={handleSubmit}
						disabled={loading || !selectedCollectionId}
					>
						{loading ? 'Добавление...' : 'Добавить в коллекцию'}
					</button>
				</div>
			</div>
		</div>
	);
};

export default BulkCollectionModal;
