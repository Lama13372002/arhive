import React, { useState, useEffect } from 'react';
import { useNotice } from 'adminjs';
import BulkCollectionModal from './BulkCollectionModal.jsx';

const BulkAddToCollectionAction = (props) => {
	const [showModal, setShowModal] = useState(true); // Сразу показываем модалку
	const [selectedRecords, setSelectedRecords] = useState([]);
	const addNotice = useNotice();

	console.log('BulkAddToCollectionAction loaded with props:', props);
	console.log('All props keys:', Object.keys(props));

	// Получаем данные из props
	const records = props.records || props.data?.records || [];
	const resource = props.resource;

	console.log('Extracted records:', records);
	console.log('Records length:', records?.length);

	// Пытаемся получить ID изданий из URL
	useEffect(() => {
		try {
			const urlParams = new URLSearchParams(window.location.search);
			const editionIds = urlParams.get('editionIds');
			console.log('URL edition IDs:', editionIds);

			if (editionIds && editionIds.length > 0) {
				const ids = editionIds.split(',').map(id => parseInt(id.trim())).filter(id => !isNaN(id));
				console.log('Parsed edition IDs:', ids);

				// Создаем объекты записей из ID
				const recordsFromIds = ids.map(id => ({
					id: id,
					params: { id: id }
				}));

				setSelectedRecords(recordsFromIds);
				console.log('Set selected records from URL:', recordsFromIds);
			}
		} catch (error) {
			console.error('Error parsing URL params:', error);
		}
	}, []);

	const handleSuccess = (result) => {
		addNotice({
			message: result.message,
			type: 'success'
		});
		setShowModal(false);
		// Перезагружаем страницу для обновления данных
		window.location.reload();
	};

	const handleClose = () => {
		setShowModal(false);
		// Возвращаемся к списку изданий
		window.history.back();
	};

	// Используем записи из URL если они есть, иначе из props
	const finalRecords = selectedRecords.length > 0 ? selectedRecords : records;

	if (!finalRecords || finalRecords.length === 0) {
		return (
			<div style={{ padding: '20px', textAlign: 'center' }}>
				<h2>Не выбрано ни одного издания</h2>
				<p>Для использования массового добавления в коллекцию необходимо выбрать издания.</p>
				<button
					onClick={handleClose}
					style={{
						backgroundColor: '#6c757d',
						color: 'white',
						border: 'none',
						padding: '10px 20px',
						borderRadius: '6px',
						cursor: 'pointer'
					}}
				>
					Назад к списку
				</button>
			</div>
		);
	}

	return (
		<div>
			{showModal && (
				<BulkCollectionModal
					selectedRecords={finalRecords}
					onClose={handleClose}
					onSuccess={handleSuccess}
				/>
			)}
		</div>
	);
};

export default BulkAddToCollectionAction;
