import { ComponentLoader } from 'adminjs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const componentLoader = new ComponentLoader();

const Components = {
	Dashboard: componentLoader.add(
		'Dashboard',
		path.join(__dirname, './components/Dashboard.jsx')
	),
	Login: componentLoader.override(
		'Login',
		path.join(__dirname, './components/login.jsx')
	),
	SetDiscountAction: componentLoader.add(
		'SetDiscountAction',
		path.join(__dirname, './components/SetDiscountAction.jsx')
	),
	ImageUpload: componentLoader.add(
		'ImageUpload',
		path.join(__dirname, './components/ImageUpload.jsx')
	),
	ImagePreview: componentLoader.add(
		'ImagePreview',
		path.join(__dirname, './components/ImagePreview.jsx')
	),
	BulkCollectionModal: componentLoader.add(
		'BulkCollectionModal',
		path.join(__dirname, './components/BulkCollectionModal.jsx')
	),
	BulkAddToCollectionAction: componentLoader.add(
		'BulkAddToCollectionAction',
		path.join(__dirname, './components/BulkAddToCollectionAction.jsx')
	),
};

export { componentLoader, Components };
