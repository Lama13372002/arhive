export const preflightMiddleware = (req, res, next) => {
	// Разрешаем запросы только с наших доменов
	const allowedOrigins = [
		'pwstore.ru',
		'https://eyes-injection-strengthening-negotiation.trycloudflare.com',
		'https://request-medications-patio-onion.trycloudflare.com',
		'https://5472-77-239-114-235.ngrok-free.app',
		'http://localhost:3000',
		'http://localhost:3443',
		'http://localhost:5312', // Добавляем порт Vite
		'http://127.0.0.1:3000',
		'http://127.0.0.1:3443',
		'http://127.0.0.1:5312', // Добавляем порт Vite
	];

	// Добавляем URL из .env.development если они есть
	if (process.env.VITE_API_BASE_URL) {
		allowedOrigins.push(process.env.VITE_API_BASE_URL);
	}
	if (process.env.TELEGRAM_WEB_APP_URL) {
		allowedOrigins.push(process.env.TELEGRAM_WEB_APP_URL);
	}

	if (process.env.BOT_URL) {
		allowedOrigins.push(process.env.BOT_URL);
	}

	const origin = req.headers.origin;

	// В режиме разработки разрешаем все origins
	if (process.env.NODE_ENV === 'development') {
		res.setHeader('Access-Control-Allow-Origin', origin || '*');
	} else if (origin && allowedOrigins.includes(origin)) {
		res.setHeader('Access-Control-Allow-Origin', origin);
	}

	// Разрешаем credentials
	res.setHeader('Access-Control-Allow-Credentials', 'true');

	// Разрешенные заголовки, включая Cloudflare и Telegram
	res.setHeader(
		'Access-Control-Allow-Headers',
		'Origin, X-Requested-With, Content-Type, Accept, Authorization, ' +
			'CF-Connecting-IP, CF-IPCountry, CF-RAY, CF-Visitor, CF-Worker, ' +
			'x-telegram-user-id' // Добавляем заголовок для Telegram
	);

	// Разрешенные методы
	res.setHeader(
		'Access-Control-Allow-Methods',
		'GET, POST, PUT, PATCH, DELETE, OPTIONS'
	);

	// Preflight cache на 1 час
	res.setHeader('Access-Control-Max-Age', '3600');

	// Добавляем заголовки безопасности
	res.setHeader(
		'Strict-Transport-Security',
		'max-age=31536000; includeSubDomains'
	);
	res.setHeader('X-Content-Type-Options', 'nosniff');
	res.setHeader('X-Frame-Options', 'SAMEORIGIN');
	res.setHeader('X-XSS-Protection', '1; mode=block');

	// Обработка Cloudflare заголовков
	if (req.headers['cf-connecting-ip']) {
		req.realIp = req.headers['cf-connecting-ip'];
	}

	// Логирование для отладки в режиме разработки
	if (process.env.NODE_ENV === 'development') {
		console.log('Request from origin:', origin);
		console.log('Request headers:', req.headers);
		console.log('Allowed origins:', allowedOrigins);
	}

	// Обработка OPTIONS запросов
	if (req.method === 'OPTIONS') {
		console.log('Handling OPTIONS request from origin:', origin);
		return res.status(204).end(); // Используем 204 вместо 200
	}

	next();
};
