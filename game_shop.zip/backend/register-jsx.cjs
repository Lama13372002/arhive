const Module = require('module');
const originalResolveFilename = Module._resolveFilename;

Module._resolveFilename = function (request, parent, isMain, options) {
  if (request.endsWith('.jsx')) {
    try {
      return originalResolveFilename(request, parent, isMain, options);
    } catch (error) {
      // If the exact file is not found, try without extension
      const withoutExtension = request.slice(0, -4);
      return originalResolveFilename(withoutExtension, parent, isMain, options);
    }
  }
  return originalResolveFilename(request, parent, isMain, options);
};

require('@babel/register')({
  presets: ['@babel/preset-env', '@babel/preset-react'],
  plugins: [
    '@babel/plugin-proposal-class-properties',
    '@babel/plugin-transform-modules-commonjs'
  ],
  extensions: ['.js', '.jsx'],
  ignore: [/node_modules/],
  sourceMaps: 'inline',
  retainLines: true,
});
