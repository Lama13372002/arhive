import asyncio
import aiohttp
from json import dumps, loads
from random import choice
from bs4 import BeautifulSoup as bs
from time import perf_counter
from re import findall
import asyncpg
from dotenv import load_dotenv
from datetime import datetime
import os
import pickle


load_dotenv()

def get_params(url: str):
    product_type, sku = url.split("/")[-2:]
    queries = {
        "concept": {
                "operationName": "conceptRetrieveForCtasWithPrice",
                "variables": dumps({"conceptId": sku}),
                "extensions": dumps({
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "eab9d873f90d4ad98fd55f07b6a0a606e6b3925f2d03b70477234b79c1df30b5"
                    }
                })
            }
        ,
        "product": [
            {
                "operationName": "productRetrieveForCtasWithPrice",
                "variables": dumps({"productId": sku}),
                "extensions": dumps({
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "8872b0419dcab2fea5916ef698544c237b1096f9e76acc6aacf629551adee8cd"
                    }
                })
            },
            {
                "operationName": "productRetrieveForUpsellWithCtas",
                "variables": dumps({"productId": sku}),
                "extensions": dumps({
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "fb0bfa0af4d8dc42b28fa5c077ed715543e7fb8a3deff8117a50b99864d246f1"
                    }
                })
            }
        ]
    }
    return queries[product_type]


header=lambda: choice([
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15',
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15'
                ])


json_headers = lambda x: {
    "Accept": "application/json",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "en-US",
    "apollographql-client-name": "@sie-private/web-commerce-anywhere",
    "apollographql-client-version": "3.23.0",
    "Cache-Control": "no-cache",
    "Content-Type": "application/json",
    "disable_query_whitelist": "false",
    "Origin": "https://store.playstation.com",
    "Pragma": "no-cache",
    "Priority": "u=1, i",
    "Referer": "https://store.playstation.com/",
    "sec-ch-ua": '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "User-Agent": header(),
    "x-psn-app-ver": "@sie-private/web-commerce-anywhere/3.23.0-d3947b39a30477ef83ad9e5fc7f3f6a72e17bb6b",
    "x-psn-store-locale-override": x.split("/")[-3]
}


page_headers = lambda: {
        "authority": "store.playstation.com",
        "method": "GET",
        "scheme": "https",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "accept-encoding": "gzip, deflate, br, zstd",
        "accept-language": "ru-RU,ru;q=0.9",
        "cache-control": "no-cache",
        "pragma": "no-cache",
        "priority": "u=0, i",
        "sec-ch-ua": '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "same-origin",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "user-agent": header()
    }


async def get_pages(session: aiohttp.ClientSession, url: str):
    try:
        async with session.get(url, headers=page_headers()) as resp:
            html = await resp.text()
        soup = bs(html, "html.parser")
        _main = soup.find("div", {"id": "__next"}).find("main")
        section = _main.find("section", {"class": "ems-sdk-grid"})
        psw = section.find("div", {"class": "psw-l-stack-center"})
        count = int(psw.find("nav").find("ol").find_all("li")[-1].find("span").text)
        return [f"{url}/{i}"
                for i in range(1, count+1)]
    except (asyncio.CancelledError, KeyboardInterrupt):
        return []


async def get_products(session: aiohttp.ClientSession, url: str):
    count = 0
    while count < 2:
        try:
            async with session.get(url, headers=page_headers()) as resp:
                html = await resp.text()
            soup = bs(html, "html.parser")
            _main = soup.find("div", {"id": "__next"}).find("main")
            section = _main.find("section", {"class": "ems-sdk-grid"})
            ul = section.find("ul", {"class": "psw-grid-list psw-l-grid"})
            products = ul.find_all("li")
            return ["https://store.playstation.com" + i.find("a")["href"]
                    for i in products]
        except (asyncio.CancelledError, KeyboardInterrupt):
            return []
        except:
            count += 1
    else:
        return []

async def unquote(session: aiohttp.ClientSession, url: str):

    try:
        if "product" in url:
            return [url]

        async with session.get("https://web.np.playstation.com/api/graphql/v1/op", headers=json_headers(url), params=get_params(url)) as resp:
            text = await resp.text()
        json = loads(text)
        products = json["data"]["conceptRetrieve"]["products"]
        res = []
        for product in products:
            ID = product["id"]
            res.append(f'{"/".join(url.split("/")[:4])}/product/{ID}')
        return res
    except (asyncio.CancelledError, KeyboardInterrupt):
        return []

async def parse(session: aiohttp.ClientSession, url: str):

    params_price, params = get_params(url)

    tr_url = url.split("/")
    tr_url[3] = "en-tr"
    tr_url = "/".join(tr_url)

    async def get_ext_data(product):
        pdp = None
        psw = None
        game_info = None
        dl = None

        counter = 0

        platforms = None
        publisher = None
        voice_languages = None
        subtitles = None
        description = None
        ext_info = None
        json = None

        while (not pdp and not psw and not game_info and not dl) and counter < 3:
            try:
                async with session.get(f"https://store.playstation.com/ru-ua/product/{product}", headers=page_headers()) as resp:
                    text = await resp.text()

                if "You don't have permission to access" in text:
                    counter = 0
                    await asyncio.sleep(30)
                    continue

                soup = bs(text, "html.parser")

                _main = soup.find("main")
                pdp = _main.find("div", {"class": "pdp-main psw-dark-theme"})
                if not pdp:
                    counter += 1
                    await asyncio.sleep(5)
                    continue
                psw = pdp.find_all("div", {"class": "psw-m-t-10 psw-fill-x"})


                for _psw in psw:
                    if _psw.find("div", {"class": "pdp-info"}):
                        psw = _psw
                        break
                else:
                    counter += 1
                    await asyncio.sleep(5)
                    continue
                game_info = psw.find("div", {"data-qa": "gameInfo"})
                if not game_info:
                    counter += 1
                    await asyncio.sleep(5)
                    continue

                dl = game_info.find("dl")
                if not dl:
                    counter += 1
                    await asyncio.sleep(5)
                    continue

                soup = bs(text, "html.parser")
                json = soup.find("script", {"id": "__NEXT_DATA__", "type": "application/json"}).text

                json = loads(json)

                if dl.find("dd", {"data-qa": "gameInfo#releaseInformation#platform-value"}):
                    platforms = dl.find("dd", {"data-qa": "gameInfo#releaseInformation#platform-value"}).text.split(', ')
                if dl.find("dd", {"data-qa": "gameInfo#releaseInformation#publisher-value"}):
                    publisher = dl.find("dd", {"data-qa": "gameInfo#releaseInformation#publisher-value"}).text

                voice_languages, subtitles = "", ""
                if dl.find("dd", {"data-qa": "gameInfo#releaseInformation#voice-value"}):
                    voice_languages = dl.find("dd", {"data-qa": "gameInfo#releaseInformation#voice-value"}).text
                if dl.find("dd", {"data-qa": "gameInfo#releaseInformation#subtitles-value"}):
                    subtitles = dl.find("dd", {"data-qa": "gameInfo#releaseInformation#subtitles-value"}).text

                if dl.find("dd", {"data-qa": "gameInfo#releaseInformation#ps5Voice-value"}):
                    voice_languages += dl.find("dd", {"data-qa": "gameInfo#releaseInformation#ps5Voice-value"}).text
                if dl.find("dd", {"data-qa": "gameInfo#releaseInformation#ps4Voice-value"}):
                    voice_languages += dl.find("dd", {"data-qa": "gameInfo#releaseInformation#ps4Voice-value"}).text

                if dl.find("dd", {"data-qa": "gameInfo#releaseInformation#ps5Subtitles-value"}):
                    subtitles += dl.find("dd", {"data-qa": "gameInfo#releaseInformation#ps5Subtitles-value"}).text
                if dl.find("dd", {"data-qa": "gameInfo#releaseInformation#ps4Voice-value"}):
                    subtitles += dl.find("dd", {"data-qa": "gameInfo#releaseInformation#ps4Subtitles-value"}).text

                description = bs(json["props"]["pageProps"]["batarangs"]["overview"]["text"], "html.parser").get_text("\n\n", strip=True)
                ext_info = json["props"]["pageProps"]["batarangs"]["compatibility-notices"]["text"]
                _tmp = findall(r">([^<]+)</", ext_info)
                if len(_tmp) > 1:
                    ext_info = dumps(_tmp[1:])


            except (asyncio.CancelledError, KeyboardInterrupt):
                return []
            except:
                counter += 1
                await asyncio.sleep(5)

        return product, platforms, publisher, voice_languages, subtitles, description, ext_info, json

    counter = 0

    while counter < 2:
        try:
            async with session.get("https://web.np.playstation.com/api/graphql/v1/op", params=params, headers=json_headers(url)) as ua_resp:
                ua = await ua_resp.text()
            async with session.get("https://web.np.playstation.com/api/graphql/v1/op", params=params_price, headers=json_headers(url)) as ua_resp_price:
                ua_price = await ua_resp_price.text()


            ua = loads(ua)
            ua_price = loads(ua_price)
            ua_products = []
            ua_price_product = []
            if ua["data"]["productRetrieve"] and ua["data"]["productRetrieve"].get("concept") and ua["data"]["productRetrieve"]["topCategory"] != "ADD_ON":
                ua_products = ua["data"]["productRetrieve"]["concept"]["products"]

                async with session.get("https://web.np.playstation.com/api/graphql/v1/op", params=params, headers=json_headers(tr_url)) as tr_resp_price:
                    tr_price = await tr_resp_price.text()

            if not ua_products:
                ua_price_product = ua_price["data"]["productRetrieve"]

                async with session.get("https://web.np.playstation.com/api/graphql/v1/op", params=params_price, headers=json_headers(tr_url)) as tr_resp_price:
                    tr_price = await tr_resp_price.text()

            tr_price = loads(tr_price)
            if not tr_price["data"]["productRetrieve"]:
                return []
            if "products" in tr_price["data"]["productRetrieve"]["concept"]:
                tr_price_products = tr_price["data"]["productRetrieve"]["concept"]["products"]
            elif "webctas" in tr_price["data"]["productRetrieve"]:
                tr_price_products = [tr_price["data"]["productRetrieve"]]
            else:
                return []
            result = []

            if "errors" in ua:
                return []

            if "name" in ua["data"]["productRetrieve"]["concept"]:
                main_name = ua["data"]["productRetrieve"]["concept"]["name"]

            tags = []

            try:

                if ua_products:
                    _pre_ext = await asyncio.gather(*[get_ext_data(p["id"]) for p in ua_products])
                    ext = {k[0]: k[1:] for k in _pre_ext}


                    for product in ua_products:
                        if main_name not in tags:
                            tags.append(main_name)
                        ID = product["id"]
                        name = product["name"]

                        platforms, publisher, voice_languages, subtitles, description, ext_info, json = ext[ID]

                        stars_json = loads(findall(r">([^<]+)</", json["props"]["pageProps"]["batarangs"]["star-rating"]["text"])[0])
                        stars = stars_json["cache"][f"Product:{ID}"]["starRating"]["averageRating"]

                        if not publisher:
                            continue
                        category = []
                        if product["localizedGenres"]:
                            category = list(set(i["value"] for i in product["localizedGenres"]))
                        product_type = ""
                        if "Подписка" in name:
                            product_type = "Подписка"
                        else:
                            if product["skus"][0]["name"].lower() != "демоверсия" or product["skus"][0]["name"].lower() != "Полная ознакомительная версия игры":
                                product_type = product["skus"][0]["name"]
                            else:
                                if len(product["skus"]) > 1:
                                    product_type = product["skus"][1]["name"]
                            if product["skus"][0]["name"].lower() == "демоверсия" or product["skus"][0]["name"].lower() == "полная ознакомительная версия игры" or not product_type:
                                product_type = "Игра"


                        image = product["media"]
                        if not image:
                            image = tr_price["data"]["productRetrieve"]["concept"]["media"]
                        for img in image:
                            if img["role"] == "MASTER":
                                image = img["url"]
                                break

                        tags.append(name)

                        if name != product["invariantName"]:
                            tags.append(product["invariantName"])

                        uah_price = 0
                        uah_old_price = 0
                        discount = ""
                        discount_end = None

                        trl_price = 0
                        trl_old_price = 0

                        # ps_plus_essential = False
                        # ps_plus_extra = False
                        # ps_plus_delux = False
                        ps_plus = False
                        ea_access = False

                        ps_price_ua = None
                        ea_price_ua = None
                        ps_price_tr = None
                        ea_price_tr = None
                        for price in product["webctas"]:
                            if price["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] or ("UPSELL" in price["type"] and ("EA_ACCESS" in price["type"] or "PS_PLUS" in price["type"]) and "TRIAL" not in price["type"]):
                                if price["type"] == "PREORDER":
                                    product_type = "Предзаказ"
                                if price["price"]["discountedPrice"] and price["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] and not uah_price:
                                    uah_price = price["price"]["discountedValue"]/100
                                if price["price"]["basePrice"] and price["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] and uah_old_price:
                                    uah_old_price = price["price"]["basePriceValue"]/100
                                if "PS_PLUS" in price["type"] and price["price"]["discountedPrice"] == "Входит в подписку":
                                    ps_plus = True
                                if "EA_ACCESS" in price["type"] and price["price"]["discountedPrice"] == "Входит в подписку":
                                    ea_access = True
                                if "UPSELL_PS_PLUS_DISCOUNT" == price["type"]:
                                    ps_price_ua = price["price"]["discountedValue"]/100
                                if "UPSELL_EA_ACCESS_DISCOUNT" == price["type"]:
                                    ea_price_ua = price["price"]["discountedValue"]/100
                                if price["price"]["discountText"] and price["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"]:
                                    discount = price["price"]["discountText"]
                                if price["price"]["endTime"] and price["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"]:
                                    discount_end = datetime.fromtimestamp(int(price["price"]["endTime"])//1000)

                        if tr_price_products:
                            for trl_product in tr_price_products:
                                eq_id = trl_product["id"].split("-")[-1][:-1] == ID.split("-")[-1][:-1]
                                if any([ID == tr["id"] for tr in tr_price_products]):
                                    eq_id = trl_product["id"] == ID
                                if eq_id:
                                    for trl in trl_product["webctas"]:
                                        if trl["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] or ("UPSELL" in trl["type"] and ("EA_ACCESS" in trl["type"] or "PS_PLUS" in trl["type"]) and "TRIAL" not in trl["type"]):
                                        # if trl["type"] in ["ADD_TO_CART", "PREORDER"] or "UPSELL" in trl["type"]:
                                            if trl["price"]["discountedPrice"] and trl["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] and not trl_price:
                                                trl_price = trl["price"]["discountedValue"]/100
                                            if trl["price"]["basePrice"] and trl["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] and not trl_old_price:
                                                trl_old_price = trl["price"]["basePriceValue"]/100
                                            if "PS_PLUS" in trl["type"] and trl["price"]["discountedPrice"] == "Included":
                                                ps_plus = True
                                            if "EA_ACCESS" in trl["type"] and trl["price"]["discountedPrice"] == "Included":
                                                ea_access = True
                                            if "UPSELL_PS_PLUS_DISCOUNT" == trl["type"]:
                                                ps_price_tr = trl["price"]["discountedValue"]/100
                                            if "UPSELL_EA_ACCESS_DISCOUNT" == trl["type"]:
                                                ea_price_tr = trl["price"]["discountedValue"]/100

                        edition = product["edition"]
                        compound = ""
                        if edition:
                            if edition["features"]:
                                compound = dumps(edition["features"])
                            edition = edition["name"]
                            if not edition:
                                edition = name

                        localization = 4

                        if voice_languages:
                            if "русский" in voice_languages.lower():
                                localization -= 2
                        if subtitles:
                            if "русский" in subtitles.lower():
                                localization -= 1

                        if not uah_price:
                            uah_price = uah_old_price
                        if not trl_price:
                            trl_price = trl_old_price

                        for t in range(len(tags)):
                            for c in ['™', '®', '©', '℗', '℠', "’"]:
                                to_replace = ""
                                if "’" in tags[t]:
                                    to_replace = "'"
                                tags[t] = tags[t].replace(c, to_replace)

                        if product_type:
                            result.append({"id": ID,
                                        "category": category,
                                        "type": product_type,
                                        "name": name,
                                        "main_name": main_name,
                                        "image": image,
                                        "compound": compound,
                                        "platforms": platforms,
                                        "publisher": publisher,
                                        "localization": localization,
                                        "rating": stars,
                                        "info": ext_info,
                                        "uah_price": uah_price,
                                        "uah_old_price": uah_old_price,
                                        "ps_price_ua": ps_price_ua,
                                        "ps_price_tr": ps_price_tr,
                                        "ea_price_ua": ea_price_ua,
                                        "ea_price_tr": ea_price_tr,
                                        "trl_price": trl_price,
                                        "trl_old_price": trl_old_price,
                                        "ps_plus": ps_plus,
                                        "ea_access": ea_access,
                                        "discount": discount,
                                        "discount_end": discount_end,
                                        "tags": set(tags),
                                        "edition": edition,
                                        "description": description})
                else:
                    tags = [main_name]
                    ID = ua_price_product["id"]
                    product, platforms, publisher, voice_languages, subtitles, description, ext_info, json = await get_ext_data(ID)

                    stars_json = loads(findall(r">([^<]+)</", json["props"]["pageProps"]["batarangs"]["star-rating"]["text"])[0])
                    stars = stars_json["cache"][f"Product:{ID}"]["starRating"]["averageRating"]

                    if not publisher:
                        return result

                    category = [ua_price_product["skus"][0]["name"]]
                    name = ua_price_product["name"]
                    product_type = "Дополнение"
                    image = json["props"]["pageProps"]["batarangs"]["background-image"]["text"]
                    image = loads(findall(r">([^<]+)</", image)[0])
                    image = image["cache"][f"Product:{ID}"]["media"]
                    for img in image:
                        if img["role"] == "MASTER":
                            image = img["url"]
                            break
                    compound = ""

                    tags.append(name)

                    if name != ua_price_product["invariantName"]:
                        tags.append(ua_price_product["invariantName"])

                    uah_price = 0
                    uah_old_price = 0
                    discount = ""
                    discount_end = None
                    trl_price = 0
                    trl_old_price = 0

                    ps_plus = False
                    ea_access = False

                    ps_price_ua = None
                    ea_price_ua = None
                    ps_price_tr = None
                    ea_price_tr = None

                    if ua_price_product["webctas"]:
                        for price in ua_price_product["webctas"]:
                            if price["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] or ("UPSELL" in price["type"] and ("EA_ACCESS" in price["type"] or "PS_PLUS" in price["type"]) and "TRIAL" not in price["type"]):
                                if price["type"] == "PREORDER":
                                    product_type = "Предзаказ"
                                if price["price"]["discountedPrice"] and price["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] and not uah_price:
                                    uah_price = price["price"]["discountedValue"]/100
                                if price["price"]["basePrice"] and price["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"] and uah_old_price:
                                    uah_old_price = price["price"]["basePriceValue"]/100
                                if "PS_PLUS" in price["type"] and price["price"]["discountedPrice"] == "Входит в подписку":
                                    ps_plus = True
                                if "EA_ACCESiS" in price["type"] and price["price"]["discountedPrice"] == "Входит в подписку":
                                    ea_access = True
                                if "UPSELL_PS_PLUS_DISCOUNT" == price["type"]:
                                    ps_price_ua = price["price"]["discountedValue"]/100
                                if "UPSELL_EA_ACCESS_DISCOUNT" == price["type"]:
                                    ea_price_ua = price["price"]["discountedValue"]/100
                                if price["price"]["discountText"] and price["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"]:
                                    discount = price["price"]["discountText"]
                                if price["price"]["endTime"] and price["type"] in ["ADD_TO_CART", "PREORDER", "BUY_NOW"]:
                                    discount_end = datetime.fromtimestamp(int(price["price"]["endTime"])//1000)

                    if tr_price_products:
                        for _trl in tr_price_products:
                            if _trl["id"] == ID and _trl.get("webctas"):
                                tr_price_products = _trl
                                break
                        else:
                            tr_price_products = tr_price_products[0]
                    else:
                        async with session.get("https://web.np.playstation.com/api/graphql/v1/op", params=params_price, headers=json_headers(tr_url)) as tr_resp_price:
                            tr_price = await tr_resp_price.text()
                            tr_price = loads(tr_price)
                            tr_price_products = tr_price["data"]["productRetrieve"]


                    if tr_price_products["id"] == ID:
                        for trl in tr_price_products["webctas"]:
                            if trl["type"] in ["ADD_TO_CART", "PREORDER"] or ("UPSELL" in trl["type"] and ("EA_ACCESS" in trl["type"] or "PS_PLUS" in trl["type"]) and "TRIAL" not in trl["type"]):
                                # if trl["type"] in ["ADD_TO_CART", "PREORDER"] or "UPSELL" in trl["type"]:
                                    if trl["price"]["discountedPrice"] and trl["type"] in ["ADD_TO_CART", "PREORDER"] and not trl_price:
                                        trl_price = trl["price"]["discountedValue"]/100
                                    if trl["price"]["basePrice"] and trl["type"] in ["ADD_TO_CART", "PREORDER"] and not trl_old_price:
                                        trl_old_price = trl["price"]["basePriceValue"]/100
                                    if "PS_PLUS" in trl["type"] and trl["price"]["discountedPrice"] == "Входит в подписку":
                                        ps_plus = True
                                    if "EA_ACCESS" in trl["type"] and trl["price"]["discountedPrice"] == "Входит в подписку":
                                        ea_access = True
                                    if "UPSELL_PS_PLUS_DISCOUNT" == trl["type"]:
                                        ps_price_tr = trl["price"]["discountedValue"]/100
                                    if "UPSELL_EA_ACCESS_DISCOUNT" == trl["type"]:
                                        ea_price_tr = trl["price"]["discountedValue"]/100

                    edition = ua_price_product["skus"][0]["name"]

                    localization = 4

                    if voice_languages:
                        if "русский" in voice_languages.lower():
                            localization -= 2
                    if subtitles:
                        if "русский" in subtitles.lower():
                            localization -= 1

                    if not uah_price:
                        uah_price = uah_old_price
                    if not trl_price:
                        trl_price = trl_old_price

                    for t in range(len(tags)):
                        for c in ['tm', 'TM', '®', '©', '℗', '℠', 'R', "’"]:
                            to_replace = ""
                            if c == "’":
                                to_replace = "'"
                            tags[t] = tags[t].replace(c, to_replace)

                    result.append({"id": ID,
                                "category": category,
                                "type": product_type,
                                "name": name,
                                "main_name": main_name,
                                "image": image,
                                "compound": compound,
                                "platforms": platforms,
                                "publisher": publisher,
                                "localization": localization,
                                "rating": stars,
                                "info": ext_info,
                                "uah_price": uah_price,
                                "uah_old_price": uah_old_price,
                                "ps_price_ua": ps_price_ua,
                                "ps_price_tr": ps_price_tr,
                                "ea_price_ua": ea_price_ua,
                                "ea_price_tr": ea_price_tr,
                                "trl_price": trl_price,
                                "trl_old_price": trl_old_price,
                                "ps_plus": ps_plus,
                                "ea_access": ea_access,
                                "discount": discount,
                                "discount_end": discount_end,
                                "tags": set(tags),
                                "edition": edition,
                                "description": description})
                return result

            except (asyncio.CancelledError, KeyboardInterrupt):
                return []

        except (asyncio.CancelledError, KeyboardInterrupt):
                return []

        except:
            counter += 1
            await asyncio.sleep(5)
    else:
        return []

def uni(non_uni: list):
    seen = set()
    for_del = []


    for idx, ele in enumerate(non_uni):
        if (ele["name"], ele["edition"], " ".join(ele["platforms"]) if ele["platforms"] else None, ele["description"]) in seen:
            for_del.append(idx)
        else:
            seen.add((ele["name"], ele["edition"], " ".join(ele["platforms"]) if ele["platforms"] else None, ele["description"]))


    for idx in reversed(for_del):
        del non_uni[idx]

async def get_promos(session: aiohttp.ClientSession, url: str):

    async def _get_names(session: aiohttp.ClientSession, page_url: str):
        async with session.get(page_url, headers=page_headers()) as resp:
            html = await resp.text()
        soup = bs(html, "html.parser")
        _main = soup.find("div", {"id": "__next"}).find("main")
        section = _main.find("section", {"class": "ems-sdk-grid"})
        ul = section.find("ul", {"class": "psw-grid-list psw-l-grid"})
        products = ul.find_all("li")
        return [loads(product.find("a")["data-telemetry-meta"])["name"] for product in products]

    pages = await get_pages(session, url)
    shift = 30
    games = []
    for i in range(0, len(pages), shift):
        _games = await asyncio.gather(*[_get_names(session, pages[j]) for j in range(i, min(len(pages), i+shift))])
        games.extend(sum(_games, []))
        await asyncio.sleep(5)
        print("\r"+" "*40+"\r"+f"Get promo names: {min(len(pages), i+shift)*100/len(pages):.2f}%", end="")
    print("\r"+" "*40+"\r"+"Parse promo names: done")
    return games


async def add_update_table():
    conn: asyncpg.Connection = await asyncpg.connect(
                                    user=os.getenv("DB_USER"),
                                    password=os.getenv("DB_PASSWORD"),
                                    database=os.getenv("DB_NAME"),
                                    host="193.17.92.132",
                                    port=5432
                                    )

    await conn.execute("""
        CREATE TABLE IF NOT EXISTS update_info (
            id TEXT,
            edition_id INTEGER,
            currency INTEGER
        )
    """)
    await conn.close()

async def main():
    start = perf_counter()

    await add_update_table()

    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(120)) as session:
        promo = await get_promos(session, "https://store.playstation.com/ru-ua/category/3f772501-f6f8-49b7-abac-874a88ca4897")

        with open("promo.pkl", "wb") as file:
            pickle.dump(promo, file)

        print("Get pages urls...", end="", flush=True)
        pages = await get_pages(session, "https://store.playstation.com/ru-ua/pages/browse")
        addons = await get_pages(session, "https://store.playstation.com/ru-ua/category/51c9aa7a-c0c7-4b68-90b4-328ad11bf42e")
        items = await get_pages(session, "https://store.playstation.com/ru-ua/category/3c49d223-9344-4009-b296-08e168854749")

        print("\r"+" "*40+"\r"+"Parse pages urls: done")
        pages.extend(addons)
        pages.extend(items)

        urls = []
        shift = 30

        print("Get products urls...", end="", flush=True)

        for i in range(0, len(pages), shift):
            _urls = await asyncio.gather(*[get_products(session, pages[j]) for j in range(i, min(len(pages), i+shift))])
            urls.extend(sum(_urls, []))
            await asyncio.sleep(5)
            print("\r"+" "*40+"\r"+f"Get products urls: {min(len(pages), i+shift)*100/len(pages):.2f}%", end="")
        print("\r"+" "*40+"\r"+"Parse products urls: done")
        shift = 250

        products = []

        urls.extend(["https://store.playstation.com/ru-ua/concept/10004507",
                     "https://store.playstation.com/ru-ua/concept/10010783"])

        urls = urls[::-1]


        print("Unquote urls...", end="", flush=True)

        for i in range(0, len(urls), shift):
            _products = sum(await asyncio.gather(*[unquote(session, urls[j]) for j in range(i, min(len(urls), i+shift))]), [])
            products.extend(_products)
            await asyncio.sleep(5)
            print("\r"+" "*40+"\r"+f"Unquote urls: {min(len(urls), i+shift)*100/len(urls):.2f}%", end="")
        print("\r"+" "*40+"\r"+"Unquote urls: done")

        products = list(set(products))

        with open("products.pkl", "wb") as file:
            pickle.dump(products, file)

        shift = 40
        print("Parse products...", end="", flush=True)

        lenght = len(products)
        result = []
        start = perf_counter()

        for i in range(0, len(products), shift):
            _result = sum(await asyncio.gather(*[parse(session, products[j]) for j in range(i, min(lenght, i+shift))]), [])
            result.extend(_result)
            await asyncio.sleep(10)
            end = perf_counter()
            uni(result)
            print("\r"+" "*40+"\r"+f"Parse products: {min(lenght, i+shift)*100/lenght:.2f}%", end="")

    print("\r"+" "*40+f"\rParse products: done\n{end-start:.2f} sec.")

    with open("result.pkl", "wb") as file:
        pickle.dump(result, file)

    _result = {}

    for r in result:
        if r["uah_price"]:
            main_name = ""
            name = ""
            edition = ""
            for c in r["main_name"]:
                if c.isalpha() or c == " ":
                    main_name += c.lower()
            for c in r["name"]:
                if c.isalpha() or c == " ":
                    name += c.lower()
            if r["edition"]:
                for c in r["edition"]:
                    if c.isalpha() or c == " ":
                        edition += c.lower()
            if r["type"] == "Предзаказ":
                if r["rating"]:
                    r["rating"] = .0
                r["localization"] = 15
            if not r["edition"] or main_name == name == edition:
                r["edition"] = ""
            if r["name"] not in _result:
                _result.update({r["name"]: {n: r[n] for n in r}})
            elif r["name"] in r["edition"] and r["edition"] not in _result:
                _result.update({r["edition"]: {n: r[n] for n in r}})
            elif r["name"] not in r["edition"] and r["name"]+" "+r["edition"] not in _result:
                _result.update({r["name"]+" "+r["edition"]: {n: r[n] for n in r}})
            else:
                char = " "
                _count = 1
                while r["name"] + char*_count in _result:
                    _count += 1
                _result.update({r["name"] + char*_count: {n: r[n] for n in r}})

    result = _result

    result_cards = {}

    for card in result:
        if result[card]["uah_price"] or result[card]["trl_price"]:
            if "Подписка PlayStation Plus" not in card and "EA Play на" not in card and "FC Points" not in card and "В-бакс" not in card:
                if result[card]["main_name"] in result_cards:
                    result_cards[result[card]["main_name"]].append(result[card])
                else:
                    result_cards.update({result[card]["main_name"]: [result[card]]})
            else:
                result_cards.update({result[card]["name"]: [result[card]]})

    _result = {}

    for main_name in result_cards:
        if any([product["type"].lower() == "игра" for product in result_cards[main_name]]) and any(["Доп" in product["type"] for product in result_cards[main_name]]):
            games = [product for product in result_cards[main_name] if product["type"].lower() == "игра"]
            addons = [product for product in result_cards[main_name] if "Доп" in product["type"]]
            _result.update({main_name: games})
            _count = 1
            while main_name+" "*_count in result_cards:
                _count += 1
            _result.update({main_name+" "*_count: addons})
        else:
            _result.update({main_name: result_cards[main_name]})

    result_cards = _result

    product_cards = []
    _product_cards = {}
    for k, r in enumerate(result_cards, 1):
        if any([j["type"] == "Игра" for j in result_cards[r]]):
            product_type = "Игра"
            product = min([j for j in result_cards[r] if j["type"] == "Игра"], key=lambda x: x["uah_price"])
        else:
            product = min(result_cards[r], key=lambda x: x["uah_price"])
            product_type = product["type"]
        product_cards.append((k, r, product["image"], product["ea_access"], product["ps_plus"], product["ps_plus"], product["ps_plus"], product["rating"], product_type, product["tags"], datetime.now(), datetime.now(), 'parser'))
        _product_cards.update({k: r})
    edition_names = {}
    editions = []
    _edn = [result[j]["name"] if "Доп" in result[j]["edition"] else result[j]["edition"] for j in result]
    for i, edition in enumerate(set([j for j in _edn if j != None]), 1):
        edition_names.update({edition: (i, edition, datetime.now(), datetime.now())})
    ID = 1
    update_info = []
    for p in product_cards:
        for ed in result_cards[p[1]]:
            edition_name_id = 1
            _id = 0
            if ed["edition"]:
                edition_name_id = edition_names[ed["name"] if "Доп" in ed["edition"] else ed["edition"]][0]
            product_card_id = p[0]
            r = ed
            discount = r["discount"]
            if discount:
                discount = 1-int(discount[1:-1])/100
            else:
                discount = 0
            if r["uah_price"]:
                editions.append([ID, edition_name_id, r["description"], product_card_id, r["uah_price"] / discount if discount else r["uah_price"], 3, r["uah_price"], r["ea_price_ua"], r["ps_price_ua"], r["discount_end"], datetime.now(), datetime.now(), r["type"], 'parser'])
                update_info.append([r["id"], ID, 3])
                _id += 1
            if r["trl_price"]:
                editions.append([ID+_id, edition_name_id, r["description"], product_card_id, r["trl_price"] / discount if discount else r["trl_price"], 2, r["trl_price"], r["ea_price_tr"], r["ps_price_tr"], r["discount_end"], datetime.now(), datetime.now(), r["type"], 'parser'])
                update_info.append([r["id"], ID+_id, 2])
                _id += 1
            ID += _id
    platforms = []
    _ids = {}
    for edition in editions:
        edition_id = edition[0]
        product_card_id = edition[3]
        name = _product_cards[product_card_id]
        for ed in result_cards[name]:
            if name in _ids:
                logical = (ed["id"], edition[5]) not in _ids[name]
            else:
                logical = True
            if logical and ((edition[5] == 3 and (ed["uah_price"] == edition[6] or ed["uah_price"] == edition[4])) or (edition[5] == 2 and (ed["trl_price"] == edition[6] or ed["trl_price"] == edition[4]))):
                if ed["platforms"]:
                    for platform in ed["platforms"]:
                        if "PS4" == platform and [edition_id, 5] not in platforms:
                            platforms.append([edition_id, 5])
                        if "PS5" == platform and [edition_id, 6] not in platforms:
                            platforms.append([edition_id, 6])
                    if name not in _ids:
                        _ids.update({name: [(ed["id"], edition[5])]})
                    else:
                        _ids[name].append((ed["id"], edition[5]))
                    break
    genres = []

    for r in result:
        genres.extend(result[r]["category"])
        genres = list(set(genres))
    _genres = {genre: k for k, genre in enumerate(genres, 1)}
    genres = [(k, genre, datetime.now(), datetime.now()) for k, genre in enumerate(genres, 1)]
    localizations = []
    for edition in editions:
        edition_id = edition[0]
        product_card_id = edition[3]
        name = _product_cards[product_card_id]
        for ed in result_cards[name]:
            if ed["description"] == edition[2]:
                localization = ed["localization"]
                if [edition_id, localization] not in localizations:
                    localizations.append([edition_id, localization])
                break

    for l in localizations:
        l.extend([datetime.now(), datetime.now()])
    product_card_genres = []
    ID = 1
    for card in product_cards:
        card_id = card[0]
        name = card[1]
        r = result_cards[name][0]
        for j in result_cards[name]:
            if j["type"] == "Игра":
                r = j
                break
        for genre in r["category"]:
            product_card_genres.append([ID, card_id, _genres[genre]])
            ID += 1

    product_collection_editions = []
    #[(32 if "EA Play" in k[2] else 29 if "PlayStation Plus" in k[2] else 37, k[0], datetime.now(), datetime.now()) for k in editions]
    for edition in editions:
        edition_id = edition[0]
        product_card_id = edition[3]
        name = _product_cards[product_card_id]
        key = -1
        for n in result_cards[name]:
            if n["description"] == edition[2]:
                name = n["name"]
                break

        if "EA Play на" in name:
            key = 32
        elif "PlayStation Plus" in name:
            key = 29
        elif "FC Points" in name:
            key = 13
        elif "В-бакс" in name and "Fortnite" in name:
            key = 12
        elif name in promo:
            key = 37
        if key >= 0:
            product_collection_editions.append([key, edition_id, datetime.now(), datetime.now()])

    connection: asyncpg.Connection = await asyncpg.connect(
                                        user=os.getenv("DB_USER"),
                                        password=os.getenv("DB_PASSWORD"),
                                        database=os.getenv("DB_NAME"),
                                        host="193.17.92.132",
                                        port=5432
                                    )
    # Удаляем только записи, добавленные парсером
    await connection.execute('DELETE FROM "ProductCards" WHERE source = \'parser\'')
    await connection.executemany("""
                    INSERT INTO "ProductCards" (
                        id, name, image_url, free_with_ea_play,
                        free_with_ps_plus_essential, free_with_ps_plus_extra,
                        free_with_ps_plus_deluxe, rating, edition_type, tags,
                        created_at, updated_at, source
                    )
                    VALUES (
                        $1, $2, $3, $4,
                        $5, $6, $7, $8,
                        $9, $10, $11, $12, $13
                    )
                    """, product_cards)
    # EditionNames могут использоваться и manual записями, поэтому удаляем только неиспользуемые
    await connection.execute('''
        DELETE FROM "EditionNames"
        WHERE id NOT IN (
            SELECT DISTINCT edition_name_id
            FROM "Editions"
            WHERE source = 'manual' AND edition_name_id IS NOT NULL
        )
    ''')
    await connection.executemany("""
                             INSERT INTO "EditionNames" (
                                id, name,
                                created_at, updated_at
                             )
                             VALUES (
                                $1, $2, $3, $4
                             )
                             """, list(edition_names.values()))

    # Удаляем только издания, добавленные парсером
    await connection.execute('DELETE FROM "Editions" WHERE source = \'parser\'')
    await connection.executemany("""
                                 INSERT INTO "Editions" (
                                    id, edition_name_id, description,
                                    product_card_id, price, display_currency_id,
                                    discount_amount, ea_play_price, ps_plus_price,
                                    promotion_end_date, created_at, updated_at, product_type, source
                                 )
                                 VALUES (
                                    $1, $2, $3, $4,
                                    $5, $6, $7, $8,
                                    $9, $10, $11, $12,
                                    $13, $14
                                 )
                                 """, editions)

    # Удаляем платформы только для изданий парсера
    await connection.execute('DELETE FROM "edition_platforms" WHERE edition_id IN (SELECT id FROM "Editions" WHERE source = \'parser\')')
    await connection.executemany("""
                                 INSERT INTO "edition_platforms" (
                                    edition_id, platform_id
                                 )
                                 VALUES (
                                    $1, $2
                                 )
                                 """, platforms)

    # Genres могут использоваться и manual записями, поэтому удаляем только неиспользуемые
    await connection.execute('''
        DELETE FROM "Genres"
        WHERE id NOT IN (
            SELECT DISTINCT pcg.genre_id
            FROM "ProductCardGenres" pcg
            JOIN "ProductCards" pc ON pcg.product_card_id = pc.id
            WHERE pc.source = 'manual'
        )
    ''')
    await connection.executemany("""
                                 INSERT INTO "Genres" (
                                    id, name,
                                    created_at,
                                    updated_at
                                 )
                                 VALUES (
                                    $1, $2, $3, $4
                                 )
                                 """, genres)

    # Удаляем локализации только для изданий парсера
    await connection.execute('DELETE FROM "edition_localizations" WHERE edition_id IN (SELECT id FROM "Editions" WHERE source = \'parser\')')
    await connection.executemany("""
                                 INSERT INTO "edition_localizations" (
                                    edition_id, localization_id,
                                    "createdAt", "updatedAt"
                                 )
                                 VALUES (
                                    $1, $2, $3, $4
                                 )
                                 """, localizations)
    # Удаляем жанры только для карточек парсера
    await connection.execute('DELETE FROM "ProductCardGenres" WHERE product_card_id IN (SELECT id FROM "ProductCards" WHERE source = \'parser\')')
    await connection.executemany("""
                                 INSERT INTO "ProductCardGenres" (
                                    id,
                                    product_card_id,
                                    genre_id
                                 )
                                 VALUES (
                                    $1, $2, $3
                                 )
                                 """, product_card_genres)

    # Удаляем коллекции только для изданий парсера
    await connection.execute('DELETE FROM "ProductCollectionEditions" WHERE edition_id IN (SELECT id FROM "Editions" WHERE source = \'parser\')')
    await connection.executemany("""
                                 INSERT INTO "ProductCollectionEditions" (
                                    product_collection_id, edition_id,
                                    created_at, updated_at
                                 )
                                 VALUES (
                                    $1, $2, $3, $4
                                 )
                                 """, product_collection_editions)
    await connection.execute('DELETE FROM "update_info"')
    await connection.executemany("""INSERT INTO "update_info" (
                                        id,
                                        edition_id,
                                        currency
                                    )
                                    VALUES (
                                        $1, $2, $3
                                    )""", update_info)
    await connection.close()
    end = perf_counter()
    print(f"Total time: {end-start:.2f} sec")

if __name__ == "__main__":
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(main())
    except KeyboardInterrupt:
        pass
    finally:
        print("\nGoodbye")
