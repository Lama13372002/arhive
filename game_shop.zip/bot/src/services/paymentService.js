import bot from '../config/botConfig.js';

export const MANAGER_CHAT_ID = -1002272015106;

// Проверяем наличие необходимых переменных окружения
const { TELEGRAM_WEB_APP_URL } = process.env;

if (!TELEGRAM_WEB_APP_URL) {
	throw new Error(
		'Missing required environment variable: TELEGRAM_WEB_APP_URL'
	);
}

export class PaymentService {
	constructor(bot) {
		this.bot = bot;
		this.activeChats = new Map(); // Хранилище активных диалогов после покупки
		this.MANAGER_CHAT_ID = MANAGER_CHAT_ID;
	}

	// Поиск пользователя по ID топика
	findUserIdByTopicId(topicId) {
		for (const [userId, chatInfo] of this.activeChats.entries()) {
			if (chatInfo.topicId === topicId) {
				return userId;
			}
		}
		return null;
	}

	// Закрытие диалога
	async closeDialog(userId, initiator = 'user') {
		const chatInfo = this.activeChats.get(userId);
		if (!chatInfo) return;

		try {
			// Отправляем сообщение пользователю
			await this.bot.sendMessage(
				userId,
				'Диалог по вашему заказу завершен. Спасибо за покупку!',
				{
					reply_markup: { remove_keyboard: true },
				}
			);

			// Отправляем сообщение в чат менеджеров
			if (chatInfo.topicId) {
				await this.bot.sendMessage(
					this.MANAGER_CHAT_ID,
					`Диалог с пользователем ${
						chatInfo.username
					} (${userId}) завершен ${
						initiator === 'user' ? 'пользователем' : 'менеджером'
					}.`,
					{ message_thread_id: chatInfo.topicId }
				);
			}
		} catch (error) {
			console.error('Error closing dialog:', error);
		} finally {
			this.activeChats.delete(userId);
		}
	}

	// Отправка уведомления менеджерам о новой покупке
	async sendManagerNotification({
		telegramUsername,
		telegramId,
		gameInfo,
		checkoutWithoutAccount,
		firstName,
		lastName,
		customerEmail,
		birthDate,
		psLogin,
		psPassword,
		psBackupCodes,
		currency,
	}) {
		try {
			// Логируем входящие данные для отладки
			console.log('sendManagerNotification received data:', {
				telegramUsername,
				telegramId,
				gameInfoCount: gameInfo?.length || 0,
				checkoutWithoutAccount,
				firstName: firstName ? 'provided' : 'not provided',
				lastName: lastName ? 'provided' : 'not provided',
				customerEmail: customerEmail ? 'provided' : 'not provided',
				birthDate: birthDate ? 'provided' : 'not provided',
				psLogin: psLogin ? 'provided' : 'not provided',
				psPassword: psPassword ? 'provided' : 'not provided',
				psPasswordType: typeof psPassword,
				psPasswordLength: psPassword ? psPassword.length : 0,
				psBackupCodes: psBackupCodes ? 'provided' : 'not provided',
				currency: currency ? 'provided' : 'not provided',
			});

			// Создаем топик в чате менеджеров
			const gamesCount = gameInfo.length;
			const userIdentifier = telegramUsername
				? `${telegramUsername}`
				: `ID:${telegramId}`;

			// Форматируем название игры для заголовка темы
			const formatGameTitle = game => {
				const editionType = game.edition_type || 'Game';
				const title = game.title || '';
				const editionName = game.editionName || 'Standard Edition';

				return `${editionType} – ${title} ${
					editionName !== 'Standard Edition' ? editionName : ''
				}`;
			};

			const topicTitle =
				gamesCount === 1
					? `🛒 Покупка – ${formatGameTitle(
							gameInfo[0]
					  )} | ${userIdentifier}`
					: `🛒 Покупка ${gamesCount} игр | ${userIdentifier}`;

			const topic = await this.bot.createForumTopic(
				this.MANAGER_CHAT_ID,
				topicTitle
			);
			const topicId = topic.message_thread_id;

			// Функция форматирования цены
			const formatPrice = price => {
				const num = Number(price);
				return num.toFixed(2);
			};

			// Функция получения символа валюты
			const getCurrencySymbol = currencyObj => {
				if (typeof currencyObj === 'string') return currencyObj;
				if (currencyObj && typeof currencyObj === 'object') {
					return currencyObj.symbol || currencyObj.code || 'руб.';
				}
				return 'руб.';
			};

			// Формируем детальную информацию о каждой игре
			const gamesDetails = gameInfo
				.map(
					game => `
Игра: ${formatGameTitle(game)}
Тип: ${game.edition_type || 'Game'}
Издание: ${game.editionName || 'Standard'}
Стоимость: ${formatPrice(
						game.finalPrice || game.discount_amount || game.price
					)} ${getCurrencySymbol(currency)} ${
						// Проверяем наличие скидки
						game.discount_amount &&
						game.price &&
						game.discount_amount < game.price
							? `(обычная цена: ${formatPrice(
									game.price
							  )} ${getCurrencySymbol(currency)})`
							: game.originalPrice
							? `(изначально: ${formatPrice(
									game.originalPrice
							  )} ${
									game.originalCurrency ||
									getCurrencySymbol(currency)
							  })`
							: ''
					}
Товар в админ-панели: ${TELEGRAM_WEB_APP_URL}admin/resources/Editions/records/${
						game.editionId
					}/show`
				)
				.join('\n');

			// Проверяем наличие данных аккаунта
			const hasAccountData =
				// Проверяем, что это НЕ оформление без аккаунта
				!(
					checkoutWithoutAccount === true ||
					checkoutWithoutAccount === 'true'
				) &&
				// И есть логин
				psLogin &&
				psLogin.trim() !== '';

			// Выводим больше диагностической информации
			console.log('Account data check details:', {
				checkoutWithoutAccount,
				checkoutWithoutAccountType: typeof checkoutWithoutAccount,
				psLogin,
				psPassword: psPassword ? 'exists' : 'missing',
				psPasswordType: typeof psPassword,
				psPasswordLength: psPassword ? psPassword.length : 0,
				hasLoginValue: Boolean(psLogin && psLogin.trim() !== ''),
				finalDecision: hasAccountData,
			});

			// Prepare purchase details based on checkout type
			let purchaseDetails;
			if (hasAccountData) {
				console.log(
					'Creating notification for checkout with existing account'
				);
				// Убедимся, что psPassword обрабатывается как строка
				const passwordToShow = psPassword
					? String(psPassword)
					: 'Не указано';

				purchaseDetails = `
Аккаунт PS Store:
Логин: ${psLogin}
Пароль: ${passwordToShow}
Резервные коды: ${psBackupCodes || 'Не указано'}

Данные заказа:
Telegram ID: ${telegramId}
Юзернейм: ${telegramUsername ? '@' + telegramUsername : 'Отсутствует'}

Информация об играх:
${gamesDetails}`;
			} else {
				console.log(
					'Creating notification for checkout without account',
					{
						checkoutWithoutAccount,
						hasAccountData,
						firstName,
						lastName,
						customerEmail,
					}
				);
				purchaseDetails = `
Новая покупка!
Нужно создать аккаунт 👤

Личные данные:
Имя: ${firstName || 'Не указано'}
Фамилия: ${lastName || 'Не указано'}
Email: ${customerEmail || 'Не указано'}
Дата рождения: ${birthDate || 'Не указано'}

Данные заказа:
Telegram ID: ${telegramId}
Юзернейм: ${telegramUsername ? '@' + telegramUsername : 'Отсутствует'}

Информация об играх:
${gamesDetails}`;
			}

			// Добавляем потерянный лог перед отправкой сообщения
			console.log('Generated purchase details with type:', {
				hasAccountData,
				checkoutWithoutAccount,
				hasLogin: Boolean(psLogin),
			});

			// Отправляем детальную информацию о заказе
			await this.bot.sendMessage(this.MANAGER_CHAT_ID, purchaseDetails, {
				message_thread_id: topicId,
			});

			// Сообщение о команде закрытия диалога
			await this.bot.sendMessage(
				this.MANAGER_CHAT_ID,
				'Для завершения диалога используйте команду /close',
				{
					message_thread_id: topicId,
				}
			);

			// Возвращаем ID топика для сохранения в activeChats
			return topicId;
		} catch (error) {
			console.error('Error sending manager notification:', error);
			throw error;
		}
	}

	async sendPaymentNotification(
		telegramUsername,
		gameInfo,
		telegramId,
		checkoutWithoutAccount,
		psLogin,
		psPassword,
		psBackupCodes,
		firstName,
		lastName,
		customerEmail,
		birthDate,
		paymentStatus,
		currency
	) {
		try {
			// Проверяем, что платеж действительно оплачен
			if (paymentStatus !== 'paid') {
				console.log('Payment not yet completed, skipping notification');
				return;
			}

			console.log('Sending payment notification:', {
				username: telegramUsername,
				gamesCount: gameInfo.length,
				telegramId: telegramId,
				telegramIdType: typeof telegramId,
				checkoutWithoutAccount,
				psLogin: psLogin ? 'provided' : 'not provided',
				psPassword: psPassword ? 'provided' : 'not provided',
				psPasswordType: typeof psPassword,
				psPasswordLength: psPassword ? psPassword.length : 0,
				status: paymentStatus,
			});

			// Функция форматирования цены
			const formatPrice = price => {
				const num = Number(price);
				return num.toFixed(2);
			};

			// Функция получения символа валюты
			const getCurrencySymbol = currencyObj => {
				if (typeof currencyObj === 'string') return currencyObj;
				if (currencyObj && typeof currencyObj === 'object') {
					return currencyObj.symbol || currencyObj.code || 'руб.';
				}
				return 'руб.';
			};

			// Формируем список игр для сообщения пользователю
			const gamesList = gameInfo
				.map(game => {
					const editionType = game.edition_type || 'Game';
					const title = game.title || '';
					const editionName = game.editionName || 'Standard Edition';

					// Формируем строку с названием игры
					let gameString = `${editionType} – ${title} ${
						editionName !== 'Standard Edition' ? editionName : ''
					}`;

					return gameString;
				})
				.join('\n\n');

			// Send message to user with keyboard
			await this.bot.sendMessage(
				telegramId,
				`Покупка прошла успешно!\n\nКуплено:\n${gamesList}\n\nОжидайте сообщения от менеджера.`,
				{
					reply_markup: {
						keyboard: [['Завершить диалог']],
						resize_keyboard: true,
						one_time_keyboard: false,
					},
				}
			);

			// Отправляем сообщение в чат менеджеров
			console.log('Preparing notification with data:', {
				checkoutWithoutAccount,
				firstName,
				lastName,
				customerEmail,
				birthDate,
				psLogin,
				psPassword,
				psBackupCodes,
			});

			// Отправляем сообщение в чат менеджеров и получаем ID топика
			const topicId = await this.sendManagerNotification({
				telegramUsername,
				telegramId,
				gameInfo,
				checkoutWithoutAccount,
				firstName,
				lastName,
				customerEmail,
				birthDate,
				psLogin,
				psPassword,
				psBackupCodes,
				currency,
			});

			// Проверяем, что topicId получен
			if (!topicId) {
				console.error(
					'Failed to get topicId from sendManagerNotification'
				);
				return;
			}

			// Преобразуем telegramId в число, если это строка
			// Telegram API всегда использует числовые ID пользователей
			const userIdKey = Number(telegramId);

			// Сохраняем информацию о диалоге
			this.activeChats.set(userIdKey, {
				status: 'active',
				username: telegramUsername || userIdKey.toString(),
				topicId: topicId,
				chatId: userIdKey,
			});

			console.log('Saved active chat info:', {
				telegramId: userIdKey,
				telegramIdType: typeof userIdKey,
				username: telegramUsername || userIdKey.toString(),
				topicId,
				activeChatsSize: this.activeChats.size,
				activeChatsKeys: Array.from(this.activeChats.keys()),
			});
		} catch (error) {
			console.error('Error sending payment notification:', error);
			throw error;
		}
	}

	setup() {
		// Handle all incoming messages
		this.bot.on('message', async msg => {
			if (!msg.text) return;

			try {
				const userId = Number(msg.from?.id);
				if (!userId) return;

				// Добавляем логирование для диагностики
				console.log('Received message in paymentService:', {
					userId: userId,
					userIdType: typeof userId,
					chatType: msg.chat?.type,
					isPrivate: msg.chat?.type === 'private',
					hasChatInfo: Boolean(this.activeChats.get(userId)),
					chatInfo: this.activeChats.get(userId),
					chatId: msg.chat?.id,
					messageText:
						msg.text?.substring(0, 30) +
						(msg.text?.length > 30 ? '...' : ''),
					activeChatsSize: this.activeChats.size,
					activeChatsKeys: Array.from(this.activeChats.keys()),
				});

				// Проверяем наличие чата в Map
				let chatInfo = this.activeChats.get(userId);

				// Если не нашли по числовому ID, попробуем найти по строковому
				if (!chatInfo && typeof userId === 'number') {
					chatInfo = this.activeChats.get(String(userId));

					// Если нашли по строковому ID, обновим Map с числовым ключом
					if (chatInfo) {
						console.log(
							`Found chat info by string ID, updating to numeric ID: ${userId}`
						);
						this.activeChats.delete(String(userId));
						this.activeChats.set(userId, chatInfo);
					}
				}

				// Обработка сообщений от пользователя в приватном чате
				if (msg.chat?.type === 'private' && chatInfo) {
					if (msg.text === 'Завершить диалог') {
						await this.closeDialog(userId);
						return;
					}

					console.log('Forwarding message from user to managers:', {
						userId,
						userIdType: typeof userId,
						managerChatId: this.MANAGER_CHAT_ID,
						topicId: chatInfo.topicId,
						messageText:
							msg.text?.substring(0, 30) +
							(msg.text?.length > 30 ? '...' : ''),
					});

					// Пересылаем сообщение в топик менеджеров
					try {
						await this.bot.sendMessage(
							this.MANAGER_CHAT_ID,
							`Сообщение от пользователя:\n${msg.text}`,
							{ message_thread_id: chatInfo.topicId }
						);
						console.log(
							'Successfully forwarded user message to managers'
						);
					} catch (forwardError) {
						console.error(
							'Error forwarding message to managers:',
							forwardError,
							{
								managerChatId: this.MANAGER_CHAT_ID,
								topicId: chatInfo.topicId,
							}
						);
					}
					return;
				} else if (msg.chat?.type === 'private') {
					console.log(
						'Received private message but no active chat found:',
						{
							userId,
							userIdType: typeof userId,
							messageText:
								msg.text?.substring(0, 30) +
								(msg.text?.length > 30 ? '...' : ''),
							activeChatsKeys: Array.from(
								this.activeChats.keys()
							),
							activeChatsKeysTypes: Array.from(
								this.activeChats.keys()
							).map(key => typeof key),
						}
					);
				}

				// Обработка сообщений от менеджеров
				if (
					msg.chat.id === this.MANAGER_CHAT_ID &&
					msg.message_thread_id
				) {
					const topicId = msg.message_thread_id;
					const userIdFromTopic = this.findUserIdByTopicId(topicId);

					console.log('Processing manager message:', {
						topicId,
						foundUserId: userIdFromTopic,
						messageText:
							msg.text?.substring(0, 30) +
							(msg.text?.length > 30 ? '...' : ''),
					});

					if (userIdFromTopic && msg.text) {
						if (msg.text === '/close') {
							await this.closeDialog(userIdFromTopic, 'manager');
							return;
						}

						console.log(
							'Forwarding message from manager to user:',
							{
								userId: userIdFromTopic,
								topicId,
								messageText:
									msg.text?.substring(0, 30) +
									(msg.text?.length > 30 ? '...' : ''),
							}
						);

						// Пересылаем сообщение пользователю
						try {
							await this.bot.sendMessage(
								userIdFromTopic,
								`Сообщение от менеджера:\n${msg.text}`
							);
							console.log(
								'Successfully forwarded manager message to user'
							);
						} catch (forwardError) {
							console.error(
								'Error forwarding message to user:',
								forwardError
							);
						}
					}
				}
			} catch (error) {
				console.error('Error handling message:', error);
			}
		});

		// Handle callback queries
		this.bot.on('callback_query', async query => {
			if (!query.data.startsWith('close_dialog:')) return;

			try {
				const threadId = query.data.split(':')[1];
				const userIdFromTopic = this.findUserIdByTopicId(threadId);

				if (userIdFromTopic) {
					await this.closeDialog(userIdFromTopic, 'manager');
				}

				// Acknowledge callback
				await this.bot.answerCallbackQuery(query.id, {
					text: 'Диалог успешно завершен',
				});
			} catch (error) {
				console.error('Error closing dialog:', error);
				await this.bot.answerCallbackQuery(query.id, {
					text: 'Ошибка при закрытии диалога',
				});
			}
		});

		console.log('Payment service message handler registered');
	}
}

// Создаем экземпляр сервиса и инициализируем его
const paymentService = new PaymentService(bot);
paymentService.setup();

// Экспортируем экземпляр для использования в других модулях
export default paymentService;
