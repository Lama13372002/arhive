import { getSettings, BOT_USERNAME } from '../config/constants.js';

const getStartKeyboard = async () => {
	const settings = await getSettings();
	return {
		reply_markup: {
			inline_keyboard: [
				[
					{
						text: '🎮 Открыть магазин',
						web_app: { url: settings.shopButtonUrl },
					},
				],
				[
					{
						text: '❓ Помощь',
						url: `https://t.me/${BOT_USERNAME}?start=support`,
					},
				],
				[
					{
						text: '📝 Отзывы',
						url: settings.reviewsButtonUrl,
					},
				],
			],
		},
	};
};

export default getStartKeyboard;
