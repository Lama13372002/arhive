import dotenv from 'dotenv';
import TelegramBot from 'node-telegram-bot-api';

dotenv.config('{path: .env}');

const token = process.env.BOT_TOKEN;

// Расширенные настройки для polling
const pollingOptions = {
	polling: {
		interval: 300,
		autoStart: true,
		params: {
			timeout: 10,
		},
	},
};

console.log('Initializing Telegram bot with polling');
const bot = new TelegramBot(token, pollingOptions);

// Добавляем обработчик ошибок для бота
bot.on('polling_error', error => {
	console.error('Polling error:', error);
});

// Логируем успешный запуск polling
bot.on('polling_start', () => {
	console.log('Bot polling started successfully');
});

export const sendMessage = (chatId, text, options) =>
	bot.sendMessage(chatId, text, options);

export const onText = (regex, callback) => bot.onText(regex, callback);

export default bot;
