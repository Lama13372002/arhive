import { sendMessage } from '../config/botConfig.js';
import { getSettings } from '../config/constants.js';
import getStartKeyboard from '../keyboards/startKeyboard.js';
import { saveOrUpdateTelegramUser } from '../services/userService.js';

async function handleStart(msg) {
    const chatId = msg.chat.id;
    try {
        // Сохраняем данные пользователя
        const telegramId = msg.from.id.toString();
        const telegramUsername = msg.from.username || null;
        await saveOrUpdateTelegramUser(telegramId, telegramUsername);

        // Отправляем приветственное сообщение
        const settings = await getSettings();
        const keyboard = await getStartKeyboard();
        sendMessage(chatId, settings.welcomeMessage, keyboard);
    } catch (error) {
        console.error('Error in handleStart:', error);
        sendMessage(
            chatId,
            'Извините, произошла ошибка. Пожалуйста, попробуйте позже.'
        );
    }
}

export default handleStart;
