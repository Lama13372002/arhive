import { createRouter, createWebHistory } from 'vue-router';
import CollectionScreen from '../components/screens/CollectionScreen.vue';
import CreatePSAccountScreen from '../components/screens/CreatePSAccountScreen.vue';
import EaPlayCollectionScreen from '../components/screens/EaPlayCollectionScreen.vue';
import FailurePayment from '../components/screens/FailurePayment.vue';
import FavouritesScreen from '../components/screens/FavouritesScreen.vue';
import HomeScreen from '../components/screens/HomeScreen.vue';
import ItemCardScreen from '../components/screens/ItemCardScreen.vue';
import PaymentScreen from '../components/screens/PaymentScreen.vue';
import ProfileScreen from '../components/screens/ProfileScreen.vue';
import PsPlusDeluxeCollectionScreen from '../components/screens/PsPlusDeluxeCollectionScreen.vue';
import PsPlusEssentialCollectionScreen from '../components/screens/PsPlusEssentialCollectionScreen.vue';
import PsPlusExtraCollectionScreen from '../components/screens/PsPlusExtraCollectionScreen.vue';
import SearchResultsScreen from '../components/screens/SearchResultsScreen.vue';
import ShopBagScreen from '../components/screens/ShopBagScreen.vue';
import SuccessPayment from '../components/screens/SuccessPayment.vue';
import SupportScreen from '../components/screens/SupportScreen.vue';

const routes = [
	{
		path: '/',
		name: 'Home',
		component: HomeScreen,
		meta: { depth: 0 },
	},
	{
		path: '/profile',
		name: 'Profile',
		component: ProfileScreen,
		meta: { depth: 1 },
	},
	{
		path: '/favourites',
		name: 'Favourites',
		component: FavouritesScreen,
		meta: { depth: 1 },
	},
	{
		path: '/create-ps-account',
		name: 'CreatePSAccount',
		component: CreatePSAccountScreen,
		meta: { depth: 2 },
	},
	{
		path: '/shop-bag',
		name: 'ShopBag',
		component: ShopBagScreen,
		meta: { depth: 1 },
	},
	{
		path: '/search-results',
		name: 'SearchResults',
		component: SearchResultsScreen,
		meta: { depth: 1 },
	},
	{
		path: '/payment',
		name: 'Payment',
		component: PaymentScreen,
		meta: { depth: 2 },
	},
	{
		path: '/support',
		name: 'Support',
		component: SupportScreen,
		meta: { depth: 1 },
	},
	{
		path: '/collection/:id',
		name: 'Collection',
		component: CollectionScreen,
		meta: { depth: 2 },
	},
	{
		path: '/item/:id',
		name: 'ItemCard',
		component: ItemCardScreen,
		meta: { depth: 2 },
		props: true,
	},
	{
		path: '/success-payment',
		name: 'SuccessPayment',
		component: SuccessPayment,
		meta: { depth: 3 },
	},
	{
		path: '/failure-payment',
		name: 'FailurePayment',
		component: FailurePayment,
		meta: { depth: 3 },
	},
	{
		path: '/ea-play-collection',
		name: 'ea-play-collection',
		component: EaPlayCollectionScreen,
		meta: { depth: 3 },
	},
	{
		path: '/ps-plus-extra-collection',
		name: 'ps-plus-extra-collection',
		component: PsPlusExtraCollectionScreen,
		meta: { depth: 3 },
	},
	{
		path: '/ps-plus-essential-collection',
		name: 'ps-plus-essential-collection',
		component: PsPlusEssentialCollectionScreen,
		meta: { depth: 3 },
	},
	{
		path: '/ps-plus-deluxe-collection',
		name: 'ps-plus-deluxe-collection',
		component: PsPlusDeluxeCollectionScreen,
		meta: { depth: 3 },
	},
];

const router = createRouter({
	history: createWebHistory(),
	routes,
});

router.beforeEach((to, from, next) => {
	if (window.Telegram && window.Telegram.WebApp) {
		if (to.path !== '/') {
			window.Telegram.WebApp.BackButton.show();
		} else {
			window.Telegram.WebApp.BackButton.hide();
		}

		window.Telegram.WebApp.BackButton.onClick(() => {
			router.back();
		});

		console.log(`Navigating to: ${to.path}`);
		console.log(`BackButton visibility: ${to.path !== '/'}`);
	}
	next();
});

router.afterEach((to, from) => {
	if (window.Telegram && window.Telegram.WebApp) {
		window.Telegram.WebApp.expand();
	}
});

export default router;
