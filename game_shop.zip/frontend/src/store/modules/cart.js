export default {
	namespaced: true,
	state: {
		items: [],
		promoDiscount: 0,
		appliedPromoCode: null,
		promoStatus: '', // Добавляем новое состояние
		serverCalculatedTotal: null, // Добавляем поле для хранения серверного расчета
		currencyId: null, // Добавляем поле для хранения ID валюты корзины
	},
	mutations: {
		SET_CART_ITEMS(state, items) {
			state.items = items;
		},
		ADD_TO_CART(state, item) {
			const existingItem = state.items.find(i => i.id === item.id);
			if (!existingItem) {
				const itemWithDiscount = {
					...item,
					discount_amount: item.discount_amount || 0,
					edition_type: item.edition_type,
					editionName: item.editionName,
					productId: item.productId, // Добавляем productId
					platforms: item.platforms || [], // добавляем платформы из издания
					priceType: item.priceType, // сохраняем тип цены (ea_play, ps_plus и т.д.)
					currencyId: state.currencyId, // Добавляем ID валюты при добавлении товара
				};
				state.items.push(itemWithDiscount);
			}
		},
		REMOVE_FROM_CART(state, itemId) {
			state.items = state.items.filter(item => item.id !== itemId);
			// Сбрасываем серверный расчет при изменении корзины
			state.serverCalculatedTotal = null;
		},
		CLEAR_CART(state) {
			state.items = [];
			state.promoDiscount = 0;
			state.appliedPromoCode = null;
			state.promoStatus = ''; // Очищаем статус
			state.serverCalculatedTotal = null; // Очищаем серверный расчет
			state.currencyId = null; // Сбрасываем ID валюты корзины
		},
		SET_PROMO_DISCOUNT(state, discount) {
			state.promoDiscount = discount;
			// Сбрасываем серверный расчет при изменении скидки
			state.serverCalculatedTotal = null;
		},
		SET_PROMO_CODE(state, code) {
			state.appliedPromoCode = code;
		},
		SET_PROMO_STATUS(state, status) {
			// Новая мутация
			state.promoStatus = status;
		},
		CLEAR_PROMO(state) {
			state.promoDiscount = 0;
			state.appliedPromoCode = null;
			state.promoStatus = ''; // Очищаем статус
			// Сбрасываем серверный расчет при очистке промокода
			state.serverCalculatedTotal = null;
		},
		// Добавляем новую мутацию для установки серверного расчета
		SET_SERVER_CALCULATED_TOTAL(state, total) {
			state.serverCalculatedTotal = total;
		},
		// Добавляем новую мутацию для установки ID валюты корзины
		SET_CART_CURRENCY_ID(state, currencyId) {
			state.currencyId = currencyId;
		},
	},
	actions: {
		loadCart({ commit, rootGetters }) {
			try {
				const savedCart = localStorage.getItem('cart');
				const items = savedCart ? JSON.parse(savedCart) : [];
				const savedPromoDiscount =
					localStorage.getItem('promoDiscount');
				const savedPromoCode = localStorage.getItem('promoCode');
				const savedPromoStatus = localStorage.getItem('promoStatus'); // Загружаем статус
				const savedCurrencyId = localStorage.getItem('cartCurrencyId');

				commit('SET_CART_ITEMS', items);
				if (savedPromoDiscount && savedPromoCode) {
					commit('SET_PROMO_DISCOUNT', Number(savedPromoDiscount));
					commit('SET_PROMO_CODE', savedPromoCode);
					commit('SET_PROMO_STATUS', savedPromoStatus); // Устанавливаем статус
				}

				// Устанавливаем ID валюты корзины
				if (savedCurrencyId) {
					commit('SET_CART_CURRENCY_ID', Number(savedCurrencyId));
				} else {
					// Если ID валюты корзины не сохранен, используем текущую валюту пользователя
					const currentCurrency = rootGetters['user/currentCurrency'];
					if (currentCurrency?.id) {
						commit('SET_CART_CURRENCY_ID', currentCurrency.id);
						localStorage.setItem(
							'cartCurrencyId',
							currentCurrency.id
						);
					}
				}
			} catch (error) {
				console.error('Error loading cart:', error);
				commit('SET_CART_ITEMS', []);
			}
		},
		addToCart({ commit, state, rootGetters }, item) {
			console.log('Adding item to cart:', item);

			// Получаем текущую валюту пользователя
			const currentCurrency = rootGetters['user/currentCurrency'];

			// Проверяем, совпадает ли валюта корзины с текущей валютой пользователя
			if (
				state.currencyId &&
				currentCurrency?.id &&
				state.currencyId !== currentCurrency.id
			) {
				console.log(
					'Currency mismatch detected. Clearing cart before adding new item.'
				);
				// Очищаем корзину перед добавлением товара с новой валютой
				commit('CLEAR_CART');
				// Устанавливаем новую валюту корзины
				commit('SET_CART_CURRENCY_ID', currentCurrency.id);
				localStorage.setItem('cartCurrencyId', currentCurrency.id);
			} else if (!state.currencyId && currentCurrency?.id) {
				// Если ID валюты корзины не установлен, устанавливаем его
				commit('SET_CART_CURRENCY_ID', currentCurrency.id);
				localStorage.setItem('cartCurrencyId', currentCurrency.id);
			}

			commit('ADD_TO_CART', item);
			// Сбрасываем серверный расчет при добавлении товара
			commit('SET_SERVER_CALCULATED_TOTAL', null);
			localStorage.setItem('cart', JSON.stringify(state.items));
		},
		removeFromCart({ commit, state }, payload) {
			let itemId;
			if (typeof payload === 'object' && payload !== null) {
				// Если передан объект, используем id из него
				itemId = payload.id;
			} else {
				// Если передано просто значение, используем его как id
				itemId = payload;
			}
			commit('REMOVE_FROM_CART', itemId);
			localStorage.setItem('cart', JSON.stringify(state.items));
		},
		clearCart({ commit }) {
			commit('CLEAR_CART');
			localStorage.removeItem('cart');
			localStorage.removeItem('promoDiscount');
			localStorage.removeItem('promoCode');
			localStorage.removeItem('promoStatus'); // Удаляем статус
			localStorage.removeItem('cartCurrencyId'); // Удаляем ID валюты корзины
		},
		applyPromoCode({ commit }, { code, discount }) {
			commit('SET_PROMO_DISCOUNT', Number(discount));
			commit('SET_PROMO_CODE', code);
			commit('SET_PROMO_STATUS', 'success'); // Устанавливаем статус успеха
			localStorage.setItem('promoDiscount', discount);
			localStorage.setItem('promoCode', code);
			localStorage.setItem('promoStatus', 'success'); // Сохраняем статус
		},
		clearPromoCode({ commit }) {
			commit('CLEAR_PROMO');
			localStorage.removeItem('promoDiscount');
			localStorage.removeItem('promoCode');
			localStorage.removeItem('promoStatus'); // Удаляем статус
		},
		// Добавляем новое действие для установки серверного расчета
		setServerCalculatedTotal({ commit }, total) {
			commit('SET_SERVER_CALCULATED_TOTAL', total);
		},
		// Добавляем новое действие для установки ID валюты корзины
		setCartCurrencyId({ commit }, currencyId) {
			commit('SET_CART_CURRENCY_ID', currencyId);
			localStorage.setItem('cartCurrencyId', currencyId);
		},
	},
	getters: {
		cartItems: state => state.items,
		// Получаем только те товары, которые соответствуют текущей валюте корзины
		filteredCartItems: (state, getters, rootState, rootGetters) => {
			const currentCurrency = rootGetters['user/currentCurrency'];
			if (
				!currentCurrency ||
				!state.currencyId ||
				currentCurrency.id === state.currencyId
			) {
				return state.items;
			}
			// Если валюта пользователя не совпадает с валютой корзины, возвращаем пустой массив
			return [];
		},
		cartTotal: (state, getters) => {
			// Если есть серверный расчет, используем его
			if (state.serverCalculatedTotal !== null) {
				return state.serverCalculatedTotal;
			}

			// Иначе используем локальный расчет
			const subtotal = getters.filteredCartItems.reduce((total, item) => {
				const price = Number(item.price);
				const discount = Number(item.discount_amount) || 0;
				const finalPrice = Number((price - discount).toFixed(2));
				return total + finalPrice;
			}, 0);

			// Применяем скидку промокода, если есть
			if (state.promoDiscount) {
				const discountedPrice =
					subtotal * (1 - state.promoDiscount / 100);
				return Number(discountedPrice.toFixed(2));
			}
			return Number(subtotal.toFixed(2));
		},
		cartSubtotal: (state, getters) => {
			return getters.filteredCartItems.reduce((total, item) => {
				return total + Number(item.price);
			}, 0);
		},
		cartSavings: (state, getters) => {
			const subtotal = getters.cartSubtotal;
			const total = getters.cartTotal;
			return subtotal - total;
		},
		isInCart: state => (productId, editionId) => {
			// Проверяем по editionId (для обратной совместимости)
			if (editionId && !productId) {
				return state.items.some(item => item.id === editionId);
			}
			// Проверяем по productId и editionId
			return state.items.some(
				item => item.productId === productId && item.id === editionId
			);
		},
		promoDiscount: state => state.promoDiscount,
		appliedPromoCode: state => state.appliedPromoCode,
		promoStatus: state => state.promoStatus,
		cartCurrencyId: state => state.currencyId,
		hasCurrencyMismatch: (state, getters, rootState, rootGetters) => {
			// Если корзина пуста или нет ID валюты корзины, нет несоответствия
			if (state.items.length === 0 || !state.currencyId) {
				return false;
			}
			const currentCurrency = rootGetters['user/currentCurrency'];
			return (
				currentCurrency &&
				state.currencyId &&
				currentCurrency.id !== state.currencyId
			);
		},
	},
};
