export default {
	namespaced: true,
	state: {
		favouriteItems: [],
	},
	mutations: {
		ADD_TO_FAVOURITES(state, item) {
			console.log('Adding to favourites, received item:', item);
			console.log('Price in item:', item.price);
			console.log('Edition in item:', item.edition);
			console.log('Price in edition:', item.edition?.price);
			console.log(
				'convertedPrice in edition:',
				item.edition?.convertedPrice
			);

			const newItems = [...state.favouriteItems];
			const editionId = item.edition?.id;

			// Проверяем наличие издания в избранном
			if (
				!newItems.some(
					favItem =>
						favItem.title === item.title &&
						favItem.editionId === editionId
				)
			) {
				// Получаем корректные значения цены и скидки
				const price =
					item.edition?.convertedPrice ||
					item.edition?.price ||
					item.price ||
					0;
				const discountAmount =
					item.edition?.discount_amount || item.discount_amount || 0;

				console.log('Calculated price for favorite:', price);
				console.log(
					'Calculated discount for favorite:',
					discountAmount
				);

				const gameData = {
					id: item.id,
					image: item.image,
					title: item.title,
					genres: item.genres,
					rating: item.rating,
					ratingCount: item.ratingCount,
					platforms: item.edition?.platforms || [],
					editions: item.editions,
					editionId: editionId,
					editionName: item.edition?.editionName?.name || null,
					subtitle: item.subtitle || '',
					edition: {
						...item.edition,
						convertedPrice: price, // Устанавливаем корректную цену
						price: price, // Дублируем для надежности
						currency: item.edition?.currency,
						displayCurrency: item.edition?.displayCurrency,
						discount_amount: discountAmount, // Устанавливаем корректную скидку
					},
					// Сохраняем и на верхнем уровне для совместимости с разными компонентами
					price: price,
					discount_amount: discountAmount,
					edition_type:
						item.product_card?.edition_type || item.edition_type,
					product_card: {
						...item.product_card,
					},
				};

				console.log(
					'Final gameData before adding to favorites:',
					gameData
				);
				console.log('Price in gameData:', gameData.price);
				console.log(
					'Price in gameData.edition:',
					gameData.edition.price
				);

				newItems.push(gameData);
				state.favouriteItems = newItems;
				console.log('Added game data:', gameData);
			}
			console.log('Current favourites after add:', state.favouriteItems);
		},
		REMOVE_FROM_FAVOURITES(state, { title, editionId }) {
			console.log('Removing from favourites:', title, editionId);
			state.favouriteItems = [...state.favouriteItems].filter(
				item => !(item.title === title && item.editionId === editionId)
			);
			console.log(
				'Current favourites after remove:',
				state.favouriteItems
			);
		},
		SET_FAVOURITES(state, items) {
			console.log('Setting favourites from storage:', items);
			state.favouriteItems = [...items];
		},
	},
	actions: {
		addToFavourites({ commit, state }, item) {
			commit('ADD_TO_FAVOURITES', item);
			try {
				localStorage.setItem(
					'favourites',
					JSON.stringify(state.favouriteItems)
				);
				console.log('Saved to localStorage:', state.favouriteItems);
			} catch (error) {
				console.error('Error saving to localStorage:', error);
			}
		},
		removeFromFavourites({ commit, state }, { title, editionId }) {
			commit('REMOVE_FROM_FAVOURITES', { title, editionId });
			try {
				localStorage.setItem(
					'favourites',
					JSON.stringify(state.favouriteItems)
				);
				console.log('Updated localStorage after remove');
			} catch (error) {
				console.error('Error saving to localStorage:', error);
			}
		},
		loadFavourites({ commit }) {
			try {
				const savedFavourites = localStorage.getItem('favourites');
				console.log('Loading from localStorage:', savedFavourites);
				if (savedFavourites) {
					const items = JSON.parse(savedFavourites);
					commit('SET_FAVOURITES', items);
					console.log('Loaded favourites:', items);
				}
			} catch (error) {
				console.error('Error loading from localStorage:', error);
			}
		},
	},
	getters: {
		isFavourite: state => (title, editionId) => {
			const result = state.favouriteItems.some(
				item => item.title === title && item.editionId === editionId
			);
			console.log(
				'Checking if favourite:',
				title,
				editionId,
				'Result:',
				result
			);
			return result;
		},
		getFavouriteItems: state => {
			console.log('Getting all favourites:', state.favouriteItems);
			return state.favouriteItems;
		},
	},
};
