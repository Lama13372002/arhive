// Модуль Vuex для хранения состояния поиска
export default {
	namespaced: true,

	state: () => ({
		searchQuery: '',
		searchResults: [],
		selectedGenres: [],
		priceFrom: '',
		priceTo: '',
		isFiltersOpen: false,
		isLoading: false,
		error: null,
		// Кеш результатов поиска
		searchCache: new Map(),
		// Пагинация
		currentPage: 1,
		itemsPerPage: 20,
		scrollPosition: 0,
	}),

	mutations: {
		SET_SEARCH_QUERY(state, query) {
			state.searchQuery = query;
		},
		SET_SEARCH_RESULTS(state, results) {
			state.searchResults = results;
		},
		SET_SELECTED_GENRES(state, genres) {
			state.selectedGenres = genres;
		},
		SET_PRICE_FROM(state, price) {
			state.priceFrom = price;
		},
		SET_PRICE_TO(state, price) {
			state.priceTo = price;
		},
		SET_FILTERS_OPEN(state, isOpen) {
			state.isFiltersOpen = isOpen;
		},
		SET_LOADING(state, isLoading) {
			state.isLoading = isLoading;
		},
		SET_ERROR(state, error) {
			state.error = error;
		},
		// Добавление результатов в кеш
		ADD_TO_CACHE(state, { key, results }) {
			state.searchCache.set(key, results);
		},
		// Пагинация
		SET_CURRENT_PAGE(state, page) {
			state.currentPage = page;
		},
		SET_SCROLL_POSITION(state, position) {
			state.scrollPosition = position;
		},
		RESET_FILTERS(state) {
			state.selectedGenres = [];
			state.priceFrom = '';
			state.priceTo = '';
			state.error = null;
		},
		RESET_ALL(state) {
			state.searchQuery = '';
			state.searchResults = [];
			state.selectedGenres = [];
			state.priceFrom = '';
			state.priceTo = '';
			state.isFiltersOpen = false;
			state.error = null;
			state.currentPage = 1;
			state.scrollPosition = 0;
		},
	},

	actions: {
		setSearchQuery({ commit }, query) {
			commit('SET_SEARCH_QUERY', query);
		},
		setSearchResults({ commit }, results) {
			commit('SET_SEARCH_RESULTS', results);
		},
		setSelectedGenres({ commit }, genres) {
			commit('SET_SELECTED_GENRES', genres);
		},
		setPriceFrom({ commit }, price) {
			commit('SET_PRICE_FROM', price);
		},
		setPriceTo({ commit }, price) {
			commit('SET_PRICE_TO', price);
		},
		toggleFilters({ commit, state }) {
			commit('SET_FILTERS_OPEN', !state.isFiltersOpen);
		},
		setLoading({ commit }, isLoading) {
			commit('SET_LOADING', isLoading);
		},
		setError({ commit }, error) {
			commit('SET_ERROR', error);
		},
		addToCache({ commit }, { key, results }) {
			commit('ADD_TO_CACHE', { key, results });
		},
		// Пагинация
		setCurrentPage({ commit }, page) {
			commit('SET_CURRENT_PAGE', page);
		},
		setScrollPosition({ commit }, position) {
			commit('SET_SCROLL_POSITION', position);
		},
		resetFilters({ commit }) {
			commit('RESET_FILTERS');
		},
		resetAll({ commit }) {
			commit('RESET_ALL');
		},
	},

	getters: {
		getSearchQuery: state => state.searchQuery,
		getSearchResults: state => state.searchResults,
		getSelectedGenres: state => state.selectedGenres,
		getPriceFrom: state => state.priceFrom,
		getPriceTo: state => state.priceTo,
		isFiltersOpen: state => state.isFiltersOpen,
		isLoading: state => state.isLoading,
		getError: state => state.error,
		getFromCache: state => key => state.searchCache.get(key),
		hasCache: state => key => state.searchCache.has(key),
		// Пагинация
		getCurrentPage: state => state.currentPage,
		getItemsPerPage: state => state.itemsPerPage,
		getScrollPosition: state => state.scrollPosition,
		activeFiltersCount: state => {
			let count = 0;
			if (state.selectedGenres.length > 0) count++;
			if (state.priceFrom || state.priceTo) count++;
			return count || null;
		},
		expandedSearchResults: state => {
			const expanded = state.searchResults.flatMap(product => {
				if (!product.editions || product.editions.length === 0) {
					return [product];
				}

				return product.editions.map(edition => ({
					...product,
					edition,
					title: product.title,
					price: edition.convertedPrice || edition.price,
					discount_amount: edition.discount_amount,
					edition_type: product.edition_type,
					editions: [edition],
				}));
			});

			// Сортируем: сначала игры (Game), потом дополнения (DLC и т.д.)
			return expanded.sort((a, b) => {
				// Если edition_type одинаковый, сохраняем исходный порядок
				if (a.edition_type === b.edition_type) {
					return 0;
				}
				// Игры (Game) идут первыми
				if (a.edition_type === 'Игра') {
					return -1;
				}
				if (b.edition_type === 'Игра') {
					return 1;
				}
				// Остальные типы сортируем по алфавиту
				return a.edition_type.localeCompare(b.edition_type);
			});
		},
		// Товары для текущей страницы
		paginatedSearchResults: (state, getters) => {
			const allResults = getters.expandedSearchResults;
			const startIndex = (state.currentPage - 1) * state.itemsPerPage;
			const endIndex = startIndex + state.itemsPerPage;
			return allResults.slice(startIndex, endIndex);
		},
		// Общее количество страниц
		getTotalPages: (state, getters) => {
			return Math.max(1, Math.ceil(getters.expandedSearchResults.length / state.itemsPerPage));
		},
	},
};
