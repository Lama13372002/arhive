import { getFeedItems } from '../../services/apiService';
import { calculateDiscountPercentage } from '@/utils/discount';

export default {
  namespaced: true,
  state: {
    games: [],
    feedItems: [],
    isLoading: false,
    error: null,
  },
  mutations: {
    SET_GAMES(state, games) {
      state.games = games;
    },
    SET_FEED_ITEMS(state, items) {
      state.feedItems = items;
    },
    SET_LOADING(state, loading) {
      state.isLoading = loading;
    },
    SET_ERROR(state, error) {
      state.error = error;
    },
  },
  actions: {
    async loadGames({ commit }) {
      try {
        commit('SET_LOADING', true);
        const response = await getFeedItems();
        commit('SET_FEED_ITEMS', response);
        commit('SET_ERROR', null);
      } catch (error) {
        console.error('Error loading feed:', error);
        commit('SET_ERROR', error.message);
      } finally {
        commit('SET_LOADING', false);
      }
    },
    async loadFeedItems({ commit }) {
      console.log('Loading feed items...');
      try {
        const items = await getFeedItems();
        console.log('Feed items loaded:', items);
        console.log(
          'Feed items structure:',
          JSON.stringify(items, null, 2)
        );
        commit('SET_FEED_ITEMS', items);
      } catch (error) {
        console.error('Error loading feed items:', error);
        throw error;
      }
    },
  },
  getters: {
    getGameByTitle: state => title => {
      console.log('Looking for game with title:', title);
      const game = state.games.find(game => game.title === title);
      if (game) {
        return {
          ...game,
          description: game.editions?.[0]?.description || 'Описание отсутствует'
        };
      }
      return null;
    },
    getAllGames: state => {
      return state.games;
    },
    calculateDiscountedPrice: () => (price, discountAmount) => {
      if (!price || !discountAmount) return price;
      return price - discountAmount;
    },
    getDiscountPercentage: () => (price, discountAmount) => {
      return calculateDiscountPercentage(price, discountAmount);
    },
    formatPrice: () => (price) => {
      if (!price) return '0р';
      const num = Number(price);
      const hasDecimal = num % 1 !== 0;
      return `${hasDecimal ? num.toFixed(2) : Math.floor(num)}р`;
    },
    getFeedItems: state => state.feedItems,
  },
};
