const state = {
  psLogin: '',
  psPassword: '',
  psBackupCodes: '',
  email: '',
  error: null,
  isLoading: false
};

const mutations = {
  SET_PROFILE_DATA(state, profileData) {
    if (profileData) {
      state.psLogin = profileData.psStoreLogin || '';
      state.psPassword = profileData.psStorePassword || '';
      state.psBackupCodes = profileData.psBackupCodes || '';
      state.email = profileData.email || '';
    }
  },
  SET_ERROR(state, error) {
    state.error = error;
  },
  SET_LOADING(state, status) {
    state.isLoading = status;
  }
};

const actions = {
  async saveProfileData({ commit, dispatch, rootState, rootGetters }, profileData) {
    try {
      commit('SET_LOADING', true);
      commit('SET_ERROR', null);

      const telegramId = rootState.auth.telegramId;
      if (!telegramId) {
        throw new Error('Telegram ID is required');
      }

      // Получаем текущую валюту (регион)
      const currentCurrency = rootGetters['user/currentCurrency'];
      if (!currentCurrency || !currentCurrency.id) {
        throw new Error('Currency is not set');
      }

      // Преобразуем данные в формат пользователя
      const userData = {
        psStoreLogin: profileData.psLogin,
        psStorePassword: profileData.psPassword,
        psBackupCodes: profileData.psBackupCodes,
        email: profileData.email
      };

      // Обновляем данные региона через новый API
      await dispatch('user/updateUserRegionData', {
        currencyId: currentCurrency.id,
        data: userData
      }, { root: true });

      // Обновляем локальное состояние профиля
      commit('SET_PROFILE_DATA', userData);
    } catch (error) {
      commit('SET_ERROR', error.message);
      throw error;
    } finally {
      commit('SET_LOADING', false);
    }
  },

  // Загрузка данных профиля для текущего региона
  async loadProfileData({ commit, dispatch, rootState, rootGetters }) {
    try {
      commit('SET_LOADING', true);
      commit('SET_ERROR', null);

      const telegramId = rootState.auth.telegramId;
      if (!telegramId) {
        throw new Error('Telegram ID is required');
      }

      // Получаем текущую валюту (регион)
      const currentCurrency = rootGetters['user/currentCurrency'];
      if (!currentCurrency || !currentCurrency.id) {
        console.log('Currency not set, skipping profile load');
        return;
      }

      // Загружаем данные региона
      const regionData = await dispatch('user/getUserRegionData', {
        currencyId: currentCurrency.id
      }, { root: true });

      // Обновляем локальное состояние профиля
      commit('SET_PROFILE_DATA', regionData);
    } catch (error) {
      commit('SET_ERROR', error.message);
      console.error('Error loading profile data:', error);
    } finally {
      commit('SET_LOADING', false);
    }
  }
};

const getters = {
  getProfileData: (state) => ({
    psLogin: state.psLogin,
    psPassword: state.psPassword,
    psBackupCodes: state.psBackupCodes,
    email: state.email
  }),
  isProfileComplete: (state) =>
    Boolean(state.psLogin && state.psPassword)
};

export default {
  namespaced: true,
  state,
  mutations,
  actions,
  getters
};


