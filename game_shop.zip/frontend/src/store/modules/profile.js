const state = {
  psLogin: '',
  psPassword: '',
  psBackupCodes: '',
  email: '',
  error: null,
  isLoading: false
};

const mutations = {
  SET_PROFILE_DATA(state, profileData) {
    if (profileData) {
      state.psLogin = profileData.psStoreLogin || '';
      state.psPassword = profileData.psStorePassword || '';
      state.psBackupCodes = profileData.psBackupCodes || '';
      state.email = profileData.email || '';
    }
  },
  SET_ERROR(state, error) {
    state.error = error;
  },
  SET_LOADING(state, status) {
    state.isLoading = status;
  }
};

const actions = {
  async saveProfileData({ commit, dispatch, rootState }, profileData) {
    try {
      commit('SET_LOADING', true);
      commit('SET_ERROR', null);

      const telegramId = rootState.auth.telegramId;
      if (!telegramId) {
        throw new Error('Telegram ID is required');
      }

      // Преобразуем данные в формат пользователя
      const userData = {
        psStoreLogin: profileData.psLogin,
        psStorePassword: profileData.psPassword,
        psBackupCodes: profileData.psBackupCodes,
        email: profileData.email
      };

      // Обновляем каждое поле через user store
      for (const [field, value] of Object.entries(userData)) {
        if (value !== undefined) {
          await dispatch('user/updateUserField', { field, value }, { root: true });
        }
      }

      // Обновляем локальное состояние профиля
      commit('SET_PROFILE_DATA', userData);
    } catch (error) {
      commit('SET_ERROR', error.message);
      throw error;
    } finally {
      commit('SET_LOADING', false);
    }
  },

  // Загрузка данных профиля из user store
  loadProfileFromUser({ commit, rootState }) {
    const user = rootState.user.user;
    if (user) {
      commit('SET_PROFILE_DATA', user);
    }
  }
};

const getters = {
  getProfileData: (state) => ({
    psLogin: state.psLogin,
    psPassword: state.psPassword,
    psBackupCodes: state.psBackupCodes,
    email: state.email
  }),
  isProfileComplete: (state) => 
    Boolean(state.psLogin && state.psPassword)
};

export default {
  namespaced: true,
  state,
  mutations,
  actions,
  getters
};
