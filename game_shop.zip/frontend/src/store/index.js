import { createStore } from 'vuex';
import auth from './modules/auth';
import cart from './modules/cart';
import collections from './modules/collections';
import favourites from './modules/favourites';
import filters from './modules/filters';
import games from './modules/games';
import payment from './modules/payment';
import profile from './modules/profile';
import search from './modules/search';
import user from './modules/user';

export default createStore({
	modules: {
		favourites,
		games,
		user,
		auth,
		cart,
		profile,
		payment,
		filters,
		search,
		collections,
	},
});
