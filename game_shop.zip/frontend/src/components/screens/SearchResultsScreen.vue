<template>
	<div class="search-results-screen" v-close-keyboard>
		<div class="search-header">
			<div class="search-container">
				<input
					type="text"
					v-model="searchQuery"
					placeholder="Поиск"
					@keyup.enter="searchAndHideKeyboard"
					enterkeyhint="search"
					class="search-input"
				/>
				<button class="filter-button" @click="toggleFilters">
					<img src="/assets/img/filters.svg" alt="Фильтры" />
					<span class="filter-count" v-if="activeFiltersCount">{{
						activeFiltersCount
					}}</span>
				</button>
			</div>
			<Transition name="slide">
				<div class="filters-panel" v-if="isFiltersOpen">
					<div class="filter-section">
						<div class="filter-header">
							<h3>Фильтры</h3>
							<button class="reset-button" @click="resetFilters">
								Сбросить все
							</button>
						</div>
						<div class="filter-chips">
							<button
								v-for="genre in availableGenres"
								:key="genre.id"
								:class="{
									active: isGenreSelected(genre.id),
								}"
								@click="toggleGenre(genre)"
								class="filter-chip"
							>
								{{ genre.name }}
							</button>
						</div>
					</div>

					<div class="filter-section price-section">
						<div class="price-filter">
							<div class="price-label">Стоимость</div>
							<div class="price-inputs">
								<div class="price-range">
									<span class="price-prefix">от</span>
									<input
										type="number"
										v-model="priceFrom"
										placeholder="0"
										enterkeyhint="done"
										@keyup.enter="hideKeyboard"
									/>
									<span class="price-prefix">до</span>
									<input
										type="number"
										v-model="priceTo"
										placeholder="999999"
										enterkeyhint="done"
										@keyup.enter="hideKeyboard"
									/>
									<span class="price-currency"> руб.</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</Transition>
		</div>
		<div class="search-results" v-if="searchQuery || activeFiltersCount">
			<div v-if="isLoading" class="loading-state">
				<div class="loading-spinner"></div>
				<p>Поиск игр...</p>
			</div>

			<div v-else-if="error" class="error-state">
				<p>{{ error }}</p>
			</div>

			<div v-else-if="searchResults.length === 0" class="empty-state">
				<p>По вашему запросу ничего не найдено</p>
			</div>

			<div v-else class="results-list">
				<template
					v-for="product in expandedSearchResults"
					:key="`${product.id}-${product.edition?.id || 'base'}`"
				>
					<ProductCard :product="product" />
				</template>
			</div>
		</div>
		<div class="empty-state" v-else>
			<p>Введите запрос для поиска</p>
		</div>
	</div>
</template>

<script setup>
import ProductCard from '@/components/common/ProductCard.vue';
import { getGenres, searchGames } from '@/services/apiService';
import { computed, onMounted, ref, watch } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';

const router = useRouter();
const store = useStore();
const currentCurrency = computed(() => store.state.user.currentCurrency);

// Используем Vuex вместо локальных переменных
const searchQuery = computed({
	get: () => store.getters['search/getSearchQuery'],
	set: value => store.dispatch('search/setSearchQuery', value),
});

const searchResults = computed(() => store.getters['search/getSearchResults']);
const isLoading = computed(() => store.getters['search/isLoading']);
const error = computed(() => store.getters['search/getError']);
const isFiltersOpen = computed(() => store.getters['search/isFiltersOpen']);
const selectedGenres = computed(
	() => store.getters['search/getSelectedGenres']
);
const priceFrom = computed({
	get: () => store.getters['search/getPriceFrom'],
	set: value => store.dispatch('search/setPriceFrom', value),
});
const priceTo = computed({
	get: () => store.getters['search/getPriceTo'],
	set: value => store.dispatch('search/setPriceTo', value),
});
const activeFiltersCount = computed(
	() => store.getters['search/activeFiltersCount']
);
const expandedSearchResults = computed(
	() => store.getters['search/expandedSearchResults']
);

// Кеширование результатов поиска
const searchCache = new Map();
const getCacheKey = params => JSON.stringify(params);

// Санитизация поискового запроса
const sanitizeSearchQuery = query => {
	return query.replace(/[<>]/g, '').trim();
};

// Функция для нормализации строки - удаляет специальные символы для лучшего поиска
const normalizeString = str => {
	return str
		.toLowerCase()
		.replace(/[^\w\sа-яё]/gi, '') // Удаляем все специальные символы, оставляя только буквы, цифры и пробелы
		.replace(/\s+/g, ' ') // Заменяем множественные пробелы на одиночные
		.trim();
};

// Состояния для жанров
const availableGenres = ref([]);

// Загрузка жанров
const loadGenres = async () => {
	try {
		const genres = await getGenres();
		availableGenres.value = genres;
	} catch (error) {
		console.error('Error loading genres:', error);
	}
};

// Загружаем жанры при монтировании компонента
onMounted(() => {
	loadGenres();

	// Если у нас уже есть результаты поиска в хранилище, не нужно делать новый запрос
	if (searchResults.value.length === 0 && searchQuery.value) {
		performSearch();
	}
});

// Функции для работы с жанрами
const isGenreSelected = genreId => {
	return selectedGenres.value.some(genre => genre.id === genreId);
};

const toggleGenre = genre => {
	const newSelectedGenres = [...selectedGenres.value];
	const index = newSelectedGenres.findIndex(g => g.id === genre.id);

	if (index === -1) {
		newSelectedGenres.push(genre);
	} else {
		newSelectedGenres.splice(index, 1);
	}

	store.dispatch('search/setSelectedGenres', newSelectedGenres);
};

const toggleFilters = () => {
	store.dispatch('search/toggleFilters');
};

const resetFilters = () => {
	store.dispatch('search/resetFilters');
	performSearch();
};

watch([priceFrom, priceTo], ([newFrom, newTo]) => {
	if (newFrom && newTo && Number(newFrom) > Number(newTo)) {
		store.dispatch(
			'search/setError',
			'Минимальная цена не может быть больше максимальной'
		);
		store.dispatch('search/setSearchResults', []);
	} else if (error.value) {
		store.dispatch('search/setError', null);
	}
});

const performSearch = async () => {
	try {
		if (error.value) return;

		store.dispatch('search/setLoading', true);
		store.dispatch('search/setError', null);

		const searchParams = {
			query: sanitizeSearchQuery(searchQuery.value),
			genres: selectedGenres.value.length
				? selectedGenres.value.map(g => g.id).join(',')
				: undefined,
			priceFrom: Number(priceFrom.value) || undefined,
			priceTo: Number(priceTo.value) || undefined,
			currency_id: currentCurrency.value?.id,
		};

		// Удаляем undefined параметры
		Object.keys(searchParams).forEach(
			key => searchParams[key] === undefined && delete searchParams[key]
		);

		// Проверяем кеш
		const cacheKey = getCacheKey(searchParams);
		if (store.getters['search/hasCache'](cacheKey)) {
			const cachedResults =
				store.getters['search/getFromCache'](cacheKey);
			store.dispatch('search/setSearchResults', cachedResults);
			store.dispatch('search/setLoading', false);
			return;
		}

		console.log('Sending search request with params:', searchParams);
		const results = await searchGames(searchParams);
		store.dispatch('search/setSearchResults', results || []);

		// Сохраняем в кеш
		store.dispatch('search/addToCache', {
			key: cacheKey,
			results: results || [],
		});
	} catch (err) {
		console.error('Search error:', err);
		store.dispatch(
			'search/setError',
			'Произошла ошибка при поиске игр. Пожалуйста, попробуйте позже.'
		);
		store.dispatch('search/setSearchResults', []);
	} finally {
		store.dispatch('search/setLoading', false);
	}
};

let searchTimeout;

watch(
	[searchQuery, selectedGenres, priceFrom, priceTo, currentCurrency],
	() => {
		clearTimeout(searchTimeout);
		searchTimeout = setTimeout(() => {
			if (
				searchQuery.value ||
				selectedGenres.value.length > 0 ||
				priceFrom.value ||
				priceTo.value
			) {
				performSearch();
			} else {
				store.dispatch('search/setSearchResults', []);
			}
		}, 300);
	},
	{ deep: true }
);

// Функция для скрытия клавиатуры
const hideKeyboard = () => {
	if (document.activeElement instanceof HTMLElement) {
		document.activeElement.blur();
	}
};

// Функция для поиска и скрытия клавиатуры
const searchAndHideKeyboard = () => {
	performSearch();
	hideKeyboard();
};
</script>

<style scoped>
.search-results-screen {
	padding: 16px;
	padding-bottom: 300px;
}

.search-header {
	position: sticky;
	top: 0;
	background: white;
	padding: 8px 0;
	margin: -16px -16px 16px -16px;
	border-bottom: 1px solid #eee;
	z-index: 1000;
}

.search-container {
	display: flex;
	align-items: center;
	gap: 8px;
	padding: 0 16px;
	animation: moveFromMenu 0.5s cubic-bezier(0.4, 0, 0.2, 1) forwards;
	transform-origin: center bottom;
	position: relative;
	width: 100%;
}

@keyframes moveFromMenu {
	0% {
		transform: translate3d(calc(-50% + 46.5px), calc(100vh + 20px), 0)
			scale(0.4);
		opacity: 0;
		width: 93px;
	}
	100% {
		transform: translate3d(0, 0, 0) scale(1);
		opacity: 1;
		width: 100%;
	}
}

.search-input {
	flex: 1;
	height: 36px;
	padding: 0 12px;
	border: 1px solid #ddd;
	border-radius: 8px;
	font-size: 16px;
	background-color: #f5f5f5;
}

.search-input:focus {
	outline: none;
	border-color: #0066cc;
	background-color: white;
}

.filter-button {
	position: relative;
	width: 36px;
	height: 36px;
	padding: 6px;
	border: none;
	border-radius: 8px;
	background: none;
	cursor: pointer;
}

.filter-button:hover {
	background-color: #f5f5f5;
}

.filter-button img {
	width: 100%;
	height: 100%;
}

.filter-count {
	position: absolute;
	top: 0;
	right: 0;
	background: #007aff;
	color: white;
	border-radius: 50%;
	width: 18px;
	height: 18px;
	font-size: 12px;
	display: flex;
	align-items: center;
	justify-content: center;
}

.filters-panel {
	background: white;
	padding: 16px;
	border-bottom: 1px solid #eee;
	transform-origin: top;
}

.filter-section {
	margin-bottom: 24px;
}

.filter-section:last-child {
	margin-bottom: 0;
}

.filter-chips {
	display: flex;
	flex-wrap: wrap;
	gap: 12px;
}

.filter-chip {
	padding: 8px 16px;
	border-radius: 100px;
	border: 1px solid #e7e7e7;
	background: white;
	font-size: 15px;
	color: #333;
	cursor: pointer;
	transition: all 0.2s;
	font-weight: 400;
}

.filter-chip:hover {
	background: #f5f5f5;
}

.filter-chip.active {
	background: #007aff;
	color: white;
	border-color: #007aff;
}

.price-section {
	padding: 0 4px;
}

.price-filter {
	display: flex;
	flex-direction: column;
	gap: 12px;
}

.price-label {
	font-size: 15px;
	color: #333;
	font-weight: 400;
}

.price-inputs {
	display: flex;
	flex-direction: column;
	gap: 8px;
}

.price-range {
	display: flex;
	align-items: center;
	gap: 8px;
}

.price-prefix {
	color: #333;
	font-size: 15px;
}

.price-currency {
	color: #333;
	font-size: 15px;
	margin-left: 4px;
}

.price-range input {
	width: 70px;
	height: 32px;
	padding: 0 8px;
	border: 1px solid #e7e7e7;
	border-radius: 8px;
	font-size: 15px;
	color: #333;
}

.price-range input:focus {
	outline: none;
	border-color: #007aff;
}

.empty-state {
	text-align: center;
	color: #666;
	margin-top: 32px;
}

.slide-enter-active,
.slide-leave-active {
	transition: all 0.3s ease-out;
}

.slide-enter-from {
	opacity: 0;
	transform: translateY(-20px);
}

.slide-leave-to {
	opacity: 0;
	transform: translateY(-20px);
}

.results-list {
	display: flex;
	flex-direction: column;
	gap: 16px;
	padding: 16px 0;
}

.loading-state {
	text-align: center;
	padding: 2rem;
}

.loading-spinner {
	width: 40px;
	height: 40px;
	border: 3px solid #f3f3f3;
	border-top: 3px solid #007aff;
	border-radius: 50%;
	margin: 0 auto 1rem;
	animation: spin 1s linear infinite;
}

.error-state {
	text-align: center;
	color: #ff3b30;
	padding: 2rem;
}

.empty-state {
	text-align: center;
	color: #666;
	padding: 2rem;
}

@keyframes spin {
	0% {
		transform: rotate(0deg);
	}
	100% {
		transform: rotate(360deg);
	}
}

.filter-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	margin-bottom: 16px;
}

.filter-header h3 {
	margin: 0;
	font-size: 16px;
	font-weight: 600;
	color: #333;
}

.reset-button {
	padding: 6px 12px;
	border: none;
	border-radius: 6px;
	background-color: #f5f5f5;
	color: #666;
	font-size: 14px;
	cursor: pointer;
	transition: all 0.2s ease;
}

.reset-button:hover {
	background-color: #e5e5e5;
	color: #333;
}

.reset-button:active {
	transform: scale(0.98);
}
</style>
