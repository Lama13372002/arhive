i
<template>
	<div class="shopbag-screen" v-close-keyboard>
		<section class="shopbag-section">
			<div class="section-header">
				<h2 class="section-title">Корзина</h2>
			</div>

			<div v-if="hasCurrencyMismatch" class="currency-mismatch-warning">
				<div class="warning-icon">⚠️</div>
				<div class="warning-text">
					<p>
						Товары в корзине добавлены в другой валюте ({{
							cartCurrencyCode
						}}).
					</p>
					<p>
						Для просмотра корзины переключитесь на соответствующую
						валюту или очистите корзину.
					</p>
					<div class="warning-actions">
						<button
							class="warning-action-btn"
							@click="switchToCurrencyFromCart"
						>
							Переключить валюту
						</button>
						<button
							class="warning-action-btn warning-clear-btn"
							@click="clearCartConfirm"
						>
							Очистить корзину
						</button>
					</div>
				</div>
			</div>

			<div v-if="showCurrencyChangeNotice" class="currency-change-notice">
				<div class="notice-icon">ℹ️</div>
				<div class="notice-text">
					<p>
						При добавлении товара в другой валюте корзина будет
						очищена.
					</p>
				</div>
			</div>

			<div
				class="shopbag-content scrollable-content"
				v-if="!filteredCartItems.length"
			>
				<img
					src="/assets/img/empty-cart.png"
					alt="Корзина пуста"
					class="empty-cart-icon"
				/>
				<p class="empty-cart-text">
					{{
						hasCurrencyMismatch
							? 'Товары скрыты из-за несоответствия валюты'
							: 'Корзина пуста :('
					}}
				</p>
				<router-link to="/" class="continue-shopping-btn">
					Перейти в каталог
				</router-link>
			</div>

			<div v-else class="cart-container scrollable-content">
				<div class="cart-content">
					<div class="cart-items">
						<div
							v-for="item in filteredCartItems"
							:key="item.id"
							class="cart-item"
						>
							<div class="item-content">
								<router-link
									:to="'/item/' + (item.productId || item.id)"
									class="image-link"
								>
									<img
										:src="getItemImage(item)"
										:alt="item.title"
										class="game-image"
									/>
								</router-link>
								<div class="item-details">
									<div class="title-row">
										<div class="title-info">
											<h3>{{ item.title }}</h3>
											<div class="types-column">
												<div class="item-type">
													{{ item.type }}
												</div>
												<div
													v-if="item.edition_type"
													class="item-type"
												>
													{{ item.edition_type }}
												</div>
												<div class="edition-info">
													<div class="edition-type">
														<img
															v-if="item.isPsPlus"
															src="@/assets/img/psplussub.png"
															alt="PS Plus"
															class="ps-plus-icon"
														/>
														<span>{{
															item.editionName ||
															'Standard'
														}}</span>
													</div>
													<div class="platforms">
														<img
															v-for="platform in item.platforms"
															:key="platform.id"
															:src="
																getPlatformIcon(
																	platform
																)
															"
															:alt="platform.name"
															class="platform-badge"
														/>
													</div>
												</div>
											</div>
										</div>

										<div class="price-info">
											<div
												class="original-price-container"
											>
												<span
													v-if="
														item.discount_amount &&
														item.discount_amount <
															item.price
													"
													class="discount-badge"
												>
													<span class="discount-text"
														>-{{
															calculateItemDiscount(
																item
															)
														}}%</span
													>
												</span>
												<div class="price-stack">
													<span
														v-if="
															item.discount_amount &&
															item.discount_amount <
																item.price
														"
														class="price-crossed"
													>
														{{
															formatPrice(
																item.price
															)
														}}
													</span>
													<span class="price-final">
														{{
															formatPrice(
																getItemFinalPrice(
																	item
																)
															)
														}}
													</span>
													<button
														class="action-button"
														@click="
															removeFromCart(item)
														"
													>
														<img
															src="@/assets/img/bin.svg"
															alt="Удалить"
														/>
													</button>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="shop-purchase fixed-bottom">
				<div class="purchase-content">
					<div class="promo-code">
						<input
							type="text"
							v-model="promoCode"
							placeholder="Промокод"
							:class="[
								'promo-input',
								{ 'promo-success': promoStatus === 'success' },
								{ 'promo-error': promoStatus === 'error' },
							]"
							enterkeyhint="done"
							@keyup.enter="focusNextField('promoCode')"
						/>
						<Button
							:text="
								promoStatus === 'success'
									? 'Промокод применен'
									: 'Применить'
							"
							:isProductCard="true"
							class="apply-promo"
							:class="{
								active: promoCode.length > 0,
								success: promoStatus === 'success',
							}"
							@buttonClicked="applyPromo"
							:disabled="promoStatus === 'success'"
						/>
					</div>

					<div class="summary">
						<div class="final-total">
							<div class="total-info">
								<span class="total-label">Итого</span>
								<span v-if="savings > 0" class="original-price">
									{{ formatPrice(originalTotalPrice) }}
								</span>
								<span v-if="savings > 0" class="savings-label">
									Выгода {{ formatPrice(savings) }}
								</span>
							</div>
							<span class="total-amount">{{
								formatPrice(convertedTotal)
							}}</span>
						</div>
						<button
							v-if="originalTotalPrice > convertedTotal"
							class="price-explanation-btn"
							@click="showPriceExplanation = true"
						>
							Цена игр в корзине уменьшилась?
						</button>
					</div>

					<div
						v-if="hasCurrencyMismatch"
						class="currency-mismatch-hint"
					>
						<span class="hint-icon">⚠️</span>
						Для оформления покупки переключитесь на соответствующую
						валюту или очистите корзину
					</div>

					<div
						v-if="cartIsEmpty && !hasCurrencyMismatch"
						class="currency-mismatch-hint empty-cart-hint"
					>
						<span class="hint-icon">ℹ️</span>
						Добавьте товары в корзину, чтобы оформить заказ
					</div>

					<Button
						text="Оформить покупку"
						:isProductCard="true"
						class="full-width-button"
						:class="{
							'disabled-button':
								hasCurrencyMismatch || cartIsEmpty,
						}"
						@buttonClicked="checkout"
						:disabled="hasCurrencyMismatch || cartIsEmpty"
					/>
				</div>
			</div>
		</section>

		<!-- Модальное окно подтверждения -->
		<Transition name="modal">
			<div v-if="showConfirmModal" class="modal-overlay">
				<div class="modal-content">
					<div class="modal-body">
						<div class="modal-icon">
							<img
								:src="getItemImage(itemToRemove)"
								alt="Game icon"
								class="game-icon"
							/>
						</div>
						<div class="modal-text">
							<h3>Убрать из корзины?</h3>
							<p>{{ itemToRemove?.title }}</p>
						</div>
						<div class="modal-actions">
							<button
								@click="confirmRemove"
								class="modal-btn confirm-btn"
							>
								Да
							</button>
							<button
								@click="cancelRemove"
								class="modal-btn cancel-btn"
							>
								Нет
							</button>
						</div>
					</div>
				</div>
			</div>
		</Transition>

		<!-- Модальное окно с объяснением цены -->
		<Transition name="modal">
			<div v-if="showPriceExplanation" class="modal-overlay">
				<div class="modal-content price-explanation-modal">
					<h3>Цена игр в корзине уменьшилась?</h3>
					<p>
						Это не ошибка! Если у вас уменьшились цены, значит мы
						снизили общую стоимость игр в вашей корзине. Чем больше
						величина покупки, тем меньше цена.
					</p>
					<button
						class="close-modal-btn"
						@click="showPriceExplanation = false"
					>
						Понятно
					</button>
				</div>
			</div>
		</Transition>

		<!-- Модальное окно подтверждения очистки корзины -->
		<Transition name="modal">
			<div v-if="showClearCartConfirm" class="modal-overlay">
				<div class="modal-content">
					<div class="modal-body">
						<div class="modal-icon warning-modal-icon">⚠️</div>
						<div class="modal-text">
							<h3>Очистить корзину?</h3>
							<p>Все товары будут удалены из корзины.</p>
						</div>
						<div class="modal-actions">
							<button
								@click="clearCart"
								class="modal-btn confirm-btn"
							>
								Да, очистить
							</button>
							<button
								@click="cancelClearCart"
								class="modal-btn cancel-btn"
							>
								Отмена
							</button>
						</div>
					</div>
				</div>
			</div>
		</Transition>
	</div>
</template>

<script setup>
import Button from '@/components/common/Button.vue';
import { calculateCartTotal, checkPromo } from '@/services/apiService';
import { formatPrice } from '@/utils/discount';
import { computed, onMounted, ref, watch } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';

const store = useStore();
const router = useRouter();

// Инициализация корзины при монтировании
onMounted(async () => {
	console.log('ShopBagScreen mounted');
	await store.dispatch('cart/loadCart');
	await updateCartTotal();
});

const cartItems = computed(() => {
	const items = store.getters['cart/cartItems'];
	console.log('Cart items:', items);
	return items;
});

const filteredCartItems = computed(() => {
	const items = store.getters['cart/filteredCartItems'];
	console.log('Filtered cart items:', items);
	return items;
});

const selectedCurrency = computed(() => {
	const currency = store.getters['user/currentCurrency'];
	console.log('Selected currency:', currency);
	return currency;
});

const hasCurrencyMismatch = computed(() => {
	// Если корзина пуста, нет несоответствия валют
	if (cartIsEmpty.value) {
		return false;
	}
	return store.getters['cart/hasCurrencyMismatch'];
});

const cartCurrencyId = computed(() => {
	return store.getters['cart/cartCurrencyId'];
});

const cartCurrencyCode = computed(() => {
	// Получаем ID валюты корзины
	const cartCurrencyId = store.getters['cart/cartCurrencyId'];
	if (!cartCurrencyId) return 'другой валюте';

	// Проверяем, есть ли в localStorage сохраненная валюта
	const savedCurrency = localStorage.getItem('userCurrency');
	if (savedCurrency) {
		try {
			const currency = JSON.parse(savedCurrency);
			if (currency.id === cartCurrencyId) {
				return currency.code || 'другой валюте';
			}
		} catch (e) {
			console.error('Ошибка при парсинге сохраненной валюты:', e);
		}
	}

	// Если не нашли в localStorage, возвращаем значение по умолчанию
	return 'другой валюте';
});

const promoDiscount = computed(() => store.getters['cart/promoDiscount']);
const appliedPromoCode = computed(() => store.getters['cart/appliedPromoCode']);
const promoStatus = computed(() => store.getters['cart/promoStatus']);

const promoCode = ref('');
const isLoading = ref(false);
const showConfirmModal = ref(false);
const itemToRemove = ref(null);
const convertedTotal = ref(0);
const showPriceExplanation = ref(false);
const showClearCartConfirm = ref(false);
const showCurrencyChangeNotice = computed(() => {
	// Показываем уведомление только если корзина пуста и есть ID валюты корзины,
	// который отличается от текущей валюты пользователя
	if (!cartIsEmpty.value) {
		return false;
	}

	const cartCurrencyId = store.getters['cart/cartCurrencyId'];
	const currentCurrency = store.getters['user/currentCurrency'];

	return (
		cartCurrencyId &&
		currentCurrency?.id &&
		cartCurrencyId !== currentCurrency.id
	);
});

// Следим за изменениями в корзине и валюте
watch(
	[filteredCartItems, selectedCurrency],
	async (newValues, oldValues) => {
		console.log('Cart or currency changed:', {
			cartItems: newValues[0],
			currency: newValues[1],
		});
		if (newValues[0]?.length > 0 && newValues[1]?.id) {
			await updateCartTotal();
		}
	},
	{ deep: true }
);

// Следим за изменением валюты пользователя
watch(
	() => selectedCurrency.value,
	async (newCurrency, oldCurrency) => {
		console.log('User currency changed:', {
			oldCurrency,
			newCurrency,
		});

		// Если валюта изменилась и есть ID валюты корзины
		if (newCurrency?.id && cartCurrencyId.value) {
			// Если валюта пользователя совпадает с валютой корзины
			if (newCurrency.id === cartCurrencyId.value) {
				console.log(
					'Currency now matches cart currency, updating cart total'
				);
				await updateCartTotal();
			}
		}
	}
);

// Общая сумма без скидок
const originalTotalPrice = computed(() => {
	return filteredCartItems.value.reduce((total, item) => {
		return total + (Number(item.price) || 0);
	}, 0);
});

// Сумма со скидками на товары
const subtotalWithItemDiscounts = computed(() => {
	return filteredCartItems.value.reduce((total, item) => {
		// discount_amount - это уже цена со скидкой
		return total + Number(item.discount_amount || item.price || 0);
	}, 0);
});

// Итоговая сумма с учетом промокода
const totalPrice = computed(() => {
	const subtotal = subtotalWithItemDiscounts.value;
	
	console.log('totalPrice computed - calculating:', {
		subtotal,
		promoDiscount: promoDiscount.value,
		hasPromoDiscount: Boolean(promoDiscount.value),
		storePromoDiscount: store.state.cart.promoDiscount,
		appliedPromoCode: store.state.cart.appliedPromoCode,
	});
	
	if (promoDiscount.value) {
		const discountedPrice =
			subtotal * (1 - (Number(promoDiscount.value) || 0) / 100);
		const result = Number(discountedPrice.toFixed(2));
		
		console.log('Applied promo discount:', {
			originalSubtotal: subtotal,
			discountPercent: promoDiscount.value,
			discountedPrice: result,
			savings: subtotal - result,
		});
		
		return result;
	}
	
	console.log('No promo discount applied, returning subtotal:', subtotal);
	return subtotal;
});

// Общая выгода (скидки на товары + скидка по промокоду + скидка от множителя)
const savings = computed(() => {
	// Если нет данных о конвертированной цене, возвращаем только скидки на товары
	if (!convertedTotal.value) {
		const itemDiscounts = filteredCartItems.value.reduce((total, item) => {
			// Разница между оригинальной ценой и ценой со скидкой
			return (
				total +
				(Number(item.price) -
					Number(item.discount_amount || item.price))
			);
		}, 0);

		return Number(itemDiscounts.toFixed(2));
	}

	// В противном случае, выгода - это разница между оригинальной ценой и конвертированной
	// с учетом всех скидок (скидки товаров, промокод, множитель диапазона)
	return Number((originalTotalPrice.value - convertedTotal.value).toFixed(2));
});

const cartIsEmpty = computed(() => !filteredCartItems.value.length);

// Methods
const calculateItemDiscount = item => {
	if (!item?.discount_amount || !item?.price) return 0;
	const discountedPrice = Number(item.discount_amount) || 0;
	const originalPrice = Number(item.price) || 0;
	if (originalPrice === 0) return 0;
	// Рассчитываем процент скидки, учитывая что discount_amount это цена со скидкой
	return Math.round(
		((originalPrice - discountedPrice) / originalPrice) * 100
	);
};

const getItemFinalPrice = item => {
	if (!item) return 0;
	// Используем discount_amount только если он существует, иначе берем обычную цену
	return item.discount_amount
		? Number(item.discount_amount).toFixed(2)
		: Number(item.price || 0).toFixed(2);
};

// Новая функция для расчета итоговой цены с учетом валютных диапазонов
const updateCartTotal = async () => {
	console.log('=== updateCartTotal START ===');
	console.log('Cart state:', {
		isEmpty: cartIsEmpty.value,
		selectedCurrency: selectedCurrency.value,
		cartItems: filteredCartItems.value,
		subtotalWithItemDiscounts: subtotalWithItemDiscounts.value,
		totalPrice: totalPrice.value,
	});

	if (cartIsEmpty.value || !selectedCurrency.value?.id) {
		console.log('Skipping cart total calculation:', {
			isEmpty: cartIsEmpty.value,
			hasCurrency: Boolean(selectedCurrency.value?.id),
		});
		convertedTotal.value = totalPrice.value;
		// Сбрасываем серверный расчет, если корзина пуста
		store.dispatch('cart/setServerCalculatedTotal', null);
		return;
	}

	try {
		isLoading.value = true;
		const editionIds = filteredCartItems.value.map(item => item.id);

		// Создаем объект с типами цен для каждого товара
		const priceTypes = {};
		filteredCartItems.value.forEach(item => {
			if (item.priceType) {
				priceTypes[item.id] = item.priceType;
			}
		});

		console.log('Preparing to calculate cart total:', {
			editionIds,
			currencyId: selectedCurrency.value.id,
			subtotal: subtotalWithItemDiscounts.value,
			cartItems: filteredCartItems.value.map(item => ({
				id: item.id,
				price: item.price,
				discount: item.discount_amount,
				priceType: item.priceType,
			})),
			priceTypes,
		});

		// Передаем промокод на сервер, если он применен
		const appliedPromoCode = store.state.cart.appliedPromoCode;
		console.log('Applied promo code:', appliedPromoCode);

		const response = await calculateCartTotal(
			editionIds,
			selectedCurrency.value.id,
			subtotalWithItemDiscounts.value,
			priceTypes, // Передаем типы цен
			appliedPromoCode // Передаем промокод
		);

		console.log('Cart total calculation response:', response);

		if (response && response.total !== undefined) {
			const calculatedTotal = response.total;
			console.log('Applying calculated total:', {
				calculatedTotal,
				hasPromoDiscount: Boolean(promoDiscount.value),
				promoDiscount: promoDiscount.value,
				originalTotal: originalTotalPrice.value,
				subtotalWithItemDiscounts: subtotalWithItemDiscounts.value,
				appliedPromo: response.appliedPromo,
			});

			// Если сервер вернул информацию о примененном промокоде, обновляем локальное состояние
			if (response.appliedPromo) {
				store.dispatch('cart/applyPromoCode', {
					code: response.appliedPromo.name,
					discount: response.appliedPromo.discount,
				});
			} else if (appliedPromoCode && !response.appliedPromo) {
				// Если локально есть промокод, но сервер его не применил - очищаем
				console.log('Server did not apply promo code, clearing local promo');
				store.dispatch('cart/clearPromoCode');
				promoStatus.value = 'error';
			}

			// Используем итоговую цену, рассчитанную на сервере (уже с учетом промокода)
			let finalTotal = calculatedTotal;

			console.log('Setting convertedTotal from server response:', {
				before: convertedTotal.value,
				after: finalTotal,
				hasAppliedPromo: Boolean(response.appliedPromo),
				appliedPromoCode: appliedPromoCode,
			});

			convertedTotal.value = finalTotal;

			// Сохраняем серверный расчет в хранилище Vuex
			store.dispatch('cart/setServerCalculatedTotal', finalTotal);

			console.log('Updated total savings:', {
				originalTotal: originalTotalPrice.value,
				convertedTotal: convertedTotal.value,
				savings: savings.value,
			});
		} else {
			console.log('Using default total price:', totalPrice.value);
			convertedTotal.value = totalPrice.value;
			// Сбрасываем серверный расчет, если ответ от сервера некорректный
			store.dispatch('cart/setServerCalculatedTotal', null);
		}
	} catch (error) {
		console.error('Error in updateCartTotal:', error);
		convertedTotal.value = totalPrice.value;
		// Сбрасываем серверный расчет при ошибке
		store.dispatch('cart/setServerCalculatedTotal', null);
	} finally {
		isLoading.value = false;
		console.log('=== updateCartTotal END ===', {
			finalTotal: convertedTotal.value,
		});
	}
};

const removeFromCart = item => {
	itemToRemove.value = item;
	showConfirmModal.value = true;
};

const confirmRemove = async () => {
	if (itemToRemove.value) {
		await store.dispatch('cart/removeFromCart', {
			id: itemToRemove.value.id,
			editionId: itemToRemove.value.editionId,
		});
		showConfirmModal.value = false;
		itemToRemove.value = null;

		// Обновляем общую стоимость корзины
		await updateCartTotal();

		// Добавляем небольшую задержку и обновляем страницу
		setTimeout(() => {
			window.location.reload();
		}, 300);
	}
};

const cancelRemove = () => {
	showConfirmModal.value = false;
	itemToRemove.value = null;
};

const applyPromo = async () => {
	if (!promoCode.value) return;

	console.log('=== APPLYING PROMO CODE ===', promoCode.value);

	try {
		const response = await checkPromo(promoCode.value);
		console.log('Promo check response:', response);
		
		if (response && response.discount) {
			console.log('Setting promo status to success, discount:', response.discount);
			promoStatus.value = 'success';
			
			// Сохраняем промокод в store
			store.dispatch('cart/applyPromoCode', {
				code: promoCode.value,
				discount: response.discount,
			});
			
			console.log('Promo state after dispatch:', {
				appliedPromoCode: store.state.cart.appliedPromoCode,
				promoDiscount: store.state.cart.promoDiscount,
				promoStatus: store.state.cart.promoStatus,
			});
			
			console.log('Calling updateCartTotal after promo application...');
			await updateCartTotal();
			
			console.log('Final state after updateCartTotal:', {
				convertedTotal: convertedTotal.value,
				totalPrice: totalPrice.value,
				savings: savings.value,
			});
		} else {
			console.log('Invalid promo response:', response);
			promoStatus.value = 'error';
		}
	} catch (error) {
		console.error('Error checking promo code:', error);
		promoStatus.value = 'error';
	}

	// Скрыть клавиатуру после применения промокода
	if (document.activeElement instanceof HTMLElement) {
		document.activeElement.blur();
	}
};

// Функция для скрытия клавиатуры при нажатии Enter
const focusNextField = field => {
	if (field === 'promoCode') {
		applyPromo();

		// Дополнительно скрываем клавиатуру после применения промокода
		if (document.activeElement instanceof HTMLElement) {
			document.activeElement.blur();
		}
	}
};

const checkout = () => {
	// Проверяем, нет ли несоответствия валют или пустой корзины
	if (hasCurrencyMismatch.value || cartIsEmpty.value) {
		return; // Блокируем оформление покупки при несоответствии валют или пустой корзине
	}

	// Убираем очистку промокода перед переходом на экран оплаты
	// store.dispatch('cart/clearPromoCode');
	router.push({ name: 'Payment' });
};

const getItemImage = item => {
	return import.meta.env.VITE_API_BASE_URL + '/uploads/' + item.image;
};

const getPlatformIcon = platform => {
	return import.meta.env.VITE_API_BASE_URL + '/uploads/' + platform.icon_url;
};

// Следим за изменениями totalPrice
watch(totalPrice, newTotal => {
	// Не перезаписываем convertedTotal, если есть серверный расчет или применен промокод
	const hasServerCalculation = store.state.cart.serverCalculatedTotal !== null;
	const hasAppliedPromo = store.state.cart.appliedPromoCode !== null;
	
	console.log('totalPrice watcher triggered:', {
		newTotal,
		currentConvertedTotal: convertedTotal.value,
		hasServerCalculation,
		hasAppliedPromo,
		cartIsEmpty: cartIsEmpty.value,
		willUpdate: (!convertedTotal.value || cartIsEmpty.value) && !hasServerCalculation && !hasAppliedPromo,
	});
	
	if ((!convertedTotal.value || cartIsEmpty.value) && !hasServerCalculation && !hasAppliedPromo) {
		console.log('Updating convertedTotal via watcher:', convertedTotal.value, '->', newTotal);
		convertedTotal.value = newTotal;
	} else {
		console.log('Watcher NOT updating convertedTotal due to conditions');
	}
});

// Lifecycle hooks
onMounted(async () => {
	store.dispatch('cart/loadCart');
	promoCode.value = appliedPromoCode.value || '';
	promoStatus.value = promoStatus.value || '';
	convertedTotal.value = totalPrice.value;
	await updateCartTotal();
});

// Функция для переключения на валюту из корзины
const switchToCurrencyFromCart = async () => {
	try {
		// Получаем ID валюты из корзины
		const cartCurrencyId = store.getters['cart/cartCurrencyId'];
		if (!cartCurrencyId) {
			console.error('ID валюты корзины не найден');
			return;
		}

		// Получаем список валют
		const response = await fetch('/api/currencies');
		if (!response.ok) {
			throw new Error('Не удалось получить список валют');
		}

		const currencies = await response.json();

		// Находим валюту по ID
		const currency = currencies.find(c => c.id === cartCurrencyId);
		if (!currency) {
			console.error('Валюта не найдена в списке доступных валют');
			return;
		}

		// Получаем telegramId из хранилища
		const telegramId = store.state.user.user?.telegramId;
		if (!telegramId) {
			console.error('TelegramId не найден в хранилище');
			return;
		}

		// Отправляем запрос на обновление валюты
		const updateResponse = await fetch(
			`/api/users/${telegramId}/currency`,
			{
				method: 'PUT',
				headers: {
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({ currencyId: currency.id }),
			}
		);

		if (!updateResponse.ok) {
			throw new Error('Не удалось обновить валюту');
		}

		// Сохраняем в localStorage
		localStorage.setItem('userCurrency', JSON.stringify(currency));

		// Обновляем состояние в store
		store.commit('user/SET_USER_CURRENCY', currency);

		console.log(`Валюта успешно изменена на: ${currency.code}`);

		// Обновляем корзину
		await updateCartTotal();
	} catch (error) {
		console.error('Ошибка при переключении валюты:', error);
	}
};

// Функция для подтверждения очистки корзины
const clearCartConfirm = () => {
	showClearCartConfirm.value = true;
};

// Функция для очистки корзины
const clearCart = () => {
	store.dispatch('cart/clearCart');
	showClearCartConfirm.value = false;

	// Добавляем небольшую задержку и обновляем страницу
	setTimeout(() => {
		window.location.reload();
	}, 300);
};

// Функция для отмены очистки корзины
const cancelClearCart = () => {
	showClearCartConfirm.value = false;
};
</script>

<style scoped>
.shopbag-screen {
	display: flex;
	flex-direction: column;
	height: 100vh;
	overflow: hidden;
}

.shopbag-section {
	flex: 1;
	display: flex;
	flex-direction: column;
	overflow: hidden;
}

.section-header {
	padding: 16px 16px 8px 16px;
	background: #fff;
	z-index: 2;
}

.section-title {
	font-size: 20px;
	font-weight: bold;
}

.scrollable-content {
	flex: 1;
	overflow-y: auto;
	-webkit-overflow-scrolling: touch;
	padding: 0 16px 200px 16px;
}

.cart-container {
	height: 100%;
}

.fixed-bottom {
	position: fixed;
	bottom: 0;
	left: 0;
	right: 0;
	background: var(--tg-theme-bg-color);
	padding: 16px;
	box-shadow: 0 -4px 12px rgba(0, 0, 0, 0.1);
	z-index: 10;
}

/* Добавляем стили для плавного скролла на iOS */
.scrollable-content {
	scrollbar-width: none; /* Firefox */
	-ms-overflow-style: none; /* IE and Edge */
}

.scrollable-content::-webkit-scrollbar {
	display: none; /* Chrome, Safari, Opera */
}

.shopbag-content {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	padding: 40px;
	text-align: center;
	height: calc(100vh - 200px);
}

.empty-cart-icon {
	width: 120px;
	height: 120px;
	margin-bottom: 20px;
	opacity: 0.6;
}

.empty-cart-text {
	font-size: 18px;
	color: #666;
	margin-bottom: 20px;
}

.continue-shopping-btn {
	display: inline-block;
	padding: 12px 24px;
	background: #f3f4f6;
	color: #000;
	text-decoration: none;
	border-radius: 13px;
	font-weight: 500;
	transition: all 0.2s ease-in-out;
}

.continue-shopping-btn:hover {
	background: #e5e7eb;
	transform: scale(0.98);
}

.continue-shopping-btn:active {
	transform: scale(0.95);
}

.cart-content {
	background: #fff;
	width: 100%;
	box-sizing: border-box;
}

.cart-items {
	margin: 0;
	padding: 0;
}

.cart-item {
	padding: 10px 0;
	border-bottom: 1px solid #e5e7eb;
}

.cart-item:last-child {
	border-bottom: none;
}

.item-content {
	display: flex;
	gap: 15px;
	align-items: flex-start;
	width: 100%;
	box-sizing: border-box;
}

.image-link {
	display: block;
	text-decoration: none;
	color: inherit;
	border-radius: 8px;
	transition: opacity 0.2s;
}

.image-link:hover {
	opacity: 0.8;
}

.game-image {
	width: 75px;
	height: 75px;
	border-radius: 12px;
	object-fit: cover;
	flex-shrink: 0;
}

.item-details {
	flex-grow: 1;
	min-width: 0;
}

.title-row {
	display: flex;
	justify-content: space-between;
	align-items: flex-start;
	width: 100%;
}

.title-info {
	flex: 1;
	min-width: 0;
}

.title-row h3 {
	margin: 0 0 4px 0;
	font-size: 15px;
	font-weight: 500;
	word-wrap: break-word;
}

.types-column {
	display: flex;
	flex-direction: column;
}

.item-type {
	color: #666;
	font-size: 13px;
	font-weight: normal;
	margin-bottom: 4px;
}

.edition-info {
	display: flex;
	align-items: center;
	gap: 6px;
	/* color: #666; */
	font-size: 13px;
}

.price-info {
	display: flex;
	flex-direction: column;
	align-items: flex-end;
	gap: 4px;
	flex-shrink: 0;
	min-width: 120px;
}

.original-price-container {
	display: flex;

	gap: 8px;
}

.price-stack {
	display: flex;
	flex-direction: column;
	align-items: flex-end;
}

.price-crossed {
	color: #666;
	font-size: 12px;
	text-decoration: line-through;
	line-height: 1;
}

.price-final {
	color: #000;
	font-size: 14px;
	font-weight: 600;
	line-height: 1.2;
}

.discount-badge {
	padding: 0 5px;
	height: 15px;
	background: linear-gradient(
		180deg,
		rgba(0, 122, 255, 1) 0%,
		rgba(0, 73, 153, 1) 100%
	);
	border-radius: 5px;
	display: flex;
	align-items: center;
	justify-content: center;
}

.discount-text {
	color: #ffffff;
	font-size: 10px;
	font-weight: normal;
}

.edition-type {
	display: flex;
	align-items: center;
	gap: 4px;
}

.ps-plus-icon {
	width: 16px;
	height: 16px;
}

.platforms {
	display: flex;
	gap: 4px;
}

.platform-badge {
	width: 17px;
	height: 17px;
	object-fit: contain;
	border-radius: 4px;
	font-size: 12px;
}

.action-button {
	background: #f3f4f6;
	border: none;
	padding: 6px;
	cursor: pointer;
	display: flex;
	align-items: center;
	justify-content: center;
	width: 32px;
	height: 32px;
	border-radius: 10px;
	transition: all 0.2s ease-in-out;
	margin-top: 8px;
}

.action-button:hover {
	background: #e5e7eb;
	transform: scale(0.98);
}

.action-button:active {
	transform: scale(0.95);
}

.action-button img {
	width: 16px;
	height: 16px;
	opacity: 0.7;
}

.shop-purchase {
	position: relative;
	margin-top: 20px;
	margin-bottom: 80px;
	background: white;
	border-radius: 15px;
}

.purchase-content {
	margin: 0 auto;
	background: white;
	width: 100%;
	box-sizing: border-box;
	border-radius: 15px;
}

.promo-code {
	display: flex;
	gap: 8px;
	margin-bottom: 16px;
	align-items: center;
}

.promo-input {
	flex: 1;
	height: 40px;
	padding: 0 12px;
	border: 1px solid #e5e7eb;
	border-radius: 13px;
	font-size: 14px;
	color: #111827;
	transition: all 0.2s ease;
}

.promo-input:focus {
	outline: none;
	border-color: #007aff;
}

.promo-input.promo-success {
	border-color: #4caf50;
	background-color: rgba(76, 175, 80, 0.1);
}

.promo-input.promo-error {
	border-color: #f44336;
	background-color: rgba(244, 67, 54, 0.1);
	animation: shake 0.82s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
}

.apply-promo {
	height: 40px;
	min-width: 120px;
}

.apply-promo :deep(.custom-button) {
	height: 100%;
	border-radius: 13px;
	background: #f3f4f6;
	transition: all 0.2s ease;
}

.apply-promo.active :deep(.custom-button) {
	background: #007aff;
}

.apply-promo.success :deep(.custom-button) {
	background: #4caf50;
	cursor: default;
}

.apply-promo :deep(.button-text) {
	color: #6b7280;
	font-size: 14px;
	font-weight: 600;
	transition: color 0.2s ease;
}

.apply-promo.active :deep(.button-text) {
	color: white;
}

.apply-promo.success :deep(.button-text) {
	color: white;
}

.summary {
	margin-bottom: 15px;
}

.final-total {
	display: flex;
	justify-content: space-between;
	align-items: center;
	font-size: 17px;
	font-weight: bold;
	padding-top: 10px;
	width: 100%;
	overflow: hidden;
}

.total-info {
	display: flex;
	align-items: center;
	gap: 12px;
	flex-wrap: nowrap;
	overflow: hidden;
	max-width: 70%;
}

.original-price {
	text-decoration: line-through;
	color: #666;
	font-size: 12px;
	font-weight: normal;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}

.original-price-in-item {
	color: #000;
	font-size: 13px;
	font-weight: normal;
}

.savings-label {
	background: linear-gradient(
		180deg,
		rgba(0, 122, 255, 1) 0%,
		rgba(0, 73, 153, 1) 100%
	);
	padding: 4px 8px;
	border-radius: 5px;
	color: #ffffff;
	font-size: 12px;
	font-weight: normal;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	display: inline-block;
	flex-shrink: 0;
}

.total-label {
	color: #333;
	white-space: nowrap;
	flex-shrink: 0;
}

.total-amount {
	font-size: 13px;
	color: #000;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}

.checkout-button {
	width: 100%;
	height: 52px;
	background: #0066cc;
	color: white;
	border: none;
	border-radius: 13px;
	font-size: 15px;
	font-weight: bold;
	cursor: pointer;
}

.full-width-button {
	width: 100%;
	height: 52px;
	font-size: 15px;
	font-weight: bold;
}

.full-width-button :deep(.custom-button) {
	width: 100%;
	height: 100%;
	border-radius: 13px;
}

.full-width-button :deep(.button-text) {
	width: 100%;
	text-align: center;
}

.disabled-button :deep(.custom-button) {
	background-color: #ccc !important;
	cursor: not-allowed !important;
}

.disabled-button :deep(.button-text) {
	color: #666 !important;
}

.currency-mismatch-hint {
	margin-bottom: 12px;
	font-size: 14px;
	color: #ff3b30;
	text-align: center;
	display: flex;
	align-items: center;
	justify-content: center;
	gap: 8px;
}

.empty-cart-hint {
	color: #666;
}

.hint-icon {
	font-size: 16px;
	display: inline-block;
}

.price-explanation-btn {
	margin-top: 8px;
	background: none;
	border: none;
	color: #0077ff;
	font-size: 14px;
	cursor: pointer;
	padding: 4px 8px;
	text-decoration: underline;
	transition: opacity 0.2s;
}

.price-explanation-btn:hover {
	opacity: 0.8;
}

.price-explanation-modal {
	max-width: 400px;
	padding: 24px;
}

.price-explanation-modal h3 {
	margin: 0 0 16px 0;
	font-size: 18px;
	color: #1a1a1a;
}

.price-explanation-modal p {
	margin: 0 0 20px 0;
	font-size: 16px;
	line-height: 1.5;
	color: #333;
}

.close-modal-btn {
	width: 100%;
	padding: 12px;
	background: #0077ff;
	color: white;
	border: none;
	border-radius: 8px;
	font-size: 16px;
	cursor: pointer;
	transition: background-color 0.2s;
}

.close-modal-btn:hover {
	background-color: #0066dd;
}

/* Стили для модального окна */
.modal-overlay {
	position: fixed;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	background-color: rgba(0, 0, 0, 0.5);
	display: flex;
	justify-content: center;
	align-items: center;
	z-index: 1000;
}

.modal-content {
	background: white;
	padding: 20px;
	border-radius: 15px;
	width: 90%;
	max-width: 400px;
}

.modal-body {
	text-align: center;
}

.modal-icon {
	width: 90px;
	height: 90px;
	margin: 0 auto 12px;
}

.game-icon {
	width: 100%;
	height: 100%;
	object-fit: cover;
	border-radius: 20px;
}

.modal-text {
	margin-bottom: 20px;
}

.modal-text h3 {
	margin: 0 0 8px 0;
	font-size: 18px;
}

.modal-text p {
	margin: 0;
	color: #666;
}

.modal-actions {
	display: flex;
	justify-content: center;
	gap: 10px;
}

.modal-btn {
	padding: 10px 20px;
	border: none;
	border-radius: 10px;
	font-size: 16px;
	cursor: pointer;
	transition: all 0.2s ease;
}

.confirm-btn {
	background-color: #f3f4f6;
	color: #333;
}

.confirm-btn:hover {
	background-color: #e5e7eb;
}

.cancel-btn {
	background-color: #007aff;
	color: white;
}

.cancel-btn:hover {
	background-color: #0066cc;
}

/* Анимации для модального окна */
.modal-enter-active,
.modal-leave-active {
	transition: opacity 0.3s ease;
}

.modal-enter-from,
.modal-leave-to {
	opacity: 0;
}

@keyframes shake {
	10%,
	90% {
		transform: translate3d(-1px, 0, 0);
	}
	20%,
	80% {
		transform: translate3d(2px, 0, 0);
	}
	30%,
	50%,
	70% {
		transform: translate3d(-4px, 0, 0);
	}
	40%,
	60% {
		transform: translate3d(4px, 0, 0);
	}
}

.currency-mismatch-warning {
	margin: 16px;
	padding: 16px;
	background-color: #fff3cd;
	border: 1px solid #ffeeba;
	border-radius: 12px;
	display: flex;
	align-items: flex-start;
	gap: 12px;
}

.warning-icon {
	font-size: 24px;
	line-height: 1;
}

.warning-text {
	flex: 1;
}

.warning-text p {
	margin: 0 0 8px 0;
	color: #856404;
	font-size: 14px;
	line-height: 1.4;
}

.warning-actions {
	display: flex;
	gap: 8px;
	margin-top: 12px;
}

.warning-action-btn {
	padding: 8px 16px;
	border-radius: 8px;
	border: none;
	font-size: 14px;
	font-weight: 500;
	cursor: pointer;
	background-color: #007aff;
	color: white;
	transition: all 0.2s ease;
}

.warning-action-btn:hover {
	background-color: #0066cc;
}

.warning-clear-btn {
	background-color: #ff3b30;
}

.warning-clear-btn:hover {
	background-color: #d9342b;
}

.warning-modal-icon {
	font-size: 48px;
	width: 60px;
	height: 60px;
	display: flex;
	align-items: center;
	justify-content: center;
}

.currency-change-notice {
	margin: 16px;
	padding: 12px;
	background-color: #e6f7ff;
	border: 1px solid #91d5ff;
	border-radius: 12px;
	display: flex;
	align-items: center;
	gap: 12px;
}

.notice-icon {
	font-size: 20px;
	line-height: 1;
}

.notice-text {
	flex: 1;
}

.notice-text p {
	margin: 0;
	color: #0066cc;
	font-size: 14px;
	line-height: 1.4;
}
</style>
