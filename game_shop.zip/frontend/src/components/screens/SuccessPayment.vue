<template>
	<div class="success-payment">
		<div class="success-content">
			<div v-if="isProcessing" class="processing">
				<div class="spinner"></div>
				<p>Проверяем статус платежа...</p>
			</div>
			<div v-else-if="error" class="error-content">
				<div class="error-icon">
					<i class="fas fa-exclamation-circle"></i>
				</div>
				<h2>Произошла ошибка</h2>
				<p>{{ error }}</p>
			</div>
			<div v-else class="success-content">
				<div class="success-icon">
					<i class="fas fa-check-circle"></i>
				</div>
				<h1>Оплата успешна!</h1>
				<p>
					Мы начали обработку вашего заказа. Вы получите уведомление в
					Telegram, как только игры будут добавлены в ваш аккаунт.
				</p>
				<router-link to="/" class="home-button">
					Вернуться на главную
				</router-link>
			</div>
		</div>
	</div>
</template>

<script setup>
import axios from 'axios';
import { onMounted, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';

const store = useStore();
const router = useRouter();
const error = ref(null);
const isProcessing = ref(true);

onMounted(async () => {
	const paymentData = store.getters['payment/getPaymentData'];

	if (!paymentData) {
		console.log('No payment data found, redirecting to home');
		router.push('/');
		return;
	}

	try {
		console.log('Verifying payment:', paymentData.orderId);
		isProcessing.value = true;

		// Проверяем статус платежа
		const response = await axios.post('/api/payment/verify', {
			orderId: paymentData.orderId,
			telegramUsername: store.getters['user/username'],
			email: paymentData.email,
		});

		if (response.data.success) {
			console.log('Payment verified successfully');

			// Очищаем корзину
			await store.dispatch('cart/clearCart');

			// Очищаем данные об оплате
			await store.dispatch('payment/savePaymentData', null);
		} else {
			console.error('Payment verification failed:', response.data);
			error.value =
				'Не удалось подтвердить платёж. Пожалуйста, свяжитесь с поддержкой.';
			router.push('/payment-error');
		}
	} catch (err) {
		console.error('Error verifying payment:', err);
		error.value =
			'Произошла ошибка при проверке платежа. Пожалуйста, свяжитесь с поддержкой.';
		router.push('/payment-error');
	} finally {
		isProcessing.value = false;
	}
});
</script>

<style scoped>
.success-payment {
	display: flex;
	justify-content: center;
	align-items: center;
	min-height: 100vh;
}

.success-content {
	text-align: center;
	background: #fff;
	padding: 40px;
	border-radius: 10px;
	box-shadow: 0 2px 10px #0000001a;
	max-width: 500px;
	width: 100%;
	margin-bottom: 30px;
}

.success-icon {
	font-size: 80px;
	color: #28a745;
	margin-bottom: 20px;
}

h1 {
	color: #28a745;
	margin-bottom: 20px;
	font-size: 24px;
}

p {
	color: #6c757d;
	margin-bottom: 30px;
	line-height: 1.5;
}

.home-button {
	display: inline-block;
	background-color: #007bff;
	color: white;
	padding: 12px 24px;
	border-radius: 5px;
	text-decoration: none;
	transition: background-color 0.2s;
}

.home-button:hover {
	background-color: #0056b3;
}

.processing {
	text-align: center;
	margin: 20px 0;
}

.spinner {
	border: 4px solid #f3f3f3;
	border-top: 4px solid #007bff;
	border-radius: 50%;
	width: 40px;
	height: 40px;
	animation: spin 1s linear infinite;
	margin: 0 auto 20px;
}

.error-content {
	text-align: center;
}

.error-icon {
	font-size: 80px;
	color: #dc3545;
	margin-bottom: 20px;
}

@keyframes spin {
	0% {
		transform: rotate(0deg);
	}
	100% {
		transform: rotate(360deg);
	}
}
</style>
