<template>
	<div class="payment-screen" v-close-keyboard>
		<h2 class="profile-title">Оплата</h2>

		<div class="form-container">
			<div class="checkout-options">
				<label class="checkout-without-account">
					<input
						type="checkbox"
						v-model="checkoutWithoutAccount"
						class="checkbox-input"
					/>
					<span class="checkbox-label"
						>У меня нет зарубежного аккаунта PlayStation</span
					>
				</label>
			</div>

			<div v-if="!checkoutWithoutAccount">
				<div class="form-group">
					<label for="ps-login">
						Почта от вашего зарубежного аккаунта PlayStation
					</label>
					<input
						type="text"
						id="ps-login"
						v-model="psLogin"
						enterkeyhint="next"
						@keyup.enter="focusNextField('psLogin')"
					/>
				</div>

				<div class="form-group">
					<label for="ps-password">
						Пароль от вашего зарубежного аккаунта PlayStation
					</label>
					<div class="password-input">
						<input
							:type="showPassword ? 'text' : 'password'"
							id="ps-password"
							v-model="psPassword"
							enterkeyhint="next"
							@keyup.enter="focusNextField('psPassword')"
						/>
						<button @click="togglePassword" class="toggle-password">
							<img
								:src="
									showPassword
										? '/assets/img/eye-open.svg'
										: '/assets/img/eye-closed.svg'
								"
								alt="Toggle password visibility"
							/>
						</button>
					</div>
				</div>

				<div class="form-group">
					<label for="ps-backup-codes"
						>Резервные коды (если есть)</label
					>
					<input
						type="text"
						id="ps-backup-codes"
						v-model="psBackupCodes"
						enterkeyhint="next"
						@keyup.enter="focusNextField('psBackupCodes')"
					/>
				</div>
			</div>

			<div v-else>
				<div class="form-group">
					<label for="firstName"> Имя </label>
					<input
						type="text"
						id="firstName"
						v-model="firstName"
						enterkeyhint="next"
						@keyup.enter="focusNextField('firstName')"
					/>
				</div>

				<div class="form-group">
					<label for="lastName"> Фамилия </label>
					<input
						type="text"
						id="lastName"
						v-model="lastName"
						enterkeyhint="next"
						@keyup.enter="focusNextField('lastName')"
					/>
				</div>

				<div class="form-group">
					<label for="customerEmail"> Email </label>
					<input
						type="email"
						id="customerEmail"
						v-model="customerEmail"
						enterkeyhint="next"
						@keyup.enter="focusNextField('customerEmail')"
					/>
				</div>

				<div class="form-group">
					<label for="birthDate"> Дата рождения </label>
					<input
						type="date"
						id="birthDate"
						v-model="birthDate"
						enterkeyhint="next"
						@keyup.enter="focusNextField('birthDate')"
					/>
				</div>
			</div>

			<div class="form-group">
				<label for="telegram-login">Логин в Telegram</label>
				<input
					type="text"
					id="telegram-login"
					disabled
					:value="telegramUsername"
				/>
			</div>

			<div class="form-group">
				<label for="email">
					Email для чека
					<span class="required">*</span>
				</label>
				<input
					type="email"
					id="email"
					v-model="email"
					required
					enterkeyhint="done"
					@keyup.enter="focusNextField('email')"
				/>
			</div>

			<button
				@click="handlePayment"
				class="submit-button"
				:disabled="isLoading"
			>
				<span v-if="!isLoading">Оплатить {{ formattedPrice }}</span>
				<span v-else>Создание счета...</span>
			</button>
			<p v-if="error" style="color: red">{{ error }}</p>
		</div>

		<!-- Добавляем компонент отслеживания статуса -->
		<PaymentStatus
			v-if="showPaymentStatus"
			:orderId="currentOrderId"
			:isVisible="showPaymentStatus"
			:paymentUrl="paymentUrl"
			@closeStatus="showPaymentStatus = false"
		/>
	</div>
</template>

<script setup>
import PaymentStatus from '@/components/PaymentStatus.vue';
import { calculateCartTotal, createLifePayBill } from '@/services/apiService';
import { formatPrice } from '@/utils/discount';
import { computed, onMounted, ref, watch } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';

const store = useStore();
const router = useRouter();

const cartItems = computed(() => store.getters['cart/cartItems']);
const totalPrice = computed(() => store.getters['cart/cartTotal']);
const formattedPrice = computed(() => formatPrice(totalPrice.value));

const selectedCurrency = computed(() => store.getters['user/currentCurrency']);

const psLogin = ref('');
const psPassword = ref('');
const psBackupCodes = ref('');
const email = ref('');
const showPassword = ref(false);
const isLoading = ref(false);
const error = ref('');
const checkoutWithoutAccount = ref(false);
const firstName = ref('');
const lastName = ref('');
const customerEmail = ref('');
const birthDate = ref('');

const isAuthenticated = computed(() => store.getters['auth/isAuthenticated']);
const telegramUsername = computed(() => store.getters['auth/telegramUsername']);
const telegramId = computed(() => store.getters['auth/telegramId']);

// Определение платформы и WebApp
const telegram = computed(() => window.Telegram?.WebApp);

const getPlatform = computed(() => {
	const tg = telegram.value;
	if (!tg) return 'unknown';

	// Проверяем UserAgent для более точного определения платформы
	const ua = navigator.userAgent.toLowerCase();
	const isMobileDevice = /mobile|android|iphone|ipad|ipod/.test(ua);

	if (tg.platform === 'unknown' && isMobileDevice) {
		return 'mobile';
	}

	return tg.platform;
});

const isMobile = computed(() => {
	const platform = getPlatform.value;
	return (
		platform === 'mobile' || platform === 'android' || platform === 'ios'
	);
});

// Добавляем новые refs для отслеживания платежа
const paymentWindow = ref(null);
const currentOrderId = ref(null);
const showPaymentStatus = ref(false);
const paymentUrl = ref('');

// Функция для обновления серверного расчета итоговой цены
const updateServerCalculatedTotal = async () => {
	if (
		!cartItems.value ||
		cartItems.value.length === 0 ||
		!selectedCurrency.value?.id
	) {
		return;
	}

	try {
		const editionIds = cartItems.value.map(item => item.id);

		// Создаем объект с типами цен для каждого товара
		const priceTypes = {};
		cartItems.value.forEach(item => {
			if (item.priceType) {
				priceTypes[item.id] = item.priceType;
			}
		});

		// Рассчитываем сумму со скидками на товары
		const subtotalWithItemDiscounts = cartItems.value.reduce(
			(total, item) => {
				const price = Number(item.price || 0);
				const discount = Number(item.discount_amount || 0);
				return total + (price - discount);
			},
			0
		);

		// Получаем промокод из хранилища
		const appliedPromoCode = store.state.cart.appliedPromoCode;
		console.log(
			'Applied promo code for payment calculation:',
			appliedPromoCode
		);

		const response = await calculateCartTotal(
			editionIds,
			selectedCurrency.value.id,
			subtotalWithItemDiscounts,
			priceTypes,
			appliedPromoCode // Передаем промокод на сервер
		);

		if (response && response.total !== undefined) {
			let finalTotal = response.total;

			// Обновляем информацию о промокоде, если сервер вернул данные
			if (response.appliedPromo) {
				store.dispatch('cart/applyPromoCode', {
					code: response.appliedPromo.name,
					discount: response.appliedPromo.discount,
				});
			}

			// Сохраняем серверный расчет в хранилище Vuex
			store.dispatch('cart/setServerCalculatedTotal', finalTotal);
		}
	} catch (error) {
		console.error('Error updating server calculated total:', error);
	}
};

onMounted(async () => {
	try {
		await store.dispatch('auth/initAuth');
		await store.dispatch('cart/loadCart'); // Загружаем корзину

		// Обновляем серверный расчет итоговой цены
		await updateServerCalculatedTotal();

		if (isAuthenticated.value) {
			// Загружаем пользователя
			await store.dispatch('user/fetchUser', store.state.auth.telegramId);

			// Получаем данные пользователя
			const user = store.state.user.user;
			if (user) {
				psLogin.value = user.psStoreLogin || '';
				psPassword.value = user.psStorePassword || '';
				psBackupCodes.value = user.psBackupCodes || '';
				email.value = user.email || '';
			}
		}
	} catch (err) {
		error.value = 'Ошибка при загрузке данных профиля';
		console.error(err);
	}
});

const handlePayment = async () => {
	if (!isAuthenticated.value) {
		error.value = 'Для оплаты необходимо открыть приложение через Telegram';
		return;
	}

	try {
		isLoading.value = true;
		error.value = '';

		// Проверяем только email для чека
		if (!email.value) {
			error.value = 'Пожалуйста, укажите email для чека';
			return;
		}

		// Проверяем корзину
		if (!cartItems.value || cartItems.value.length === 0) {
			error.value = 'Корзина пуста';
			return;
		}

		// Обновляем серверный расчет итоговой цены перед созданием платежа
		await updateServerCalculatedTotal();

		console.log('Cart items:', cartItems.value);

		// Сохраняем обновленные данные через user store
		const fields = {
			psStoreLogin: psLogin.value,
			psStorePassword: psPassword.value,
			psBackupCodes: psBackupCodes.value,
			email: email.value,
		};

		for (const [field, value] of Object.entries(fields)) {
			await store.dispatch('user/updateUserField', { field, value });
		}

		// Формируем описание заказа
		const gameNames = cartItems.value.map(item => item.title).join(', ');
		console.log('Game names:', gameNames);

		const description = `Подключение ${gameNames}`;
		console.log('Payment description:', description);

		// Создаем счет на оплату с расширенными данными
		const paymentData = {
			telegramId: telegramId.value,
			...(telegramUsername.value && {
				telegramUsername: telegramUsername.value,
			}),
			gameInfo: cartItems.value.map(item => {
				// Считаем финальную цену с учетом скидки
				const price = Number(item.price || 0);
				const discount = Number(item.discount_amount || 0);
				const finalPrice = discount > 0 ? price - discount : price;

				// Получаем название издания
				const editionName =
					item.editionName ||
					item.edition?.edition_name?.name ||
					'Standard';

				return {
					id: item.id,
					title: item.title,
					editionId: item.editionId,
					edition_type: item.edition_type || 'Game',
					edition: item.edition,
					editionName: editionName,
					price: price,
					finalPrice: Number(finalPrice),
					discount_amount: discount,
					currency: selectedCurrency.value, // Добавляем информацию о валюте для каждой игры
				};
			}),
			currency: selectedCurrency.value,
			checkoutWithoutAccount: checkoutWithoutAccount.value,
			psLogin: psLogin.value,
			// Убедимся, что пароль передается как строка
			psPassword: psPassword.value ? String(psPassword.value) : '',
			psBackupCodes: psBackupCodes.value,
			firstName: firstName.value,
			lastName: lastName.value,
			customerEmail: customerEmail.value,
			birthDate: birthDate.value,
		};

		// Логируем данные для отладки (без вывода полного пароля)
		console.log('Payment data being sent:', {
			...paymentData,
			psPassword: psPassword.value
				? `${psPassword.value.length} chars`
				: 'not provided',
			psLogin: psLogin.value || 'not provided',
			psBackupCodes: psBackupCodes.value ? 'provided' : 'not provided',
			checkoutWithoutAccount: checkoutWithoutAccount.value,
		});

		const bill = await createLifePayBill({
			amount: totalPrice.value,
			email: email.value,
			description,
			...paymentData,
		});

		// Сохраняем данные о платеже
		if (bill && bill.paymentUrl) {
			await store.dispatch('payment/savePaymentData', {
				orderId: bill.orderId,
				amount: totalPrice.value,
				items: cartItems.value,
				psLogin: psLogin.value,
				email: email.value,
				paymentUrl: bill.paymentUrl, // Сохраняем URL платежа
			});

			console.log(
				'Payment data saved, handling payment URL:',
				bill.paymentUrl
			);

			// Сохраняем orderId для отслеживания
			currentOrderId.value = bill.orderId;
			paymentUrl.value = bill.paymentUrl;
			showPaymentStatus.value = true;

			const platform = getPlatform.value;
			console.log('Current platform:', platform);
			console.log('Telegram WebApp available:', !!telegram.value);

			// Улучшенная логика открытия платежного окна
			if (isMobile.value) {
				console.log('Opening payment on mobile device');
				const tg = telegram.value;

				if (tg && typeof tg.openLink === 'function') {
					console.log('Using Telegram WebApp openLink');
					tg.openLink(bill.paymentUrl, {
						try_instant_view: false,
						open_in_browser: true,
					});
				} else {
					console.log('Fallback to direct link');
					window.location.href = bill.paymentUrl;
				}
			} else {
				// Для десктопа открываем в новом окне с улучшенными параметрами
				const screenWidth = window.screen.width;
				const screenHeight = window.screen.height;
				const width = Math.min(screenWidth * 0.4, 500);
				const height = Math.min(screenHeight * 0.8, 700);
				const left = (screenWidth - width) / 2;
				const top = (screenHeight - height) / 2;

				window.paymentWindow = window.open(
					bill.paymentUrl,
					'payment_window',
					`width=${width},height=${height},left=${left},top=${top},menubar=no,toolbar=no,location=no,status=no,scrollbars=yes`
				);

				// Отслеживаем закрытие окна
				if (window.paymentWindow) {
					const checkWindowClosed = setInterval(() => {
						if (window.paymentWindow.closed) {
							clearInterval(checkWindowClosed);
							isPaymentWindowClosed.value = true;
						}
					}, 500);
				}
			}
		} else {
			throw new Error('Не удалось создать счет для оплаты');
		}
	} catch (err) {
		console.error('Payment error:', err);
		error.value =
			err.response?.data?.error ||
			'Произошла ошибка при создании платежа. Пожалуйста, попробуйте позже или обратитесь в поддержку.';

		// Отправляем ошибку в систему мониторинга
		console.error('Detailed payment error:', {
			error: err,
			response: err.response?.data,
			cartItems: cartItems.value,
			user: {
				telegramUsername: telegramUsername.value,
				email: email.value,
			},
		});
	} finally {
		isLoading.value = false;
	}
};

const togglePassword = () => {
	showPassword.value = !showPassword.value;
};

const focusNextField = currentField => {
	switch (currentField) {
		case 'psLogin':
			document.getElementById('ps-password').focus();
			break;
		case 'psPassword':
			document.getElementById('ps-backup-codes').focus();
			break;
		case 'psBackupCodes':
			document.getElementById('email').focus();
			break;
		case 'firstName':
			document.getElementById('lastName').focus();
			break;
		case 'lastName':
			document.getElementById('customerEmail').focus();
			break;
		case 'customerEmail':
			document.getElementById('birthDate').focus();
			break;
		case 'birthDate':
			document.getElementById('email').focus();
			break;
		case 'email':
			handlePayment();
			break;
	}
};

// Отслеживаем изменения в корзине
watch(
	cartItems,
	newItems => {
		console.log('Cart items changed:', newItems);
	},
	{ deep: true }
);

// Добавляем обработчик закрытия окна оплаты
onMounted(() => {
	window.addEventListener('message', event => {
		if (event.data === 'payment_window_closed' && paymentWindow.value) {
			paymentWindow.value = null;
		}
	});
});
</script>

<style scoped>
.payment-screen {
	padding: 25px 15px 250px 15px;
	padding-bottom: 80px;
	background-color: #ffffff;
	max-width: 600px;
	margin: 0 auto;
	box-sizing: border-box;
	min-height: 100vh;
	display: flex;
	flex-direction: column;
}

.profile-title {
	font-size: 20px;
	font-weight: bold;
	margin-bottom: 30px;
}

.form-container {
	flex-grow: 1;
	padding-bottom: 250px;
}

.form-group {
	margin-bottom: 30px;
	width: 100%;
	box-sizing: border-box;
	position: relative;
}

label {
	display: block;
	margin-bottom: 10px;
	font-size: 15px;
	font-weight: 500;
}

input[type='text'],
input[type='password'],
input[type='email'] {
	width: 100%;
	height: 42px;
	padding: 0 15px;
	border: none;
	border-radius: 13px;
	background-color: #f8f8f8;
	font-size: 15px;
	font-weight: 400;
}

.password-input {
	position: relative;
	width: 100%;
	display: flex;
	align-items: center;
}

.toggle-password {
	position: absolute;
	right: 15px;
	top: 50%;
	transform: translateY(-50%);
	background: none;
	border: none;
	cursor: pointer;
	padding: 0;
	height: 42px;
	display: flex;
	align-items: center;
}

.toggle-password img {
	width: 20px;
	height: 20px;
}

.action-button {
	display: flex;
	justify-content: space-between;
	align-items: center;
	width: 100%;
	height: 42px;
	padding: 0 15px;
	background-color: #f8f8f8;
	border: none;
	border-radius: 13px;
	text-decoration: none;
	margin-bottom: 30px;
	box-sizing: border-box;
}

.action-button span {
	font-size: 15px;
	font-weight: 400;
	color: #037ee5;
}

.arrow-icon {
	width: 16px;
	height: 16px;
}

.submit-button {
	display: flex;
	align-items: center;
	justify-content: center;
	padding: 10px 15px;
	width: 100%;
	border-radius: 13px;
	background-color: rgba(0, 122, 255, 1);
	color: white;
	margin-bottom: 40px;
	border: none;
	height: 52px;
	cursor: pointer;
	transition: background-color 0.3s;
}

.submit-button:disabled {
	background-color: #ccc;
	cursor: not-allowed;
}

.checkout-options {
	margin-bottom: 20px;
}

.checkout-without-account {
	display: flex;
	align-items: center;
	cursor: pointer;
}

.checkbox-input {
	appearance: none;
	width: 20px;
	height: 20px;
	border: 2px solid #1f2937;
	border-radius: 4px;
	margin-right: 8px;
	position: relative;
	cursor: pointer;
	transition: all 0.2s ease;
}

.checkbox-input:checked {
	background-color: #1f2937;
}

.checkbox-input:checked::after {
	content: '';
	position: absolute;
	left: 6px;
	top: 2px;
	width: 5px;
	height: 10px;
	border: solid white;
	border-width: 0 2px 2px 0;
	transform: rotate(45deg);
}

.checkbox-label {
	color: #1f2937;
	font-size: 14px;
	font-weight: 500;
}

.required {
	color: #ef4444;
	margin-left: 2px;
}
</style>
