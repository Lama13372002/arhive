<template>
	<button
		class="cart-button"
		:class="{ active: isActive }"
		@click="toggleCart"
	>
		<img src="/assets/img/shopbag.svg" alt="В корзину" />
	</button>
</template>

<script setup>
import { ref, watch } from 'vue';
import { useStore } from 'vuex';

const props = defineProps({
	modelValue: {
		type: Boolean,
		required: true,
	},
	game: {
		type: Object,
		required: true,
	},
});

const emit = defineEmits(['update:modelValue']);
const store = useStore();
const isActive = ref(props.modelValue);

watch(
	() => props.modelValue,
	newValue => {
		isActive.value = newValue;
	}
);

const toggleCart = async event => {
	event.preventDefault();
	event.stopPropagation();

	try {
		if (!isActive.value) {
			// Находим издание с самой выгодной ценой
			let bestEdition = null;
			let lowestPrice = Infinity;

			props.game.editions.forEach(edition => {
				// Расчет финальной цены для издания
				let currentPrice = Number(edition.price) || 0;

				// Учитываем скидку
				if (edition.discount_percentage) {
					currentPrice =
						currentPrice * (1 - edition.discount_percentage / 100);
				}

				// Учитываем PS Plus цену
				if (edition.ps_plus_price && store.getters['user/hasPsPlus']) {
					currentPrice = Number(edition.ps_plus_price);
				}

				// Учитываем EA Play цену
				if (edition.ea_play_price && store.getters['user/hasEaPlay']) {
					currentPrice = Number(edition.ea_play_price);
				}

				if (currentPrice < lowestPrice) {
					lowestPrice = currentPrice;
					bestEdition = edition;
				}
			});

			if (bestEdition) {
				const cartItem = {
					id: bestEdition.id,
					productId: props.game.id,
					title: props.game.title,
					image: props.game.image,
					price: bestEdition.price,
					originalPrice: bestEdition.price,
					editionType: bestEdition.editionType?.name || 'Standard',
					priceType: 'standard',
					ps_plus_price: bestEdition.ps_plus_price,
					ea_play_price: bestEdition.ea_play_price,
					discount_percentage: bestEdition.discount_percentage || 0,
					type: props.game.type || 'Игра',
					platforms: props.game.platforms || ['PS5'],
				};

				await store.dispatch('cart/addToCart', cartItem);
				isActive.value = true;
			}
		} else {
			await store.dispatch('cart/removeFromCart', props.game.id);
			isActive.value = false;
		}
		emit('update:modelValue', isActive.value);
	} catch (error) {
		console.error('Error toggling cart:', error);
	}
};
</script>

<style scoped>
.cart-button {
	width: 30px;
	height: 30px;
	display: flex;
	align-items: center;
	justify-content: center;
	border-radius: 10px;
	background-color: #f2f2f2;
	border: none;
	cursor: pointer;
	transition: all 0.3s ease;
}

.cart-button img {
	width: 13px;
	height: 14px;
	transition: filter 0.3s ease;
}

.cart-button:hover {
	background-color: #e5e5e5;
}

.cart-button.active {
	background-color: #007aff;
	animation: buttonPop 0.3s ease;
}

.cart-button.active img {
	filter: brightness(0) invert(1);
}

@keyframes buttonPop {
	0% {
		transform: scale(0.95);
	}
	50% {
		transform: scale(1.05);
	}
	100% {
		transform: scale(1);
	}
}
</style>
