<template>
	<div
		class="custom-button-container"
		:class="{ 'full-width-button': isFullWidth }"
	>
		<button
			:class="['custom-button', { active: modelValue }]"
			@click="handleClick"
		>
			<span class="button-text">{{ text }}</span>
		</button>
		<button
			v-if="modelValue && showCancel"
			class="cancel-button"
			@click="handleCancel"
		>
			<span class="cancel-text">Отменить</span>
		</button>
	</div>
</template>

<script>
export default {
	name: 'Button',
	props: {
		text: {
			type: String,
			required: true,
		},
		isProductCard: {
			type: Boolean,
			default: false,
		},
		isFullWidth: {
			type: Boolean,
			default: false,
		},
		modelValue: {
			type: Boolean,
			default: false,
		},
	},
	emits: ['update:modelValue', 'buttonClicked'],
	computed: {
		showCancel() {
			return this.isProductCard && this.modelValue;
		},
	},
	methods: {
		handleClick() {
			this.$emit('buttonClicked');
			if (this.isProductCard && !this.modelValue) {
				this.$emit('update:modelValue', true);
			}
		},
		handleCancel() {
			this.$emit('update:modelValue', false);
		},
	},
};
</script>

<style scoped>
.custom-button-container {
	display: flex;
	align-items: center;
	gap: 15px;
}

.custom-button-container.full-width-button {
	width: 100%;
}

.custom-button-container.full-width-button .custom-button {
	width: 100%;
	height: 52px;
}

.custom-button {
	display: flex;
	align-items: center;
	justify-content: center;
	padding: 10px 15px;
	border-radius: 13px;
	background-color: rgba(0, 122, 255, 1);
	border: none;
	cursor: pointer;
	transition: background-color 0.3s;
}

.custom-button.active {
	background-color: rgba(52, 199, 89, 1);
}

.button-text {
	color: white;
	font-size: 15px;
	font-weight: 500;
	font-family: 'Open Sans', sans-serif;
	text-align: center;
	width: 100%;
}

.cancel-button {
	display: flex;
	align-items: center;
	justify-content: center;
	padding: 10px 15px;
	border-radius: 13px;
	background-color: rgba(248, 248, 248, 1);
	border: none;
	cursor: pointer;
}

.cancel-text {
	color: rgba(0, 0, 0, 0.5);
	font-size: 15px;
	font-weight: 500;
	font-family: 'Open Sans', sans-serif;
}
</style>
