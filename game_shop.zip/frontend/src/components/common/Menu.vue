<template>
	<nav class="bottom-nav" :class="{ 'search-expanded': isSearchExpanded }">
		<div
			v-show="isHomePage"
			class="search-container"
			:class="{ 'full-width': isSearchExpanded }"
			@click="goToSearch"
		>
			<input
				type="text"
				v-model="searchQuery"
				placeholder="Поиск"
				@focus="goToSearch"
				style="width: 100%"
				readonly
			/>
		</div>
		<div class="nav-buttons" :class="{ hidden: isSearchExpanded }">
			<div class="localization-dropdown">
				<button
					class="nav-item"
					@click="toggleLocalizationDropdown"
					:class="{ active: isLocalizationDropdownOpen }"
				>
					<img
						:src="currentLocalizationFlag"
						alt="Локализация"
						class="local-button"
					/>
				</button>
				<div
					v-if="isLocalizationDropdownOpen"
					class="localization-options"
				>
					<button
						v-for="currency in localizationOptions"
						:key="currency.id"
						@click="setLocalization(currency)"
					>
						<img
							:src="getCurrencyIcon(currency.icon)"
							:alt="currency.name"
						/>
					</button>
				</div>
			</div>
			<router-link
				to="/"
				class="nav-item"
				:class="{ active: isActive('/') }"
			>
				<img src="/assets/img/home.svg" alt="Домашняя страница" />
			</router-link>
			<router-link
				to="/shop-bag"
				class="nav-item"
				:class="{ active: isActive('/shop-bag') }"
			>
				<div class="nav-item-container">
					<img src="/assets/img/shopbag.svg" alt="Корзина" />
					<span v-if="cartItemsCount > 0" class="counter-badge">{{
						cartItemsCount
					}}</span>
				</div>
			</router-link>
			<router-link
				to="/favourites"
				class="nav-item"
				:class="{ active: isActive('/favourites') }"
			>
				<div class="nav-item-container">
					<img src="/assets/img/favorits.svg" alt="Избранное" />
					<span v-if="favouritesCount > 0" class="counter-badge">{{
						favouritesCount
					}}</span>
				</div>
			</router-link>
			<router-link
				to="/profile"
				class="nav-item"
				:class="{ active: isActive('/profile') }"
			>
				<img src="/assets/img/profile.svg" alt="Профиль" />
			</router-link>
		</div>
	</nav>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useStore } from 'vuex';

const store = useStore();
const router = useRouter();
const route = useRoute();

const currencies = ref([]);
const currentLocalization = computed({
	get: () => store.state.user.currentCurrency,
	set: value => store.commit('user/SET_USER_CURRENCY', value),
});

const isLocalizationDropdownOpen = ref(false);
const isSearchExpanded = ref(false);
const searchQuery = ref('');

const currentLocalizationFlag = computed(() => {
	const icon = currentLocalization.value?.icon;
	if (!icon) return '/assets/img/rub.svg';

	const baseUrl = import.meta.env.VITE_API_BASE_URL;
	if (!baseUrl) {
		console.error('VITE_API_BASE_URL не определен в переменных окружения');
		return icon;
	}

	// Если это полный URL, заменяем домен
	if (icon.startsWith('http')) {
		const path = icon.split('/uploads/')[1];
		return path ? `${baseUrl}/uploads/${path}` : icon;
	}

	return `${baseUrl}/uploads/${icon}`;
});

const getCurrencyIcon = icon => {
	if (!icon) return '/assets/img/rub.svg';

	const baseUrl = import.meta.env.VITE_API_BASE_URL;
	if (!baseUrl) {
		console.error('VITE_API_BASE_URL не определен в переменных окружения');
		return icon;
	}

	// Если это полный URL, заменяем домен
	if (icon.startsWith('http')) {
		const path = icon.split('/uploads/')[1];
		return path ? `${baseUrl}/uploads/${path}` : icon;
	}

	return `${baseUrl}/uploads/${icon}`;
};

const fetchCurrencies = async () => {
    console.log('=== fetchCurrencies START ===');
    try {
        const response = await fetch('/api/currencies');
        if (!response.ok) {
            throw new Error('Failed to fetch currencies');
        }
        const data = await response.json();
        console.log('Received currencies:', data);
        currencies.value = data;

        // Если у пользователя нет выбранной валюты, устанавливаем первую из списка
        console.log('Current localization:', currentLocalization.value);
        if (!currentLocalization.value && data.length > 0) {
            console.log('Setting default currency:', data[0]);
            store.commit('user/SET_USER_CURRENCY', data[0]);
        }
    } catch (error) {
        console.error('Error fetching currencies:', error);
    } finally {
        console.log('=== fetchCurrencies END ===');
    }
};

const fetchUserCurrency = async () => {
	try {
		let telegramId = store.state.user.user?.telegramId;

		// Если пользователь не инициализирован, получаем ID из Telegram Web App
		if (!telegramId) {
			telegramId = window.Telegram?.WebApp?.initDataUnsafe?.user?.id;
			if (telegramId) {
				// Инициализируем пользователя в store
				await store.dispatch('user/fetchUser', telegramId);
			} else {
				console.warn('Telegram user ID not available');
				return;
			}
		}

		const response = await fetch(`/api/users/${telegramId}/currency`);
		if (response.data) {
			store.commit('user/SET_USER_CURRENCY', response.data);
		}
	} catch (error) {
		console.error('Error fetching user currency:', error);
	}
};

onMounted(async () => {
    console.log('=== Menu component mounted ===');
    
    // Загружаем список валют
    await fetchCurrencies();

    // Пробуем получить сохраненную валюту из localStorage
    const savedCurrency = localStorage.getItem('userCurrency');
    console.log('Saved currency from localStorage:', savedCurrency);
    
    if (savedCurrency) {
        try {
            const currency = JSON.parse(savedCurrency);
            console.log('Parsed saved currency:', currency);
            store.commit('user/SET_USER_CURRENCY', currency);
        } catch (e) {
            console.error('Error parsing saved currency:', e);
        }
    }

    // В любом случае делаем запрос к серверу для синхронизации
    console.log('Fetching user currency from server...');
    await fetchUserCurrency();
    console.log('=== Menu component mounted END ===');
});

const isHomePage = computed(() => route.path === '/');

const toggleLocalization = () => {
	console.log('Переключение локализации');
};

const isActive = path => route.path === path;

const expandSearch = () => {
	isSearchExpanded.value = true;
	document.querySelector('.search-container input').focus();
};

const contractSearch = () => {
	if (searchQuery.value === '') {
		isSearchExpanded.value = false;
	}
};

const handleBlur = () => {
	setTimeout(() => {
		contractSearch();
	}, 100);
};

const handleClickOutside = event => {
	if (!event.target.closest('.search-container')) {
		contractSearch();
	}
};

const toggleLocalizationDropdown = () => {
	isLocalizationDropdownOpen.value = !isLocalizationDropdownOpen.value;
};

const setLocalization = async currency => {
	try {
		// Получаем telegramId из хранилища
		const telegramId = store.state.user.user?.telegramId;
		if (!telegramId) {
			console.error('TelegramId not found in store');
			return;
		}

		// Отправляем запрос на обновление валюты
		const response = await fetch(`/api/users/${telegramId}/currency`, {
			method: 'PUT',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({ currencyId: currency.id }),
		});

		if (!response.ok) {
			throw new Error('Failed to update currency');
		}

		// Сохраняем в localStorage
		localStorage.setItem('userCurrency', JSON.stringify(currency));

		// Обновляем состояние в store
		store.commit('user/SET_USER_CURRENCY', currency);
		isLocalizationDropdownOpen.value = false;

		console.log(`Валюта успешно изменена на: ${currency.code}`);
	} catch (error) {
		console.error('Error updating currency:', error);
	}
};

const goToSearch = () => {
	router.push('/search-results');
};

const cartItemsCount = computed(() => store.state.cart.items.length);
const favouritesCount = computed(
	() => store.state.favourites.favouriteItems.length
);

const localizationOptions = computed(() => {
	return currencies.value.filter(c => c.id !== currentLocalization.value?.id);
});

onUnmounted(() => {
	document.removeEventListener('click', handleClickOutside);
});
</script>

<style scoped>
.bottom-nav {
	position: fixed;
	bottom: 0;
	left: 0;
	right: 0;
	display: flex;
	justify-content: center;
	align-items: center;
	background-color: #f8f8f8;
	padding: 15px 20px 30px;
	transition: all 0.3s ease;
	z-index: 1000;
	box-sizing: border-box;
	border-top: 0.6px solid #dcdcdc;
}

.bottom-nav.search-expanded {
	transform: translateY(-50px);
	animation: slideUp 0.3s ease-out;
}

.search-container {
	width: 93px;
	height: 45px;
	display: flex;
	justify-content: center;
	align-items: center;
	opacity: 1;
	transition: all 0.3s ease;
	background-color: #ffffff;
	border-radius: 13px;
	padding: 3px 7px;
	margin-right: 10px;
}

.search-container.full-width {
	width: 100%;
	padding: 3px 7px;
	animation: slideUp 0.3s ease-out, fadeIn 0.3s ease-out;
}

.search-container input {
	width: 100%;
	height: 100%;
	padding: 0;
	border: none;
	border-radius: 13px;
	background-color: transparent;
	font-size: 15px;
	font-family: 'Open Sans', sans-serif;
	color: #8a8a8a;
}

.search-container input::placeholder {
	color: #8a8a8a;
}

.nav-buttons {
	display: flex;
	justify-content: center;
	align-items: center;
	gap: 10px;
	transition: all 0.3s ease;
}

.nav-buttons.hidden {
	opacity: 0;
	pointer-events: none;
	transform: translateY(20px);
}

.nav-item {
	display: flex;
	justify-content: center;
	align-items: center;
	width: 45px;
	height: 45px;
	background-color: #ffffff;
	border-radius: 13px;
	text-decoration: none;
	flex-shrink: 0;
	transition: all 0.3s ease;
}

.nav-item.active {
	transform: translateY(-5px);
	box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.nav-item:active {
	transform: translateY(-2px);
	box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

button.nav-item {
	border: none;
	cursor: pointer;
}

.nav-item img {
	width: 26px;
	height: 26px;
}

.local-button {
	width: 26px;
	height: 19px;
	border-radius: 3px;
}

.localization-dropdown {
	position: relative;
}

.localization-options {
	position: absolute;
	bottom: 100%;
	left: 50%;
	transform: translateX(-50%);
	background-color: #ffffff;
	border: 0.6px solid #dcdcdc;
	border-radius: 13px;
	padding: 5px;
	z-index: 1001;
	box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.1);
	display: flex;
	flex-direction: column;
	gap: 5px;
	margin-bottom: 10px;
}

.localization-options button {
	display: flex;
	justify-content: center;
	align-items: center;
	width: 45px;
	height: 45px;
	padding: 0;
	border: none;
	background-color: #ffffff;
	border-radius: 13px;
	cursor: pointer;
	transition: all 0.3s ease;
}

.localization-options button:hover {
	background-color: #f8f8f8;
	transform: translateY(-2px);
	box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.localization-options img {
	width: 26px;
	height: 19px;
	border-radius: 3px;
}

.nav-item-container {
	position: relative;
	display: flex;
	justify-content: center;
	align-items: center;
	width: 100%;
	height: 100%;
}

.counter-badge {
	position: absolute;
	top: -8px;
	right: -8px;
	background-color: rgba(0, 122, 255, 1);
	color: white;
	border-radius: 50%;
	min-width: 18px;
	height: 18px;
	padding: 0 4px;
	font-size: 12px;
	font-weight: bold;
	display: flex;
	justify-content: center;
	align-items: center;
}

@keyframes slideUp {
	from {
		transform: translateY(100%);
	}
	to {
		transform: translateY(0);
	}
}

@keyframes fadeIn {
	from {
		opacity: 0;
	}
	to {
		opacity: 1;
	}
}

@keyframes fadeInUp {
	from {
		opacity: 0;
		transform: translate(-50%, 10px);
	}
	to {
		opacity: 1;
		transform: translate(-50%, 0);
	}
}

.localization-options {
	animation: fadeInUp 0.3s ease-out;
}
</style>
