import { createApp } from 'vue';
import App from './App.vue';
import './assets/css/style.css';
import router from './router/router.js';
import store from './store';
import { closeKeyboard } from './directives/closeKeyboard';

// Добавляем директиву свайпа
const swipe = {
	mounted(el, binding) {
		let touchstartX = 0;
		let touchendX = 0;

		const handleGesture = () => {
			if (touchendX > touchstartX + 50) {
				// Добавляем порог в 50px для предотвращения случайных срабатываний
				// Свайп вправо - возврат назад
				if (typeof binding.value === 'function') {
					binding.value();
				}
			}
		};

		el.addEventListener(
			'touchstart',
			e => {
				touchstartX = e.changedTouches[0].screenX;
			},
			{ passive: true }
		);

		el.addEventListener(
			'touchend',
			e => {
				touchendX = e.changedTouches[0].screenX;
				handleGesture();
			},
			{ passive: true }
		);
	},
};

function initApp() {
	const app = createApp(App);
	app.use(router);
	app.use(store);

	// Регистрируем директиву свайпа
	app.directive('swipe', swipe);
	app.directive('close-keyboard', closeKeyboard);

	// Инициализируем авторизацию
	store.dispatch('auth/initAuth');

	app.mount('#app');

	// Дополнительная инициализация для Telegram WebApp
	if (window.Telegram && window.Telegram.WebApp) {
		const tgApp = window.Telegram.WebApp;

		// Расширяем WebApp на весь экран
		tgApp.expand();

		// Обработчик изменения области просмотра
		tgApp.onEvent('viewportChanged', () => {
			const root = document.documentElement;
			const isExpanded = tgApp.isExpanded;
			root.style.setProperty(
				'--tg-viewport-height',
				`${tgApp.viewportHeight}px`
			);
			document.body.classList.toggle('tg-app-expanded', isExpanded);
		});

		// Сообщаем Telegram, что приложение готово
		tgApp.ready();
	}
}

// Проверяем, запущено ли приложение в среде Telegram WebApp
if (window.Telegram && window.Telegram.WebApp) {
	// Инициализируем приложение сразу, без ожидания viewportChanged
	initApp();
} else {
	console.warn('Telegram WebApp is not available');
	// Если не в Telegram WebApp, инициализируем приложение сразу
	initApp();
}

// Обработка ошибок
window.addEventListener('error', event => {
	console.error('Uncaught error:', event.error);
	// Здесь вы можете добавить код для отправки ошибок на сервер или показа пользователю
});
