<template>
	<!-- чтобы вернуть свайпы при возврате назад: @v-swipe="handleBackNavigation" -->
	<div id="app">
		<transition :name="transitionName">
			<RouterView />
		</transition>
		<Menu />
	</div>
</template>

<script setup>
import { onMounted, onUnmounted, ref, watch } from 'vue';
import { RouterView, useRoute, useRouter } from 'vue-router';
import { useStore } from 'vuex';
import Menu from './components/common/Menu.vue';

const router = useRouter();
const route = useRoute();
const store = useStore();
const telegramWebAppAvailable = ref(false);
const transitionName = ref('slide-right');

function handleBackNavigation() {
	if (route.path !== '/') {
		if (router.options.history.state.back) {
			transitionName.value = 'slide-right';
			router.back();
		} else {
			transitionName.value = 'slide-right';
			router.push('/');
		}
	} else if (telegramWebAppAvailable.value) {
		window.Telegram.WebApp.close();
	}
}

const initUser = async () => {
    if (window.Telegram?.WebApp?.initDataUnsafe?.user) {
        const user = window.Telegram.WebApp.initDataUnsafe.user;
        try {
            await store.dispatch('user/fetchUser', user.id);
        } catch (error) {
            console.error('Failed to initialize user:', error);
        }
    }
};

onMounted(async () => {
    if (window.Telegram && window.Telegram.WebApp) {
        telegramWebAppAvailable.value = true;
        console.log('Telegram WebApp is available');

        const WebApp = window.Telegram.WebApp;
        const BackButton = WebApp.BackButton;

        WebApp.setBackgroundColor('#FFFFFF');
        
        // Инициализируем пользователя
        await initUser();

        BackButton.onClick(handleBackNavigation);
        WebApp.onEvent('backButtonClicked', handleBackNavigation);

        console.log('BackButton:', BackButton);
        console.log('BackButton methods:', Object.keys(BackButton));
    } else {
        console.warn('Telegram WebApp is not available');
    }
});

onUnmounted(() => {
	if (telegramWebAppAvailable.value) {
		const WebApp = window.Telegram.WebApp;
		const BackButton = WebApp.BackButton;

		BackButton.offClick(handleBackNavigation);
		WebApp.offEvent('backButtonClicked', handleBackNavigation);
	}
});

watch(
	() => route.path,
	(newPath, oldPath) => {
		if (telegramWebAppAvailable.value) {
			const BackButton = window.Telegram.WebApp.BackButton;
			if (newPath === '/') {
				BackButton.hide();
			} else {
				BackButton.show();
			}
		}

		// Проверяем, определен ли oldPath
		if (oldPath !== undefined) {
			const toDepth = newPath.split('/').length;
			const fromDepth = oldPath.split('/').length;
			transitionName.value =
				toDepth < fromDepth ? 'slide-right' : 'slide-left';
		} else {
			// При первой загрузке не применяем анимацию
			transitionName.value = '';
		}
	},
	{ immediate: true }
);
</script>

<style scoped>
#app {
	background-color: #fff !important;
}
.slide-left-enter-active,
.slide-left-leave-active,
.slide-right-enter-active,
.slide-right-leave-active {
	transition: all 0.3s ease-out;
}

.slide-left-enter-from {
	transform: translateX(100%);
}

.slide-left-leave-to {
	transform: translateX(-100%);
}

.slide-right-enter-from {
	transform: translateX(-100%);
}

.slide-right-leave-to {
	transform: translateX(100%);
}

.slide-left-enter-to,
.slide-left-leave-from,
.slide-right-enter-to,
.slide-right-leave-from {
	transform: translateX(0);
}
</style>
