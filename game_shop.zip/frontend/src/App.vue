<template>
	<!-- чтобы вернуть свайпы при возврате назад: @v-swipe="handleBackNavigation" -->
	<div id="app">
		<MaintenanceScreen
			v-if="maintenanceMode"
			:message="maintenanceMessage"
		/>
		<template v-else>
			<transition :name="transitionName">
				<RouterView />
			</transition>
			<Menu />
		</template>
	</div>
</template>

<script setup>
import { onMounted, onUnmounted, ref, watch } from 'vue';
import { RouterView, useRoute, useRouter } from 'vue-router';
import { useStore } from 'vuex';
import Menu from './components/common/Menu.vue';
import MaintenanceScreen from './components/screens/MaintenanceScreen.vue';
import axios from './config/axios.js';

const router = useRouter();
const route = useRoute();
const store = useStore();
const telegramWebAppAvailable = ref(false);
const transitionName = ref('slide-right');
const maintenanceMode = ref(false);
const maintenanceMessage = ref('');
let maintenanceCheckInterval = null;

function handleBackNavigation() {
	if (route.path !== '/') {
		if (router.options.history.state.back) {
			transitionName.value = 'slide-right';
			router.back();
		} else {
			transitionName.value = 'slide-right';
			router.push('/');
		}
	} else if (telegramWebAppAvailable.value) {
		window.Telegram.WebApp.close();
	}
}

const checkMaintenanceMode = async () => {
	try {
		const response = await axios.get('/settings/maintenance-status');
		const wasInMaintenance = maintenanceMode.value;
		maintenanceMode.value = response.data.maintenanceMode;
		maintenanceMessage.value = response.data.maintenanceMessage;

		// Если режим техработ был выключен - перезагружаем страницу
		if (wasInMaintenance && !maintenanceMode.value) {
			window.location.reload();
		}
	} catch (error) {
		// В случае ошибки продолжаем работу приложения
		maintenanceMode.value = false;
	}
};

const startMaintenanceCheck = () => {
	// Проверяем статус каждые 30 секунд
	maintenanceCheckInterval = setInterval(async () => {
		await checkMaintenanceMode();
	}, 30000); // 30 секунд
};

const initUser = async () => {
    if (window.Telegram?.WebApp?.initDataUnsafe?.user) {
        const user = window.Telegram.WebApp.initDataUnsafe.user;
        try {
            await store.dispatch('user/fetchUser', user.id);
        } catch (error) {
            // Ошибка инициализации пользователя
        }
    }
};

onMounted(async () => {
    // Проверяем режим технических работ
    await checkMaintenanceMode();

    // Если режим техработ включен, не инициализируем остальное
    if (maintenanceMode.value) {
        // Запускаем периодическую проверку на случай, если режим выключат
        startMaintenanceCheck();
        return;
    }

    if (window.Telegram && window.Telegram.WebApp) {
        telegramWebAppAvailable.value = true;

        const WebApp = window.Telegram.WebApp;
        const BackButton = WebApp.BackButton;

        WebApp.setBackgroundColor('#FFFFFF');

        // Инициализируем пользователя
        await initUser();

        BackButton.onClick(handleBackNavigation);
        WebApp.onEvent('backButtonClicked', handleBackNavigation);
    }

    // Запускаем периодическую проверку режима техработ
    startMaintenanceCheck();
});

onUnmounted(() => {
	// Очищаем интервал проверки режима техработ
	if (maintenanceCheckInterval) {
		clearInterval(maintenanceCheckInterval);
		maintenanceCheckInterval = null;
	}

	if (telegramWebAppAvailable.value) {
		const WebApp = window.Telegram.WebApp;
		const BackButton = WebApp.BackButton;

		BackButton.offClick(handleBackNavigation);
		WebApp.offEvent('backButtonClicked', handleBackNavigation);
	}
});

watch(
	() => route.path,
	(newPath, oldPath) => {
		if (telegramWebAppAvailable.value) {
			const BackButton = window.Telegram.WebApp.BackButton;
			if (newPath === '/') {
				BackButton.hide();
			} else {
				BackButton.show();
			}
		}

		// Проверяем, определен ли oldPath
		if (oldPath !== undefined) {
			const toDepth = newPath.split('/').length;
			const fromDepth = oldPath.split('/').length;
			transitionName.value =
				toDepth < fromDepth ? 'slide-right' : 'slide-left';
		} else {
			// При первой загрузке не применяем анимацию
			transitionName.value = '';
		}
	},
	{ immediate: true }
);
</script>

<style scoped>
#app {
	background-color: #fff !important;
}
.slide-left-enter-active,
.slide-left-leave-active,
.slide-right-enter-active,
.slide-right-leave-active {
	transition: all 0.3s ease-out;
}

.slide-left-enter-from {
	transform: translateX(100%);
}

.slide-left-leave-to {
	transform: translateX(-100%);
}

.slide-right-enter-from {
	transform: translateX(-100%);
}

.slide-right-leave-to {
	transform: translateX(100%);
}

.slide-left-enter-to,
.slide-left-leave-from,
.slide-right-enter-to,
.slide-right-leave-from {
	transform: translateX(0);
}
</style>
