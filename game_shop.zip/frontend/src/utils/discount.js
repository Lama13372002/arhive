export const calculateDiscountPercentage = (originalPrice, discountPrice) => {
	if (!originalPrice || !discountPrice) return 0;
	return Math.round(((originalPrice - discountPrice) / originalPrice) * 100);
};

// Проверяет, истекла ли акция
export const isPromotionExpired = (promotionEndDate) => {
	if (!promotionEndDate) return false;
	const endDate = new Date(promotionEndDate);
	const now = new Date();
	return now > endDate;
};

export const formatPrice = (price, currency = null) => {
	if (!price) return '0 руб.';
	const num = Number(price);
	if (isNaN(num)) return '0 руб.';

	// Всегда округляем в меньшую сторону (убираем копейки)
	const formattedNum = Math.floor(num);

	// Если передана валюта, используем её символ и код
	if (currency) {
		// Используем код валюты, если он есть
		if (currency.code) {
			return `${formattedNum} ${currency.code}`;
		}

		// Иначе используем символ валюты, если он есть
		if (currency.symbol) {
			return `${formattedNum} ${currency.symbol}`;
		}
	}

	// Форматируем без копеек
	return `${formattedNum} руб.`;
};

export const getFinalPrice = edition => {
	if (!edition) {
		// console.log('getFinalPrice: edition is null or undefined');
		return 0;
	}

	// console.log('getFinalPrice input:', edition);

	// Проверяем наличие цены со скидкой
	if (
		edition.discount_amount !== null &&
		edition.discount_amount !== undefined
	) {
		// console.log(
		// 	'getFinalPrice: returning discount_amount:',
		// 	Number(edition.discount_amount)
		// );
		return Number(edition.discount_amount);
	}

	// Если скидки нет, используем конвертированную цену или обычную цену
	const result = Number(edition.convertedPrice || edition.price);
	// console.log('getFinalPrice: returning convertedPrice or price:', result);
	return result;
};

export const getOriginalPrice = edition => {
	if (!edition) {
		// console.log('getOriginalPrice: edition is null or undefined');
		return 0;
	}

	// console.log('getOriginalPrice input:', edition);

	// Всегда используем конвертированную цену или базовую цену
	const result = Number(edition.convertedPrice || edition.price);
	// console.log('getOriginalPrice: returning result:', result);
	return result;
};

export const calculateDiscount = edition => {
	if (!edition) return 0;

	// Проверяем наличие всех необходимых данных для расчета скидки
	if (
		edition.price === undefined ||
		edition.discount_amount === null ||
		edition.discount_amount === undefined
	) {
		return 0;
	}

	// Используем price или convertedPrice как оригинальную цену
	const originalPrice = Number(edition.convertedPrice || edition.price);
	// Используем discount_amount как цену со скидкой
	const discountedPrice = Number(edition.discount_amount);

	// Проверяем, что цена со скидкой действительно меньше оригинальной цены
	if (discountedPrice >= originalPrice) return 0;

	// Расчитываем процент скидки
	return Math.round(
		((originalPrice - discountedPrice) / originalPrice) * 100
	);
};
