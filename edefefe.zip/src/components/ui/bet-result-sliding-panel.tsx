"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { TrendingUp, TrendingDown, Sparkles, Zap, Trophy, X } from "lucide-react";

interface BetResultSlidingPanelProps {
  status: "won" | "lost" | "refunded" | "active" | "cancelled";
  winAmount?: number;
  lossAmount?: number;
  currency: "TON" | "STARS";
  isVisible?: boolean;
}

export function BetResultSlidingPanel({
  status,
  winAmount,
  lossAmount,
  currency,
  isVisible = true
}: BetResultSlidingPanelProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  // Автоматически показываем панель для выигрышей/проигрышей
  useEffect(() => {
    if ((status === "won" && winAmount) || (status === "lost" && lossAmount)) {
      const timer = setTimeout(() => setIsExpanded(true), 800);
      return () => clearTimeout(timer);
    }
  }, [status, winAmount, lossAmount]);

  // Определяем данные для отображения
  const isWin = status === "won" && winAmount;
  const isLoss = status === "lost" && lossAmount;

  if (!isWin && !isLoss) return null;

  const amount = isWin ? winAmount : lossAmount;
  const sign = isWin ? "+" : "-";

  return (
    <div className="relative overflow-hidden">
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ x: "100%", opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: "100%", opacity: 0 }}
            transition={{
              type: "spring",
              stiffness: 100,
              damping: 20,
              duration: 0.6
            }}
            className={`absolute -right-2 top-1/2 -translate-y-1/2 z-20 ${
              isWin
                ? "bg-gradient-to-r from-green-500/20 via-emerald-500/30 to-green-600/20"
                : "bg-gradient-to-r from-red-500/20 via-rose-500/30 to-red-600/20"
            } backdrop-blur-lg border border-white/20 rounded-2xl shadow-2xl overflow-hidden min-w-[120px]`}
            style={{
              background: isWin
                ? "linear-gradient(135deg, rgba(34, 197, 94, 0.15) 0%, rgba(16, 185, 129, 0.25) 50%, rgba(5, 150, 105, 0.15) 100%)"
                : "linear-gradient(135deg, rgba(239, 68, 68, 0.15) 0%, rgba(244, 63, 94, 0.25) 50%, rgba(220, 38, 38, 0.15) 100%)"
            }}
          >
            {/* Анимированный фон */}
            <div className="absolute inset-0 overflow-hidden">
              <motion.div
                className={`absolute inset-0 ${
                  isWin ? "bg-gradient-to-r from-green-400/10 to-emerald-500/10" : "bg-gradient-to-r from-red-400/10 to-rose-500/10"
                }`}
                animate={{
                  x: [-100, 100, -100],
                  opacity: [0.3, 0.7, 0.3]
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
            </div>

            {/* Контент панели */}
            <motion.div
              className="relative z-10 p-4 flex items-center space-x-3"
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.3, type: "spring", stiffness: 200 }}
            >
              {/* Анимированная иконка */}
              <motion.div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  isWin
                    ? "bg-gradient-to-br from-green-400 to-emerald-600"
                    : "bg-gradient-to-br from-red-400 to-rose-600"
                } shadow-lg`}
                animate={isWin ? {
                  rotate: [0, 10, -10, 0],
                  scale: [1, 1.1, 1]
                } : {
                  rotate: [0, -5, 5, 0],
                  scale: [1, 0.95, 1]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                {isWin ? (
                  <Trophy className="h-4 w-4 text-white" />
                ) : (
                  <TrendingDown className="h-4 w-4 text-white" />
                )}
              </motion.div>

              {/* Сумма с анимацией */}
              <motion.div
                className="flex flex-col"
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                <motion.div
                  className={`font-bold text-lg ${
                    isWin ? "text-green-300" : "text-red-300"
                  } flex items-center space-x-1`}
                  animate={{
                    textShadow: isWin
                      ? ["0 0 10px rgba(34, 197, 94, 0.5)", "0 0 20px rgba(34, 197, 94, 0.8)", "0 0 10px rgba(34, 197, 94, 0.5)"]
                      : ["0 0 10px rgba(239, 68, 68, 0.5)", "0 0 20px rgba(239, 68, 68, 0.8)", "0 0 10px rgba(239, 68, 68, 0.5)"]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  <span>{sign}{amount}</span>
                  <span className="text-sm">{currency}</span>
                  {isWin && (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                    >
                      <Sparkles className="h-4 w-4 text-yellow-400" />
                    </motion.div>
                  )}
                </motion.div>

                <motion.div
                  className={`text-xs ${
                    isWin ? "text-green-400/80" : "text-red-400/80"
                  } font-medium`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.7 }}
                >
                  {isWin ? "Выигрыш" : "Потеря"}
                </motion.div>
              </motion.div>

              {/* Кнопка закрытия */}
              <motion.button
                onClick={() => setIsExpanded(false)}
                className="ml-auto w-6 h-6 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <X className="h-3 w-3 text-white/70" />
              </motion.button>
            </motion.div>

            {/* Декоративные элементы */}
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/30 to-transparent" />
            <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/20 to-transparent" />

            {/* Анимированные частицы для выигрыша */}
            {isWin && (
              <div className="absolute inset-0 pointer-events-none">
                {[...Array(3)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-1 h-1 bg-yellow-400 rounded-full"
                    style={{
                      left: `${20 + i * 30}%`,
                      top: `${20 + i * 20}%`
                    }}
                    animate={{
                      y: [-10, -20, -10],
                      opacity: [0, 1, 0],
                      scale: [0, 1, 0]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: i * 0.5,
                      ease: "easeInOut"
                    }}
                  />
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Индикатор для скрытой панели */}
      {!isExpanded && ((status === "won" && winAmount) || (status === "lost" && lossAmount)) && (
        <motion.button
          onClick={() => setIsExpanded(true)}
          className={`absolute -right-1 top-1/2 -translate-y-1/2 z-10 w-6 h-12 ${
            isWin
              ? "bg-gradient-to-b from-green-500 to-emerald-600"
              : "bg-gradient-to-b from-red-500 to-rose-600"
          } rounded-l-lg shadow-lg flex items-center justify-center`}
          whileHover={{ x: -2, scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          initial={{ x: 6, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 1.5 }}
        >
          <motion.div
            animate={{ x: [-1, 1, -1] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
          >
            <Zap className="h-3 w-3 text-white" />
          </motion.div>
        </motion.button>
      )}
    </div>
  );
}
