import { TrendingUp, TrendingDown, Sparkles } from "lucide-react";

interface BetResultDisplayProps {
  status: "won" | "lost" | "refunded" | "active" | "cancelled";
  winAmount?: number;
  lossAmount?: number;
  currency: "TON" | "STARS";
  className?: string;
}

export function BetResultDisplay({
  status,
  winAmount,
  lossAmount,
  currency,
  className = ""
}: BetResultDisplayProps) {
  if (status === "won" && winAmount) {
    return (
      <div className={`flex items-center space-x-2 ${className}`}>
        <div className="flex items-center space-x-1 bg-green-500/10 backdrop-blur-sm border border-green-500/20 rounded-full px-3 py-1.5">
          <TrendingUp className="h-4 w-4 text-green-400" />
          <Sparkles className="h-3 w-3 text-yellow-400" />
          <span className="font-bold text-green-400">
            +{winAmount} {currency}
          </span>
        </div>
      </div>
    );
  }

  if (status === "lost" && lossAmount) {
    return (
      <div className={`flex items-center space-x-2 ${className}`}>
        <div className="flex items-center space-x-1 bg-red-500/10 backdrop-blur-sm border border-red-500/20 rounded-full px-3 py-1.5">
          <TrendingDown className="h-4 w-4 text-red-400" />
          <span className="font-bold text-red-400">
            -{lossAmount} {currency}
          </span>
        </div>
      </div>
    );
  }

  return null;
}
