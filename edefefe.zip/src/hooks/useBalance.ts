import { useState, useEffect, useCallback } from 'react';
import { useTelegram } from '@/components/providers/TelegramProvider';

interface BalanceData {
  TON: number;
  STARS: number;
  totalUSD: number;
}

interface ExchangeRates {
  TON_TO_USD: number;
  STARS_TO_USD: number;
}

export const useBalance = () => {
  const { user } = useTelegram();
  const [balance, setBalance] = useState<BalanceData>({
    TON: 0,
    STARS: 0,
    totalUSD: 0
  });
  const [exchangeRates, setExchangeRates] = useState<ExchangeRates>({
    TON_TO_USD: 5.1, // Fallback значение
    STARS_TO_USD: 0.015 // 1 Star = $0.015 (стабильный курс к доллару как на Fragment)
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Получаем актуальный курс TON через наш API
  const fetchExchangeRates = useCallback(async () => {
    try {
      const response = await fetch('/api/exchange-rates');
      const data = await response.json();

      if (data.success && data.rates) {
        setExchangeRates({
          TON_TO_USD: data.rates.TON_TO_USD,
          STARS_TO_USD: data.rates.STARS_TO_USD
        });
      }
    } catch (error) {
      console.error('Error fetching exchange rates:', error);
      // Используем fallback значения при ошибке
    }
  }, []);

  const calculateTotalUSD = useCallback((tonBalance: number, starsBalance: number) => {
    return (tonBalance * exchangeRates.TON_TO_USD) + (starsBalance * exchangeRates.STARS_TO_USD);
  }, [exchangeRates]);

  const fetchBalance = useCallback(async () => {
    if (!user?.id) return;

    try {
      setLoading(true);
      setError(null);

      const response = await fetch('/api/user/balance', {
        headers: {
          'x-telegram-user-id': user.id.toString()
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch balance');
      }

      const data = await response.json();
      const tonBalance = data.user.ton_balance || 0;
      const starsBalance = data.user.stars_balance || 0;
      const totalUSD = calculateTotalUSD(tonBalance, starsBalance);

      setBalance({
        TON: tonBalance,
        STARS: starsBalance,
        totalUSD
      });
    } catch (err) {
      console.error('Error fetching balance:', err);
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [user?.id, calculateTotalUSD]);

  // Обновление баланса при успешных транзакциях
  const updateBalance = useCallback((newTonBalance?: number, newStarsBalance?: number) => {
    setBalance(prev => {
      const tonBalance = newTonBalance !== undefined ? newTonBalance : prev.TON;
      const starsBalance = newStarsBalance !== undefined ? newStarsBalance : prev.STARS;
      const totalUSD = calculateTotalUSD(tonBalance, starsBalance);

      return {
        TON: tonBalance,
        STARS: starsBalance,
        totalUSD
      };
    });
  }, [calculateTotalUSD]);

  // Загружаем курсы валют при инициализации
  useEffect(() => {
    fetchExchangeRates();

    // Обновляем курсы каждые 30 секунд
    const ratesInterval = setInterval(() => {
      fetchExchangeRates();
    }, 30000); // 30 секунд

    return () => clearInterval(ratesInterval);
  }, [fetchExchangeRates]);

  // Загружаем баланс при изменении пользователя или курсов
  useEffect(() => {
    fetchBalance();
  }, [fetchBalance]);

  // Автоматическое обновление баланса каждые 30 секунд
  useEffect(() => {
    const interval = setInterval(() => {
      fetchBalance();
    }, 30000);

    return () => clearInterval(interval);
  }, [fetchBalance]);

  return {
    balance,
    exchangeRates,
    loading,
    error,
    refreshBalance: fetchBalance,
    updateBalance
  };
};
