import { useEffect, useCallback } from 'react';

interface ProximityDisablerOptions {
  enabled: boolean;
}

/**
 * Хук для отключения датчика приближения в мобильных браузерах
 * Предотвращает переключение звука на верхний динамик при поднесении к уху
 */
export function useProximityDisabler(options: ProximityDisablerOptions = { enabled: true }) {
  const { enabled } = options;

  // Функция для принудительного использования громкого динамика
  const enforceMainSpeaker = useCallback(async () => {
    if (!enabled) return;

    try {
      // 1. Устанавливаем громкость на максимум для основного динамика
      const audioElements = document.querySelectorAll('audio');
      audioElements.forEach(audio => {
        audio.volume = 1;
        // Устанавливаем атрибуты для предотвращения оптимизаций браузера
        audio.setAttribute('playsinline', 'true');
        audio.setAttribute('webkit-playsinline', 'true');
        audio.muted = false;
      });

      // 2. Создаем тихий аудио контекст для "захвата" аудио вывода
      const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) {
        console.warn('AudioContext не поддерживается');
        return;
      }
      const audioContext = new AudioContextClass();

      // Создаем oscillator для поддержания активного аудио контекста
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      // Устанавливаем очень тихую громкость (но не ноль)
      gainNode.gain.setValueAtTime(0.001, audioContext.currentTime);

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      // Воспроизводим очень тихий звук для активации контекста
      oscillator.frequency.setValueAtTime(20000, audioContext.currentTime); // Ультразвук
      oscillator.start();
      oscillator.stop(audioContext.currentTime + 0.1);

      console.log('🔊 Принудительное использование основного динамика активировано');
    } catch (error) {
      console.warn('⚠️ Не удалось настроить принудительное использование динамика:', error);
    }
  }, [enabled]);

  // Функция для предотвращения переключения на верхний динамик
  const preventProximitySwitching = useCallback(() => {
    if (!enabled) return;

    try {
      // Отключаем автоматическое управление аудио выводом
      if ('mediaSession' in navigator) {
        navigator.mediaSession.setActionHandler('seekto', null);
        navigator.mediaSession.setActionHandler('play', null);
        navigator.mediaSession.setActionHandler('pause', null);
      }

      // Предотвращаем обработку событий датчика приближения
      const preventProximityEvents = (event: Event) => {
        event.preventDefault();
        event.stopPropagation();
        return false;
      };

      // Блокируем возможные события датчика приближения
      const eventsToBlock = [
        'deviceproximity',
        'userproximity',
        'deviceorientation',
        'orientationchange'
      ];

      eventsToBlock.forEach(eventType => {
        document.addEventListener(eventType, preventProximityEvents, {
          passive: false,
          capture: true
        });
        window.addEventListener(eventType, preventProximityEvents, {
          passive: false,
          capture: true
        });
      });

      console.log('🚫 Блокировка датчика приближения активирована');

      // Возвращаем функцию очистки
      return () => {
        eventsToBlock.forEach(eventType => {
          document.removeEventListener(eventType, preventProximityEvents, true);
          window.removeEventListener(eventType, preventProximityEvents, true);
        });
      };
    } catch (error) {
      console.warn('⚠️ Не удалось заблокировать датчик приближения:', error);
    }
  }, [enabled]);

  // Функция для настройки CSS стилей
  const applySpeakerStyles = useCallback(() => {
    if (!enabled) return;

    const styleId = 'proximity-disabler-styles';

    // Удаляем существующие стили если есть
    const existingStyle = document.getElementById(styleId);
    if (existingStyle) {
      existingStyle.remove();
    }

    // Создаем новые стили
    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = `
      /* Принудительное использование основного динамика */
      audio {
        -webkit-playsinline: true !important;
        playsinline: true !important;
        volume: 1 !important;
        muted: false !important;
      }

      /* Предотвращение оптимизаций браузера для аудио */
      body {
        -webkit-touch-callout: none !important;
        -webkit-user-select: none !important;
        -webkit-tap-highlight-color: transparent !important;
      }

      /* Блокировка автоматического переключения аудио */
      * {
        -webkit-audio-session: play-and-record !important;
        audio-session: play-and-record !important;
      }
    `;

    document.head.appendChild(style);
    console.log('🎨 CSS стили для принудительного использования динамика применены');

    // Возвращаем функцию очистки
    return () => {
      const styleElement = document.getElementById(styleId);
      if (styleElement) {
        styleElement.remove();
      }
    };
  }, [enabled]);

  // Основная функция инициализации
  const initializeProximityDisabler = useCallback(async () => {
    if (!enabled) return;

    console.log('🚀 Инициализация отключения датчика приближения...');

    // Применяем все методы
    const cleanupStyles = applySpeakerStyles();
    const cleanupEvents = preventProximitySwitching();
    await enforceMainSpeaker();

    // Возвращаем функцию очистки
    return () => {
      cleanupStyles?.();
      cleanupEvents?.();
    };
  }, [enabled, applySpeakerStyles, preventProximitySwitching, enforceMainSpeaker]);

  // Эффект для инициализации при монтировании
  useEffect(() => {
    let cleanup: (() => void) | undefined;

    if (enabled) {
      initializeProximityDisabler().then(cleanupFn => {
        cleanup = cleanupFn;
      });
    }

    // Очистка при размонтировании
    return () => {
      cleanup?.();
    };
  }, [enabled, initializeProximityDisabler]);

  // Эффект для переинициализации при изменении видимости страницы
  useEffect(() => {
    if (!enabled) return;

    const handleVisibilityChange = () => {
      if (!document.hidden) {
        // Страница стала видимой - переинициализируем
        setTimeout(initializeProximityDisabler, 100);
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [enabled, initializeProximityDisabler]);

  return {
    enforceMainSpeaker,
    preventProximitySwitching,
    applySpeakerStyles,
    initializeProximityDisabler
  };
}
