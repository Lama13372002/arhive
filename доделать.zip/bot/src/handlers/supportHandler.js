// Не нужно импортировать TelegramBot, так как мы его только используем
export class SupportHandler {
	constructor(bot) {
		this.bot = bot;
		this.activeChats = new Map(); // Store active support chats
		this.SUPPORT_CHAT_ID = -1002272015106;
	}

	setup() {
		// Handle messages
		this.bot.on('message', async msg => {
			const userId = msg.from?.id;
			if (!userId) return;

			const chatInfo = this.activeChats.get(userId);

			console.log('Received message:', {
				from: userId,
				chatType: msg.chat?.type,
				chatInfo: chatInfo,
				messageThreadId: msg.message_thread_id,
				text: msg.text,
				hasPhoto: !!msg.photo,
				hasDocument: !!msg.document,
				hasVideo: !!msg.video,
				hasAudio: !!msg.audio,
				hasVoice: !!msg.voice,
				hasVideoNote: !!msg.video_note,
			});

			// Handle user messages in private chat
			if (msg.chat?.type === 'private' && chatInfo) {
				if (msg.text === 'Завершить диалог') {
					await this.closeDialog(msg, userId);
					return;
				}

				if (chatInfo.status === 'waiting_for_question') {
					await this.handleNewQuestion(msg, userId, chatInfo);
				} else if (chatInfo.status === 'active' && chatInfo.topicId) {
					// Forward user message to the support topic
					try {
						console.log('Forwarding user message to support:', {
							userId,
							topicId: chatInfo.topicId,
							text: msg.text,
						});

						await this.forwardUserMessageToSupport(msg, chatInfo.topicId);
					} catch (error) {
						console.error(
							'Error forwarding message to support:',
							error
						);
						await this.bot.sendMessage(
							msg.chat.id,
							'Произошла ошибка при отправке сообщения. Пожалуйста, попробуйте еще раз.'
						);
					}
				}
			}

			// Handle support team messages
			if (msg.chat.id === this.SUPPORT_CHAT_ID) {
				console.log('Support chat message received:', {
					messageId: msg.message_id,
					messageThreadId: msg.message_thread_id,
					text: msg.text,
				});

				// Используем message_thread_id для идентификации топика
				const topicId = msg.message_thread_id;

				if (topicId) {
					const userIdFromTopic = this.findUserIdByTopicId(topicId);
					console.log('Found user for topic:', {
						topicId,
						userId: userIdFromTopic,
						activeChats: Array.from(this.activeChats.entries()),
					});

					if (userIdFromTopic && msg.text !== '/close') {
						try {
							console.log('Forwarding support message to user:', {
								userId: userIdFromTopic,
								text: msg.text,
							});

							await this.forwardSupportMessageToUser(msg, userIdFromTopic, topicId);
						} catch (error) {
							console.error(
								'Error forwarding message to user:',
								error
							);
							await this.bot.sendMessage(
								this.SUPPORT_CHAT_ID,
								'Ошибка при отправке сообщения пользователю',
								{ message_thread_id: topicId }
							);
						}
					}
				}
			}
		});

		// Handle /close command in support chat
		this.bot.onText(/\/close/, async msg => {
			if (msg.chat.id !== this.SUPPORT_CHAT_ID) return;

			const threadId = msg.message_thread_id;
			if (!threadId) return;

			const userId = this.findUserIdByTopicId(threadId);
			if (userId) {
				await this.closeDialog(msg, userId);
			}
		});
	}

	async handleSupportCommand(msg) {
		console.log('Received /support command:', msg);

		if (!msg.chat || msg.chat.type !== 'private') {
			console.log('Ignoring /support command: not a private chat');
			return;
		}

		if (!msg.from) {
			console.log('Ignoring /support command: no user information');
			return;
		}

		const userId = msg.from.id;
		const username = msg.from.username || 'Неизвестный пользователь';

		console.log('Processing /support command for user:', {
			userId,
			username,
			chatId: msg.chat.id,
		});

		// Проверяем, не активен ли уже чат поддержки
		const existingChat = this.activeChats.get(userId);
		if (existingChat) {
			console.log('User already has active support chat:', existingChat);
			await this.bot.sendMessage(
				msg.chat.id,
				'У вас уже есть активный диалог с поддержкой. Используйте его или нажмите "Завершить диалог", чтобы начать новый.'
			);
			return;
		}

		try {
			await this.bot.sendMessage(
				msg.chat.id,
				'Добрый день! Напишите свой вопрос ниже, а мы обязательно на него ответим прямо тут.\n\nВы также можете отправить файлы, фото, видео или документы.',
				{
					reply_markup: {
						keyboard: [['Завершить диалог']],
						resize_keyboard: true,
						one_time_keyboard: false,
					},
				}
			);

			// Store chat info
			this.activeChats.set(userId, {
				status: 'waiting_for_question',
				username,
				topicId: null,
				chatId: msg.chat.id,
			});

			console.log('Started support chat for user:', {
				userId,
				username,
				chatId: msg.chat.id,
				activeChats: Array.from(this.activeChats.entries()),
			});
		} catch (error) {
			console.error('Error starting support chat:', error);
			await this.bot.sendMessage(
				msg.chat.id,
				'Произошла ошибка при начале диалога. Пожалуйста, попробуйте позже.'
			);
			// Очищаем чат из активных в случае ошибки
			this.activeChats.delete(userId);
		}
	}

	async handleNewQuestion(msg, userId, chatInfo) {
		const username = chatInfo.username;

		try {
			console.log('Creating new support topic for user:', userId);

			// Создаем новый топик в форуме
			const topic = await this.bot.createForumTopic(
				this.SUPPORT_CHAT_ID,
				`❓ Вопрос от ${username}`
			);

			console.log('Forum topic created:', topic);

			const topicId = topic.message_thread_id;
			console.log('Topic ID:', topicId);

			// Отправляем информацию о пользователе в топик
			const questionText = msg.text || '(файл без текста)';
			await this.bot.sendMessage(
				this.SUPPORT_CHAT_ID,
				`#новый_вопрос\nID пользователя: ${userId}\nUsername: @${username}\n\nВопрос:\n${questionText}`,
				{ message_thread_id: topicId }
			);

			// Если есть файл, отправляем его
			if (msg.photo || msg.document || msg.video || msg.audio || msg.voice || msg.video_note || msg.sticker) {
				await this.forwardUserMessageToSupport(msg, topicId);
			}

			// Обновляем информацию о чате
			this.activeChats.set(userId, {
				...chatInfo,
				status: 'active',
				topicId: topicId,
			});

			console.log(
				'Active chat updated for user:',
				userId,
				'with topicId:',
				topicId
			);

			await this.bot.sendMessage(
				msg.chat.id,
				'Ваш вопрос отправлен в службу поддержки. Ожидайте ответа.'
			);
		} catch (error) {
			console.error('Error handling support question:', error);
			await this.bot.sendMessage(
				msg.chat.id,
				'Произошла ошибка при обработке вашего вопроса. Пожалуйста, попробуйте позже.'
			);
			this.activeChats.delete(userId);
		}
	}

	async closeDialog(msg, userId) {
		const chatInfo = this.activeChats.get(userId);
		if (!chatInfo) return;

		const closeMessage = 'Диалог завершен. Спасибо за обращение!';

		try {
			// Send close message to user
			await this.bot.sendMessage(userId, closeMessage, {
				reply_markup: {
					remove_keyboard: true,
				},
			});

			// Send close message to support chat if there's an active topic
			if (chatInfo.topicId) {
				await this.bot.sendMessage(
					this.SUPPORT_CHAT_ID,
					`Диалог с пользователем ${chatInfo.username} (${userId}) завершен.`,
					{ message_thread_id: chatInfo.topicId }
				);
			}
		} catch (error) {
			console.error('Error closing support dialog:', error);
		} finally {
			// Remove chat from active chats
			this.activeChats.delete(userId);
		}
	}

	findUserIdByTopicId(topicId) {
		for (const [userId, chatInfo] of this.activeChats.entries()) {
			if (chatInfo.topicId === topicId) {
				return userId;
			}
		}
		return null;
	}

	async forwardUserMessageToSupport(msg, topicId) {
		const options = { message_thread_id: topicId };
		const caption = msg.caption ? `Сообщение от пользователя:\n${msg.caption}` : 'Сообщение от пользователя:';

		if (msg.photo) {
			// Берем фото с максимальным разрешением
			const photo = msg.photo[msg.photo.length - 1];
			await this.bot.sendPhoto(this.SUPPORT_CHAT_ID, photo.file_id, {
				...options,
				caption: caption
			});
		} else if (msg.document) {
			await this.bot.sendDocument(this.SUPPORT_CHAT_ID, msg.document.file_id, {
				...options,
				caption: caption
			});
		} else if (msg.video) {
			await this.bot.sendVideo(this.SUPPORT_CHAT_ID, msg.video.file_id, {
				...options,
				caption: caption
			});
		} else if (msg.audio) {
			await this.bot.sendAudio(this.SUPPORT_CHAT_ID, msg.audio.file_id, {
				...options,
				caption: caption
			});
		} else if (msg.voice) {
			await this.bot.sendVoice(this.SUPPORT_CHAT_ID, msg.voice.file_id, {
				...options,
				caption: caption
			});
		} else if (msg.video_note) {
			await this.bot.sendVideoNote(this.SUPPORT_CHAT_ID, msg.video_note.file_id, options);
			if (msg.text || msg.caption) {
				await this.bot.sendMessage(this.SUPPORT_CHAT_ID, caption, options);
			}
		} else if (msg.sticker) {
			await this.bot.sendSticker(this.SUPPORT_CHAT_ID, msg.sticker.file_id, options);
			if (msg.text || msg.caption) {
				await this.bot.sendMessage(this.SUPPORT_CHAT_ID, caption, options);
			}
		} else if (msg.text) {
			await this.bot.sendMessage(
				this.SUPPORT_CHAT_ID,
				`Сообщение от пользователя:\n${msg.text}`,
				options
			);
		}
	}

	async forwardSupportMessageToUser(msg, userId, topicId) {
		const caption = msg.caption ? `Ответ поддержки:\n${msg.caption}` : 'Ответ поддержки:';

		try {
			if (msg.photo) {
				const photo = msg.photo[msg.photo.length - 1];
				await this.bot.sendPhoto(userId, photo.file_id, {
					caption: caption
				});
			} else if (msg.document) {
				await this.bot.sendDocument(userId, msg.document.file_id, {
					caption: caption
				});
			} else if (msg.video) {
				await this.bot.sendVideo(userId, msg.video.file_id, {
					caption: caption
				});
			} else if (msg.audio) {
				await this.bot.sendAudio(userId, msg.audio.file_id, {
					caption: caption
				});
			} else if (msg.voice) {
				await this.bot.sendVoice(userId, msg.voice.file_id, {
					caption: caption
				});
			} else if (msg.video_note) {
				await this.bot.sendVideoNote(userId, msg.video_note.file_id);
				if (msg.text || msg.caption) {
					await this.bot.sendMessage(userId, caption);
				}
			} else if (msg.sticker) {
				await this.bot.sendSticker(userId, msg.sticker.file_id);
				if (msg.text || msg.caption) {
					await this.bot.sendMessage(userId, caption);
				}
			} else if (msg.text) {
				await this.bot.sendMessage(userId, `Ответ поддержки:\n${msg.text}`);
			}
		} catch (error) {
			console.error('Error forwarding message to user:', error);
			throw error;
		}
	}
}


