import express from 'express';
import paymentService from '../services/paymentService.js';

const router = express.Router();

// Обработчик для уведомлений о платежах
router.post('/payment-notification', async (req, res) => {
	try {
		const {
			telegramUsername,
			gameInfo,
			telegramId,
			checkoutWithoutAccount,
			psLogin,
			psPassword,
			psBackupCodes,
			firstName,
			lastName,
			customerEmail,
			birthDate,
			paymentStatus,
			currency,
			promoCode,
		} = req.body;

		// Логируем полученные данные (без вывода полного пароля)
		console.log('Payment notification received:', {
			telegramUsername,
			gameInfoCount: gameInfo?.length || 0,
			telegramId,
			checkoutWithoutAccount,
			psLogin: psLogin ? 'provided' : 'not provided',
			psPassword: psPassword
				? `${psPassword.length} chars`
				: 'not provided',
			psPasswordType: typeof psPassword,
			psBackupCodes: psBackupCodes ? 'provided' : 'not provided',
			firstName: firstName ? 'provided' : 'not provided',
			lastName: lastName ? 'provided' : 'not provided',
			customerEmail: customerEmail ? 'provided' : 'not provided',
			birthDate: birthDate ? 'provided' : 'not provided',
			paymentStatus,
			currency: currency ? 'provided' : 'not provided',
		});

		// Проверяем наличие обязательных полей
		if (
			!telegramId ||
			!gameInfo ||
			!Array.isArray(gameInfo) ||
			gameInfo.length === 0
		) {
			return res.status(400).json({ error: 'Missing required fields' });
		}

		// Убедимся, что psPassword передается как строка
		const sanitizedPsPassword = psPassword ? String(psPassword) : null;

		// Отправляем уведомление через бота
		await paymentService.sendPaymentNotification(
			telegramUsername,
			gameInfo,
			telegramId,
			checkoutWithoutAccount,
			psLogin,
			sanitizedPsPassword,
			psBackupCodes,
			firstName,
			lastName,
			customerEmail,
			birthDate,
			paymentStatus,
			currency,
			promoCode
		);

		res.status(200).json({ success: true });
	} catch (error) {
		console.error('Error processing payment notification:', error);
		res.status(500).json({ error: 'Internal server error' });
	}
});

export default router;


