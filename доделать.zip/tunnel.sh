#!/bin/bash

# Генерируем случайные имена для туннелей
FRONTEND_NAME=$(LC_ALL=C tr -dc 'a-z0-9' < /dev/urandom | head -c 8)
BACKEND_NAME=$(LC_ALL=C tr -dc 'a-z0-9' < /dev/urandom | head -c 8)
BOT_NAME=$(LC_ALL=C tr -dc 'a-z0-9' < /dev/urandom | head -c 8)

# Функция для получения URL из лог-файла
get_tunnel_url() {
    local log_file=$1
    local max_attempts=30
    local attempt=1

    while [ $attempt -le $max_attempts ]; do
        if grep -q "https://.*trycloudflare.com" "$log_file"; then
            echo $(grep -m 1 "https://.*trycloudflare.com" "$log_file" | grep -o 'https://[^[:space:]]*')
            return 0
        fi
        sleep 1
        attempt=$((attempt + 1))
    done
    return 1
}

# Запускаем туннели через cloudflared
echo "Запуск туннелей..."

# Запускаем туннель для фронтенда
cloudflared tunnel --url http://localhost:5312 > frontend_url.txt 2>&1 &
FRONTEND_PID=$!

# Запускаем туннель для бэкенда
cloudflared tunnel --url http://localhost:3000 > backend_url.txt 2>&1 &
BACKEND_PID=$!

# Запускаем туннель для бота
cloudflared tunnel --url http://localhost:3001 > bot_url.txt 2>&1 &
BOT_PID=$!

echo "Ожидание создания туннелей (может занять до 30 секунд)..."

# Получаем URL туннелей
FRONTEND_URL=$(get_tunnel_url frontend_url.txt)
BACKEND_URL=$(get_tunnel_url backend_url.txt)
BOT_URL=$(get_tunnel_url bot_url.txt)

# Проверяем, получили ли мы URL
if [ -z "$FRONTEND_URL" ] || [ -z "$BACKEND_URL" ] || [ -z "$BOT_URL" ]; then
    echo "Ошибка: Не удалось получить URL туннелей после 30 секунд ожидания"
    echo "Frontend log:"
    cat frontend_url.txt
    echo "Backend log:"
    cat backend_url.txt
    echo "Bot log:"
    cat bot_url.txt
    kill $FRONTEND_PID $BACKEND_PID $BOT_PID
    rm frontend_url.txt backend_url.txt bot_url.txt
    exit 1
fi

# Удаляем временные файлы
rm frontend_url.txt backend_url.txt bot_url.txt

echo "Tunnels created:"
echo "Backend URL: $BACKEND_URL"
echo "Frontend URL: $FRONTEND_URL"
echo "Bot URL: $BOT_URL"

# Обновляем .env.development
sed -i '' "s|VITE_API_BASE_URL=.*|VITE_API_BASE_URL=${BACKEND_URL}|" .env.development
sed -i '' "s|TELEGRAM_WEB_APP_URL=.*|TELEGRAM_WEB_APP_URL=${FRONTEND_URL}|" .env.development
sed -i '' "s|BOT_URL=.*|BOT_URL=${BOT_URL}|" .env.development

echo "Обновил .env.development"
echo ""
echo "Нажми Ctrl+C чтобы завершить скрипт"

# Ожидаем нажатия Ctrl+C
echo "Press Ctrl+C to stop tunnels"
wait

# Очистка при выходе
trap "kill $FRONTEND_PID $BACKEND_PID $BOT_PID" EXIT
