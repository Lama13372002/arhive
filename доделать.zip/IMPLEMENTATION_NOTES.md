# Реализация раздельных корзин и данных профиля для регионов

## Обзор

Реализована функциональность раздельного хранения корзин и данных профиля для каждого региона (валюты). Теперь пользователь может:
- Добавлять товары в корзину в разных регионах независимо
- Переключаться между регионами без потери товаров в корзине
- Хранить разные данные профиля (логин, пароль, email и т.д.) для каждого региона

## Изменения в базе данных

### Новая таблица: UserRegionData

```sql
CREATE TABLE "UserRegionData" (
    "id" SERIAL PRIMARY KEY,
    "userId" INTEGER NOT NULL,
    "currencyId" INTEGER NOT NULL,
    "psStoreLogin" VARCHAR(255),
    "psStorePassword" VARCHAR(255),
    "psBackupCodes" TEXT,
    "email" VARCHAR(255),
    "createdAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE ("userId", "currencyId")
);
```

Таблица создана через скрипт `create_user_region_data_table.js`

## Backend изменения

### 1. Модель UserRegionData
**Файл:** `backend/src/models/userRegionData.js`

Создана новая модель для хранения региональных данных пользователя с связями:
- `User` (userId)
- `Currency` (currencyId)

### 2. Контроллеры
**Файл:** `backend/src/controllers/userController.js`

Добавлены новые контроллеры:
- `getRegionData` - получение данных профиля для конкретного региона
- `updateRegionData` - обновление данных профиля для конкретного региона

### 3. Сервисы
**Файл:** `backend/src/services/userService.js`

Добавлены новые сервисы:
- `getUserRegionData(telegramId, currencyId)` - получение региональных данных
- `updateUserRegionData(telegramId, currencyId, data)` - обновление/создание региональных данных

### 4. Роуты
**Файл:** `backend/src/routes/userRouter.js`

Добавлены новые эндпоинты:
- `GET /api/users/:telegramId/region/:currencyId` - получение данных региона
- `PUT /api/users/:telegramId/region/:currencyId` - обновление данных региона

## Frontend изменения

### 1. Логика корзины
**Файл:** `frontend/src/store/modules/cart.js`

**Изменения в хранении данных:**
- Корзина теперь хранится с ключом `cart_region_{currencyId}` вместо просто `cart`
- Промокоды хранятся с ключами `promoCode_region_{currencyId}`, `promoDiscount_region_{currencyId}`, `promoStatus_region_{currencyId}`

**Изменённые действия:**
- `loadCart` - загружает корзину для текущего региона
- `addToCart` - сохраняет в корзину текущего региона
- `removeFromCart` - удаляет из корзины текущего региона
- `clearCart` - очищает корзину текущего региона
- `applyPromoCode` - применяет промокод для текущего региона
- `clearPromoCode` - очищает промокод текущего региона

**Удалено:**
- Логика очистки корзины при смене валюты (строки 130-142)

### 2. API сервисы
**Файл:** `frontend/src/services/apiService.js`

Добавлены новые функции:
- `getUserRegionData(telegramId, currencyId)` - получение данных региона
- `updateUserRegionData(telegramId, currencyId, data)` - обновление данных региона

### 3. Модуль профиля
**Файл:** `frontend/src/store/modules/profile.js`

**Изменённые действия:**
- `saveProfileData` - теперь сохраняет данные через `updateUserRegionData` для текущего региона
- `loadProfileData` - новое действие для загрузки данных текущего региона

### 4. Модуль пользователя
**Файл:** `frontend/src/store/modules/user.js`

Добавлены новые действия:
- `getUserRegionData({ currencyId })` - получение региональных данных
- `updateUserRegionData({ currencyId, data })` - обновление региональных данных

### 5. Компонент профиля
**Файл:** `frontend/src/components/screens/ProfileScreen.vue`

**Изменения:**
- Добавлена функция `loadRegionProfile()` для загрузки данных текущего региона
- Добавлен watcher для отслеживания смены валюты и автоматической перезагрузки данных профиля
- Функция `saveField` теперь использует `profile/saveProfileData` вместо прямого обновления полей пользователя

### 6. Компонент меню
**Файл:** `frontend/src/components/common/Menu.vue`

**Изменения в функции `setLocalization`:**
- Добавлен вызов `store.dispatch('cart/loadCart')` после смены валюты для автоматической загрузки корзины нового региона

## Как это работает

### Сценарий 1: Работа с корзиной

1. **Пользователь в регионе RUB (id=1):**
   - Добавляет игру A в корзину
   - Данные сохраняются в `localStorage` с ключом `cart_region_1`

2. **Пользователь переключается на регион USD (id=2):**
   - Вызывается `setLocalization()` в Menu.vue
   - Обновляется валюта в store
   - Автоматически вызывается `cart/loadCart`
   - Загружается корзина из `localStorage` с ключом `cart_region_2` (пустая)

3. **Пользователь добавляет игру B в корзину:**
   - Данные сохраняются в `cart_region_2`

4. **Пользователь возвращается в регион RUB:**
   - Автоматически загружается `cart_region_1` с игрой A

### Сценарий 2: Работа с данными профиля

1. **Пользователь в регионе RUB заполняет данные профиля:**
   - Email: user@rub.com
   - Login: rub_user
   - Вызывается `profile/saveProfileData`
   - Данные сохраняются в БД в таблице `UserRegionData` с `currencyId=1`

2. **Пользователь переключается на регион USD:**
   - Срабатывает watcher в ProfileScreen.vue
   - Автоматически вызывается `loadRegionProfile()`
   - Загружаются данные из БД для `currencyId=2` (пустые или ранее сохранённые)

3. **Пользователь заполняет данные для региона USD:**
   - Email: user@usd.com
   - Login: usd_user
   - Данные сохраняются в БД для `currencyId=2`

4. **Пользователь возвращается в регион RUB:**
   - Автоматически загружаются данные для `currencyId=1` (user@rub.com, rub_user)

## Миграция существующих данных

Для миграции существующих данных пользователей из таблицы `Users` в `UserRegionData` можно использовать следующий SQL скрипт:

```sql
-- Копируем данные из Users в UserRegionData для каждой валюты
INSERT INTO "UserRegionData" ("userId", "currencyId", "psStoreLogin", "psStorePassword", "psBackupCodes", "email", "createdAt", "updatedAt")
SELECT
    u."id" as "userId",
    u."currencyId",
    u."psStoreLogin",
    u."psStorePassword",
    u."psBackupCodes",
    u."email",
    NOW() as "createdAt",
    NOW() as "updatedAt"
FROM "Users" u
WHERE u."psStoreLogin" IS NOT NULL
   OR u."psStorePassword" IS NOT NULL
   OR u."psBackupCodes" IS NOT NULL
   OR u."email" IS NOT NULL
ON CONFLICT ("userId", "currencyId") DO NOTHING;
```

## Тестирование

Для тестирования функциональности:

1. **Тест корзины:**
   - Добавьте товары в корзину в регионе RUB
   - Переключитесь на USD - корзина должна быть пустой
   - Добавьте другие товары в USD
   - Вернитесь в RUB - должны увидеть товары, добавленные ранее

2. **Тест профиля:**
   - Заполните данные профиля в регионе RUB
   - Переключитесь на USD - поля должны быть пустыми
   - Заполните данные для USD
   - Вернитесь в RUB - должны увидеть данные RUB

3. **Тест промокодов:**
   - Примените промокод в регионе RUB
   - Переключитесь на USD - промокод не должен быть применён
   - Вернитесь в RUB - промокод должен остаться применённым

## Возможные улучшения

1. Добавить индикатор количества товаров в корзине для каждого региона в UI
2. Добавить возможность копирования данных профиля между регионами
3. Добавить очистку старых данных корзины (например, товары старше 30 дней)
4. Добавить синхронизацию корзины с сервером (сейчас только в localStorage)


