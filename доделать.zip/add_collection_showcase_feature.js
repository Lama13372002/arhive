import pkg from 'pg';
const { Client } = pkg;

const client = new Client({
  host: '193.17.92.132',
  port: 5432,
  database: 'game_shop_db',
  user: 'nkarasyov',
  password: 'pAssW_ord123',
});

async function runMigration() {
  try {
    await client.connect();
    console.log('✅ Подключено к базе данных');

    // Создаем таблицу для витринных (showcase) товаров коллекций
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS "CollectionShowcaseEditions" (
        id SERIAL PRIMARY KEY,
        collection_id INTEGER NOT NULL REFERENCES "ProductCollections"(id) ON DELETE CASCADE,
        edition_id INTEGER NOT NULL REFERENCES "Editions"(id) ON DELETE CASCADE,
        currency_id INTEGER NOT NULL REFERENCES "Currencies"(id) ON DELETE CASCADE,
        position INTEGER NOT NULL CHECK (position >= 1 AND position <= 3),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(collection_id, currency_id, position),
        UNIQUE(collection_id, currency_id, edition_id)
      );
    `;

    await client.query(createTableQuery);
    console.log('✅ Таблица CollectionShowcaseEditions создана');

    // Создаем индексы для оптимизации запросов
    const createIndexesQuery = `
      CREATE INDEX IF NOT EXISTS idx_showcase_collection_currency
        ON "CollectionShowcaseEditions"(collection_id, currency_id);

      CREATE INDEX IF NOT EXISTS idx_showcase_edition
        ON "CollectionShowcaseEditions"(edition_id);

      CREATE INDEX IF NOT EXISTS idx_showcase_position
        ON "CollectionShowcaseEditions"(position);
    `;

    await client.query(createIndexesQuery);
    console.log('✅ Индексы созданы');

    // Создаем триггер для обновления updated_at
    const createTriggerQuery = `
      CREATE OR REPLACE FUNCTION update_showcase_updated_at()
      RETURNS TRIGGER AS $$
      BEGIN
        NEW.updated_at = CURRENT_TIMESTAMP;
        RETURN NEW;
      END;
      $$ LANGUAGE plpgsql;

      DROP TRIGGER IF EXISTS trigger_showcase_updated_at ON "CollectionShowcaseEditions";

      CREATE TRIGGER trigger_showcase_updated_at
        BEFORE UPDATE ON "CollectionShowcaseEditions"
        FOR EACH ROW
        EXECUTE FUNCTION update_showcase_updated_at();
    `;

    await client.query(createTriggerQuery);
    console.log('✅ Триггер для updated_at создан');

    // Добавляем комментарии к таблице и полям
    const addCommentsQuery = `
      COMMENT ON TABLE "CollectionShowcaseEditions" IS
        'Витринные товары для коллекций - позволяет вручную выбирать до 3 товаров для предпросмотра коллекции для каждого региона (валюты)';

      COMMENT ON COLUMN "CollectionShowcaseEditions".collection_id IS
        'ID коллекции';

      COMMENT ON COLUMN "CollectionShowcaseEditions".edition_id IS
        'ID издания игры для витрины';

      COMMENT ON COLUMN "CollectionShowcaseEditions".currency_id IS
        'ID валюты (региона) - для разных регионов могут быть разные витринные товары';

      COMMENT ON COLUMN "CollectionShowcaseEditions".position IS
        'Позиция товара в витрине (1, 2 или 3)';
    `;

    await client.query(addCommentsQuery);
    console.log('✅ Комментарии добавлены');

    console.log('\n📊 РЕЗУЛЬТАТ МИГРАЦИИ:');
    console.log('==========================================');
    console.log('✅ Создана таблица: CollectionShowcaseEditions');
    console.log('✅ Добавлены индексы для оптимизации');
    console.log('✅ Создан триггер для автообновления updated_at');
    console.log('✅ Добавлены комментарии к таблице');
    console.log('\n📝 СТРУКТУРА ТАБЛИЦЫ:');
    console.log('- id: Serial PRIMARY KEY');
    console.log('- collection_id: INTEGER (FK → ProductCollections)');
    console.log('- edition_id: INTEGER (FK → Editions)');
    console.log('- currency_id: INTEGER (FK → Currencies)');
    console.log('- position: INTEGER (1-3)');
    console.log('- created_at: TIMESTAMP');
    console.log('- updated_at: TIMESTAMP');
    console.log('\n🎯 УНИКАЛЬНЫЕ ОГРАНИЧЕНИЯ:');
    console.log('- Для каждой коллекции + валюты + позиция = уникально');
    console.log('- Для каждой коллекции + валюты + издание = уникально');
    console.log('==========================================\n');

  } catch (error) {
    console.error('❌ Ошибка при выполнении миграции:', error);
    process.exit(1);
  } finally {
    await client.end();
    console.log('✅ Соединение с базой данных закрыто');
  }
}

runMigration();
