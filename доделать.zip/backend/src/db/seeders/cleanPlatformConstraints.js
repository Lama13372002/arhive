import dotenv from 'dotenv';
import path from 'path';
import { Sequelize } from 'sequelize';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Загружаем переменные окружения из .env.development
dotenv.config({
	path: path.resolve(__dirname, '../../../../.env.development'),
});

async function cleanConstraints() {
	try {
		// Создаем подключение к базе данных используя переменные окружения
		const sequelize = new Sequelize(
			process.env.DB_NAME,
			process.env.DB_USER,
			process.env.DB_PASSWORD,
			{
				host: process.env.DB_HOST,
				port: process.env.DB_PORT,
				dialect: 'postgres',
				logging: console.log,
			}
		);

		// Проверяем подключение
		await sequelize.authenticate();
		console.log('Connected to database successfully.');

		// SQL для удаления дублирующихся ограничений
		const cleanupSQL = `
			DO $$
			DECLARE
				r RECORD;
			BEGIN
				FOR r IN (
					SELECT constraint_name
					FROM information_schema.table_constraints
					WHERE table_name = 'Platforms'
					AND constraint_type = 'UNIQUE'
					AND constraint_name LIKE 'Platforms_name_key%'
					AND constraint_name != 'Platforms_name_key'
				)
				LOOP
					EXECUTE 'ALTER TABLE "Platforms" DROP CONSTRAINT ' || quote_ident(r.constraint_name);
					RAISE NOTICE 'Dropped constraint: %', r.constraint_name;
				END LOOP;
			END $$;
		`;

		// Выполняем очистку
		await sequelize.query(cleanupSQL);
		console.log('Cleanup completed successfully.');

		// Проверяем оставшиеся ограничения
		const [constraints] = await sequelize.query(`
			SELECT constraint_name
			FROM information_schema.table_constraints
			WHERE table_name = 'Platforms'
			AND constraint_type = 'UNIQUE';
		`);

		console.log('Remaining constraints:', constraints);

		// Закрываем соединение
		await sequelize.close();
		console.log('Connection closed.');
		process.exit(0);
	} catch (error) {
		console.error('Error during cleanup:', error);
		process.exit(1);
	}
}

// Запускаем скрипт
cleanConstraints();
