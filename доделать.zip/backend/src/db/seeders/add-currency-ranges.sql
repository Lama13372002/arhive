-- Получаем ID валюты GBP
WITH currency_ids AS (
    SELECT id, code 
    FROM "Currencies" 
    WHERE code = 'GBP'
)
INSERT INTO "CurrencyRanges" ("currencyId", "amountFrom", "amountTo", rate_multiplier, "createdAt", "updatedAt")
SELECT 
    id as "currencyId",
    CASE 
        WHEN ranges.range_num = 1 THEN 0
        WHEN ranges.range_num = 2 THEN 1000
        WHEN ranges.range_num = 3 THEN 5000
        WHEN ranges.range_num = 4 THEN 10000
    END as "amountFrom",
    CASE 
        WHEN ranges.range_num = 1 THEN 999
        WHEN ranges.range_num = 2 THEN 4999
        WHEN ranges.range_num = 3 THEN 9999
        WHEN ranges.range_num = 4 THEN 999999999
    END as "amountTo",
    CASE 
        WHEN ranges.range_num = 1 THEN 1.0
        WHEN ranges.range_num = 2 THEN 0.95
        WHEN ranges.range_num = 3 THEN 0.9
        WHEN ranges.range_num = 4 THEN 0.85
    END as rate_multiplier,
    CURRENT_TIMESTAMP as "createdAt",
    CURRENT_TIMESTAMP as "updatedAt"
FROM currency_ids
CROSS JOIN (
    SELECT generate_series(1, 4) as range_num
) as ranges;
