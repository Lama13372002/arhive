-- Очищаем все таблицы
TRUNCATE TABLE "ProductCards" CASCADE;
TRUNCATE TABLE "Genres" CASCADE;
TRUNCATE TABLE "Localizations" CASCADE;
TRUNCATE TABLE "EditionTypes" CASCADE;
TRUNCATE TABLE "ProductCardGenres" CASCADE;
TRUNCATE TABLE "ProductCardPlatforms" CASCADE;
TRUNCATE TABLE "Editions" CASCADE;
TRUNCATE TABLE "ProductCollections" CASCADE;
TRUNCATE TABLE "ProductCollectionCards" CASCADE;
TRUNCATE TABLE "FeedItems" CASCADE;
TRUNCATE TABLE "Platforms" CASCADE;
TRUNCATE TABLE "Currencies" CASCADE;

-- Добавление платформ
INSERT INTO "Platforms" (id, name, icon_url)
VALUES
    (1, 'PlayStation 5', '/assets/img/ps5.png');

-- Добавление валют
INSERT INTO "Currencies" (id, code, name, symbol, exchange_rate, is_default, icon)
VALUES
    (1, 'RUB', 'Российский рубль', '₽', 1.0, true, '/assets/img/rub.png'),
    (2, 'USD', 'Доллар США', '$', 90.0, false, '/assets/img/usd.png');

-- Добавление ProductCards
INSERT INTO "ProductCards" (id, name, image_url, free_with_ea_play, free_with_ps_plus, rating, edition_type, description, created_at, updated_at)
VALUES
    (1, 'God of War Ragnarök', 'https://example.com/games/god-of-war.jpg', false, false, 9.5, 'Game',
        'Отправьтесь в скандинавские царства и сразитесь с северными богами в новом приключении Кратоса и Атрея.',
        NOW(), NOW()),
    (2, 'Marvel''s Spider-Man 2', 'https://example.com/games/spiderman-2.jpg', false, false, 9.0, 'Game',
        'Питер Паркер и Майлз Моралес возвращаются в захватывающем новом приключении серии Marvel''s Spider-Man.',
        NOW(), NOW()),
    (3, 'Final Fantasy XVI', 'https://example.com/games/ff16.jpg', false, false, 8.8, 'Game',
        'Эпическое приключение в мире, где магия и технологии сосуществуют.',
        NOW(), NOW()),
    (4, 'Horizon Forbidden West', 'https://example.com/games/horizon.jpg', false, false, 9.2, 'Game',
        'Продолжение приключений Элой в постапокалиптическом мире.',
        NOW(), NOW()),
    (5, 'Assassin''s Creed Mirage', 'https://example.com/games/ac-mirage.jpg', false, false, 8.5, 'Game',
        'Вернитесь к истокам серии в роли молодого Басима.',
        NOW(), NOW()),
    (6, 'Mortal Kombat 1', 'https://example.com/games/mk1.jpg', false, false, 8.7, 'Game',
        'Новая эра легендарной файтинг-серии.',
        NOW(), NOW()),
    (7, 'Cyberpunk 2077', 'https://example.com/games/cyberpunk.jpg', false, false, 8.9, 'Game',
        'Исследуйте Найт-Сити в роли наемника V.',
        NOW(), NOW()),
    (8, 'EA Sports FC 24', 'https://example.com/games/eafc24.jpg', false, false, 8.4, 'Game',
        'Новая эра футбольных симуляторов.',
        NOW(), NOW()),
    (9, 'Resident Evil 4', 'https://example.com/games/re4.jpg', false, false, 9.3, 'Game',
        'Ремейк классического хоррора.',
        NOW(), NOW()),
    (10, 'The Last of Us Part I', 'https://example.com/games/tlou.jpg', false, false, 9.6, 'Game',
        'Переживите заново знаковое приключение, воссозданное для PS5.',
        NOW(), NOW()),
    (11, 'Gran Turismo 7', 'https://example.com/games/gt7.jpg', false, false, 8.8, 'Game',
        'Почувствуйте реальную скорость в лучшем автосимуляторе для PS5.',
        NOW(), NOW()),
    (12, 'Demon''s Souls', 'https://example.com/games/demons-souls.jpg', false, false, 9.2, 'Game',
        'Классическая RPG, возрожденная для нового поколения.',
        NOW(), NOW()),
    (13, 'Ratchet & Clank: Rift Apart', 'https://example.com/games/ratchet.jpg', false, false, 9.0, 'Game',
        'Межпространственное приключение любимых героев PlayStation.',
        NOW(), NOW()),
    (14, 'Hogwarts Legacy', 'https://example.com/games/hogwarts.jpg', false, false, 8.9, 'Game',
        'Создайте своего волшебника и исследуйте магический мир Хогвартса.',
        NOW(), NOW()),
    (15, 'Игра 1', '/assets/img/offer1.png', false, false, 0, 'Game', '', NOW(), NOW()),
    (16, 'Игра 2', '/assets/img/offer1.png', false, false, 0, 'Game', '', NOW(), NOW()),
    (17, 'Игра 3', '/assets/img/offer1.png', false, false, 0, 'Game', '', NOW(), NOW()),
    (18, 'Игра 4', '/assets/img/offer1.png', false, false, 0, 'Game', '', NOW(), NOW()),
    (19, 'Тестовый товар', '/assets/img/test-item.png', false, false, 0, 'Game', '', NOW(), NOW()),
    (20, 'Marvel''s Человек-Паук 2', '/assets/img/item1.png', false, false, 0, 'Game', '', NOW(), NOW()),
    (21, 'Игра 8', '/assets/img/collection1.png', false, false, 0, 'Game', '', NOW(), NOW()),
    (22, 'Игра 9', '/assets/img/collection1.png', false, false, 0, 'Game', '', NOW(), NOW()),
    (23, 'Игра 10', '/assets/img/collection1.png', false, false, 0, 'Game', '', NOW(), NOW()),
    (24, 'Игра 11', '/assets/img/collection1.png', false, false, 0, 'Game', '', NOW(), NOW())
ON CONFLICT (id) DO NOTHING;

-- Добавление жанров
INSERT INTO "Genres" (id, name, created_at, updated_at)
VALUES
    (1, 'Action', NOW(), NOW()),
    (2, 'RPG', NOW(), NOW()),
    (3, 'Adventure', NOW(), NOW()),
    (4, 'Sports', NOW(), NOW()),
    (5, 'Racing', NOW(), NOW()),
    (6, 'Strategy', NOW(), NOW()),
    (7, 'Fighting', NOW(), NOW()),
    (8, 'Horror', NOW(), NOW());

-- Добавление локализаций
INSERT INTO "Localizations" (name, image_url, created_at, updated_at)
VALUES
    ('Россия', 'https://example.com/flags/ru.png', NOW(), NOW()),
    ('США', 'https://example.com/flags/us.png', NOW(), NOW()),
    ('Турция', 'https://example.com/flags/tr.png', NOW(), NOW());

-- Добавление типов изданий
INSERT INTO "EditionTypes" (id, name, created_at, updated_at)
VALUES
    (1, 'Standard', NOW(), NOW()),
    (2, 'Ultimate', NOW(), NOW());

-- Связь продуктов с жанрами
INSERT INTO "ProductCardGenres" (product_card_id, genre_id)
VALUES
    (1, 1),  -- God of War: Action
    (1, 2),  -- God of War: RPG
    (2, 1),  -- Spider-Man: Action
    (2, 3),  -- Spider-Man: Adventure
    (3, 2),  -- Final Fantasy: RPG
    (3, 1),  -- Final Fantasy: Action
    (4, 1),  -- Horizon: Action
    (4, 2),  -- Horizon: RPG
    (5, 1),  -- AC Mirage: Action
    (5, 3),  -- AC Mirage: Adventure
    (6, 1),  -- MK1: Action
    (6, 7),  -- MK1: Fighting
    (7, 1),  -- Cyberpunk: Action
    (7, 2),  -- Cyberpunk: RPG
    (8, 4),  -- EA FC 24: Sports
    (9, 1),  -- RE4: Action
    (9, 8),  -- RE4: Horror
    (10, 1), -- TLOU: Action
    (10, 3), -- TLOU: Adventure
    (11, 5), -- GT7: Racing
    (12, 2), -- Demon's Souls: RPG
    (12, 1), -- Demon's Souls: Action
    (13, 1), -- Ratchet: Action
    (13, 3), -- Ratchet: Adventure
    (14, 2), -- Hogwarts: RPG
    (14, 3); -- Hogwarts: Adventure

-- Связь продуктов с платформой PS5
INSERT INTO "ProductCardPlatforms" (product_card_id, platform_id)
VALUES
    (1, 1),  -- God of War
    (2, 1),  -- Spider-Man
    (3, 1),  -- Final Fantasy
    (4, 1),  -- Horizon
    (5, 1),  -- AC Mirage
    (6, 1),  -- MK1
    (7, 1),  -- Cyberpunk
    (8, 1),  -- EA FC 24
    (9, 1),  -- RE4
    (10, 1), -- TLOU
    (11, 1), -- GT7
    (12, 1), -- Demon's Souls
    (13, 1), -- Ratchet
    (14, 1), -- Hogwarts
    (15, 1), -- Игра 1
    (16, 1), -- Игра 2
    (17, 1), -- Игра 3
    (18, 1), -- Игра 4
    (19, 1), -- Тестовый товар
    (20, 1), -- Marvel's Человек-Паук 2
    (21, 1), -- Игра 8
    (22, 1), -- Игра 9
    (23, 1), -- Игра 10
    (24, 1); -- Игра 11

-- Добавление изданий для продуктов
INSERT INTO "Editions" (id, edition_type_id, product_card_id, price, display_currency_id, discount_percentage, ea_play_price, ps_plus_price, created_at, updated_at)
VALUES
    -- God of War Ragnarök
    (1, 1, 1, 4999.99, 2, 0, NULL, 4499.99, NOW(), NOW()),    -- Standard
    (2, 2, 1, 6999.99, 2, 10, NULL, 6299.99, NOW(), NOW()),   -- Ultimate

    -- Spider-Man 2
    (3, 1, 2, 5499.99, 2, 0, NULL, 4999.99, NOW(), NOW()),    -- Standard
    (4, 2, 2, 7499.99, 2, 0, NULL, 6749.99, NOW(), NOW()),    -- Ultimate

    -- Final Fantasy XVI
    (5, 1, 3, 4799.99, 2, 15, NULL, 4079.99, NOW(), NOW()),   -- Standard
    (6, 2, 3, 6799.99, 2, 15, NULL, 5779.99, NOW(), NOW()),   -- Ultimate

    -- Horizon Forbidden West
    (7, 1, 4, 4299.99, 2, 25, 0.00, 3224.99, NOW(), NOW()),   -- Standard
    (8, 2, 4, 5999.99, 2, 25, 0.00, 4499.99, NOW(), NOW()),   -- Ultimate

    -- AC Mirage
    (9, 1, 5, 3999.99, 2, 20, NULL, 3199.99, NOW(), NOW()),   -- Standard

    -- Mortal Kombat 1
    (10, 1, 6, 4999.99, 2, 0, NULL, 4499.99, NOW(), NOW()),    -- Standard
    (11, 2, 6, 7999.99, 2, 0, NULL, 7199.99, NOW(), NOW()),    -- Ultimate

    -- Cyberpunk 2077
    (12, 1, 7, 3999.99, 2, 30, NULL, 2799.99, NOW(), NOW()),   -- Standard

    -- EA FC 24
    (13, 1, 8, 4499.99, 2, 0, 0.00, 4049.99, NOW(), NOW()),    -- Standard
    (14, 2, 8, 6499.99, 2, 0, 0.00, 5849.99, NOW(), NOW()),    -- Ultimate

    -- Resident Evil 4
    (15, 1, 9, 4599.99, 2, 15, NULL, 3909.99, NOW(), NOW()),   -- Standard

    -- The Last of Us Part I
    (16, 1, 10, 4999.99, 2, 0, NULL, 4499.99, NOW(), NOW()),   -- Standard

    -- Gran Turismo 7
    (17, 1, 11, 4999.99, 2, 25, NULL, 3749.99, NOW(), NOW()),  -- Standard
    (18, 2, 11, 6999.99, 2, 25, NULL, 5249.99, NOW(), NOW()),  -- Ultimate

    -- Demon's Souls
    (19, 1, 12, 4499.99, 2, 20, NULL, 3599.99, NOW(), NOW()),  -- Standard

    -- Ratchet & Clank
    (20, 1, 13, 4999.99, 2, 30, NULL, 3499.99, NOW(), NOW()),  -- Standard
    (21, 2, 13, 5999.99, 2, 30, NULL, 4199.99, NOW(), NOW()),  -- Ultimate

    -- Hogwarts Legacy
    (22, 1, 14, 4999.99, 2, 0, NULL, 4499.99, NOW(), NOW());   -- Standard

-- Создаем тестовую коллекцию "Горячие предложения"
INSERT INTO "ProductCollections" (id, name, description, created_at, updated_at)
VALUES (1, 'Горячие предложения', 'Коллекция горячих предложений', NOW(), NOW());

-- Создаем тестовую коллекцию "Сейчас играют"
INSERT INTO "ProductCollections" (id, name, description, created_at, updated_at)
VALUES (2, 'Сейчас играют', 'Популярные игры', NOW(), NOW());

-- Создаем тестовую коллекцию "Специальные предложения"
INSERT INTO "ProductCollections" (id, name, description, created_at, updated_at)
VALUES (3, 'Специальные предложения', 'Специальные предложения и скидки', NOW(), NOW());

-- Создаем элементы фида
INSERT INTO "FeedItems" (type, position, title, collection_id, created_at, updated_at)
VALUES 
    ('banner', 1, 'Горячие предложения', 1, NOW(), NOW()),
    ('list', 2, 'Сейчас играют', 2, NOW(), NOW()),
    ('banner', 3, 'Специальные предложения', 3, NOW(), NOW());

-- Связываем продукты с коллекциями
INSERT INTO "ProductCollectionCards" (product_collection_id, product_card_id, created_at, updated_at)
VALUES 
    -- Горячие предложения
    (1, 1, NOW(), NOW()), -- God of War
    (1, 2, NOW(), NOW()), -- Spider-Man 2
    (1, 3, NOW(), NOW()), -- Final Fantasy XVI
    (1, 4, NOW(), NOW()), -- Horizon
    -- Сейчас играют
    (2, 5, NOW(), NOW()), -- AC Mirage
    (2, 6, NOW(), NOW()), -- Mortal Kombat
    (2, 7, NOW(), NOW()), -- Cyberpunk
    -- Специальные предложения
    (3, 8, NOW(), NOW()), -- EA FC 24
    (3, 9, NOW(), NOW()); -- RE4
