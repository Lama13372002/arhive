import React, { useState, useEffect } from 'react';
import { Box, Button, FormGroup, Label, Select, Text, MessageBox } from '@adminjs/design-system';
import { ApiClient, useNotice } from 'adminjs';

const api = new ApiClient();

const CollectionShowcaseManager = ({ record }) => {
	const [currencies, setCurrencies] = useState([]);
	const [selectedCurrency, setSelectedCurrency] = useState('');
	const [editions, setEditions] = useState([]);
	const [showcaseEditions, setShowcaseEditions] = useState({
		1: null,
		2: null,
		3: null,
	});
	const [loading, setLoading] = useState(false);
	const addNotice = useNotice();

	const collectionId = record?.params?.id;

	useEffect(() => {
		loadCurrencies();
		if (collectionId) {
			loadCollectionEditions();
		}
	}, [collectionId]);

	useEffect(() => {
		if (selectedCurrency && collectionId) {
			loadShowcaseEditions();
		}
	}, [selectedCurrency, collectionId]);

	const loadCurrencies = async () => {
		try {
			const response = await api.resourceAction({
				resourceId: 'Currency',
				actionName: 'list',
			});
			setCurrencies(response.data.records || []);
			if (response.data.records?.length > 0) {
				setSelectedCurrency(response.data.records[0].params.id);
			}
		} catch (error) {
			console.error('Error loading currencies:', error);
			addNotice({
				message: 'Ошибка загрузки валют',
				type: 'error',
			});
		}
	};

	const loadCollectionEditions = async () => {
		try {
			const response = await api.resourceAction({
				resourceId: 'ProductCollection',
				actionName: 'show',
				recordId: collectionId,
			});

			const editionIds = response.data.record?.params?.editions || [];

			if (editionIds.length > 0) {
				const editionsData = await Promise.all(
					editionIds.map(async (editionId) => {
						const editionResponse = await api.resourceAction({
							resourceId: 'Edition',
							actionName: 'show',
							recordId: editionId,
						});
						return editionResponse.data.record;
					})
				);
				setEditions(editionsData);
			}
		} catch (error) {
			console.error('Error loading collection editions:', error);
		}
	};

	const loadShowcaseEditions = async () => {
		try {
			const response = await api.resourceAction({
				resourceId: 'CollectionShowcaseEdition',
				actionName: 'list',
				params: {
					filters: {
						collection_id: collectionId,
						currency_id: selectedCurrency,
					},
				},
			});

			const newShowcaseEditions = { 1: null, 2: null, 3: null };
			response.data.records?.forEach((record) => {
				const position = record.params.position;
				const editionId = record.params.edition_id;
				newShowcaseEditions[position] = {
					id: record.params.id,
					edition_id: editionId,
				};
			});
			setShowcaseEditions(newShowcaseEditions);
		} catch (error) {
			console.error('Error loading showcase editions:', error);
		}
	};

	const handleEditionChange = (position, editionId) => {
		setShowcaseEditions((prev) => ({
			...prev,
			[position]: editionId ? { edition_id: editionId } : null,
		}));
	};

	const handleSave = async () => {
		if (!selectedCurrency || !collectionId) {
			addNotice({
				message: 'Выберите валюту',
				type: 'error',
			});
			return;
		}

		setLoading(true);
		try {
			// Удаляем старые записи для этой коллекции и валюты
			const existingRecords = await api.resourceAction({
				resourceId: 'CollectionShowcaseEdition',
				actionName: 'list',
				params: {
					filters: {
						collection_id: collectionId,
						currency_id: selectedCurrency,
					},
				},
			});

			for (const record of existingRecords.data.records || []) {
				await api.recordAction({
					resourceId: 'CollectionShowcaseEdition',
					recordId: record.params.id,
					actionName: 'delete',
				});
			}

			// Создаем новые записи
			for (const [position, showcase] of Object.entries(showcaseEditions)) {
				if (showcase?.edition_id) {
					await api.resourceAction({
						resourceId: 'CollectionShowcaseEdition',
						actionName: 'new',
						data: {
							collection_id: collectionId,
							currency_id: selectedCurrency,
							edition_id: showcase.edition_id,
							position: parseInt(position),
						},
					});
				}
			}

			addNotice({
				message: 'Витрина успешно обновлена',
				type: 'success',
			});
			loadShowcaseEditions();
		} catch (error) {
			console.error('Error saving showcase:', error);
			addNotice({
				message: 'Ошибка сохранения витрины',
				type: 'error',
			});
		} finally {
			setLoading(false);
		}
	};

	const getEditionLabel = (edition) => {
		if (!edition?.params) return '';
		const productCardName = edition.populated?.productCard?.params?.name || 'Unknown';
		const editionName = edition.populated?.editionName?.params?.name || '';
		const price = edition.params.price || '0';
		return `${productCardName} - ${editionName} (${price})`;
	};

	if (!collectionId) {
		return (
			<Box margin="xl">
				<MessageBox message="Сохраните коллекцию, чтобы управлять витриной" variant="info" />
			</Box>
		);
	}

	return (
		<Box margin="xl">
			<Text fontSize="xl" fontWeight="bold" marginBottom="lg">
				Управление витриной коллекции
			</Text>

			<FormGroup>
				<Label>Выберите регион (валюту)</Label>
				<Select
					value={selectedCurrency}
					onChange={(value) => setSelectedCurrency(value)}
				>
					{currencies.map((currency) => (
						<option key={currency.params.id} value={currency.params.id}>
							{currency.params.name} ({currency.params.code})
						</option>
					))}
				</Select>
			</FormGroup>

			<Box marginTop="lg">
				<Text fontWeight="bold" marginBottom="default">
					Выберите 3 товара для витрины:
				</Text>

				{[1, 2, 3].map((position) => (
					<FormGroup key={position}>
						<Label>Позиция {position}</Label>
						<Select
							value={showcaseEditions[position]?.edition_id || ''}
							onChange={(value) => handleEditionChange(position, value)}
						>
							<option value="">-- Не выбрано --</option>
							{editions.map((edition) => (
								<option
									key={edition.params.id}
									value={edition.params.id}
								>
									{getEditionLabel(edition)}
								</option>
							))}
						</Select>
					</FormGroup>
				))}
			</Box>

			<Box marginTop="xl">
				<Button onClick={handleSave} disabled={loading} variant="primary">
					{loading ? 'Сохранение...' : 'Сохранить витрину'}
				</Button>
			</Box>
		</Box>
	);
};

export default CollectionShowcaseManager;
