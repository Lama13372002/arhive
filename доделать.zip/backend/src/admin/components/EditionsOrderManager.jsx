import React, { useState, useEffect } from 'react';
import { Box, Button, FormGroup, Input, Label, Text } from '@adminjs/design-system';
import { ApiClient } from 'adminjs';
import axios from 'axios';

const EditionsOrderManager = (props) => {
    const { record, property, onChange } = props;
    const [editionsByRegion, setEditionsByRegion] = useState({});
    const [currencies, setCurrencies] = useState([]);
    const [showAddModal, setShowAddModal] = useState(null); // null или currency_id
    const [newEditionId, setNewEditionId] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const api = new ApiClient();

    useEffect(() => {
        loadCurrencies();
        if (record.id) {
            loadEditions();
        }
    }, [record.id]);

    const loadCurrencies = async () => {
        console.log('=== loadCurrencies START ===');
        try {
            const response = await api.resourceAction({
                resourceId: 'Currencies',
                actionName: 'list',
            });

            console.log('Currencies API response:', response);

            if (response.data.records) {
                const currencyList = response.data.records.map(record => ({
                    id: record.params.id,
                    code: record.params.code,
                    name: record.params.name,
                }));
                console.log('Processed currency list:', currencyList);
                setCurrencies(currencyList);
            }
            console.log('=== loadCurrencies END ===');
        } catch (error) {
            console.error('=== loadCurrencies ERROR ===');
            console.error('Error loading currencies:', error);
        }
    };

    const loadEditions = async () => {
        console.log('=== loadEditions START ===');
        console.log('Record ID:', record.id);

        if (!record.id) {
            setEditionsByRegion({});
            return;
        }

        try {
            let editionsData = [];

            // Сначала пробуем получить данные из record.params (они уже подготовлены в backend)
            if (record.params?.editions && Array.isArray(record.params.editions)) {
                console.log('Loading editions from record.params');
                console.log('Raw record.params.editions:', record.params.editions);
                editionsData = record.params.editions
                    .filter(edition => edition && typeof edition === 'object' && edition.id)
                    .map(edition => ({
                        id: edition.id,
                        name: edition.name,
                        position: edition.position || 999,
                        currency_id: edition.display_currency_id || edition.currency_id,
                        currency: edition.currency,
                    }));
            }

            console.log('Processed editions data:', editionsData);

            // Группируем по валютам
            const grouped = {};
            editionsData.forEach(edition => {
                const currencyId = edition.currency_id;
                console.log('Processing edition:', edition.id, 'currency_id:', currencyId, 'type:', typeof currencyId);
                if (!currencyId) {
                    console.warn('Edition without currency:', edition);
                    return;
                }

                if (!grouped[currencyId]) {
                    grouped[currencyId] = [];
                }
                grouped[currencyId].push(edition);
            });

            // Сортируем в каждой группе по позиции
            Object.keys(grouped).forEach(currencyId => {
                grouped[currencyId].sort((a, b) => a.position - b.position);
            });

            console.log('Editions grouped by region:', grouped);
            console.log('Grouped keys:', Object.keys(grouped));
            setEditionsByRegion(grouped);
            console.log('=== loadEditions END ===');
        } catch (error) {
            console.error('=== loadEditions ERROR ===');
            console.error('Error loading editions:', error);
        }
    };



    const handlePositionChange = async (currencyId, editionId, newPosition) => {
        const regionEditions = editionsByRegion[currencyId] || [];
        const newPos = parseInt(newPosition);

        if (isNaN(newPos) || newPos < 1 || newPos > regionEditions.length) {
            alert(`Позиция должна быть от 1 до ${regionEditions.length}`);
            return;
        }

        setIsLoading(true);
        try {
            const currentIndex = regionEditions.findIndex(e => e.id === editionId);
            const newIndex = newPos - 1;

            if (currentIndex === newIndex) {
                setIsLoading(false);
                return;
            }

            const updatedEditions = [...regionEditions];
            const [movedEdition] = updatedEditions.splice(currentIndex, 1);
            updatedEditions.splice(newIndex, 0, movedEdition);

            // Пересчитываем позиции
            const reorderedEditions = updatedEditions.map((edition, index) => ({
                ...edition,
                position: index + 1,
            }));

            // Обновляем состояние для этого региона
            const newByRegion = {
                ...editionsByRegion,
                [currencyId]: reorderedEditions
            };

            setEditionsByRegion(newByRegion);
            await saveEditionsOrder(newByRegion);
        } catch (error) {
            console.error('Error changing position:', error);
            alert('Ошибка при изменении позиции');
        } finally {
            setIsLoading(false);
        }
    };

    const handleMoveUp = async (currencyId, editionId) => {
        const regionEditions = editionsByRegion[currencyId] || [];
        const currentIndex = regionEditions.findIndex(e => e.id === editionId);
        if (currentIndex === 0) return;

        const newPosition = currentIndex;
        await handlePositionChange(currencyId, editionId, newPosition);
    };

    const handleMoveDown = async (currencyId, editionId) => {
        const regionEditions = editionsByRegion[currencyId] || [];
        const currentIndex = regionEditions.findIndex(e => e.id === editionId);
        if (currentIndex === regionEditions.length - 1) return;

        const newPosition = currentIndex + 2;
        await handlePositionChange(currencyId, editionId, newPosition);
    };

    const handleRemoveEdition = async (currencyId, editionId) => {
        if (!confirm('Удалить издание из коллекции?')) return;

        setIsLoading(true);
        try {
            const regionEditions = editionsByRegion[currencyId] || [];
            const updatedEditions = regionEditions
                .filter(e => e.id !== editionId)
                .map((edition, index) => ({
                    ...edition,
                    position: index + 1,
                }));

            const newByRegion = {
                ...editionsByRegion,
                [currencyId]: updatedEditions
            };

            setEditionsByRegion(newByRegion);
            await saveEditionsOrder(newByRegion);
        } catch (error) {
            console.error('Error removing edition:', error);
            alert('Ошибка при удалении издания');
        } finally {
            setIsLoading(false);
        }
    };

    const handleAddEdition = async (currencyId) => {
        const editionId = parseInt(newEditionId);
        console.log('=== handleAddEdition START ===');
        console.log('Input editionId:', newEditionId, 'parsed:', editionId);
        console.log('Target currencyId:', currencyId, 'type:', typeof currencyId);

        if (!editionId || isNaN(editionId)) {
            alert('Введите корректный ID издания');
            return;
        }

        // Проверяем, не добавлено ли уже это издание в этот регион
        const regionEditions = editionsByRegion[currencyId] || [];
        console.log('Current region editions:', regionEditions.length);
        if (regionEditions.find(e => e.id === editionId)) {
            alert('Это издание уже добавлено в этот регион');
            return;
        }

        setIsLoading(true);
        try {
            // Загружаем информацию об издании через прямой запрос к бэкенду
            console.log('Fetching edition data for ID:', editionId);
            const response = await axios.get(`/api/editions/${editionId}`);

            console.log('API Response:', response.data);

            if (!response.data) {
                alert('Издание с таким ID не найдено');
                setIsLoading(false);
                return;
            }

            const edition = response.data;
            console.log('Edition object:', edition);
            console.log('Edition display_currency_id:', edition.display_currency_id, 'type:', typeof edition.display_currency_id);
            console.log('Target currencyId:', currencyId, 'type:', typeof currencyId);

            const editionCurrencyId = edition.display_currency_id;

            console.log('Final editionCurrencyId:', editionCurrencyId, 'type:', typeof editionCurrencyId);
            console.log('Comparison (!=):', editionCurrencyId != currencyId);
            console.log('Comparison (==):', editionCurrencyId == currencyId);
            console.log('Comparison (strict !==):', editionCurrencyId !== currencyId);
            console.log('All currencies:', currencies);

            // Проверяем, что издание имеет нужную валюту
            if (editionCurrencyId && editionCurrencyId != currencyId) {
                const currency = currencies.find(c => c.id == currencyId);
                const editionCurrency = edition.currency || currencies.find(c => c.id == editionCurrencyId);
                console.log('Currency mismatch! Edition currency:', editionCurrency, 'Target currency:', currency);
                alert(`Это издание имеет другую валюту (${editionCurrency?.name || editionCurrencyId})! Нужно издание с валютой ${currency?.name || currencyId}`);
                setIsLoading(false);
                return;
            }

            console.log('Currency check passed!');

            // Формируем имя издания
            let editionName = 'Unknown Edition';
            if (edition.productCard && edition.editionName) {
                const productName = edition.productCard.name || 'Unknown Product';
                const editionTypeName = edition.editionName.name || 'Standard';
                editionName = editionTypeName === 'Standard'
                    ? productName
                    : `${productName} - ${editionTypeName}`;
            } else if (edition.name) {
                editionName = edition.name;
            } else {
                editionName = `Edition ${editionId}`;
            }

            const newEdition = {
                id: editionId,
                name: editionName,
                position: regionEditions.length + 1,
                currency_id: currencyId,
            };

            console.log('Creating new edition object:', newEdition);
            console.log('Adding edition to region:', currencyId, newEdition);

            const updatedEditions = [...regionEditions, newEdition];
            console.log('Updated editions for region:', updatedEditions);

            const newByRegion = {
                ...editionsByRegion,
                [currencyId]: updatedEditions
            };

            console.log('New editionsByRegion state:', newByRegion);

            // Сразу обновляем state
            setEditionsByRegion(newByRegion);
            console.log('State updated');

            // Сохраняем в базу
            console.log('Calling saveEditionsOrder...');
            await saveEditionsOrder(newByRegion);
            console.log('saveEditionsOrder completed');

            setShowAddModal(null);
            setNewEditionId('');
            console.log('=== handleAddEdition SUCCESS ===');
        } catch (error) {
            console.error('=== handleAddEdition ERROR ===');
            console.error('Error adding edition:', error);
            console.error('Error stack:', error.stack);
            alert('Ошибка при добавлении издания. Проверьте ID.');
        } finally {
            setIsLoading(false);
        }
    };

    const saveEditionsOrder = async (byRegion) => {
        console.log('=== saveEditionsOrder START ===');
        console.log('Input byRegion:', byRegion);

        // Собираем все издания из всех регионов в один массив
        const allEditions = [];

        Object.keys(byRegion).forEach(currencyId => {
            console.log('Processing region:', currencyId);
            const regionEditions = byRegion[currencyId] || [];
            console.log('Region editions count:', regionEditions.length);
            regionEditions.forEach(edition => {
                const editionData = {
                    editionId: edition.id,
                    position: edition.position,
                };
                console.log('Adding to allEditions:', editionData);
                allEditions.push(editionData);
            });
        });

        console.log('Final allEditions array:', allEditions);
        console.log('Total editions to save:', allEditions.length);

        // Сохраняем через onChange для обработки в handleEditions
        if (onChange) {
            console.log('Calling onChange with editionsOrder');
            onChange('editionsOrder', JSON.stringify(allEditions));
            console.log('onChange called successfully');
        } else {
            console.warn('onChange is not defined!');
        }
        console.log('=== saveEditionsOrder END ===');
    };

    return (
        <Box>
            <Label>{property.label || 'Издания в коллекции (по регионам)'}</Label>

            {currencies.length === 0 ? (
                <Text mb="default">Загрузка регионов...</Text>
            ) : (
                currencies.map(currency => {
                    const regionEditions = editionsByRegion[currency.id] || [];

                    return (
                        <Box key={currency.id} mb="xl" style={{
                            padding: '16px',
                            border: '2px solid #4a90e2',
                            borderRadius: '8px',
                            backgroundColor: '#f8f9fa'
                        }}>
                            <Text mb="default" style={{
                                fontSize: '18px',
                                fontWeight: 'bold',
                                color: '#4a90e2'
                            }}>
                                📍 Регион: {currency.name} ({currency.code})
                            </Text>

                            {regionEditions.length === 0 ? (
                                <Text mb="sm" style={{ color: '#666' }}>
                                    Нет изданий для этого региона
                                </Text>
                            ) : (
                                <Box mb="default">
                                    {regionEditions.map((edition, index) => (
                                        <Box
                                            key={edition.id}
                                            p="default"
                                            mb="sm"
                                            style={{
                                                border: '1px solid #e0e0e0',
                                                borderRadius: '4px',
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '12px',
                                                backgroundColor: '#fff'
                                            }}
                                        >
                                            <Box style={{ minWidth: '40px', fontWeight: 'bold' }}>
                                                [{index + 1}]
                                            </Box>

                                            <Box style={{ flex: 1 }}>
                                                <Text>{edition.name}</Text>
                                            </Box>

                                            <Box style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                                                <Button
                                                    size="sm"
                                                    onClick={() => handleMoveUp(currency.id, edition.id)}
                                                    disabled={index === 0 || isLoading}
                                                    variant="light"
                                                >
                                                    ↑
                                                </Button>

                                                <Button
                                                    size="sm"
                                                    onClick={() => handleMoveDown(currency.id, edition.id)}
                                                    disabled={index === regionEditions.length - 1 || isLoading}
                                                    variant="light"
                                                >
                                                    ↓
                                                </Button>
                                            </Box>

                                            <Box style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                                                <Input
                                                    type="number"
                                                    min="1"
                                                    max={regionEditions.length}
                                                    defaultValue={index + 1}
                                                    style={{ width: '60px' }}
                                                    onKeyPress={(e) => {
                                                        if (e.key === 'Enter') {
                                                            handlePositionChange(currency.id, edition.id, e.target.value);
                                                        }
                                                    }}
                                                    disabled={isLoading}
                                                    placeholder="Поз."
                                                />

                                                <Button
                                                    size="sm"
                                                    onClick={(e) => {
                                                        const input = e.target.parentElement.querySelector('input');
                                                        handlePositionChange(currency.id, edition.id, input.value);
                                                    }}
                                                    disabled={isLoading}
                                                >
                                                    Применить
                                                </Button>
                                            </Box>

                                            <Button
                                                size="sm"
                                                onClick={() => handleRemoveEdition(currency.id, edition.id)}
                                                disabled={isLoading}
                                                variant="danger"
                                            >
                                                ×
                                            </Button>
                                        </Box>
                                    ))}
                                </Box>
                            )}

                            {showAddModal !== currency.id ? (
                                <Button
                                    onClick={() => {
                                        setShowAddModal(currency.id);
                                        setNewEditionId('');
                                    }}
                                    disabled={isLoading}
                                    size="sm"
                                >
                                    + Добавить издание для {currency.name}
                                </Button>
                            ) : (
                                <Box p="default" style={{ border: '1px solid #e0e0e0', borderRadius: '4px', backgroundColor: '#fff' }}>
                                    <FormGroup>
                                        <Label>Введите ID издания для {currency.name}</Label>
                                        <Input
                                            type="number"
                                            value={newEditionId}
                                            onChange={(e) => setNewEditionId(e.target.value)}
                                            placeholder="Например: 12345"
                                            disabled={isLoading}
                                            onKeyPress={(e) => {
                                                if (e.key === 'Enter') {
                                                    handleAddEdition(currency.id);
                                                }
                                            }}
                                        />
                                        <Text mt="sm" style={{ fontSize: '12px', color: '#666' }}>
                                            Издание должно иметь валюту {currency.name}. Вы можете найти ID издания в разделе "Editions" админки.
                                        </Text>
                                    </FormGroup>

                                    <Box mt="default" style={{ display: 'flex', gap: '8px' }}>
                                        <Button
                                            onClick={() => handleAddEdition(currency.id)}
                                            disabled={isLoading || !newEditionId}
                                            size="sm"
                                        >
                                            Добавить
                                        </Button>
                                        <Button
                                            onClick={() => {
                                                setShowAddModal(null);
                                                setNewEditionId('');
                                            }}
                                            variant="light"
                                            disabled={isLoading}
                                            size="sm"
                                        >
                                            Отмена
                                        </Button>
                                    </Box>
                                </Box>
                            )}
                        </Box>
                    );
                })
            )}
        </Box>
    );
};

export default EditionsOrderManager;
