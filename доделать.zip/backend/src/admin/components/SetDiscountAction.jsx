// backend/src/admin/components/SetDiscountAction.jsx
import { Box, Button, Input, Text } from '@adminjs/design-system';
import { useRecord } from 'adminjs';
import React, { useState } from 'react';

const SetDiscountAction = props => {
	const [discountPercentage, setDiscountPercentage] = useState('');
	const { record, handleActionClick } = useRecord(
		props.resource.id,
		props.action.name
	);

	const handleSubmit = async event => {
		event.preventDefault();
		const response = await handleActionClick({
			data: { discountPercentage: Number(discountPercentage) },
		});
		if (response.data && response.data.notice) {
			// Здесь можно добавить логику для отображения уведомления
			console.log(response.data.notice.message);
		}
	};

	return (
		<Box as='form' onSubmit={handleSubmit}>
			<Text>Введите процент скидки (от 0 до 100):</Text>
			<Input
				type='number'
				value={discountPercentage}
				onChange={e => setDiscountPercentage(e.target.value)}
				min={0}
				max={100}
			/>
			<Button type='submit'>Применить скидку</Button>
		</Box>
	);
};

export default SetDiscountAction;
