import React, { useState, useEffect } from 'react';
import { useNotice } from 'adminjs';
import BulkCollectionModal from './BulkCollectionModal.jsx';

const BulkAddToCollectionAction = (props) => {
	const [showModal, setShowModal] = useState(true);
	const addNotice = useNotice();

	console.log('BulkAddToCollectionAction loaded with props:', props);
	console.log('All props keys:', Object.keys(props));

	// Получаем выбранные записи из props (при bulk action AdminJS передает их автоматически)
	const records = props.records || [];

	console.log('Selected records from props:', records);
	console.log('Records length:', records?.length);

	const handleSuccess = (result) => {
		addNotice({
			message: result.message,
			type: 'success'
		});
		setShowModal(false);
		// Перезагружаем страницу для обновления данных
		window.location.reload();
	};

	const handleClose = () => {
		setShowModal(false);
		// Возвращаемся к списку изданий
		window.history.back();
	};

	const finalRecords = records;

	if (!finalRecords || finalRecords.length === 0) {
		return (
			<div style={{ padding: '20px', textAlign: 'center' }}>
				<h2>Не выбрано ни одного издания</h2>
				<p>Для использования массового добавления в коллекцию необходимо выбрать издания.</p>
				<button
					onClick={handleClose}
					style={{
						backgroundColor: '#6c757d',
						color: 'white',
						border: 'none',
						padding: '10px 20px',
						borderRadius: '6px',
						cursor: 'pointer'
					}}
				>
					Назад к списку
				</button>
			</div>
		);
	}

	return (
		<div>
			{showModal && (
				<BulkCollectionModal
					selectedRecords={finalRecords}
					onClose={handleClose}
					onSuccess={handleSuccess}
				/>
			)}
		</div>
	);
};

export default BulkAddToCollectionAction;
