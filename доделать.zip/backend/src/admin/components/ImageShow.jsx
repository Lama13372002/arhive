import { Box } from '@adminjs/design-system';
import React from 'react';

const ImageShow = props => {
	const { record, property } = props;
	const srcValue = record.params[property.path];

	return (
		<Box>
			<img
				src={srcValue}
				alt={property.label}
				style={{ maxWidth: '100%' }}
			/>
		</Box>
	);
};

export default ImageShow;
