import { Box, DropZone, Label } from '@adminjs/design-system';
import React, { useState } from 'react';

const ImageUpload = props => {
	const { property, onChange, record } = props;
	const [file, setFile] = useState(null);
	const [preview, setPreview] = useState(
		record?.params[property.path] || null
	);

	const handleDropZoneChange = files => {
		const file = files[0];
		if (!file) return;

		console.log('Selected file:', {
			name: file.name,
			type: file.type,
			size: file.size,
		});

		setFile(file);

		const reader = new FileReader();
		reader.onloadend = () => {
			const result = reader.result;
			console.log('File read complete:', {
				resultLength: result.length,
				hasBase64Data: result.includes('base64'),
			});
			
			setPreview(result);
			onChange(property.path, {
				name: file.name,
				size: file.size,
				mime: file.type || 'image/png',
				file: result,
			});
		};
		reader.onerror = (error) => {
			console.error('Error reading file:', error);
		};
		reader.readAsDataURL(file);
	};

	return (
		<Box variant='filter'>
			<Label>{property.label}</Label>
			<DropZone
				onChange={handleDropZoneChange}
				validate={{
					mimeTypes: [
						'image/*',
						'image/svg+xml',
						'image/jpeg',
						'image/png',
						'image/gif',
						'image/bmp',
						'image/webp',
						'image/avif',
					],
				}}
			/>
			{preview && (
				<Box mt='default'>
					<img
						src={preview}
						alt='Preview'
						style={{ maxWidth: '200px', maxHeight: '200px' }}
					/>
				</Box>
			)}
		</Box>
	);
};

export default ImageUpload;
