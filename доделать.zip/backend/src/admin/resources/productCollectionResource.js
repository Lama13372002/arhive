import sequelize from '../../config/database.js';
import Edition from '../../models/edition.js';
import ProductCollection from '../../models/productCollection.js';
import ProductCollectionEdition from '../../models/productCollectionEdition.js';
import ImageShow from '../components/ImageShow.jsx';
import { Components } from '../componentLoader.js';
import { beforeCreateHook, beforeUpdateHook } from '../hooks.js';

const debugLog = (message, data) => {
    console.log(`[ProductCollection Resource] ${message}`, data || '');
};

const handleEditions = async (response, request, context) => {
    try {
        const { record } = context;

        debugLog('HandleEditions started');
        debugLog('Record params:', record.params);

        // Проверяем наличие данных о порядке изданий
        const editionsOrderData = record.params.editionsOrder;

        if (editionsOrderData) {
            // Обработка данных о порядке из компонента EditionsOrderManager
            debugLog('Processing editions order data:', editionsOrderData);

            const collection = record.params.id
                ? await ProductCollection.findByPk(record.params.id)
                : response.record.resource;

            if (!collection) {
                throw new Error(`Collection not found`);
            }

            const editionsOrder = JSON.parse(editionsOrderData);

            await sequelize.transaction(async t => {
                // Удаляем все существующие связи
                await ProductCollectionEdition.destroy({
                    where: { product_collection_id: collection.id },
                    transaction: t
                });

                // Создаем новые связи с позициями
                for (const item of editionsOrder) {
                    // Пропускаем элементы без editionId
                    if (!item.editionId) {
                        debugLog('Skipping item without editionId:', item);
                        continue;
                    }

                    await ProductCollectionEdition.create({
                        product_collection_id: collection.id,
                        edition_id: item.editionId,
                        position: item.position
                    }, { transaction: t });
                }
            });

            debugLog('Editions order saved successfully');
            return response;
        }

        // Старая логика для обратной совместимости
        const editions = Object.entries(record.params)
            .filter(([key]) => key.startsWith('editions.'))
            .map(([_, value]) => parseInt(value))
            .filter(id => !isNaN(id));

        if (!editions.length) {
            debugLog('No editions provided, returning early');
            return response;
        }

        const collection = record.params.id
            ? await ProductCollection.findByPk(record.params.id)
            : response.record.resource;

        if (!collection) {
            debugLog('Collection not found:', record.params.id);
            throw new Error(`Collection not found`);
        }

        debugLog('Processed edition IDs:', editions);

        await sequelize.transaction(async t => {
            debugLog('Starting transaction to set editions');

            // Удаляем старые связи
            await ProductCollectionEdition.destroy({
                where: { product_collection_id: collection.id },
                transaction: t
            });

            // Создаем новые связи с автоматическими позициями
            for (let i = 0; i < editions.length; i++) {
                // Пропускаем невалидные ID
                if (!editions[i] || isNaN(editions[i])) {
                    debugLog('Skipping invalid edition ID:', editions[i]);
                    continue;
                }

                await ProductCollectionEdition.create({
                    product_collection_id: collection.id,
                    edition_id: editions[i],
                    position: i + 1
                }, { transaction: t });
            }

            debugLog('Editions set successfully');
        });

        const updatedCollection = await ProductCollection.findByPk(
            collection.id,
            {
                include: [
                    {
                        model: Edition,
                        as: 'editions',
                        through: { attributes: ['position'] },
                    },
                ],
            }
        );

        response.record.params.editions = updatedCollection.editions;

        debugLog(
            'Updated collection editions:',
            updatedCollection.editions.map(e => e.id)
        );

        return response;
    } catch (error) {
        debugLog('Error in handleEditions:', error);
        console.error('Error in handleEditions:', error);
        throw error;
    }
};

export const productCollectionResource = {
    resource: ProductCollection,
    options: {
        navigation: {
            name: 'Коллекции',
            icon: 'Catalog',
        },
        properties: {
            id: {
                position: 1,
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: false,
                },
            },
            name: {
                position: 2,
                isTitle: true,
                isRequired: true,
            },
            description: {
                position: 3,
                type: 'textarea',
            },
            editions: {
                position: 4,
                type: 'mixed',
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: true,
                },
                description: 'Издания в коллекции',
                components: {
                    edit: Components.EditionsOrderManager,
                },
            },
            editionsOrder: {
                type: 'string',
                isVisible: false,
            },
            image_url: {
                position: 5,
                components: {
                    show: ImageShow,
                },
            },
            is_active: {
                position: 6,
                type: 'boolean',
            },
            created_at: {
                position: 7,
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: false,
                },
            },
            updated_at: {
                position: 8,
                isVisible: {
                    list: false,
                    filter: false,
                    show: true,
                    edit: false,
                },
            },
        },
        actions: {
            new: {
                before: [beforeCreateHook],
                after: handleEditions,
            },
            edit: {
                before: async (request, context) => {
                    try {
                        if (request.method === 'get') {
                            const collectionId = context.record.params.id;

                            // Импортируем необходимые модели
                            const { EditionName, ProductCard, Currency } = await import('../../models/index.js');

                            const collection = await ProductCollection.findByPk(
                                collectionId,
                                {
                                    include: [
                                        {
                                            model: Edition,
                                            as: 'editions',
                                            through: {
                                                attributes: ['position'],
                                            },
                                            include: [
                                                {
                                                    model: EditionName,
                                                    as: 'editionName',
                                                    attributes: ['id', 'name'],
                                                },
                                                {
                                                    model: ProductCard,
                                                    as: 'productCard',
                                                    attributes: ['id', 'name'],
                                                },
                                                {
                                                    model: Currency,
                                                    as: 'currency',
                                                    attributes: ['id', 'code', 'name'],
                                                }
                                            ],
                                        },
                                    ],
                                }
                            );

                            if (collection && collection.editions) {
                                // СНАЧАЛА сортируем по позиции
                                const sortedEditions = collection.editions.sort((a, b) => {
                                    const posA = a.ProductCollectionEdition?.position || 999999;
                                    const posB = b.ProductCollectionEdition?.position || 999999;
                                    return posA - posB;
                                });

                                debugLog('Raw edition sample:', {
                                    id: sortedEditions[0]?.id,
                                    display_currency_id: sortedEditions[0]?.display_currency_id,
                                    currency: sortedEditions[0]?.currency,
                                    allKeys: sortedEditions[0] ? Object.keys(sortedEditions[0]) : []
                                });

                                // Формируем полное имя издания
                                context.record.params.editions = sortedEditions.map(edition => {
                                    const productName = edition.productCard?.name || 'Unknown Product';
                                    const editionName = edition.editionName?.name || 'Standard';
                                    const fullName = editionName === 'Standard' ? productName : `${productName} - ${editionName}`;

                                    const result = {
                                        id: edition.id,
                                        name: fullName,
                                        position: edition.ProductCollectionEdition?.position,
                                        display_currency_id: edition.display_currency_id,
                                        currency_id: edition.display_currency_id,
                                        currency: edition.currency,
                                        ProductCollectionEdition: edition.ProductCollectionEdition,
                                    };

                                    if (edition.id === sortedEditions[0].id) {
                                        debugLog('First processed edition:', result);
                                    }

                                    return result;
                                });

                                debugLog(
                                    'Loaded editions with positions:',
                                    context.record.params.editions.map(e => ({
                                        id: e.id,
                                        name: e.name,
                                        position: e.position
                                    }))
                                );
                            }
                        }
                        return beforeUpdateHook(request, context);
                    } catch (error) {
                        console.error('Error in edit.before hook:', error);
                        throw error;
                    }
                },
                after: handleEditions,
            },
            list: {
                before: async (request, context) => {
                    context.query = {
                        ...context.query,
                        include: ['editions'],
                    };
                    return request;
                },
                after: async (response, request, context) => {
                    return response;
                },
            },
            show: {
                before: async (request, context) => {
                    context.query = {
                        ...context.query,
                        include: ['editions'],
                    };
                    return request;
                },
                after: async (response, request, context) => {
                    return response;
                },
            },
        },
        listProperties: ['id', 'name', 'image_url', 'is_active', 'created_at'],
        filterProperties: ['name', 'is_active', 'editions', 'created_at'],
        editProperties: [
            'name',
            'description',
            'editions',
            'image_url',
            'is_active',
        ],
        showProperties: [
            'id',
            'name',
            'description',
            'editions',
            'image_url',
            'is_active',
            'created_at',
            'updated_at',
        ],
    },
};
