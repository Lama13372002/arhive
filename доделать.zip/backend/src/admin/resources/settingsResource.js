import Settings from '../../models/settings.js';
import { beforeUpdateHook } from '../hooks.js';

export const settingsResource = {
    resource: Settings,
    options: {
        navigation: {
            name: 'Сообщения бота',
            icon: 'Settings',
        },
        properties: {
            welcomeMessage: {
                type: 'richtext',
                label: 'Приветственное сообщение',
                isRequired: true,
                isVisible: {
                    list: false,
                    filter: false,
                    show: true,
                    edit: true,
                },
            },
            maintenanceMode: {
                type: 'boolean',
                label: 'Режим технических работ',
                isRequired: true,
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: true,
                },
            },
            maintenanceMessage: {
                type: 'richtext',
                label: 'Сообщение при техработах',
                isRequired: true,
                isVisible: {
                    list: false,
                    filter: false,
                    show: true,
                    edit: true,
                },
            },
            globalPriceLock: {
                type: 'boolean',
                label: '🔒 Глобальная фиксация цен',
                isRequired: true,
                isVisible: {
                    list: true,
                    filter: true,
                    show: true,
                    edit: true,
                },
                description: 'Если включено - парсер НЕ СМОЖЕТ изменить цены ВСЕХ товаров. Промокоды продолжают работать.',
            },
        },
        actions: {
            new: { isAccessible: true },
            delete: { isAccessible: false },
            edit: { before: beforeUpdateHook },
        },
    },
};
