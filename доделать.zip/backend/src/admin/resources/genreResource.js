import Genre from '../../models/genre.js';

export const genreResource = {
  resource: Genre,
  options: {
    navigation: {
      name: 'Жанры',
      icon: 'Folder',
    },
    properties: {
      id: {
        position: 1,
      },
      name: {
        position: 2,
        isTitle: true,
      },
      createdAt: {
        position: 3,
        isVisible: { list: true, filter: true, show: true, edit: false },
      },
      updatedAt: {
        position: 4,
        isVisible: { list: true, filter: true, show: true, edit: false },
      },
    },
  },
};
