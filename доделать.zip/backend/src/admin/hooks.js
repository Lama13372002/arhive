export const beforeCreateHook = async (request, context) => {
    console.log('Create request payload:', request.payload);
    request.payload = {
        ...request.payload,
        createdBy: context.currentAdmin.id,
        createdAt: new Date(),
    };
    return request;
};

export const beforeUpdateHook = async (request, context) => {
    console.log('Update request payload:', request.payload);
    request.payload = {
        ...request.payload,
        updatedAt: new Date(),
    };
    return request;
};
