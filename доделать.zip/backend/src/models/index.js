import fs from 'fs';
import path from 'path';
import Sequelize from 'sequelize';
import { fileURLToPath } from 'url';
import config from '../config/config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const basename = path.basename(__filename);
const db = {};

// Инициализация Sequelize с расширенным логированием
console.log('Starting database initialization with config:', {
    database: config.database,
    host: config.host,
    port: config.port,
    dialect: config.dialect,
});

let sequelize;
try {
    if (config.use_env_variable) {
        sequelize = new Sequelize(process.env[config.use_env_variable], config);
    } else {
        sequelize = new Sequelize(
            config.database,
            config.username,
            config.password,
            {
                ...config,
                logging: msg => {
                    console.log('Sequelize Log:', msg);
                    if (msg.includes('Error:')) {
                        console.error('Sequelize Error:', msg);
                    }
                },
            }
        );
    }
    console.log('Sequelize instance created successfully');
} catch (error) {
    console.error('Failed to create Sequelize instance:', error);
    throw error;
}

// Тестирование соединения
try {
    await sequelize.authenticate();
    console.log('Database connection has been established successfully.');
} catch (error) {
    console.error('Unable to connect to the database:', error);
    throw error;
}

// Определение порядка инициализации моделей
const modelOrder = [
    // 1. Базовые модели без зависимостей
    'platform.js',
    'genre.js',
    'localization.js',
    'currency.js',
    'currencyRange.js',
    'editionName.js',
    'settings.js',
    'promo.js',
    'usedPromo.js',

    // 2. Базовые модели для продуктов
    'productCard.js',
    'productCollection.js',

    // 3. Связующие модели
    'edition.js',
    'productCollectionCard.js',
    'productCardGenre.js',
    'productCardPlatform.js',
    'feedItem.js',
    'collectionShowcaseEdition.js',

    // 4. Дополнительные модели
    'mailing.js',
    'user.js',
    'userRegionData.js',
    'payment.js',
];

// Поиск файлов моделей с логированием
const modelFiles = fs.readdirSync(__dirname).filter(file => {
    const isValid =
        file.indexOf('.') !== 0 &&
        file !== basename &&
        file.slice(-3) === '.js' &&
        file.indexOf('.test.js') === -1;

    if (isValid) {
        console.log(`Found valid model file: ${file}`);
    }
    return isValid;
});

// Добавление остальных моделей в конец списка
const otherModels = modelFiles.filter(file => !modelOrder.includes(file));
const orderedModelFiles = [...modelOrder, ...otherModels];

console.log('Model initialization order:', orderedModelFiles);

// Функция для синхронизации одной модели с подробным логированием
async function syncModel(model) {
    try {
        console.log(`Syncing model ${model.name}...`);
        // Отключаем автоматическое изменение структуры таблиц
        await model.sync({ force: false, alter: false });
        console.log(`Model ${model.name} synced successfully`);
    } catch (error) {
        console.error(`Error syncing model ${model.name}:`, error);
        throw error;
    }
}

// Импорт и регистрация моделей
console.log('Starting model registration process...');
for (const file of orderedModelFiles) {
    const modelPath = path.join(__dirname, file);

    if (!fs.existsSync(modelPath)) {
        console.log(`Skipping non-existent file: ${file}`);
        continue;
    }

    try {
        console.log(`Importing model from file: ${file}`);
        const modelModule = await import(modelPath);
        const model = modelModule.default;

        if (model) {
            if (typeof model === 'function') {
                if (model.prototype instanceof Sequelize.Model) {
                    db[model.name] = model;
                    console.log(
                        `Successfully registered class-based model: ${model.name}`
                    );
                } else {
                    const modelInstance = model(sequelize);
                    db[modelInstance.name] = modelInstance;
                    console.log(
                        `Successfully registered define-based model: ${modelInstance.name}`
                    );
                }
            } else {
                console.warn(
                    `Model in file ${file} is not recognized as a valid Sequelize model`
                );
            }
        } else {
            console.warn(`No default export found in model file: ${file}`);
        }
    } catch (error) {
        console.error(`Error importing model from file ${file}:`, error);
    }
}

// Установка ассоциаций между моделями
console.log('Setting up model associations...');
Object.keys(db).forEach(modelName => {
    if (db[modelName].associate) {
        console.log(`Setting up associations for model: ${modelName}`);
        try {
            db[modelName].associate(db);
            console.log(
                `Successfully set up associations for model: ${modelName}`
            );
        } catch (error) {
            console.error(
                `Error setting up associations for model ${modelName}:`,
                error
            );
        }
    } else {
        console.log(`No associations to set up for model: ${modelName}`);
    }
});

const syncOrder = [
    'Platform',
    'Genre',
    'Localization',
    'Currency',
    'CurrencyRange',
    'EditionName',
    'Settings',
    'Promo',
    'UsedPromo',
    'ProductCard',
    'ProductCollection',
    'ProductCollectionCard',
    'ProductCardGenre',
    'Edition',
    'CollectionShowcaseEdition',
    'FeedItem',
    'Mailing',
    'User',
    'UserRegionData',
    'Payment',
];

// Функция для синхронизации всех моделей
db.syncModels = async () => {
    console.log('Starting model synchronization process...');
    try {
        for (const modelName of syncOrder) {
            if (db[modelName]) {
                await syncModel(db[modelName]);
            } else {
                console.warn(
                    `Model ${modelName} not found for synchronization`
                );
            }
        }
        console.log('Model synchronization completed successfully');
    } catch (error) {
        console.error('Error during model synchronization:', error);
        throw error;
    }
};

// Добавление sequelize в объект db
db.sequelize = sequelize;
db.Sequelize = Sequelize;

// Вывод списка зарегистрированных моделей
console.log('Successfully registered models:', Object.keys(db));

export default db;
export const sequelizeInstance = sequelize;
export const Settings = db.Settings;
export const Promo = db.Promo;
export const UsedPromo = db.UsedPromo;
export const Currency = db.Currency;
export const CurrencyRange = db.CurrencyRange;
export const Edition = db.Edition;
export const EditionName = db.EditionName;
export const FeedItem = db.FeedItem;
export const Genre = db.Genre;
export const Localization = db.Localization;
export const Mailing = db.Mailing;
export const Platform = db.Platform;
export const ProductCard = db.ProductCard;
export const ProductCollection = db.ProductCollection;
export const ProductCollectionCard = db.ProductCollectionCard;
export const CollectionShowcaseEdition = db.CollectionShowcaseEdition;
export const User = db.User;
export const UserRegionData = db.UserRegionData;
export const Payment = db.Payment;


