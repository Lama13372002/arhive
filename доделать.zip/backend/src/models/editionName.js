import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

export default class EditionName extends Model {
	static init(sequelize) {
		super.init(
			{
				id: {
					type: DataTypes.INTEGER,
					primaryKey: true,
					autoIncrement: true,
				},
				name: {
					type: DataTypes.STRING,
					allowNull: false,
					unique: true,
				},
			},
			{
				sequelize,
				modelName: 'EditionName',
				tableName: 'EditionNames',
				underscored: true,
			}
		);
		return this;
	}

	static associate(models) {
		EditionName.hasMany(models.Edition, {
			foreignKey: 'edition_name_id',
			as: 'editions',
			sourceKey: 'id',
		});
	}
}

EditionName.init(sequelize);
