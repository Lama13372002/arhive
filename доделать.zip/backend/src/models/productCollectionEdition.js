import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

class ProductCollectionEdition extends Model {
    static associate(models) {
        ProductCollectionEdition.belongsTo(models.ProductCollection, {
            foreignKey: 'product_collection_id',
            as: 'collection',
        });

        ProductCollectionEdition.belongsTo(models.Edition, {
            foreignKey: 'edition_id',
            as: 'edition',
        });
    }
}

ProductCollectionEdition.init(
    {
        product_collection_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            references: {
                model: 'ProductCollections',
                key: 'id',
            },
            onDelete: 'CASCADE',
        },
        edition_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            references: {
                model: 'Editions',
                key: 'id',
            },
            onDelete: 'CASCADE',
        },
        position: {
            type: DataTypes.INTEGER,
            allowNull: true,
            defaultValue: null,
            comment: 'Позиция издания в коллекции (порядковый номер)',
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
            defaultValue: DataTypes.NOW,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
            defaultValue: DataTypes.NOW,
        },
    },
    {
        sequelize,
        modelName: 'ProductCollectionEdition',
        tableName: 'ProductCollectionEditions',
        timestamps: true,
        underscored: true,
    }
);

export default ProductCollectionEdition;
