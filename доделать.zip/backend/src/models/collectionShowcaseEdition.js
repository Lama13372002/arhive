import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

class CollectionShowcaseEdition extends Model {
	static associate(models) {
		// Связь с коллекцией
		CollectionShowcaseEdition.belongsTo(models.ProductCollection, {
			foreignKey: 'collection_id',
			as: 'collection',
		});

		// Связь с изданием
		CollectionShowcaseEdition.belongsTo(models.Edition, {
			foreignKey: 'edition_id',
			as: 'edition',
		});

		// Связь с валютой (регионом)
		CollectionShowcaseEdition.belongsTo(models.Currency, {
			foreignKey: 'currency_id',
			as: 'currency',
		});
	}
}

CollectionShowcaseEdition.init(
	{
		id: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
		},
		collection_id: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'ProductCollections',
				key: 'id',
			},
		},
		edition_id: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'Editions',
				key: 'id',
			},
		},
		currency_id: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: 'Currencies',
				key: 'id',
			},
		},
		position: {
			type: DataTypes.INTEGER,
			allowNull: false,
			validate: {
				min: 1,
				max: 3,
			},
		},
	},
	{
		sequelize,
		modelName: 'CollectionShowcaseEdition',
		tableName: 'CollectionShowcaseEditions',
		underscored: true,
	}
);

export default CollectionShowcaseEdition;
