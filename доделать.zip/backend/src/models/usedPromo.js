import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database.js';

export default class UsedPromo extends Model {
	static init(sequelize) {
		super.init(
			{
				id: {
					type: DataTypes.INTEGER,
					primaryKey: true,
					autoIncrement: true,
				},
				userId: {
					type: DataTypes.STRING, // Меняем тип на STRING для Telegram ID
					allowNull: false,
				},
				promoId: {
					type: DataTypes.INTEGER,
					allowNull: false,
					references: {
						model: 'Promos',
						key: 'id',
					},
				},
				currencyId: {
					type: DataTypes.INTEGER,
					allowNull: false,
					references: {
						model: 'Currencies',
						key: 'id',
					},
					defaultValue: 1,
				},
				usedAt: {
					type: DataTypes.DATE,
					defaultValue: DataTypes.NOW,
				},
			},
			{
				sequelize,
				modelName: 'UsedPromo',
				indexes: [
					{
						unique: true,
						fields: ['userId', 'promoId', 'currencyId'],
					},
				],
			}
		);
	}
}

UsedPromo.init(sequelize);


