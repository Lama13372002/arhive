import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

export default class Currency extends Model {
    static init(sequelize) {
        super.init(
            {
                id: {
                    type: DataTypes.INTEGER,
                    primaryKey: true,
                    autoIncrement: true,
                },
                code: {
                    type: DataTypes.STRING,
                    allowNull: false,
                    unique: true,
                },
                name: {
                    type: DataTypes.STRING,
                    allowNull: false,
                },
                symbol: {
                    type: DataTypes.STRING,
                    allowNull: false,
                },
                exchange_rate: {
                    type: DataTypes.DECIMAL(10, 4),
                    allowNull: false,
                    defaultValue: 1.0,
                    comment: 'Exchange rate relative to RUB'
                },
                is_default: {
                    type: DataTypes.BOOLEAN,
                    allowNull: false,
                    defaultValue: false
                },
                icon: {
                    type: DataTypes.STRING,
                    allowNull: true,
                    comment: 'URL or path to currency icon'
                }
            },
            {
                sequelize,
                modelName: 'Currency',
                tableName: 'Currencies',
                underscored: true,
                timestamps: false
            }
        );
        return this;
    }

    static associate(models) {
        Currency.hasMany(models.Edition, {
            foreignKey: 'display_currency_id',
            as: 'editions'
        });
    }
}

Currency.init(sequelize);
