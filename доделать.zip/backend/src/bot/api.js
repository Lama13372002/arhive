import dotenv from 'dotenv';
import TelegramBot from 'node-telegram-bot-api';

dotenv.config();

const token = process.env.BOT_TOKEN;
const isDevelopment = process.env.NODE_ENV === 'development';

if (!token && !isDevelopment) {
	throw new Error('BOT_TOKEN is not defined in environment variables');
}

// Создаем экземпляр бота или заглушку для разработки
const bot = token
	? new TelegramBot(token, { polling: false })
	: {
			sendMessage: async (chatId, text, options = {}) => {
				console.log(
					'Development mode: Would send message to',
					chatId,
					':',
					text,
					options
				);
				return Promise.resolve({ ok: true });
			},
			sendPhoto: async (chatId, photo, options = {}) => {
				console.log(
					'Development mode: Would send photo to',
					chatId,
					':',
					photo,
					options
				);
				return Promise.resolve({ ok: true });
			},
	  };

// Экспортируем API для отправки сообщений
export const botApi = {
	sendMessage: async (chatId, text, options = {}) => {
		try {
			return await bot.sendMessage(chatId, text, options);
		} catch (error) {
			console.error('Error sending message:', error);
			throw error;
		}
	},

	sendPhoto: async (chatId, photo, options = {}) => {
		try {
			return await bot.sendPhoto(chatId, photo, options);
		} catch (error) {
			console.error('Error sending photo:', error);
			throw error;
		}
	},
};
