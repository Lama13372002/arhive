'use strict';

const dotenv = require('dotenv');
const path = require('path');

// Загружаем .env файл из корневой директории проекта
dotenv.config({ path: path.resolve(__dirname, '../../../.env.development') });

// Выводим конфигурацию для отладки
console.log('Database Configuration:', {
	username: process.env.DB_USER,
	database: process.env.DB_NAME,
	host: process.env.DB_HOST,
	port: process.env.DB_PORT,
});

module.exports = {
	development: {
		username: process.env.DB_USER || 'nkarasyov',
		password: process.env.DB_PASSWORD || 'pAssW_ord123',
		database: process.env.DB_NAME || 'game_shop_db',
		host: process.env.DB_HOST || 'localhost',
		port: process.env.DB_PORT || '5432',
		dialect: 'postgres',
		logging: console.log,
		pool: {
			max: 5,
			min: 0,
			acquire: 30000,
			idle: 10000,
		},
	},
	test: {
		username: process.env.DB_USER,
		password: process.env.DB_PASSWORD,
		database: process.env.DB_NAME,
		host: process.env.DB_HOST,
		port: process.env.DB_PORT,
		dialect: 'postgres',
		logging: console.log,
	},
	production: {
		username: process.env.DB_USER,
		password: process.env.DB_PASSWORD,
		database: process.env.DB_NAME,
		host: process.env.DB_HOST,
		port: process.env.DB_PORT,
		dialect: 'postgres',
		logging: console.log,
	},
};
