import dotenv from 'dotenv';

// Загрузка переменных окружения из файла .env
dotenv.config();

const config = {
	development: {
		username: process.env.DB_USER || 'nkarasyov',
		password: process.env.DB_PASSWORD || 'pAssW_ord123',
		database: process.env.DB_NAME || 'game_shop_db',
		host: process.env.DB_HOST || 'localhost',
		port: process.env.DB_PORT || '5432',
		dialect: 'postgres',
		pool: {
			max: 5,
			min: 0,
			acquire: 30000,
			idle: 10000,
		},
		logging: msg => {
			console.log('Sequelize Log:', msg);
			if (msg.includes('Error:')) {
				console.error('Sequelize Error:', msg);
			}
		},
	},
	test: {
		username: process.env.DB_USER,
		password: process.env.DB_PASSWORD,
		database: process.env.DB_NAME,
		host: process.env.DB_HOST,
		port: process.env.DB_PORT,
		dialect: 'postgres',
		logging: false,
	},
	production: {
		username: process.env.DB_USER,
		password: process.env.DB_PASSWORD,
		database: process.env.DB_NAME,
		host: process.env.DB_HOST,
		port: process.env.DB_PORT,
		dialect: 'postgres',
		logging: false,
	},
};

export default config[process.env.NODE_ENV || 'development'];
