import User from '../models/user.js';
import UserRegionData from '../models/userRegionData.js';

export const getUserByTelegramId = async (telegramId) => {
  try {
    console.log('Searching for user with telegramId:', telegramId);
    const user = await User.findOne({
      where: { telegramId }
    });
    console.log('Found user:', user);
    return user;
  } catch (error) {
    console.error('Error in getUserByTelegramId:', error);
    throw error;
  }
};

export const updateUser = async (telegramId, updateData) => {
  try {
    console.log('Updating user with telegramId:', telegramId);
    console.log('Update data:', updateData);

    const [count, updatedUsers] = await User.update(updateData, {
      where: { telegramId },
      returning: true
    });

    if (count === 0) {
      console.log('No user found to update');
      return null;
    }

    // Получаем обновленного пользователя
    const updatedUser = await User.findOne({
      where: { telegramId }
    });

    console.log('Updated user:', updatedUser);
    return updatedUser;
  } catch (error) {
    console.error('Error in updateUser:', error);
    throw error;
  }
};

export const createUser = async (userData) => {
  try {
    console.log('Creating new user:', userData);
    const user = await User.create(userData);
    console.log('Created user:', user);
    return user;
  } catch (error) {
    console.error('Error in createUser:', error);
    throw error;
  }
};

export const getUserRegionData = async (telegramId, currencyId) => {
  try {
    console.log('Getting region data for:', { telegramId, currencyId });

    // Сначала находим пользователя
    const user = await User.findOne({
      where: { telegramId }
    });

    if (!user) {
      throw new Error('User not found');
    }

    // Ищем данные региона
    const regionData = await UserRegionData.findOne({
      where: {
        userId: user.id,
        currencyId: currencyId
      }
    });

    console.log('Found region data:', regionData);
    return regionData;
  } catch (error) {
    console.error('Error in getUserRegionData:', error);
    throw error;
  }
};

export const updateUserRegionData = async (telegramId, currencyId, updateData) => {
  try {
    console.log('Updating region data for:', { telegramId, currencyId, updateData });

    // Сначала находим пользователя
    const user = await User.findOne({
      where: { telegramId }
    });

    if (!user) {
      throw new Error('User not found');
    }

    // Преобразуем пустые строки в null для полей, которые могут быть null
    const cleanedData = { ...updateData };
    if (cleanedData.email !== undefined && (!cleanedData.email || cleanedData.email.trim() === '')) {
      cleanedData.email = null;
    }
    if (cleanedData.psStoreLogin !== undefined && (!cleanedData.psStoreLogin || cleanedData.psStoreLogin.trim() === '')) {
      cleanedData.psStoreLogin = null;
    }
    if (cleanedData.psStorePassword !== undefined && (!cleanedData.psStorePassword || cleanedData.psStorePassword.trim() === '')) {
      cleanedData.psStorePassword = null;
    }
    if (cleanedData.psBackupCodes !== undefined && (!cleanedData.psBackupCodes || cleanedData.psBackupCodes.trim() === '')) {
      cleanedData.psBackupCodes = null;
    }

    // Пытаемся найти существующие данные региона
    let regionData = await UserRegionData.findOne({
      where: {
        userId: user.id,
        currencyId: currencyId
      }
    });

    if (regionData) {
      // Обновляем существующие данные
      await regionData.update(cleanedData);
      console.log('Updated region data:', regionData);
    } else {
      // Создаем новые данные региона
      regionData = await UserRegionData.create({
        userId: user.id,
        currencyId: currencyId,
        ...cleanedData
      });
      console.log('Created region data:', regionData);
    }

    return regionData;
  } catch (error) {
    console.error('Error in updateUserRegionData:', error);
    throw error;
  }
};
