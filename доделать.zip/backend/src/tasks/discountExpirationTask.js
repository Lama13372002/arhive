import { scheduleJob } from 'node-schedule';
import { Op } from 'sequelize';
import Edition from '../models/edition.js';

/**
 * Задача для проверки и удаления истекших скидок
 * Запускается каждый день в 00:05
 */
export const setupDiscountExpirationJob = () => {
	// Запускаем задачу каждый день в 00:05
	scheduleJob('5 0 * * *', async () => {
		try {
			console.log('Запуск задачи проверки истекших скидок:', new Date());

			// Находим все издания с истекшими акциями
			const currentDate = new Date();
			const expiredEditions = await Edition.findAll({
				where: {
					discount_amount: { [Op.ne]: null, [Op.gt]: 0 },
					promotion_end_date: { [Op.lt]: currentDate },
				},
			});

			if (expiredEditions.length === 0) {
				console.log('Истекших акций не найдено');
				return;
			}

			console.log(
				`Найдено ${expiredEditions.length} изданий с истекшими акциями`
			);

			// Обновляем каждое издание, удаляя скидку
			for (const edition of expiredEditions) {
				const originalPrice = edition.price;
				const discountAmount = edition.discount_amount;

				// Сбрасываем скидку
				edition.discount_amount = null;
				await edition.save();

				console.log(`Удалена скидка для издания ID ${edition.id}:`, {
					originalPrice,
					removedDiscountPrice: discountAmount,
					promotionEndDate: edition.promotion_end_date,
				});
			}

			console.log(
				`Успешно обработано ${expiredEditions.length} изданий с истекшими акциями`
			);
		} catch (error) {
			console.error('Ошибка при обработке истекших скидок:', error);
		}
	});

	console.log('Задача проверки истекших скидок настроена');
};

// Запускаем задачу при импорте модуля
setupDiscountExpirationJob();
