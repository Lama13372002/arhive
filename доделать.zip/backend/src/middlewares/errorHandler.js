// backend/src/middlewares/errorHandler.js
import { ValidationError } from 'sequelize';

const errorHandler = (err, req, res, next) => {
	console.error(err.stack);

	// Обработка ошибок валидации Sequelize
	if (err instanceof ValidationError) {
		return res.status(400).json({
			status: 'error',
			message: 'Validation error',
			errors: err.errors.map(e => ({
				field: e.path,
				message: e.message,
			})),
		});
	}

	// Обработка пользовательских ошибок
	if (err.name === 'CustomError') {
		return res.status(err.statusCode || 400).json({
			status: 'error',
			message: err.message,
		});
	}

	// Обработка ошибок авторизации
	if (err.name === 'UnauthorizedError') {
		return res.status(401).json({
			status: 'error',
			message: 'Unauthorized access',
		});
	}

	// Общий обработчик ошибок
	res.status(err.statusCode || 500).json({
		status: 'error',
		message: err.message || 'Internal server error',
	});
};

export default errorHandler;
