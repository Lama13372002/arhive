import { Router } from 'express';
import db from '../models/index.js';

const router = Router();

// GET / - Получить все жанры
router.get('/', async (req, res) => {
    try {
        const genres = await db.Genre.findAll({
            order: [['name', 'ASC']], // Сортировка по имени
        });
        res.json(genres);
    } catch (error) {
        console.error('Error fetching genres:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// GET /:id - Получить жанр по ID с играми
router.get('/:id', async (req, res) => {
    try {
        const genre = await db.Genre.findByPk(req.params.id, {
            include: [
                {
                    model: db.ProductCard,
                    through: { attributes: [] }, // Исключаем атрибуты связующей таблицы
                }
            ]
        });

        if (!genre) {
            return res.status(404).json({ error: 'Genre not found' });
        }

        res.json(genre);
    } catch (error) {
        console.error('Error fetching genre:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// POST / - Создать новый жанр
router.post('/', async (req, res) => {
    try {
        const { name } = req.body;
        
        if (!name) {
            return res.status(400).json({ error: 'Name is required' });
        }

        const genre = await db.Genre.create({ name });
        res.status(201).json(genre);
    } catch (error) {
        if (error.name === 'SequelizeUniqueConstraintError') {
            return res.status(400).json({ error: 'Genre with this name already exists' });
        }
        console.error('Error creating genre:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// PUT /:id - Обновить жанр
router.put('/:id', async (req, res) => {
    try {
        const { name } = req.body;
        const genre = await db.Genre.findByPk(req.params.id);

        if (!genre) {
            return res.status(404).json({ error: 'Genre not found' });
        }

        if (!name) {
            return res.status(400).json({ error: 'Name is required' });
        }

        await genre.update({ name });
        res.json(genre);
    } catch (error) {
        if (error.name === 'SequelizeUniqueConstraintError') {
            return res.status(400).json({ error: 'Genre with this name already exists' });
        }
        console.error('Error updating genre:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// DELETE /:id - Удалить жанр
router.delete('/:id', async (req, res) => {
    try {
        const genre = await db.Genre.findByPk(req.params.id);

        if (!genre) {
            return res.status(404).json({ error: 'Genre not found' });
        }

        await genre.destroy();
        res.status(204).end();
    } catch (error) {
        console.error('Error deleting genre:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

export default router;
