import { Router } from 'express';
import { Currency } from '../models/index.js'; // Импортируем модель Currency

const router = Router();

// Получение всех валют
router.get('/', async (req, res) => {
	try {
		const currencies = await Currency.findAll({
			attributes: ['id', 'code', 'name', 'symbol', 'icon', 'is_default'],
		});

		// Формируем полные URL для иконок
		const currenciesWithIcons = currencies.map(currency => ({
			...currency.toJSON(),
			icon: currency.icon || null,
		}));

		res.json(currenciesWithIcons);
	} catch (error) {
		console.error('Ошибка получения валют:', error);
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

// Получение валюты по умолчанию
router.get('/default', async (req, res) => {
	try {
		const defaultCurrency = await Currency.findOne({
			where: { is_default: true },
		});

		if (!defaultCurrency) {
			// Если нет валюты по умолчанию, попробуем найти российский рубль
			const rubleCurrency = await Currency.findOne({
				where: { code: 'RUB' },
			});

			if (rubleCurrency) {
				const currencyWithIcon = {
					...rubleCurrency.toJSON(),
					icon: rubleCurrency.icon || null,
				};
				return res.json(currencyWithIcon);
			}

			return res
				.status(404)
				.json({ message: 'Валюта по умолчанию не найдена' });
		}

		const currencyWithIcon = {
			...defaultCurrency.toJSON(),
			icon: defaultCurrency.icon || null,
		};
		res.json(currencyWithIcon);
	} catch (error) {
		console.error('Ошибка получения валюты по умолчанию:', error);
		res.status(500).json({ message: 'Ошибка сервера' });
	}
});

export default router;
