import { Router } from 'express';
import collectionsRouter from './collections.js';
import currencyRouter from './currencyRouter.js';
import editionsRouter from './editions.js';
import feedRouter from './feed.js';
import genresRouter from './genresRouter.js';
import paymentRouter from './payment.js';
import productsRouter from './products.js';
import promoRouter from './promoRouter.js';
import userRouter from './userRouter.js';
import settingsRouter from './settingsRouter.js';

const router = Router();

// Основные маршруты
router.use('/products', productsRouter);
router.use('/collections', collectionsRouter);
router.use('/editions', editionsRouter);
router.use('/feed', feedRouter);
router.use('/genres', genresRouter);
router.use('/users', userRouter);
router.use('/promos', promoRouter);
router.use('/currencies', currencyRouter);
router.use('/payment', paymentRouter);
router.use('/settings', settingsRouter);

// Обработка ошибок для платежных маршрутов
router.use((err, req, res, next) => {
    if (err.name === 'PaymentError') {
        console.error('Payment Error:', err);
        return res.status(err.status || 500).json({
            success: false,
            error: err.message
        });
    }
    next(err);
});

export default router;
