import { Router } from 'express';
import db from '../models/index.js';

const router = Router();

router.get('/', async (req, res) => {
	try {
		console.log('GET /feed - Starting to fetch feed items');
		const { currency_id } = req.query;

		// Получаем валюту по умолчанию
		const defaultCurrency = await db.Currency.findOne({
			where: { is_default: true },
		});

		if (!defaultCurrency) {
			throw new Error('Default currency not found');
		}

		// Получаем пользователя и его валюту
		const telegramId = req.headers['x-telegram-user-id'];
		console.log('Telegram User ID from headers:', telegramId);

		let user = null;
		if (telegramId) {
			user = await db.User.findOne({
				where: { telegramId },
				include: [
					{
						model: db.Currency,
						as: 'Currency',
					},
				],
			});
			console.log('Found user with currency:', user?.toJSON());
		} else {
			console.log('No Telegram User ID in headers');
		}

		// Получаем выбранную пользователем валюту
		let userCurrency;
		if (currency_id) {
			userCurrency = await db.Currency.findByPk(currency_id);
		} else if (user?.Currency) {
			userCurrency = user.Currency;
		} else {
			userCurrency = defaultCurrency;
		}

		if (!userCurrency) {
			throw new Error('Selected currency not found');
		}

		console.log('Using currency:', {
			id: userCurrency.id,
			code: userCurrency.code,
			exchange_rate: userCurrency.exchange_rate,
		});

		// Загружаем все диапазоны для выбранной валюты
		const currencyRanges = await db.CurrencyRange.findAll({
			where: {
				currencyId: userCurrency.id,
			},
		});

		console.log(
			'Loaded currency ranges:',
			currencyRanges.map(range => ({
				id: range.id,
				currencyId: range.currencyId,
				amountFrom: range.amountFrom,
				amountTo: range.amountTo,
				rate_multiplier: range.rate_multiplier,
			}))
		);

		// Функция для получения множителя курса на основе диапазона
		const getRateMultiplier = amount => {
			if (!currencyRanges || currencyRanges.length === 0) {
				console.log('No currency ranges found');
				return 1.0;
			}

			const numericAmount = Number(amount);
			if (isNaN(numericAmount)) {
				console.log('Invalid amount:', amount);
				return 1.0;
			}

			console.log('Looking for range:', {
				amount: numericAmount,
				type: typeof numericAmount,
				ranges: currencyRanges.map(range => ({
					from: Number(range.amountFrom),
					to: Number(range.amountTo),
					multiplier: Number(range.rate_multiplier),
					matches:
						numericAmount >= Number(range.amountFrom) &&
						numericAmount <= Number(range.amountTo),
				})),
			});

			const range = currencyRanges.find(
				range =>
					numericAmount >= Number(range.amountFrom) &&
					numericAmount <= Number(range.amountTo)
			);

			const multiplier = range ? Number(range.rate_multiplier) : 1.0;
			console.log('Found multiplier:', {
				range,
				multiplier,
			});

			return multiplier;
		};

		const feedItems = await db.FeedItem.findAll({
			include: [
				{
					model: db.ProductCollection,
					as: 'collections',
					through: { attributes: [] },
					include: [
						{
							model: db.Edition,
							as: 'editions',
							through: { attributes: [] },
							required: false,
							include: [
								{
									model: db.EditionName,
									as: 'editionName',
									attributes: ['id', 'name'],
								},
								{
									model: db.ProductCard,
									as: 'productCard',
									attributes: [
										'id',
										'name',
										'image_url',
										'edition_type',
									],
								},
								{
									model: db.Platform,
									as: 'platforms',
									through: { attributes: [] },
								},
								{
									model: db.Currency,
									as: 'currency',
									attributes: ['id', 'code', 'exchange_rate'],
								},
							],
						},
					],
				},
			],
			order: [['position', 'ASC']],
		});

		// Преобразуем цены с учетом валют
		const processedFeedItems = await Promise.all(
			feedItems.map(async item => {
				const processedItem = item.toJSON();

				if (processedItem.collections) {
					processedItem.collections = await Promise.all(
						processedItem.collections.map(async collection => {
							if (collection.editions) {
								collection.editions = await Promise.all(
									collection.editions.map(async edition => {
										if (edition.price && edition.currency) {
											// Конвертируем цену из валюты издания в валюту пользователя
											const exchangeRate = Number(
												edition.currency.exchange_rate
											);

											// Рассчитываем базовую цену в валюте пользователя
											const basePrice =
												Number(edition.price) *
												exchangeRate;

											// Сохраняем оригинальные цены
											edition.original_price =
												edition.price;
											edition.original_discount_price =
												edition.discount_amount;
											edition.original_eaplay_price =
												edition.ea_play_price;
											edition.original_psplus_price =
												edition.ps_plus_price;

											// Сначала обработаем базовую цену
											const baseMultiplier =
												getRateMultiplier(basePrice);
											edition.convertedPrice =
												basePrice * baseMultiplier;

											// Теперь обработаем цену со скидкой отдельно, используя свой множитель
											if (
												edition.discount_amount !==
													undefined &&
												edition.discount_amount !== null
											) {
												const discountPrice =
													Number(
														edition.discount_amount
													) * exchangeRate;
												// Всегда берем диапазон для цены со скидкой
												const discountMultiplier =
													getRateMultiplier(
														discountPrice
													);
												edition.discount_amount =
													discountPrice *
													discountMultiplier;

												console.log(
													'Price conversion details:',
													{
														original: {
															price: edition.original_price,
															discount:
																edition.original_discount_price,
														},
														converted: {
															price: edition.convertedPrice,
															discount:
																edition.discount_amount,
														},
														calculation: {
															exchangeRate,
															basePrice,
															baseMultiplier,
															discountPrice,
															discountMultiplier,
														},
														currency: {
															from: edition
																.currency.code,
															to: userCurrency.code,
														},
													}
												);
											} else {
												console.log(
													'Price conversion details (no discount):',
													{
														original: {
															price: edition.original_price,
														},
														converted: {
															price: edition.convertedPrice,
														},
														calculation: {
															exchangeRate,
															basePrice,
															baseMultiplier,
														},
														currency: {
															from: edition
																.currency.code,
															to: userCurrency.code,
														},
													}
												);
											}

											edition.displayCurrency = {
												code: userCurrency.code,
												id: userCurrency.id,
											};
										}
										return edition;
									})
								);
							}

							// Заменяем товары на позициях 1, 2, 3 витринными товарами для ЛЮБОЙ коллекции
							if (collection.editions && collection.editions.length > 0) {
								try {
									console.log(`🎯 [FEED] Обрабатываем замену товаров для "${collection.name}":`, {
										collectionId: collection.id,
										collectionName: collection.name,
										userCurrencyId: userCurrency.id,
										totalEditions: collection.editions.length,
									});

									const showcaseEditions = await db.CollectionShowcaseEdition.findAll({
										where: {
											collection_id: collection.id,
											currency_id: userCurrency.id,
										},
										order: [['position', 'ASC']],
										include: [{
											model: db.Edition,
											as: 'edition',
											include: [
												{
													model: db.EditionName,
													as: 'editionName',
													attributes: ['id', 'name'],
												},
												{
													model: db.ProductCard,
													as: 'productCard',
													attributes: ['id', 'name', 'image_url', 'edition_type'],
												},
												{
													model: db.Platform,
													as: 'platforms',
													through: { attributes: [] },
												},
												{
													model: db.Currency,
													as: 'currency',
													attributes: ['id', 'code', 'exchange_rate'],
												},
											],
										}],
									});

									console.log('📦 [FEED] Найдено витринных товаров:', showcaseEditions.length);

									// Заменяем товары на соответствующих позициях
									for (const showcaseEntry of showcaseEditions) {
										const position = showcaseEntry.position - 1; // Позиция 1 = индекс 0
										if (position >= 0 && position < collection.editions.length && showcaseEntry.edition) {
											const edition = showcaseEntry.edition.toJSON();

											if (edition.price && edition.currency) {
												const exchangeRate = Number(edition.currency.exchange_rate);
												const basePrice = Number(edition.price) * exchangeRate;

												edition.original_price = edition.price;
												edition.original_discount_price = edition.discount_amount;
												edition.original_eaplay_price = edition.ea_play_price;
												edition.original_psplus_price = edition.ps_plus_price;

												const baseMultiplier = getRateMultiplier(basePrice);
												edition.convertedPrice = basePrice * baseMultiplier;

												if (edition.discount_amount !== undefined && edition.discount_amount !== null) {
													const discountPrice = Number(edition.discount_amount) * exchangeRate;
													const discountMultiplier = getRateMultiplier(discountPrice);
													edition.discount_amount = discountPrice * discountMultiplier;
												}

												edition.displayCurrency = {
													code: userCurrency.code,
													id: userCurrency.id,
												};
											}

											collection.editions[position] = edition;
											console.log(`✅ [FEED] Заменен товар на позиции ${position + 1}: ${edition.productCard?.name}`);
										}
									}

									console.log(`✅ [FEED] Заменено ${showcaseEditions.length} товаров в "${collection.name}"`);
								} catch (error) {
									console.error('❌ [FEED] Error replacing showcase editions:', error);
								}
							}

							return collection;
						})
					);

					// Для элементов типа 'list' оставляем только первую коллекцию
					if (
						processedItem.type === 'list' &&
						processedItem.collections.length > 0
					) {
						processedItem.collection = processedItem.collections[0];
						delete processedItem.collections;
					}
				}

				return processedItem;
			})
		);

		res.json(processedFeedItems);
	} catch (error) {
		console.error('Error in GET /feed:', error);
		res.status(500).json({ error: error.message });
	}
});

router.get('/:id', async (req, res) => {
	try {
		console.log(
			'GET /feed/:id - Starting to fetch feed item by id:',
			req.params.id
		);
		const feedItem = await db.FeedItem.findByPk(req.params.id, {
			include: [
				{
					model: db.ProductCollection,
					as: 'collections',
					through: { attributes: [] },
					include: [
						{
							model: db.Edition,
							as: 'editions',
							through: { attributes: [] },
							include: [
								{
									model: db.EditionName,
									as: 'editionName',
									attributes: ['id', 'name'],
								},
								{
									model: db.ProductCard,
									as: 'productCard',
									attributes: [
										'id',
										'name',
										'image_url',
										'edition_type',
									],
								},
								{
									model: db.Platform,
									as: 'platforms',
									through: { attributes: [] },
								},
							],
						},
					],
				},
			],
		});

		if (!feedItem) {
			return res.status(404).json({ error: 'Feed item not found' });
		}

		console.log(
			'GET /feed/:id - Feed item fetched:',
			JSON.stringify(feedItem, null, 2)
		);
		res.json(feedItem);
	} catch (error) {
		console.error('Error fetching feed item:', error);
		res.status(500).json({ error: 'Internal server error' });
	}
});

export default router;


