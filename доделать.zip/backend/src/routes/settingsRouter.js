import { Router } from 'express';
import Settings from '../models/settings.js';

const router = Router();

// Получить статус режима техработ
router.get('/maintenance-status', async (req, res) => {
	try {
		const settings = await Settings.findOne();

		if (!settings) {
			return res.json({
				maintenanceMode: false,
				maintenanceMessage: '',
			});
		}

		res.json({
			maintenanceMode: settings.maintenanceMode,
			maintenanceMessage: settings.maintenanceMessage,
		});
	} catch (error) {
		console.error('Error fetching maintenance status:', error);
		res.status(500).json({
			error: 'Failed to fetch maintenance status',
		});
	}
});

export default router;
