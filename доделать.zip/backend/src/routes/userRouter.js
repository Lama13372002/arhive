import express from 'express';
import { getUser, updateUserProfile, updateUserCurrency, getRegionData, updateRegionData } from '../controllers/userController.js';
import User from '../models/user.js';
import Currency from '../models/currency.js';

const router = express.Router();

// Логирование для отладки
router.use((req, res, next) => {
	console.log('User Router:', {
		method: req.method,
		path: req.path,
		params: req.params,
		body: req.body,
	});
	next();
});

// Получение пользователя по telegramId
router.get('/:telegramId', getUser);

// Получение валюты пользователя
router.get('/:telegramId/currency', async (req, res) => {
	try {
		console.log('User Router:', {
			method: 'GET',
			path: `/${req.params.telegramId}/currency`,
			params: req.params,
			body: req.body,
		});

		const user = await User.findOne({
			where: { telegramId: req.params.telegramId },
			include: [{
				model: Currency,
				as: 'Currency'
			}]
		});

		if (!user) {
			return res.status(404).json({ error: 'User not found' });
		}

		res.json(user.Currency);
	} catch (error) {
		console.error('Error fetching user currency:', error);
		res.status(500).json({ error: error.message });
	}
});

// Обновление данных пользователя
router.put('/:telegramId', updateUserProfile);

// Обновление валюты пользователя
router.put('/:telegramId/currency', updateUserCurrency);

// Получение данных региона пользователя
router.get('/:telegramId/region/:currencyId', getRegionData);

// Обновление данных региона пользователя
router.put('/:telegramId/region/:currencyId', updateRegionData);

export default router;


