import { Router } from 'express';
import db from '../models/index.js';
import ProductCollectionEdition from '../models/productCollectionEdition.js';

const router = Router();

const getRateMultiplier = async (numericAmount, currencyId) => {
    const currencyRanges = await db.CurrencyRange.findAll({
        where: {
            currencyId: currencyId,
        },
        order: [['amountFrom', 'ASC']],
    });

    if (!currencyRanges || currencyRanges.length === 0) {
        console.log('No currency ranges found for currency ID:', currencyId);
        return 1.0;
    }

    const numericAmountValue = Number(numericAmount);
    if (isNaN(numericAmountValue)) {
        console.log('Invalid amount:', numericAmount);
        return 1.0;
    }

    console.log('Looking for range:', {
        amount: numericAmountValue,
        currencyId: currencyId,
        ranges: currencyRanges.map(range => ({
            from: Number(range.amountFrom),
            to: Number(range.amountTo),
            multiplier: Number(range.rate_multiplier),
            matches:
                numericAmountValue >= Number(range.amountFrom) &&
                numericAmountValue <= Number(range.amountTo),
        })),
    });

    const range = currencyRanges.find(
        range =>
            numericAmountValue >= Number(range.amountFrom) &&
            numericAmountValue <= Number(range.amountTo)
    );

    const multiplier = range ? Number(range.rate_multiplier) : 1.0;
    console.log('Found multiplier:', {
        range,
        multiplier,
    });

    return multiplier;
};

router.get('/', async (req, res) => {
    try {
        const { currency_id } = req.query;

        // Получаем валюту по умолчанию
        const defaultCurrency = await db.Currency.findOne({
            where: { is_default: true },
        });

        if (!defaultCurrency) {
            throw new Error('Default currency not found');
        }

        // Получаем пользователя и его валюту
        const telegramId = req.headers['x-telegram-user-id'];
        console.log('Telegram User ID from headers:', telegramId);

        let user = null;
        if (telegramId) {
            user = await db.User.findOne({
                where: { telegramId },
                include: [
                    {
                        model: db.Currency,
                        as: 'Currency',
                    },
                ],
            });
            console.log('Found user with currency:', user?.toJSON());
        } else {
            console.log('No Telegram User ID in headers');
        }

        // Получаем выбранную пользователем валюту
        let userCurrency;
        if (currency_id) {
            userCurrency = await db.Currency.findByPk(currency_id);
        } else if (user?.Currency) {
            userCurrency = user.Currency;
        } else {
            userCurrency = defaultCurrency;
        }

        if (!userCurrency) {
            throw new Error('Selected currency not found');
        }

        const collections = await db.ProductCollection.findAll({
            where: {
                isActive: true,
            },
            include: [
                {
                    model: db.Edition,
                    as: 'editions',
                    through: {
                        attributes: ['position'],
                    },
                    required: false,
                    include: [
                        {
                            model: db.EditionName,
                            as: 'editionName',
                            attributes: ['id', 'name'],
                        },
                        {
                            model: db.ProductCard,
                            as: 'productCard',
                            attributes: [
                                'id',
                                'name',
                                'image_url',
                                'edition_type',
                            ],
                        },
                        {
                            model: db.Platform,
                            as: 'platforms',
                            through: { attributes: [] },
                        },
                        {
                            model: db.Currency,
                            as: 'currency',
                        },
                    ],
                },
            ],
            order: [['createdAt', 'DESC']],
        });

        const processedCollections = await Promise.all(
            collections.map(async collection => {
                const processedCollection = collection.toJSON();

                if (processedCollection.editions) {
                    // Сортируем издания по позиции
                    processedCollection.editions.sort((a, b) => {
                        const posA = a.ProductCollectionEdition?.position || 999999;
                        const posB = b.ProductCollectionEdition?.position || 999999;
                        return posA - posB;
                    });

                    processedCollection.editions = await Promise.all(
                        processedCollection.editions.map(async edition => {
                            if (edition.price && edition.currency) {
                                // Конвертируем цену из валюты издания в валюту пользователя
                                const exchangeRate = Number(
                                    edition.currency.exchange_rate
                                );
                                const basePrice =
                                    Number(edition.price) * exchangeRate;

                                // Сохраняем оригинальные цены
                                edition.original_price = edition.price;
                                edition.original_discount_price =
                                    edition.discount_amount;
                                edition.original_eaplay_price =
                                    edition.ea_play_price;
                                edition.original_psplus_price =
                                    edition.ps_plus_price;

                                // Сначала обработаем базовую цену с её собственным множителем
                                const baseMultiplier = await getRateMultiplier(
                                    basePrice,
                                    userCurrency.id
                                );
                                edition.convertedPrice =
                                    basePrice * baseMultiplier;

                                // Теперь обработаем цену со скидкой отдельно, используя свой множитель
                                if (
                                    edition.discount_amount !== undefined &&
                                    edition.discount_amount !== null
                                ) {
                                    const discountPrice =
                                        Number(edition.discount_amount) *
                                        exchangeRate;
                                    // Всегда берем диапазон для цены со скидкой
                                    const discountMultiplier =
                                        await getRateMultiplier(
                                            discountPrice,
                                            userCurrency.id
                                        );
                                    edition.discount_amount =
                                        discountPrice * discountMultiplier;

                                    console.log('Price conversion details:', {
                                        original: {
                                            price: edition.original_price,
                                            discount:
                                                edition.original_discount_price,
                                        },
                                        converted: {
                                            price: edition.convertedPrice,
                                            discount: edition.discount_amount,
                                        },
                                        calculation: {
                                            exchangeRate,
                                            basePrice,
                                            baseMultiplier,
                                            discountPrice,
                                            discountMultiplier,
                                        },
                                        currency: {
                                            from: edition.currency.code,
                                            to: userCurrency.code,
                                        },
                                    });
                                } else {
                                    console.log(
                                        'Price conversion details (no discount):',
                                        {
                                            original: {
                                                price: edition.original_price,
                                            },
                                            converted: {
                                                price: edition.convertedPrice,
                                            },
                                            calculation: {
                                                exchangeRate,
                                                basePrice,
                                                baseMultiplier,
                                            },
                                            currency: {
                                                from: edition.currency.code,
                                                to: userCurrency.code,
                                            },
                                        }
                                    );
                                }

                                edition.displayCurrency = {
                                    code: userCurrency.code,
                                    id: userCurrency.id,
                                };
                            }
                            return edition;
                        })
                    );
                }

                // Заменяем товары на позициях 1, 2, 3 витринными товарами для ЛЮБОЙ коллекции
                // ВАЖНО: проверяем витрину даже если в коллекции нет базовых товаров!
                if (processedCollection.editions || true) {
                    // Если editions нет, создаем пустой массив
                    if (!processedCollection.editions) {
                        processedCollection.editions = [];
                    }
                    try {
                        console.log(`🎯 Обрабатываем замену товаров для "${processedCollection.name}":`, {
                            collectionId: processedCollection.id,
                            collectionName: processedCollection.name,
                            userCurrencyId: userCurrency.id,
                            userCurrencyCode: userCurrency.code,
                            totalEditions: processedCollection.editions.length,
                        });

                        const showcaseEditions = await db.CollectionShowcaseEdition.findAll({
                            where: {
                                collection_id: processedCollection.id,
                                currency_id: userCurrency.id,
                            },
                            order: [['position', 'ASC']],
                            include: [{
                                model: db.Edition,
                                as: 'edition',
                                include: [
                                    {
                                        model: db.EditionName,
                                        as: 'editionName',
                                        attributes: ['id', 'name'],
                                    },
                                    {
                                        model: db.ProductCard,
                                        as: 'productCard',
                                        attributes: ['id', 'name', 'image_url', 'edition_type'],
                                    },
                                    {
                                        model: db.Platform,
                                        as: 'platforms',
                                        through: { attributes: [] },
                                    },
                                    {
                                        model: db.Currency,
                                        as: 'currency',
                                        attributes: ['id', 'code', 'exchange_rate'],
                                    },
                                ],
                            }],
                        });

                        console.log('📦 Найдено витринных товаров:', showcaseEditions.length);

                        if (showcaseEditions.length > 0) {
                            // Собираем ID витринных товаров
                            const showcaseEditionIds = showcaseEditions.map(se => se.edition_id);
                            console.log('🔍 ID витринных товаров:', showcaseEditionIds);

                            // УДАЛЯЕМ витринные товары из основного массива, если они там есть
                            processedCollection.editions = processedCollection.editions.filter(edition => {
                                const isShowcaseEdition = showcaseEditionIds.includes(edition.id);
                                if (isShowcaseEdition) {
                                    console.log(`🗑️ Удаляем из массива товар ID=${edition.id} (${edition.productCard?.name}), т.к. он будет на витрине`);
                                }
                                return !isShowcaseEdition;
                            });

                            // Подготавливаем витринные товары с обработанными ценами
                            const processedShowcaseEditions = [];
                            for (const showcaseEntry of showcaseEditions) {
                                if (showcaseEntry.edition) {
                                    const edition = showcaseEntry.edition.toJSON();

                                    if (edition.price && edition.currency) {
                                        const exchangeRate = Number(edition.currency.exchange_rate);
                                        const basePrice = Number(edition.price) * exchangeRate;

                                        edition.original_price = edition.price;
                                        edition.original_discount_price = edition.discount_amount;
                                        edition.original_eaplay_price = edition.ea_play_price;
                                        edition.original_psplus_price = edition.ps_plus_price;

                                        const baseMultiplier = await getRateMultiplier(basePrice, userCurrency.id);
                                        edition.convertedPrice = basePrice * baseMultiplier;

                                        if (edition.discount_amount !== undefined && edition.discount_amount !== null) {
                                            const discountPrice = Number(edition.discount_amount) * exchangeRate;
                                            const discountMultiplier = await getRateMultiplier(discountPrice, userCurrency.id);
                                            edition.discount_amount = discountPrice * discountMultiplier;
                                        }

                                        edition.displayCurrency = {
                                            code: userCurrency.code,
                                            id: userCurrency.id,
                                        };
                                    }

                                    processedShowcaseEditions.push({
                                        edition,
                                        position: showcaseEntry.position
                                    });
                                }
                            }

                            // ВСТАВЛЯЕМ витринные товары на нужные позиции (1, 2, 3)
                            processedShowcaseEditions.sort((a, b) => a.position - b.position);
                            for (const { edition, position } of processedShowcaseEditions) {
                                const targetIndex = position - 1; // Позиция 1 = индекс 0
                                processedCollection.editions.splice(targetIndex, 0, edition);
                                console.log(`✅ Вставлен витринный товар на позицию ${position}: ${edition.productCard?.name}`);
                            }

                            console.log(`✅ Обработано ${showcaseEditions.length} витринных товаров в "${processedCollection.name}"`);
                        }
                    } catch (error) {
                        console.error('❌ Error replacing showcase editions:', error);
                    }
                }

                return processedCollection;
            })
        );

        res.json(processedCollections);
    } catch (error) {
        console.error('Error in GET /collections:', error);
        res.status(500).json({ error: error.message });
    }
});

router.get('/:id', async (req, res) => {
    try {
        const { currency_id } = req.query;

        // Получаем валюту по умолчанию
        const defaultCurrency = await db.Currency.findOne({
            where: { is_default: true },
        });

        if (!defaultCurrency) {
            throw new Error('Default currency not found');
        }

        // Получаем пользователя и его валюту
        const telegramId = req.headers['x-telegram-user-id'];
        console.log('Telegram User ID from headers:', telegramId);

        let user = null;
        if (telegramId) {
            user = await db.User.findOne({
                where: { telegramId },
                include: [
                    {
                        model: db.Currency,
                        as: 'Currency',
                    },
                ],
            });
            console.log('Found user with currency:', user?.toJSON());
        } else {
            console.log('No Telegram User ID in headers');
        }

        // Получаем выбранную пользователем валюту
        let userCurrency;
        if (currency_id) {
            userCurrency = await db.Currency.findByPk(currency_id);
        } else if (user?.Currency) {
            userCurrency = user.Currency;
        } else {
            userCurrency = defaultCurrency;
        }

        if (!userCurrency) {
            throw new Error('Selected currency not found');
        }

        const collection = await db.ProductCollection.findByPk(req.params.id, {
            include: [
                {
                    model: db.Edition,
                    as: 'editions',
                    through: {
                        attributes: ['position'],
                    },
                    required: false,
                    include: [
                        {
                            model: db.EditionName,
                            as: 'editionName',
                            attributes: ['id', 'name'],
                        },
                        {
                            model: db.ProductCard,
                            as: 'productCard',
                            attributes: [
                                'id',
                                'name',
                                'image_url',
                                'edition_type',
                            ],
                        },
                        {
                            model: db.Platform,
                            as: 'platforms',
                            through: { attributes: [] },
                        },
                        {
                            model: db.Currency,
                            as: 'currency',
                        },
                    ],
                },
            ],
        });

        if (!collection) {
            return res.status(404).json({ error: 'Collection not found' });
        }

        const processedCollection = collection.toJSON();

        if (processedCollection.editions) {
            // Сортируем издания по позиции
            processedCollection.editions.sort((a, b) => {
                const posA = a.ProductCollectionEdition?.position || 999999;
                const posB = b.ProductCollectionEdition?.position || 999999;
                return posA - posB;
            });

            processedCollection.editions = await Promise.all(
                processedCollection.editions.map(async edition => {
                    if (edition.price && edition.currency) {
                        // Конвертируем цену из валюты издания в валюту пользователя
                        const exchangeRate = Number(
                            edition.currency.exchange_rate
                        );
                        const basePrice = Number(edition.price) * exchangeRate;

                        // Сохраняем оригинальные цены
                        edition.original_price = edition.price;
                        edition.original_discount_price =
                            edition.discount_amount;
                        edition.original_eaplay_price = edition.ea_play_price;
                        edition.original_psplus_price = edition.ps_plus_price;

                        // Сначала обработаем базовую цену с её собственным множителем
                        const baseMultiplier = await getRateMultiplier(
                            basePrice,
                            userCurrency.id
                        );
                        edition.convertedPrice = basePrice * baseMultiplier;

                        // Теперь обработаем цену со скидкой отдельно, используя свой множитель
                        if (
                            edition.discount_amount !== undefined &&
                            edition.discount_amount !== null
                        ) {
                            const discountPrice =
                                Number(edition.discount_amount) * exchangeRate;
                            // Всегда берем диапазон для цены со скидкой
                            const discountMultiplier = await getRateMultiplier(
                                discountPrice,
                                userCurrency.id
                            );
                            edition.discount_amount =
                                discountPrice * discountMultiplier;

                            console.log('Price conversion details:', {
                                original: {
                                    price: edition.original_price,
                                    discount: edition.original_discount_price,
                                },
                                converted: {
                                    price: edition.convertedPrice,
                                    discount: edition.discount_amount,
                                },
                                calculation: {
                                    exchangeRate,
                                    basePrice,
                                    baseMultiplier,
                                    discountPrice,
                                    discountMultiplier,
                                },
                                currency: {
                                    from: edition.currency.code,
                                    to: userCurrency.code,
                                },
                            });
                        } else {
                            console.log(
                                'Price conversion details (no discount):',
                                {
                                    original: {
                                        price: edition.original_price,
                                    },
                                    converted: {
                                        price: edition.convertedPrice,
                                    },
                                    calculation: {
                                        exchangeRate,
                                        basePrice,
                                        baseMultiplier,
                                    },
                                    currency: {
                                        from: edition.currency.code,
                                        to: userCurrency.code,
                                    },
                                }
                            );
                        }

                        edition.displayCurrency = {
                            code: userCurrency.code,
                            id: userCurrency.id,
                        };
                    }
                    return edition;
                })
            );
        }

        // Заменяем товары на позициях 1, 2, 3 витринными товарами для ЛЮБОЙ коллекции
        // ВАЖНО: проверяем витрину даже если в коллекции нет базовых товаров!
        if (processedCollection.editions || true) {
            // Если editions нет, создаем пустой массив
            if (!processedCollection.editions) {
                processedCollection.editions = [];
            }
            try {
                console.log(`🎯 [/:id] Обрабатываем замену товаров для "${processedCollection.name}":`, {
                    collectionId: processedCollection.id,
                    collectionName: processedCollection.name,
                    userCurrencyId: userCurrency.id,
                    userCurrencyCode: userCurrency.code,
                    totalEditions: processedCollection.editions.length,
                });

                const showcaseEditions = await db.CollectionShowcaseEdition.findAll({
                    where: {
                        collection_id: processedCollection.id,
                        currency_id: userCurrency.id,
                    },
                    order: [['position', 'ASC']],
                    include: [{
                        model: db.Edition,
                        as: 'edition',
                        include: [
                            {
                                model: db.EditionName,
                                as: 'editionName',
                                attributes: ['id', 'name'],
                            },
                            {
                                model: db.ProductCard,
                                as: 'productCard',
                                attributes: ['id', 'name', 'image_url', 'edition_type'],
                            },
                            {
                                model: db.Platform,
                                as: 'platforms',
                                through: { attributes: [] },
                            },
                            {
                                model: db.Currency,
                                as: 'currency',
                                attributes: ['id', 'code', 'exchange_rate'],
                            },
                        ],
                    }],
                });

                console.log('📦 [/:id] Найдено витринных товаров:', showcaseEditions.length);

                if (showcaseEditions.length > 0) {
                    // Собираем ID витринных товаров
                    const showcaseEditionIds = showcaseEditions.map(se => se.edition_id);
                    console.log('🔍 [/:id] ID витринных товаров:', showcaseEditionIds);

                    // УДАЛЯЕМ витринные товары из основного массива, если они там есть
                    processedCollection.editions = processedCollection.editions.filter(edition => {
                        const isShowcaseEdition = showcaseEditionIds.includes(edition.id);
                        if (isShowcaseEdition) {
                            console.log(`🗑️ [/:id] Удаляем из массива товар ID=${edition.id} (${edition.productCard?.name}), т.к. он будет на витрине`);
                        }
                        return !isShowcaseEdition;
                    });

                    // Подготавливаем витринные товары с обработанными ценами
                    const processedShowcaseEditions = [];
                    for (const showcaseEntry of showcaseEditions) {
                        if (showcaseEntry.edition) {
                            const edition = showcaseEntry.edition.toJSON();

                            if (edition.price && edition.currency) {
                                const exchangeRate = Number(edition.currency.exchange_rate);
                                const basePrice = Number(edition.price) * exchangeRate;

                                edition.original_price = edition.price;
                                edition.original_discount_price = edition.discount_amount;
                                edition.original_eaplay_price = edition.ea_play_price;
                                edition.original_psplus_price = edition.ps_plus_price;

                                const baseMultiplier = await getRateMultiplier(basePrice, userCurrency.id);
                                edition.convertedPrice = basePrice * baseMultiplier;

                                if (edition.discount_amount !== undefined && edition.discount_amount !== null) {
                                    const discountPrice = Number(edition.discount_amount) * exchangeRate;
                                    const discountMultiplier = await getRateMultiplier(discountPrice, userCurrency.id);
                                    edition.discount_amount = discountPrice * discountMultiplier;
                                }

                                edition.displayCurrency = {
                                    code: userCurrency.code,
                                    id: userCurrency.id,
                                };
                            }

                            processedShowcaseEditions.push({
                                edition,
                                position: showcaseEntry.position
                            });
                        }
                    }

                    // ВСТАВЛЯЕМ витринные товары на нужные позиции (1, 2, 3)
                    processedShowcaseEditions.sort((a, b) => a.position - b.position);
                    for (const { edition, position } of processedShowcaseEditions) {
                        const targetIndex = position - 1; // Позиция 1 = индекс 0
                        processedCollection.editions.splice(targetIndex, 0, edition);
                        console.log(`✅ [/:id] Вставлен витринный товар на позицию ${position}: ${edition.productCard?.name}`);
                    }

                    console.log(`✅ [/:id] Обработано ${showcaseEditions.length} витринных товаров в "${processedCollection.name}"`);
                }
            } catch (error) {
                console.error('❌ [/:id] Error replacing showcase editions:', error);
            }
        }

        res.json(processedCollection);
    } catch (error) {
        console.error('Error in GET /collections/:id:', error);
        res.status(500).json({ error: error.message });
    }
});

export default router;
