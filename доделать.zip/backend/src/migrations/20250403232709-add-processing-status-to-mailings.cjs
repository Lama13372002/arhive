'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
	async up(queryInterface, Sequelize) {
		// PostgreSQL требует переопределения типа ENUM
		// 1. Создаем новый тип с обновленным набором значений
		await queryInterface.sequelize.query(`
      CREATE TYPE "enum_Mailings_status_new" AS ENUM('draft', 'scheduled', 'processing', 'sent', 'cancelled', 'error');
    `);

		// 2. Сначала удаляем значение по умолчанию
		await queryInterface.sequelize.query(`
      ALTER TABLE "Mailings" ALTER COLUMN status DROP DEFAULT;
    `);

		// 3. Обновляем колонку, чтобы использовать новый тип
		await queryInterface.sequelize.query(`
      ALTER TABLE "Mailings"
      ALTER COLUMN status TYPE "enum_Mailings_status_new"
      USING (status::text::"enum_Mailings_status_new");
    `);

		// 4. Восстанавливаем дефолтное значение
		await queryInterface.sequelize.query(`
      ALTER TABLE "Mailings" ALTER COLUMN status SET DEFAULT 'draft';
    `);

		// 5. Удаляем старый тип
		await queryInterface.sequelize.query(`
      DROP TYPE IF EXISTS "enum_Mailings_status";
    `);

		// 6. Переименовываем новый тип в старое имя
		await queryInterface.sequelize.query(`
      ALTER TYPE "enum_Mailings_status_new" RENAME TO "enum_Mailings_status";
    `);
	},

	async down(queryInterface, Sequelize) {
		// Откат изменений — удаляем статус 'processing' из ENUM
		// 1. Создаем новый тип без значения 'processing'
		await queryInterface.sequelize.query(`
      CREATE TYPE "enum_Mailings_status_new" AS ENUM('draft', 'scheduled', 'sent', 'cancelled', 'error');
    `);

		// 2. Обновляем все записи со статусом 'processing' на 'scheduled'
		await queryInterface.sequelize.query(`
      UPDATE "Mailings" SET status = 'scheduled' WHERE status = 'processing';
    `);

		// 3. Удаляем значение по умолчанию
		await queryInterface.sequelize.query(`
      ALTER TABLE "Mailings" ALTER COLUMN status DROP DEFAULT;
    `);

		// 4. Обновляем колонку, чтобы использовать новый тип
		await queryInterface.sequelize.query(`
      ALTER TABLE "Mailings"
      ALTER COLUMN status TYPE "enum_Mailings_status_new"
      USING (status::text::"enum_Mailings_status_new");
    `);

		// 5. Восстанавливаем дефолтное значение
		await queryInterface.sequelize.query(`
      ALTER TABLE "Mailings" ALTER COLUMN status SET DEFAULT 'draft';
    `);

		// 6. Удаляем старый тип
		await queryInterface.sequelize.query(`
      DROP TYPE IF EXISTS "enum_Mailings_status";
    `);

		// 7. Переименовываем новый тип в старое имя
		await queryInterface.sequelize.query(`
      ALTER TYPE "enum_Mailings_status_new" RENAME TO "enum_Mailings_status";
    `);
	},
};
