import { transformSync } from '@babel/core';
import { readFile } from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export async function resolve(specifier, context, nextResolve) {
	console.log(`resolve: specifier=${specifier}, context=${context}`);
	if (specifier.endsWith('.jsx')) {
		const resolved = await nextResolve(specifier, context);
		return {
			...resolved,
			format: 'module',
		};
	}
	// Для всех остальных файлов вызываем nextResolve
	console.log(
		`resolve: calling nextResolve(specifier=${specifier}, context=${context})`
	);
	return nextResolve(specifier, context);
}

export async function load(url, context, nextLoad) {
	console.log(`Loading: ${url}`);
	if (url.endsWith('.jsx')) {
		console.log(`Processing JSX file: ${url}`);
		const filePath = fileURLToPath(url);
		console.log(`load: reading file at ${filePath}`);
		const source = await readFile(filePath, 'utf8');
		console.log(`load: transforming file at ${filePath}`);
		const transformed = transformSync(source, {
			filename: filePath,
			presets: ['@babel/preset-react'],
			babelrc: false,
			configFile: false,
		});
		console.log(`load: transformed source: ${transformed.code}`);
		return {
			format: 'module',
			source: transformed.code,
			shortCircuit: true,
		};
	}
	// Для всех остальных файлов вызываем nextLoad
	console.log(`load: calling nextLoad(url=${url}, context=${context})`);
	return nextLoad(url);
}
