AdminJS.UserComponents = {}
import Dashboard from '../src/admin/components/Dashboard'
AdminJS.UserComponents.Dashboard = Dashboard
import Login from '../src/admin/components/login'
AdminJS.UserComponents.Login = Login
import SetDiscountAction from '../src/admin/components/SetDiscountAction'
AdminJS.UserComponents.SetDiscountAction = SetDiscountAction
import ImageUpload from '../src/admin/components/ImageUpload'
AdminJS.UserComponents.ImageUpload = ImageUpload
import ImagePreview from '../src/admin/components/ImagePreview'
AdminJS.UserComponents.ImagePreview = ImagePreview
import BulkCollectionModal from '../src/admin/components/BulkCollectionModal'
AdminJS.UserComponents.BulkCollectionModal = BulkCollectionModal
import BulkAddToCollectionAction from '../src/admin/components/BulkAddToCollectionAction'
AdminJS.UserComponents.BulkAddToCollectionAction = BulkAddToCollectionAction
import CollectionShowcaseManager from '../src/admin/components/CollectionShowcaseManager'
AdminJS.UserComponents.CollectionShowcaseManager = CollectionShowcaseManager
