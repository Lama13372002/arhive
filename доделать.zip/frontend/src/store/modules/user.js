import { updateUserField as apiUpdateUserField, getUser, getUserRegionData as apiGetUserRegionData, updateUserRegionData as apiUpdateUserRegionData } from '@/services/apiService';

const state = {
	user: null,
	loading: false,
	error: null,
	currentCurrency: null,
};

const mutations = {
	SET_USER(state, user) {
		state.user = user;
	},
	SET_LOADING(state, loading) {
		state.loading = loading;
	},
	SET_ERROR(state, error) {
		state.error = error;
	},
	UPDATE_USER_FIELD(state, { field, value }) {
		if (state.user) {
			state.user[field] = value;
		}
	},
	SET_USER_CURRENCY(state, currency) {
		state.currentCurrency = currency;
		if (state.user) {
			state.user.currencyId = currency.id;
		}
	},
};

const actions = {
	async initializeUser({ dispatch }) {
		const telegramId = window.Telegram?.WebApp?.initDataUnsafe?.user?.id;
		if (telegramId) {
			await dispatch('fetchUser', telegramId);
		}
	},

	async fetchUser({ commit }, telegramId) {
		try {
			if (!telegramId) {
				throw new Error('Telegram ID is required');
			}
			commit('SET_LOADING', true);
			commit('SET_ERROR', null);
			const user = await getUser(telegramId);
			commit('SET_USER', user);
		} catch (error) {
			commit(
				'SET_ERROR',
				error.response?.data?.error || 'Failed to fetch user'
			);
			throw error;
		} finally {
			commit('SET_LOADING', false);
		}
	},

	async updateUserField({ commit, rootState }, { field, value }) {
		try {
			const telegramId = rootState.auth.telegramId;
			if (!telegramId) {
				throw new Error('Telegram ID is required');
			}

			commit('SET_LOADING', true);
			commit('SET_ERROR', null);

			// Обновляем поле на сервере
			await apiUpdateUserField(telegramId, field, value);

			// Обновляем поле в store
			commit('UPDATE_USER_FIELD', { field, value });
		} catch (error) {
			commit(
				'SET_ERROR',
				error.response?.data?.error || 'Failed to update user field'
			);
			throw error;
		} finally {
			commit('SET_LOADING', false);
		}
	},

	async getUserRegionData({ commit, rootState }, { currencyId }) {
		try {
			const telegramId = rootState.auth.telegramId;
			if (!telegramId) {
				throw new Error('Telegram ID is required');
			}

			commit('SET_LOADING', true);
			commit('SET_ERROR', null);

			// Получаем данные региона
			const regionData = await apiGetUserRegionData(telegramId, currencyId);
			return regionData;
		} catch (error) {
			commit(
				'SET_ERROR',
				error.response?.data?.error || 'Failed to get user region data'
			);
			throw error;
		} finally {
			commit('SET_LOADING', false);
		}
	},

	async updateUserRegionData({ commit, rootState }, { currencyId, data }) {
		try {
			const telegramId = rootState.auth.telegramId;
			if (!telegramId) {
				throw new Error('Telegram ID is required');
			}

			commit('SET_LOADING', true);
			commit('SET_ERROR', null);

			// Обновляем данные региона
			const updatedData = await apiUpdateUserRegionData(telegramId, currencyId, data);
			return updatedData;
		} catch (error) {
			commit(
				'SET_ERROR',
				error.response?.data?.error || 'Failed to update user region data'
			);
			throw error;
		} finally {
			commit('SET_LOADING', false);
		}
	},
};

const getters = {
	user: state => state.user,
	loading: state => state.loading,
	error: state => state.error,
	currentCurrency: state => state.currentCurrency,
	telegramUsername: state => state.user?.telegramUsername || state.user?.username || null
};

export default {
	namespaced: true,
	state,
	mutations,
	actions,
	getters,
};


