import axios from 'axios';

// Создаем экземпляр axios с базовым URL
const baseURL = import.meta.env.VITE_API_BASE_URL;

// Добавляем /api если его нет в конце URL
let cleanBaseURL = baseURL.endsWith('/') ? baseURL.slice(0, -1) : baseURL;
if (!cleanBaseURL.endsWith('/api')) {
	cleanBaseURL = `${cleanBaseURL}/api`;
}

console.log('Using API base URL:', cleanBaseURL);

const axiosInstance = axios.create({
	baseURL: cleanBaseURL,
	timeout: 10000,
	headers: {
		'Content-Type': 'application/json',
	},
});

// Добавляем интерцептор для логирования запросов
axiosInstance.interceptors.request.use(request => {
	console.log('Request:', {
		method: request.method,
		url: request.url,
		baseURL: request.baseURL,
		headers: request.headers,
	});
	return request;
});

// Добавляем интерцептор для логирования ответов
axiosInstance.interceptors.response.use(
	response => {
		console.log('Response:', {
			status: response.status,
			data: response.data,
		});
		return response;
	},
	error => {
		console.error('Response error:', {
			message: error.message,
			config: error.config,
			response: error.response,
		});
		return Promise.reject(error);
	}
);

export default axiosInstance;
