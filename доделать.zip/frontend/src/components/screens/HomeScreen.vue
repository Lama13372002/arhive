<template>
    <div v-if="isLoading" class="loader-container">
        <div class="loader"></div>
        <p class="loader-text">Загрузка...</p>
    </div>
    <div v-else-if="error" class="error-container">
        <p class="error-text">{{ error }}</p>
    </div>
    <template v-else>
        <div class="home-screen">
            <div v-if="!feedItems.length" class="empty-state">
                <p>Нет доступных товаров</p>
            </div>

            <!-- Группировка элементов для правильного отображения -->
            <div>
                <!-- Обрабатываем баннеры и списки в порядке, в котором они приходят -->
                <template
                    v-for="(item, index) in processedFeedItems"
                    :key="index"
                >
                    <!-- Секция с баннерами -->
                    <section
                        v-if="item.type === 'bannerGroup'"
                        class="hot-offers"
                    >
                        <div class="banner-grid">
                            <template
                                v-for="banner in item.banners"
                                :key="banner.id"
                            >
                                <template
                                    v-for="collection in banner.collections"
                                    :key="collection.id"
                                >
                                    <router-link
                                        :to="{
                                            name: 'Collection',
                                            params: { id: collection.id },
                                        }"
                                        class="offer-card"
                                    >
                                        <img
                                            :src="collection.image_url"
                                            :alt="collection.name"
                                        />
                                    </router-link>
                                </template>
                            </template>
                        </div>
                    </section>

                    <!-- Секция со списками -->
                    <section
                        v-if="
                            item.type === 'list' &&
                            processCollectionProducts(
                                item.collection,
                                item.type
                            ).length > 0
                        "
                        class="now-playing"
                    >
                        <div class="section-header">
                            <h2 class="section-title">{{ item.title }}</h2>
                            <router-link
                                v-if="item.collection?.products?.length"
                                :to="{
                                    name: 'Collection',
                                    params: { id: item.collection.id },
                                }"
                                class="see-all"
                                >Все</router-link
                            >
                        </div>
                        <ul
                            v-if="item.collection?.products?.length"
                            class="product-list"
                        >
                            <li
                                v-for="product in processCollectionProducts(
                                    item.collection,
                                    item.type
                                )"
                                :key="product.id"
                                class="product-item"
                            >
                                <ProductCard :product="product" />
                            </li>
                        </ul>
                        <p v-else class="empty-message">
                            Нет доступных товаров
                        </p>
                    </section>
                </template>
            </div>

            <!-- Кнопка обращения в поддержку -->
            <SupportButton />
        </div>
    </template>
</template>

<script>
import ProductCard from '@/components/common/ProductCard.vue';
import SupportButton from '@/components/common/SupportButton.vue';
import { getFeedItems } from '@/services/apiService';
import { computed, onMounted, ref, watch } from 'vue';
import { useStore } from 'vuex';

export default {
    name: 'HomeScreen',
    components: {
        ProductCard,
        SupportButton,
    },

    setup() {
        const store = useStore();
        const feedItems = ref([]);
        const isLoading = ref(true);
        const error = ref(null);

        // Преобразуем feedItems для группировки баннеров
        const processedFeedItems = computed(() => {
            // Создаем новый массив
            const processedItems = [];
            let bannerGroup = null;

            // Обходим все элементы
            feedItems.value.forEach((item, index) => {
                if (item.type === 'banner' && item.collections?.length > 0) {
                    // Если это баннер
                    if (!bannerGroup) {
                        // Если группа баннеров еще не создана, создаем новую
                        bannerGroup = {
                            type: 'bannerGroup',
                            banners: [item],
                        };
                        processedItems.push(bannerGroup);
                    } else {
                        // Добавляем баннер к существующей группе
                        bannerGroup.banners.push(item);
                    }
                } else {
                    // Если это не баннер, сбрасываем группу и добавляем элемент как есть
                    bannerGroup = null;
                    processedItems.push(item);
                }
            });

            return processedItems;
        });

        // Получаем все коллекции из всех баннеров
        const bannerCollections = computed(() => {
            const collections = [];

            feedItems.value.forEach(item => {
                if (item.type === 'banner' && item.collections?.length > 0) {
                    item.collections.forEach(collection => {
                        collections.push(collection);
                    });
                }
            });

            return collections;
        });

        const fetchFeedItems = async () => {
            try {
                isLoading.value = true;
                const response = await getFeedItems();
                feedItems.value = response;

                // Логирование данных для отладки
                feedItems.value.forEach(item => {
                    if (
                        item.type === 'banner' &&
                        item.collections?.length > 0
                    ) {
                        console.log(
                            `Коллекции в баннере "${item.title}":`,
                            item.collections
                        );
                    }
                });
            } catch (err) {
                console.error('Error fetching feed items:', err);
                error.value = 'Ошибка при загрузке данных';
            } finally {
                isLoading.value = false;
            }
        };

        // Обрабатываем товары для отображения
        const processCollectionProducts = (collection, type) => {
            if (!collection?.products) {
                console.log('No products in collection:', collection);
                return [];
            }

            const currentCurrency = store.state.user.currentCurrency;
            console.log('Processing products with currency:', currentCurrency);

            // Фильтруем по валюте и сортируем по позиции из админки
            const filteredProducts = collection.products
                .filter(product => {
                    const hasEdition = product && product.edition;
                    const matchesCurrency =
                        !currentCurrency ||
                        (hasEdition &&
                            product.edition.display_currency_id ===
                                currentCurrency.id);

                    return hasEdition && matchesCurrency;
                })
                .sort((a, b) => {
                    // Сортируем по позиции из ProductCollectionEdition
                    const posA = a.ProductCollectionEdition?.position || 999999;
                    const posB = b.ProductCollectionEdition?.position || 999999;
                    return posA - posB;
                });

            console.log('Filtered products:', filteredProducts);
            // Возвращаем только нужное количество продуктов
            return filteredProducts.slice(0, type === 'banner' ? 4 : 3);
        };

        // Следим за изменением валюты и обновляем данные
        watch(
            () => store.state.user.currentCurrency,
            (newCurrency, oldCurrency) => {
                if (
                    newCurrency &&
                    (!oldCurrency || newCurrency.id !== oldCurrency?.id)
                ) {
                    console.log(
                        'Currency changed in HomeScreen, refreshing feed items:',
                        {
                            from: oldCurrency?.code,
                            to: newCurrency?.code,
                        }
                    );

                    // Перезагружаем данные при изменении валюты
                    fetchFeedItems();
                }
            }
        );

        onMounted(() => {
            fetchFeedItems();
        });

        return {
            feedItems,
            processedFeedItems,
            bannerCollections,
            isLoading,
            error,
            processCollectionProducts,
        };
    },
};
</script>

<style scoped>
/* Удаляем отладочные стили */
.debug-mode .banner-grid {
    border: 1px dashed red;
    padding: 5px;
}

.debug-mode .offer-card {
    border: 1px solid blue;
}

.home-screen {
    padding: 25px 15px;
    padding-bottom: 96px;
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.section-title {
    font-size: 20px;
    font-weight: bold;
    margin: 0;
}

.see-all {
    background: none;
    border: none;
    color: #007aff;
    font-size: 15px;
    font-weight: 500;
    padding: 0;
    cursor: pointer;
}

.hot-offers {
    margin-bottom: 24px;
}

.now-playing {
    margin-bottom: 24px;
}

.banner-grid {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    gap: 12px;
    width: 100%;
    max-width: 370px;
    margin: 0 auto;
    justify-content: center;
}

.offer-grid {
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    gap: 12px;
    width: 100%;
    max-width: 370px;
    margin: 0 auto;
    overflow-x: auto;
    padding-bottom: 10px;
    padding-top: 5px;
    scrollbar-width: thin;
    position: relative;
}

.offer-card {
    width: 170px;
    min-width: 170px;
    aspect-ratio: 1 / 1;
    overflow: hidden;
    border-radius: 10px;
    position: relative;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s ease-in-out;
    margin-bottom: 12px;
}

.offer-card:hover,
.offer-card:active {
    transform: scale(1.03);
}

.offer-card img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 10px;
    display: block;
}

.product-list {
    gap: 10px;
    display: flex;
    align-self: stretch;
    align-items: flex-start;
    flex-direction: column;
    width: 100%;
    padding: 0;
    margin: 0;
    list-style: none;
}

.product-item {
    width: 100%;
    list-style: none;
}

.product-link {
    display: flex;
    align-items: center;
    justify-content: space-between;
    text-decoration: none;
    color: inherit;
    width: 100%;
}

.loader-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.loader {
    width: 50px;
    height: 50px;
    border: 3px solid #f8f8f8;
    border-top: 3px solid #037ee5;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    animation: spin 1s linear infinite;
}

.loader-text {
    margin-top: 20px;
    font-size: 15px;
    font-weight: 500;
    color: #037ee5;
}

@keyframes spin {
    0% {
        transform: rotate(0deg);
    }
    100% {
        transform: rotate(360deg);
    }
}

.error-container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.error-text {
    color: #ff3b30;
    font-size: 16px;
    text-align: center;
}

.loading-placeholder {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    font-size: 16px;
    color: #037ee5;
}

.show-all {
    margin-top: 10px;
}

.empty-state {
    text-align: center;
    padding: 2rem;
    color: #666;
}

.empty-message {
    text-align: center;
    padding: 1rem;
    color: #666;
}

/* Добавляем медиа-запрос для разных размеров экранов */
@media (min-width: 400px) {
    .offer-card {
        width: 175px;
        min-width: 170px;
    }
}

@media (max-width: 350px) {
    .banner-grid {
        gap: 8px;
    }

    .offer-card {
        width: 160px;
        min-width: 160px;
    }
}

/* Скрываем скроллбар, но оставляем функциональность прокрутки */
.offer-grid::-webkit-scrollbar {
    height: 4px;
}

.offer-grid::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}

.offer-grid::-webkit-scrollbar-thumb {
    background: #ccc;
    border-radius: 10px;
}

.collection-debug {
    font-size: 12px;
    color: #666;
}
</style>
