<template>
	<div class="collection-screen" ref="collectionScreenRef">
		<div v-if="loading" class="loading">Загрузка...</div>
		<template v-else>
			<div class="content-container">
				<h1 class="collection-title">
					{{ collectionName }}
				</h1>

				<section class="product-section">
					<div
						v-if="filteredProducts.length === 0"
						class="no-products-message"
					>
						В данной коллекции нет доступных товаров для текущей
						валюты
					</div>
					<div v-else class="product-list">
						<ProductCard
							v-for="product in displayedGames"
							:key="product.id"
							:product="product"
							@card-click="handleProductCardClick"
						/>
					</div>
				</section>

				<!-- Кнопка обращения в поддержку на последней странице -->
				<div v-if="currentPage === totalPages && filteredProducts.length > 0" class="support-wrapper">
					<SupportButton />
				</div>

				<div v-if="totalPages > 1" class="pagination-container">
					<button
						class="pagination-btn"
						@click="goToFirstPage"
						:disabled="currentPage === 1"
					>
						«
					</button>
					<button
						class="pagination-btn"
						@click="goToPrevPage"
						:disabled="currentPage === 1"
					>
						‹
					</button>

					<div class="page-numbers">
						<button
							v-for="page in displayedPages"
							:key="page"
							class="page-number"
							:class="{ active: currentPage === page }"
							@click="goToPage(page)"
						>
							{{ page }}
						</button>
					</div>

					<button
						class="pagination-btn"
						@click="goToNextPage"
						:disabled="currentPage === totalPages"
					>
						›
					</button>
					<button
						class="pagination-btn"
						@click="goToLastPage"
						:disabled="currentPage === totalPages"
					>
						»
					</button>
				</div>
			</div>
		</template>
	</div>
</template>

<script>
import ProductCard from '@/components/common/ProductCard.vue';
import SupportButton from '@/components/common/SupportButton.vue';
import { getCollection } from '@/services/apiService';
import { getFinalPrice } from '@/utils/discount';

export default {
	name: 'CollectionScreen',
	components: {
		ProductCard,
		SupportButton,
	},

	data() {
		return {
			collection: null,
			loading: true,
			error: null,
			currentPage: 1,
			itemsPerPage: 12,
			// Флаг для отслеживания первоначальной загрузки
			initialLoadComplete: false,
			// Для дебаунсинга прокрутки
			scrollTimeout: null,
		};
	},

	computed: {
		collectionId() {
			return this.$route.params.id;
		},

		collectionName() {
			return this.collection?.name || '';
		},

		products() {
			return this.collection?.products || [];
		},

		// Добавляем новый computed свойство filteredProducts, чтобы отделить
		// фильтрацию товаров от пагинации
		filteredProducts() {
			if (!this.products || !this.products.length) return [];

			const currentCurrency = this.$store.state.user.currentCurrency;

			console.log('Filtering products from collection:', {
				totalProducts: this.products.length,
				sampleProduct: this.products[0],
				currentCurrency: currentCurrency,
			});

			// Проверяем, что у продукта есть издание с подходящей валютой
			return this.products.filter(product => {
				// Проверяем, что продукт существует
				if (!product) {
					console.log('Найден пустой продукт');
					return false;
				}

				// Проверяем структуру продукта и изданий
				// Бывает, что edition является отдельным свойством, а не массивом editions
				if (product.edition) {
					// Если у продукта есть свойство edition (устаревший формат)
					console.log(
						'Продукт использует устаревший формат (свойство edition):',
						product.id
					);

					if (!currentCurrency) return true;

					return (
						product.edition &&
						product.edition.display_currency_id ===
							currentCurrency.id
					);
				}
				// Проверяем наличие массива editions
				else if (product.editions && product.editions.length) {
					console.log(
						`Продукт ${product.id} имеет ${product.editions.length} изданий`
					);

					// Если валюта не выбрана, показываем все продукты
					if (!currentCurrency) return true;

					// Проверяем, есть ли у продукта издание с нужной валютой
					const hasMatchingEdition = product.editions.some(
						edition =>
							edition &&
							edition.display_currency_id === currentCurrency.id
					);

					return hasMatchingEdition;
				} else {
					console.log('Продукт не имеет изданий:', product.id);
					return false;
				}
			});
		},

		totalPages() {
			return Math.max(
				1,
				Math.ceil(this.filteredProducts.length / this.itemsPerPage)
			);
		},

		displayedGames() {
			if (!this.filteredProducts.length) return [];

			// Вычисляем начальный и конечный индексы для текущей страницы
			const startIndex = (this.currentPage - 1) * this.itemsPerPage;
			const endIndex = startIndex + this.itemsPerPage;

			// Корректируем текущую страницу, если она выходит за пределы допустимого диапазона
			if (this.currentPage > this.totalPages && this.totalPages > 0) {
				this.$nextTick(() => {
					this.currentPage = this.totalPages;
				});
				return [];
			}

			// Возвращаем только продукты для текущей страницы
			return this.filteredProducts
				.sort((a, b) => {
					// Находим подходящие издания для сравнения цен
					const currentCurrency =
						this.$store.state.user.currentCurrency;

					// Обрабатываем случай, когда edition может быть как свойством, так и в массиве editions
					const getEdition = product => {
						if (product.edition) return product.edition;
						if (product.editions && product.editions.length) {
							return currentCurrency
								? product.editions.find(
										e =>
											e.display_currency_id ===
											currentCurrency.id
								  )
								: product.editions[0];
						}
						return null;
					};

					const editionA = getEdition(a);
					const editionB = getEdition(b);

					if (!editionA && !editionB) return 0;
					if (!editionA) return 1;
					if (!editionB) return -1;

					const priceA = getFinalPrice(editionA);
					const priceB = getFinalPrice(editionB);

					return priceA - priceB;
				})
				.slice(startIndex, endIndex);
		},

		displayedPages() {
			const pages = [];
			const maxVisiblePages = 5;
			const halfVisible = Math.floor(maxVisiblePages / 2);

			let startPage = Math.max(this.currentPage - halfVisible, 1);
			let endPage = Math.min(
				startPage + maxVisiblePages - 1,
				this.totalPages
			);

			if (endPage - startPage + 1 < maxVisiblePages) {
				startPage = Math.max(endPage - maxVisiblePages + 1, 1);
			}

			for (let i = startPage; i <= endPage; i++) {
				pages.push(i);
			}

			return pages;
		},
	},

	methods: {
		async loadCollection() {
			try {
				// Проверяем, есть ли данные в кеше ДО установки loading
				const cachedCollection = this.$store.getters[
					'collections/getCachedCollection'
				](this.collectionId);

				// Устанавливаем loading только если данных нет в кеше
				if (!cachedCollection) {
					this.loading = true;
				}

				// Ждем загрузки пользователя
				if (this.$store.state.user.loading) {
					await new Promise(resolve => {
						const unwatch = this.$store.watch(
							state => state.user.loading,
							loading => {
								if (!loading) {
									unwatch();
									resolve();
								}
							}
						);
					});
				}

				if (cachedCollection) {
					console.log(
						'Using cached collection data:',
						this.collectionId,
						'Products:',
						cachedCollection.products
							? cachedCollection.products.length
							: 0
					);

					// Восстанавливаем состояние страницы из хранилища
					const savedState = this.$store.getters[
						'collections/getCollectionState'
					](this.collectionId);

					// Устанавливаем данные и состояние
					this.collection = cachedCollection;
					this.initialLoadComplete = true;

					// Проверяем, что сохраненная страница не выходит за пределы
					if (
						savedState.currentPage &&
						savedState.currentPage <=
							Math.ceil(
								this.filteredProducts.length / this.itemsPerPage
							)
					) {
						this.currentPage = savedState.currentPage;
					} else {
						this.currentPage = 1;
					}

					// loading уже false, так как мы его не устанавливали для кеша
				} else {
					// Загружаем данные с сервера
					const response = await getCollection(this.collectionId);
					console.log(
						'Loaded collection data from server:',
						this.collectionId,
						'Products:',
						response.products ? response.products.length : 0
					);

					// Добавляем отладочный вывод для проверки структуры данных
					if (response.products && response.products.length) {
						console.log(
							'Пример продукта с сервера:',
							JSON.stringify(response.products[0], null, 2)
						);
					}

					this.collection = response;

					// Сохраняем данные в кеш
					this.$store.dispatch('collections/cacheCollection', {
						collectionId: this.collectionId,
						data: response,
					});

					// Восстанавливаем состояние страницы из хранилища
					const savedState = this.$store.getters[
						'collections/getCollectionState'
					](this.collectionId);

					// Устанавливаем флаг загрузки
					this.initialLoadComplete = true;

					// Проверяем, что сохраненная страница не выходит за пределы
					if (
						savedState.currentPage &&
						savedState.currentPage <=
							Math.ceil(
								this.filteredProducts.length / this.itemsPerPage
							)
					) {
						this.currentPage = savedState.currentPage;
					} else {
						this.currentPage = 1;
					}

					// Снимаем состояние загрузки
					this.loading = false;

				}
			} catch (error) {
				console.error('Error loading collection:', error);
				this.loading = false;
			}
		},

		// Сохраняем состояние страницы
		savePageState() {
			if (!this.initialLoadComplete) return;

			const scrollPosition = this.$refs.collectionScreenRef
				? this.$refs.collectionScreenRef.scrollTop
				: 0;

			this.$store.dispatch('collections/saveCollectionState', {
				collectionId: this.collectionId,
				pageState: {
					currentPage: this.currentPage,
					scrollPosition: scrollPosition,
				},
			});

			console.log('Saved collection state:', {
				collectionId: this.collectionId,
				currentPage: this.currentPage,
				scrollPosition: scrollPosition,
			});
		},

		// Обработчик события прокрутки с дебаунсингом
		handleScroll() {
			if (this.scrollTimeout) {
				clearTimeout(this.scrollTimeout);
			}

			this.scrollTimeout = setTimeout(() => {
				this.savePageState();
			}, 200);
		},

		// Обработчик клика на карточку продукта
		handleProductCardClick() {
			// Очищаем таймаут дебаунсинга
			if (this.scrollTimeout) {
				clearTimeout(this.scrollTimeout);
				this.scrollTimeout = null;
			}
			// Немедленно сохраняем позицию скролла перед переходом
			this.savePageState();
			console.log('Product card clicked, scroll position saved immediately');
		},

		goToPage(page) {
			this.currentPage = page;
			this.savePageState();
			// Прокручиваем страницу вверх при смене страницы
			if (this.$refs.collectionScreenRef) {
				this.$refs.collectionScreenRef.scrollTop = 0;
			}
		},

		goToFirstPage() {
			this.goToPage(1);
		},

		goToLastPage() {
			this.goToPage(this.totalPages);
		},

		goToPrevPage() {
			if (this.currentPage > 1) {
				this.goToPage(this.currentPage - 1);
			}
		},

		goToNextPage() {
			if (this.currentPage < this.totalPages) {
				this.goToPage(this.currentPage + 1);
			}
		},

		// Метод для обновления данных коллекции при смене валюты
		refreshCollectionAfterCurrencyChange() {
			// Сбрасываем кеш для данной коллекции
			this.$store.dispatch(
				'collections/invalidateCache',
				this.collectionId
			);
			// Сбрасываем на первую страницу
			this.currentPage = 1;
			// Перезагружаем коллекцию
			this.loadCollection();
		},
	},

	watch: {
		// Следим за filteredProducts, чтобы корректировать currentPage при необходимости
		filteredProducts: {
			handler(newProducts) {
				const maxPage = Math.ceil(
					newProducts.length / this.itemsPerPage
				);
				if (this.currentPage > maxPage && maxPage > 0) {
					this.currentPage = maxPage;
				}
			},
			immediate: true,
		},

		'$store.state.user.currentCurrency': {
			handler(newCurrency, oldCurrency) {
				if (
					newCurrency &&
					(!oldCurrency || newCurrency.id !== oldCurrency?.id)
				) {
					console.log(
						'Currency changed in CollectionScreen, refreshing collection:',
						{
							from: oldCurrency?.code,
							to: newCurrency?.code,
							collectionId: this.collectionId,
						}
					);

					// Устанавливаем флаг загрузки и делаем прямой API запрос вместо использования кеша
					this.loading = true;

					// Сбрасываем страницу на первую
					this.currentPage = 1;

					// Очищаем кеш для данной коллекции
					this.$store.dispatch(
						'collections/invalidateCache',
						this.collectionId
					);

					// Делаем прямой запрос к API вместо вызова метода loadCollection
					getCollection(this.collectionId)
						.then(response => {
							console.log(
								'Collection data refreshed after currency change:',
								response
							);
							this.collection = response;

							// Сохраняем обновленные данные в кеш
							this.$store.dispatch(
								'collections/cacheCollection',
								{
									collectionId: this.collectionId,
									data: response,
								}
							);

							// Устанавливаем флаг загрузки
							this.loading = false;
							this.initialLoadComplete = true;

							// Сбрасываем прокрутку вверх
							this.$nextTick(() => {
								if (this.$refs.collectionScreenRef) {
									this.$refs.collectionScreenRef.scrollTop = 0;
								}
							});
						})
						.catch(error => {
							console.error(
								'Error refreshing collection:',
								error
							);
							this.error = 'Ошибка при обновлении коллекции';
							this.loading = false;
						});
				}
			},
			immediate: true,
		},
	},

	created() {
		// Восстанавливаем currentPage из store ДО загрузки коллекции
		// Это важно для правильного отображения при наличии кеша
		const savedState = this.$store.getters['collections/getCollectionState'](this.collectionId);
		if (savedState.currentPage) {
			this.currentPage = savedState.currentPage;
		}

		this.loadCollection();
	},

	// Добавляем обработчик события прокрутки
	mounted() {
		// Добавляем обработчик события прокрутки для сохранения позиции
		this.$refs.collectionScreenRef.addEventListener(
			'scroll',
			this.handleScroll
		);

		// Восстанавливаем позицию скролла
		// Используем requestAnimationFrame для более плавной работы
		const restoreScroll = () => {
			const savedState = this.$store.getters['collections/getCollectionState'](this.collectionId);
			if (savedState.scrollPosition && this.$refs.collectionScreenRef && !this.loading) {
				requestAnimationFrame(() => {
					this.$refs.collectionScreenRef.scrollTop = savedState.scrollPosition;
					console.log('Restored scroll position:', savedState.scrollPosition);
				});
			}
		};

		// Если данные уже загружены (из кеша), восстанавливаем сразу
		if (!this.loading) {
			this.$nextTick(restoreScroll);
		} else {
			// Если идет загрузка, ждем её завершения
			const unwatch = this.$watch('loading', (newVal) => {
				if (!newVal) {
					this.$nextTick(restoreScroll);
					unwatch();
				}
			});
		}
	},

	beforeUnmount() {
		// Удаляем обработчик события прокрутки
		if (this.$refs.collectionScreenRef) {
			this.$refs.collectionScreenRef.removeEventListener(
				'scroll',
				this.handleScroll
			);
		}
		// Очищаем таймаут дебаунсинга, если он активен
		if (this.scrollTimeout) {
			clearTimeout(this.scrollTimeout);
			this.scrollTimeout = null;
		}
		// Немедленно сохраняем текущую позицию скролла
		if (this.initialLoadComplete && this.$refs.collectionScreenRef) {
			const scrollPosition = this.$refs.collectionScreenRef.scrollTop;
			this.$store.dispatch('collections/saveCollectionState', {
				collectionId: this.collectionId,
				pageState: {
					currentPage: this.currentPage,
					scrollPosition: scrollPosition,
				},
			});
			console.log('Saved scroll position in beforeUnmount:', {
				collectionId: this.collectionId,
				currentPage: this.currentPage,
				scrollPosition: scrollPosition,
			});
		}
	},
};
</script>

<style scoped>
.collection-screen {
	height: 100vh;
	overflow-y: auto;
	-webkit-overflow-scrolling: touch;
	position: relative;
	padding: 25px 0;
}

.content-container {
	position: relative;
	z-index: 2;
	background-color: #ffffff;
	min-height: calc(100vh - 187px);
	border-radius: 13px 13px 0 0;
	margin-top: -13px;
	padding: 20px 20px 120px;
}

.collection-title {
	font-size: 20px;
	font-weight: bold;
	color: #000;
	margin: 0 0 10px 0;
}

.product-section {
	margin-bottom: 60px;
	max-width: 800px;
	margin: 0 auto;
}

.product-list {
	display: flex;
	flex-direction: column;
	gap: 8px;
	width: 100%;
}

.product-list > * {
	background: #ffffff;
	border-radius: 13px;
	/* padding: 12px; */
	margin-bottom: 0;
}

.no-products-message {
	text-align: center;
	padding: 40px 0;
	color: #666;
	font-size: 16px;
}

.loading {
	display: flex;
	justify-content: center;
	align-items: center;
	height: 100vh;
	font-size: 18px;
	color: #666;
}

.pagination-container {
	display: flex;
	justify-content: center;
	align-items: center;
	gap: 8px;
	position: fixed;
	bottom: 90px;
	left: 0;
	right: 0;
	/* background: #ffffff; */
	padding: 16px;
	/* box-shadow: 0 -4px 10px rgba(0, 0, 0, 0.05); */
	z-index: 10;
}

.pagination-btn,
.page-number {
	min-width: 32px;
	height: 32px;
	padding: 0;
	display: flex;
	align-items: center;
	justify-content: center;
	background: #ffffff;
	color: #000000;
	font-size: 14px;
	cursor: pointer;
	border-radius: 8px;
	transition: background-color 0.2s;
}

.pagination-btn {
	border: none;
}

.page-number {
	border: 1px solid #007aff;
}

.pagination-btn:disabled {
	opacity: 0.3;
	cursor: not-allowed;
}

.pagination-btn:not(:disabled):hover,
.page-number:not(.active):hover {
	background: #f1f1f1;
}

.page-numbers {
	display: flex;
	gap: 8px;
}

.page-number.active {
	background: #007aff;
	color: #ffffff;
}

/* Добавляем отступ для кнопки поддержки в коллекции */
.support-wrapper {
	margin-top: 24px;
}
</style>


