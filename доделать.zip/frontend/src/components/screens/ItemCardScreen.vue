<template>
	<div v-if="isLoading" class="loader-container">
		<div class="loader"></div>
		<p class="loader-text">Загрузка...</p>
	</div>
	<div v-else-if="error" class="loader-container">
		<p class="loader-text">{{ error }}</p>
	</div>
	<div v-else class="game-card-container">
		<div class="game-card">
			<div class="game-image-container">
				<img :src="imageUrl" :alt="game.title" class="game-image" />
			</div>
			<div class="game-details">
				<div class="game-header">
					<div class="game-info">
						<div class="game-title-wrapper">
							<div class="title-and-favorite">
								<h1 class="game-title">{{ game.title }}</h1>
								<FavoriteButton
									:game="{
										...game,
										image: imageUrl,
										edition: selectedEdition,
										title: game.name,
									}"
									v-model="isFavorite"
									class="favorite-button-fixed"
								/>
							</div>
						</div>
						<span class="game-genres">{{
							game.genres?.join(', ') || ''
						}}</span>
						<div class="game-rating" v-if="currentRating > 0">
							<div class="rating-stars">
								<img
									v-for="n in 5"
									:key="n"
									src="/assets/img/star.svg"
									:class="{
										filled:
											n <= Math.floor(currentRating),
									}"
									alt="star"
								/>
							</div>
							<span class="rating-score">{{
								currentRating.toFixed(2)
							}}</span>
						</div>
					</div>
					<div class="favorite-button-wrapper"></div>
				</div>
				<div class="game-subscription">
					<div
						class="subscription-buttons"
						v-if="hasSubscriptionOptions"
					>
						<EaPlayButton
							v-if="game.free_with_ea_play"
							:text="eaPlaySubscriptionText"
							class="subscription-button"
							:isPsPlus="false"
							@click="$router.push('/ea-play-collection')"
						/>
						<EaPlayButton
							v-if="hasPsPlusSubscription"
							:text="psPlusSubscriptionText"
							class="subscription-button"
							:isPsPlus="true"
							@click="navigateToPsPlusCollection"
						/>
					</div>
					<div class="edition-selector">
						<swiper
							ref="editionSwiper"
							:slides-per-view="2.2"
							:space-between="16"
							:breakpoints="{
								'640': {
									slidesPerView: 4,
									spaceBetween: 20,
								},
								'1024': {
									slidesPerView: 4.5,
									spaceBetween: 24,
								},
							}"
							class="edition-swiper"
							@swiper="onSwiperReady"
						>
							<swiper-slide
								v-for="edition in filteredEditions"
								:key="edition.id"
								class="edition-slide"
							>
								<div class="edition-column">
									<h3 class="edition-header">
										{{
											edition.editionName?.name ||
											'Standard'
										}}
									</h3>
									<div class="edition-detail">
										<div
											v-for="priceOption in getPriceOptions(
												edition
											)"
											:key="priceOption.type"
										>
											<button
												class="price-option-button clickable"
												:class="{
													active: isEditionPriceSelected(
														edition,
														priceOption.type
													),
												}"
												@click="
													selectEditionAndPrice(
														edition,
														priceOption.type
													)
												"
											>
												<div class="price-label">
													<span>{{
														priceOption.label
													}}</span>
													<img
														v-if="priceOption.icon"
														:src="priceOption.icon"
														:alt="priceOption.label"
														class="subscription-icon"
													/>
												</div>
												<div class="price-info">
													<span
														v-if="
															priceOption.discount
														"
														class="discount-badge"
													>
														<span
															class="discount-text"
															>-{{
																priceOption.discount
															}}%</span
														>
													</span>
													<span
														v-if="
															priceOption.originalPrice
														"
														class="original-price"
														>{{
															formatPrice(
																priceOption.originalPrice
															)
														}}
													</span>
													<span class="current-price"
														>{{
															formatPrice(
																priceOption.price
															)
														}}
													</span>
												</div>
												<div
													v-if="
														priceOption.promotionEndDate
													"
													class="promotion-end-date"
												>
													Акция до
													{{
														formatPromotionEndDate(
															priceOption.promotionEndDate
														)
													}}
												</div>
											</button>
										</div>
									</div>
								</div>
							</swiper-slide>
						</swiper>
					</div>
				</div>
				<div class="game-characteristics">
					<h2 class="section-title">Характеристики</h2>
					<div class="characteristics-list">
						<div class="characteristic-item" v-if="platformsList !== 'Платформа не указана'">
							<span class="characteristic-label"
								>Платформа:&nbsp;</span
							>
							<span class="characteristic-value">{{
								platformsList
							}}</span>
						</div>
						<div class="characteristic-item">
							<span class="characteristic-label"
								>Тип издания:&nbsp;</span
							>
							<span class="characteristic-value">{{
								game.edition_type || 'Standard'
							}}</span>
						</div>
						<div class="characteristic-item" v-if="shouldShowLocalization">
							<span class="characteristic-label"
								>Локализация:&nbsp;
							</span>
							<span class="characteristic-value">
								{{
									selectedEdition.localizations
										.map(loc => loc.name)
										.join(', ')
								}}
							</span>
						</div>
					</div>
				</div>
				<div class="game-description">
					<h2 class="section-title">Описание</h2>
					<div class="description-text">
						{{
							selectedEdition?.description ||
							'Описание отсутствует'
						}}
					</div>
				</div>
			</div>
			<div class="game-purchase">
				<div class="fixed-bottom">
					<Button
						:text="buttonText"
						:isProductCard="true"
						:modelValue="buttonState"
						:isFullWidth="true"
						@buttonClicked="handleCartAction"
						@update:modelValue="handleModelUpdate"
					/>
				</div>
			</div>
		</div>
	</div>
</template>

<script setup>
import Button from '@/components/common/Button.vue';
import EaPlayButton from '@/components/common/EAPlayButton.vue';
import FavoriteButton from '@/components/common/FavoriteButton.vue';
import 'swiper/css';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { computed, onMounted, ref, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useStore } from 'vuex';
import {
	getGameById,
	getTelegramUserId,
	getUser,
} from '../../services/apiService.js';

const route = useRoute();
const router = useRouter();
const store = useStore();

const game = ref(null);
const error = ref(null);
const isLoading = ref(true);
const isFavorite = ref(false);

const selectedEdition = ref(null);
const selectedPrices = ref(new Map()); // Карта для хранения выбранных цен по изданиям

const buttonState = ref(false);
const swiperInstance = ref(null);
const isInCart = computed(() => {
	if (!selectedEdition.value) return false;
	return store.getters['cart/isInCart'](
		game.value.id,
		selectedEdition.value.id
	);
});
const buttonText = computed(() =>
	isInCart.value ? 'Перейти в корзину' : 'В корзину'
);

const imageUrl = computed(() => {
	if (!game.value) return '';

	// Если image начинается с http, значит это полный URL
	if (
		game.value.image_url?.startsWith('http') ||
		game.value.image_url?.startsWith('https')
	) {
		return game.value.image_url;
	}

	const baseUrl = `${import.meta.env.VITE_API_BASE_URL}/uploads/`;
	if (!baseUrl) {
		console.error('VITE_API_BASE_URL не определен в переменных окружения');
		return game.value.image_url || '';
	}

	const imageUrl = game.value.image_url || '';
	return `${baseUrl.replace(/\/$/, '')}/${imageUrl.replace(/^\//, '')}`;
});

const hasSubscriptionOptions = computed(() => {
	return (
		game.value?.free_with_ea_play ||
		game.value?.free_with_ps_plus_essential ||
		game.value?.free_with_ps_plus_extra ||
		game.value?.free_with_ps_plus_deluxe
	);
});

const hasPsPlusSubscription = computed(() => {
	return (
		game.value?.free_with_ps_plus_essential ||
		game.value?.free_with_ps_plus_extra ||
		game.value?.free_with_ps_plus_deluxe
	);
});

const eaPlaySubscriptionText = computed(() => {
	return 'Входит в подписку EA Play';
});

const psPlusSubscriptionText = computed(() => {
	const subscriptions = [];
	if (game.value?.free_with_ps_plus_essential) subscriptions.push('Essential');
	if (game.value?.free_with_ps_plus_extra) subscriptions.push('Extra');
	if (game.value?.free_with_ps_plus_deluxe) subscriptions.push('Deluxe');
	return `Входит в подписку PS Plus ${subscriptions.join(' / ')}`;
});

const navigateToPsPlusCollection = () => {
	// Собираем список подписок для передачи на страницу коллекции
	const subscriptions = [];
	if (game.value?.free_with_ps_plus_essential) subscriptions.push('Essential');
	if (game.value?.free_with_ps_plus_extra) subscriptions.push('Extra');
	if (game.value?.free_with_ps_plus_deluxe) subscriptions.push('Deluxe');

	// Приоритет: Deluxe > Extra > Essential
	let targetRoute = '/ps-plus-essential-collection';
	if (game.value?.free_with_ps_plus_deluxe) {
		targetRoute = '/ps-plus-deluxe-collection';
	} else if (game.value?.free_with_ps_plus_extra) {
		targetRoute = '/ps-plus-extra-collection';
	}

	// Передаём подписки через query параметр для динамического заголовка
	router.push({
		path: targetRoute,
		query: { subs: subscriptions.join(' / ') }
	});
};

const filteredEditions = computed(() => {
	const currentCurrency = store.state.user.currentCurrency;
	console.log('Current currency:', currentCurrency);
	console.log('All editions:', game.value?.editions);

	if (!game.value?.editions || !currentCurrency) {
		console.log('No editions or currency, returning empty array');
		return [];
	}

	const filtered = game.value.editions.filter(edition => {
		console.log('Checking edition:', edition);
		if (!edition) return false;

		// Используем display_currency_id для фильтрации
		const editionCurrencyId = edition.display_currency_id;
		console.log('Edition currency:', editionCurrencyId);
		console.log('Current currency:', currentCurrency.id);

		return editionCurrencyId === currentCurrency.id;
	});

	// Сортируем издания по оригинальной цене БЕЗ скидки (по возрастанию)
	const sorted = filtered.sort((a, b) => {
		const priceA = parseFloat(a.convertedPrice || a.price || 0);
		const priceB = parseFloat(b.convertedPrice || b.price || 0);
		return priceA - priceB;
	});

	console.log('Filtered and sorted editions:', sorted);
	return sorted;
});

watch(
	[filteredEditions, () => store.state.user.currentCurrency],
	([newEditions]) => {
		if (newEditions.length > 0) {
			// Проверяем, есть ли editionId в query параметрах
			const requestedEditionId = route.query.editionId ? parseInt(route.query.editionId) : null;

			// Если текущее выбранное издание не в текущей валюте, выбираем нужное
			if (!newEditions.find(e => e.id === selectedEdition.value?.id)) {
				let editionToSelect = null;

				// Пытаемся найти запрошенное издание
				if (requestedEditionId) {
					editionToSelect = newEditions.find(e => e.id === requestedEditionId);
				}

				// Если не нашли, выбираем первое
				if (!editionToSelect) {
					editionToSelect = newEditions[0];
				}

				selectedEdition.value = editionToSelect;
				const priceOptions = getPriceOptions(editionToSelect);
				if (priceOptions.length > 0) {
					selectEditionAndPrice(editionToSelect, priceOptions[0].type);
				}

				// Прокручиваем к выбранному изданию
				if (requestedEditionId && editionToSelect) {
					setTimeout(() => {
						scrollToSelectedEdition(editionToSelect.id);
					}, 300);
				}
			}
		} else {
			// Если нет доступных изданий, сбрасываем выбор
			selectedEdition.value = null;
			selectedPrices.value.clear();
		}
	},
	{ immediate: true }
);

watch(
	[() => store.state.user.currentCurrency],
	async ([newCurrency], [oldCurrency]) => {
		if (
			newCurrency &&
			(!oldCurrency || newCurrency.id !== oldCurrency?.id)
		) {
			console.log('Currency changed, refreshing game data:', {
				from: oldCurrency?.code,
				to: newCurrency?.code,
			});

			// Перезагружаем данные игры с новой валютой
			try {
				isLoading.value = true;
				const gameId = route.params.id;
				const gameData = await getGameById(gameId, newCurrency.id);

				// Обновляем данные игры
				game.value = {
					id: gameData.id,
					name: gameData.name || 'Название недоступно',
					title: gameData.name || 'Название недоступно',
					image_url:
						gameData.image_url || '/assets/img/placeholder.png',
					genres: (gameData.genres || []).map(genre => genre.name),
					rating: gameData.rating || 0,
					ratingCount: 0,
					editions: gameData.editions || [],
					platforms: gameData.platforms || [],
					description: gameData.description || 'Описание отсутствует',
					edition_type: gameData.edition_type || 'Game',
					free_with_ea_play: gameData.free_with_ea_play || false,
					free_with_ps_plus_essential:
						gameData.free_with_ps_plus_essential || false,
					free_with_ps_plus_extra:
						gameData.free_with_ps_plus_extra || false,
					free_with_ps_plus_deluxe:
						gameData.free_with_ps_plus_deluxe || false,
				};

				console.log(
					'Game data refreshed after currency change:',
					game.value
				);
			} catch (error) {
				console.error('Error refreshing game data:', error);
			} finally {
				isLoading.value = false;
			}
		}
	}
);

onMounted(async () => {
	try {
		const gameId = route.params.id;
		console.log('Received game ID:', gameId);

		if (!gameId) {
			throw new Error('Game ID is required');
		}

		const telegramUserId = getTelegramUserId();
		console.log('Telegram User ID:', telegramUserId);

		const userData = await getUser(telegramUserId);
		const currencyId = userData?.currencyId;
		console.log('User currency ID:', currencyId);

		console.log(
			'Fetching game data for ID:',
			gameId,
			'with currency:',
			currencyId
		);
		const gameData = await getGameById(gameId, currencyId);
		console.log('Received game data:', gameData);

		// Детально проверяем структуру и значения для изданий и цен
		if (gameData.editions && gameData.editions.length > 0) {
			console.log('Детальная проверка данных изданий:');
			gameData.editions.forEach(edition => {
				console.log(`Издание #${edition.id}:`, {
					name: edition.editionName?.name,
					price: edition.price,
					convertedPrice: edition.convertedPrice,
					discount_amount: edition.discount_amount,
					is_discount_valid:
						edition.price &&
						edition.discount_amount &&
						edition.price > edition.discount_amount,
					discount_percent:
						edition.price && edition.discount_amount
							? Math.round(
									((edition.price - edition.discount_amount) /
										edition.price) *
										100
							  )
							: 0,
				});
			});
		}

		// Преобразуем данные с учетом возможных undefined значений
		game.value = {
			id: gameData.id,
			name: gameData.name || 'Название недоступно',
			title: gameData.name || 'Название недоступно',
			image_url: gameData.image_url || '/assets/img/placeholder.png',
			genres: (gameData.genres || []).map(genre => genre.name),
			rating: gameData.rating || 0,
			ratingCount: 0,
			editions: gameData.editions || [],
			platforms: gameData.platforms || [],
			description: gameData.description || 'Описание отсутствует',
			edition_type: gameData.edition_type || 'Game',
			free_with_ea_play: gameData.free_with_ea_play || false,
			free_with_ps_plus_essential:
				gameData.free_with_ps_plus_essential || false,
			free_with_ps_plus_extra: gameData.free_with_ps_plus_extra || false,
			free_with_ps_plus_deluxe:
				gameData.free_with_ps_plus_deluxe || false,
		};

		console.log('Processed game data:', game.value);
		console.log('Available editions:', game.value.editions);

		// Проверяем, есть ли editionId в query параметрах
		const requestedEditionId = route.query.editionId ? parseInt(route.query.editionId) : null;
		console.log('Requested edition ID from query:', requestedEditionId);

		// Если есть издания, выбираем нужное
		if (filteredEditions.value.length > 0) {
			// Пытаемся найти запрошенное издание
			let editionToSelect = null;
			if (requestedEditionId) {
				editionToSelect = filteredEditions.value.find(e => e.id === requestedEditionId);
				console.log('Found requested edition:', editionToSelect);
			}

			// Если не нашли запрошенное издание, выбираем первое
			if (!editionToSelect) {
				editionToSelect = filteredEditions.value[0];
				console.log('Using first edition as fallback:', editionToSelect);
			}

			selectedEdition.value = editionToSelect;
			const priceOptions = getPriceOptions(selectedEdition.value);
			if (priceOptions.length > 0) {
				selectEditionAndPrice(
					selectedEdition.value,
					priceOptions[0].type
				);
			}

			// Прокручиваем к выбранному изданию после небольшой задержки
			if (requestedEditionId && editionToSelect) {
				setTimeout(() => {
					scrollToSelectedEdition(editionToSelect.id);
				}, 100);
			}
		}

		isLoading.value = false;
	} catch (err) {
		console.error('Error loading game:', err);
		error.value = 'Ошибка при загрузке игры';
		isLoading.value = false;
	}
});

const handleCartAction = async () => {
	if (
		!selectedEdition.value ||
		!selectedPrices.value.get(selectedEdition.value.id)
	) {
		console.error('No edition or price type selected');
		return;
	}

	if (isInCart.value) {
		router.push('/shop-bag');
	} else {
		const priceOption = getPriceOptions(selectedEdition.value).find(
			option =>
				option.type ===
				selectedPrices.value.get(selectedEdition.value.id)
		);

		if (!priceOption) {
			console.error('Price option not found');
			return;
		}

		// Добавляем логирование
		console.log('Selected Edition:', selectedEdition.value);
		console.log('Game:', game.value);

		// Получаем текущую валюту пользователя
		const currentCurrency = store.state.user.currentCurrency;

		const cartItem = {
			id: selectedEdition.value.id,
			editionId: selectedEdition.value.id,
			productId: game.value.id,
			title: game.value.title,
			image: game.value.image_url,
			type: selectedEdition.value.type || game.value.edition_type, // Используем тип из издания или из игры
			platforms: selectedEdition.value.platforms?.length
				? selectedEdition.value.platforms
				: game.value.platforms,
			edition: selectedEdition.value,
			editionName:
				selectedEdition.value.editionName?.name ||
				selectedEdition.value.name,
			edition_type:
				selectedEdition.value.edition_type ||
				selectedEdition.value.type,
			price: priceOption.originalPrice || priceOption.price,
			// Устанавливаем discount_amount только если есть реальная скидка
			discount_amount: priceOption.originalPrice
				? priceOption.price
				: null,
			isPsPlus: priceOption.type === 'ps_plus',
			isEaPlay: priceOption.type === 'ea_play',
			priceType: selectedPrices.value.get(selectedEdition.value.id),
			currencyId: currentCurrency?.id, // Добавляем ID валюты
		};

		// Логируем финальный объект
		console.log('Cart Item:', cartItem);

		await store.dispatch('cart/addToCart', cartItem);
		buttonState.value = true;
	}
};

const handleModelUpdate = value => {
	buttonState.value = value;
};

const handleRemoveFromCart = async () => {
	if (selectedEdition.value) {
		await store.dispatch('cart/removeFromCart', selectedEdition.value.id);
		buttonState.value = false;
	}
};

const getPriceOptions = edition => {
	if (!edition) return [];

	const options = [];
	const hasPsPlus = store.getters['user/hasPsPlus'];
	const currentCurrency = store.state.user.currentCurrency;

	// Функция для проверки, истекла ли акция
	const isPromotionExpired = (promotionEndDate) => {
		if (!promotionEndDate) return false;
		const endDate = new Date(promotionEndDate);
		const now = new Date();
		return now > endDate;
	};

	// Основная стандартная цена
	const standardOption = {
		type: 'standard',
		label: 'Стандартная цена',
		price: null, // Текущая цена, которую надо заплатить (со скидкой, если есть)
		originalPrice: null, // Перечеркнутая цена (без скидки)
		discount: null, // Процент скидки
		icon: null,
		promotionEndDate: null,
	};

	// Преобразуем значения в числа для корректного сравнения
	const origPrice = parseFloat(edition.convertedPrice || edition.price);
	const discPrice = edition.discount_amount
		? parseFloat(edition.discount_amount)
		: null;

	// Проверяем, истекла ли акция
	const promotionExpired = isPromotionExpired(edition.promotion_end_date);

	console.log('Преобразованные числовые значения цен:', {
		origPrice,
		discPrice,
		isDiscountValid: discPrice !== null && origPrice > discPrice,
		promotionExpired,
		promotionEndDate: edition.promotion_end_date,
	});

	// Проверяем наличие скидки и что акция не истекла
	if (discPrice !== null && !isNaN(discPrice) && !promotionExpired) {
		// В бэкенде discount_amount - это цена СО скидкой!
		// price/convertedPrice - это цена БЕЗ скидки

		console.log('Цены для расчета скидки:', {
			origPrice,
			discPrice,
			difference: origPrice - discPrice,
		});

		// Устанавливаем цены
		standardOption.originalPrice = origPrice; // Перечеркнутая цена - БЕЗ скидки
		standardOption.price = discPrice; // Текущая цена - СО скидкой

		// Рассчитываем скидку, только если оригинальная цена больше цены со скидкой
		// и разница существенна (больше 1 рубля)
		if (
			!isNaN(origPrice) &&
			origPrice > discPrice &&
			origPrice - discPrice > 1
		) {
			standardOption.discount = Math.round(
				((origPrice - discPrice) / origPrice) * 100
			);
			standardOption.promotionEndDate = edition.promotion_end_date;
			console.log('Рассчитанная скидка:', standardOption.discount + '%');
		} else {
			console.log(
				'Скидка не рассчитана - цены равны или разница незначительна'
			);
		}
	} else {
		// Если скидки нет или акция истекла
		standardOption.price = origPrice;
		console.log(
			'Скидки нет или акция истекла, используем обычную цену:',
			standardOption.price,
			'promotionExpired:',
			promotionExpired
		);
	}

	// Если discount_amount существует, но мы не смогли рассчитать скидку,
	// или скидка получилась 0% - скрываем перечеркнутую цену
	if (
		discPrice !== null &&
		(!standardOption.discount || standardOption.discount <= 0)
	) {
		console.log('Скрываем перечеркнутую цену из-за нулевой скидки');
		standardOption.originalPrice = null;
		standardOption.discount = null;
		standardOption.promotionEndDate = null;
	}

	console.log('Standard price option (fixed):', standardOption);
	options.push(standardOption);

	// PS Plus цена
	if (edition.ps_plus_price !== null) {
		const psPlusPrice = parseFloat(edition.ps_plus_price);
		const standardPrice = standardOption.price;
		const psPlusPromotionExpired = isPromotionExpired(edition.ps_plus_promotion_end_date);

		console.log('PS Plus цены для сравнения:', {
			standardPrice,
			psPlusPrice,
			psPlusPromotionExpired,
			promotionEndDate: edition.ps_plus_promotion_end_date,
			isValid:
				!isNaN(psPlusPrice) &&
				!isNaN(standardPrice) &&
				psPlusPrice < standardPrice &&
				!psPlusPromotionExpired,
		});

		const psPlusOption = {
			type: 'ps_plus',
			label: 'С PS Plus',
			price: psPlusPrice,
			originalPrice: standardPrice, // Для сравнения используем текущую стандартную цену
			discount: null,
			icon: '/assets/img/psplussub.png',
			promotionEndDate: null,
		};

		// Вычисляем скидку PS Plus только если эта цена меньше стандартной
		// и разница существенная (больше 1 рубля) и акция не истекла
		if (
			!isNaN(psPlusPrice) &&
			!isNaN(standardPrice) &&
			psPlusOption.originalPrice &&
			psPlusPrice < standardPrice &&
			standardPrice - psPlusPrice > 1 &&
			!psPlusPromotionExpired
		) {
			psPlusOption.discount = Math.round(
				((standardPrice - psPlusPrice) / standardPrice) * 100
			);
			psPlusOption.promotionEndDate = edition.ps_plus_promotion_end_date;
			console.log('PS Plus скидка:', psPlusOption.discount + '%', {
				originalPrice: standardPrice,
				discountPrice: psPlusPrice,
			});
		} else {
			console.log('PS Plus скидка не рассчитана', {
				originalPrice: standardPrice,
				psPrice: psPlusPrice,
				promotionExpired: psPlusPromotionExpired,
			});
			psPlusOption.originalPrice = null; // Не показываем перечеркнутую цену
		}

		console.log('PS Plus price option (fixed):', psPlusOption);
		options.push(psPlusOption);
	}

	// EA Play цена
	if (edition.ea_play_price !== null) {
		const eaPlayPrice = parseFloat(edition.ea_play_price);
		const standardPrice = standardOption.price;
		const eaPlayPromotionExpired = isPromotionExpired(edition.ea_play_promotion_end_date);

		console.log('EA Play цены для сравнения:', {
			standardPrice,
			eaPlayPrice,
			eaPlayPromotionExpired,
			promotionEndDate: edition.ea_play_promotion_end_date,
			isValid:
				!isNaN(eaPlayPrice) &&
				!isNaN(standardPrice) &&
				eaPlayPrice < standardPrice &&
				!eaPlayPromotionExpired,
		});

		const eaPlayOption = {
			type: 'ea_play',
			label: 'С EA Play',
			price: eaPlayPrice,
			originalPrice: standardPrice, // Для сравнения используем текущую стандартную цену
			discount: null,
			icon: '/assets/img/eaplaysub.png',
			promotionEndDate: null,
		};

		// Вычисляем скидку EA Play только если эта цена меньше стандартной
		// и разница существенная (больше 1 рубля) и акция не истекла
		if (
			!isNaN(eaPlayPrice) &&
			!isNaN(standardPrice) &&
			eaPlayOption.originalPrice &&
			eaPlayPrice < standardPrice &&
			standardPrice - eaPlayPrice > 1 &&
			!eaPlayPromotionExpired
		) {
			eaPlayOption.discount = Math.round(
				((standardPrice - eaPlayPrice) / standardPrice) * 100
			);
			eaPlayOption.promotionEndDate = edition.ea_play_promotion_end_date;
			console.log('EA Play скидка:', eaPlayOption.discount + '%', {
				originalPrice: standardPrice,
				discountPrice: eaPlayPrice,
			});
		} else {
			console.log('EA Play скидка не рассчитана', {
				originalPrice: standardPrice,
				eaPrice: eaPlayPrice,
				promotionExpired: eaPlayPromotionExpired,
			});
			eaPlayOption.originalPrice = null; // Не показываем перечеркнутую цену
		}

		console.log('EA Play price option (fixed):', eaPlayOption);
		options.push(eaPlayOption);
	}

	return options;
};

const formatPrice = price => {
	if (!price) return '0 руб.';
	const num = Number(price);
	if (isNaN(num)) return '0 руб.';
	// Всегда округляем в меньшую сторону (убираем копейки)
	const formattedNum = Math.floor(num);
	return `${formattedNum} руб.`;
};

const selectEditionAndPrice = (edition, type) => {
	// Очищаем все предыдущие выборы
	selectedPrices.value.clear();
	// Устанавливаем новый выбор
	selectedPrices.value.set(edition.id, type);
	selectedEdition.value = edition;
};

const isEditionPriceSelected = (edition, type) => {
	return selectedPrices.value.get(edition.id) === type;
};

const platformsList = computed(() => {
	if (!selectedEdition.value?.platforms?.length) {
		return 'Платформа не указана';
	}

	const platformNames = selectedEdition.value.platforms.map(
		platform => platform.name
	);
	return platformNames.join(', ');
});

const currentRating = computed(() => {
	// Используем рейтинг из выбранного издания, если он есть
	// Иначе берем рейтинг из ProductCard
	if (selectedEdition.value?.rating != null) {
		return selectedEdition.value.rating;
	}
	return game.value?.rating || 0;
});

const shouldShowLocalization = computed(() => {
	if (!selectedEdition.value?.localizations?.length) {
		return false;
	}
	// Скрываем если есть только "Без русского языка" (парсер не нашел данных)
	const hasOnlyNoRussian =
		selectedEdition.value.localizations.length === 1 &&
		selectedEdition.value.localizations[0].name?.toLowerCase().includes('без русского');

	return !hasOnlyNoRussian;
});

const formatPromotionEndDate = date => {
	if (!date) return '';
	const dateObj = new Date(date);
	const dateOptions = {
		day: 'numeric',
		month: 'long',
		year: 'numeric'
	};
	const timeOptions = {
		hour: '2-digit',
		minute: '2-digit'
	};
	const datePart = dateObj.toLocaleDateString('ru-RU', dateOptions);
	const timePart = dateObj.toLocaleTimeString('ru-RU', timeOptions);
	return `${datePart} ${timePart}`;
};

const onSwiperReady = (swiper) => {
	console.log('Swiper is ready:', swiper);
	swiperInstance.value = swiper;
};

const scrollToSelectedEdition = (editionId) => {
	console.log('Scrolling to edition:', editionId);
	// Находим индекс выбранного издания в отфильтрованном массиве
	const editionIndex = filteredEditions.value.findIndex(e => e.id === editionId);
	console.log('Edition index:', editionIndex);

	if (editionIndex === -1) {
		console.log('Edition not found in filtered editions');
		return;
	}

	// Используем API Swiper для прокрутки к нужному слайду
	if (swiperInstance.value) {
		console.log('Using Swiper API to slide to index:', editionIndex);
		swiperInstance.value.slideTo(editionIndex, 300); // 300ms анимация
	} else {
		console.log('Swiper instance not ready, retrying...');
		// Если Swiper еще не готов, пробуем еще раз через небольшую задержку
		setTimeout(() => {
			if (swiperInstance.value) {
				swiperInstance.value.slideTo(editionIndex, 300);
			}
		}, 100);
	}
};
</script>

<style scoped>
.game-card-container {
	height: 100vh;
	overflow-y: auto;
	-webkit-overflow-scrolling: touch;
	position: relative;
	padding-bottom: 150px; /* Добавляем отступ для фиксированных кнопок */
}

.game-image-container {
	position: sticky;
	top: 0;
	z-index: 1;
	height: 200px;
	width: 100%;
}

.game-card {
	position: relative;
	z-index: 2;
	background-color: #ffffff;
	min-height: calc(100vh - 187px);
}

.game-image {
	width: 100%;
	height: 100%;
	object-fit: cover;
}

.game-details {
	gap: 15px;
	display: flex;
	padding: 15px;
	overflow: hidden;
	align-self: stretch;
	border-radius: 13px 13px 0 0;
	flex-direction: column;
	background-color: #ffffff;
	position: relative;
	z-index: 2;
	margin-top: -13px;
}

.game-header {
	display: flex;
	justify-content: space-between;
	align-items: flex-start;
	margin-bottom: 10px;
	position: relative;
}

.game-info {
	flex: 1;
}

.favorite-button-wrapper {
	position: absolute;
	right: 0;
	top: 0;
}

.game-title-wrapper {
	display: flex;
	flex-direction: column;
}

.title-and-favorite {
	display: flex;
	justify-content: space-between;
	align-items: center;
	width: 100%;
}

.game-title {
	font-size: 24px;
	font-weight: bold;
	margin: 0;
	flex: 1;
}

.favorite-button-fixed {
	margin-left: 20px;
}

.game-genres {
	color: #8a8a8a;
	font-size: 15px;
	line-height: 22px;
}

.game-rating {
	gap: 5px;
	display: flex;
	align-self: stretch;
	align-items: center;
	flex-shrink: 0;
}

.rating-stars {
	display: flex;
	margin-right: 5px;
}

.rating-stars img {
	width: 12px;
	height: 12px;
	margin-right: 2px;
}

.rating-score,
.rating-count {
	color: #8a8a8a;
	font-size: 15px;
	line-height: 22px;
}

.game-subscription {
	width: 100%;
	display: flex;
	flex-direction: column;
	align-items: stretch;
}

.subscription-buttons {
	display: flex;
	flex-direction: column;
	gap: 10px;
	margin-bottom: 20px;
	width: 100%;
}

.subscription-button {
	width: 100%;
	max-width: none;
}

.fixed-bottom {
	position: fixed;
	bottom: 90px;
	left: 0;
	right: 0;
	padding: 10px 15px;
	z-index: 1000;
}

.game-purchase {
	display: flex;
	flex-direction: column;
	gap: 10px;
	margin-bottom: 20px;
}

.edition-selector {
	display: flex;
	flex-direction: column;
	gap: 5px;
	width: 100%;
}

.edition-swiper {
	width: 100%;
	padding: 16px 0;
}

.edition-slide {
	height: auto;
	max-width: 100%;
}

.edition-header {
	text-align: center;
	white-space: normal !important;
	word-wrap: break-word !important;
	overflow-wrap: break-word !important;
}

.edition-column {
	height: 100%;
	background: #ffffff;
	border: 1px solid #999999;
	border-radius: 12px;
	padding: 16px;
	display: flex;
	flex-direction: column;
	gap: 12px;
}

.price-option-button {
	width: 100%;
	padding: 12px;
	border: 1px solid #e5e7eb;
	border-radius: 8px;
	background: #fff;
	cursor: pointer;
	align-items: center;
	display: flex;
	flex-direction: column;
	gap: 8px;
	transition: all 0.2s ease;
}

.price-option-button:last-child {
	margin-bottom: 0;
}

.price-option-button.disabled {
	cursor: default;
}

.price-option-button:not(.disabled):hover {
	border-color: rgba(0, 122, 255, 0.5);
}

.price-option-button.active {
	border-color: #007aff;
	background-color: rgba(0, 122, 255, 0.05);
}

.price-option-button:active:not(.disabled) {
	transform: scale(0.98);
}

.price-option-button.single-price {
	padding: 10px 5px;
	border: none;
	background-color: transparent;
	cursor: default;
}

.price-option-button.single-price:hover {
	border-color: transparent;
	transform: none;
}

.price-label {
	display: flex;
	align-items: center;
	gap: 8px;
	color: #374151;
	justify-content: center;
}

.price-label span {
	font-size: 13px;
}

.subscription-icon {
	width: 50px;
	height: 30px;
	margin-top: 5px;
	margin-left: -15px;
}

.price-info {
	display: flex;
	flex-direction: column;
	gap: 4px;
}
.price-option-button.single-price .price-info {
	justify-content: center;
	align-items: center;
}

.price-option-button.single-price .current-price {
	font-size: 20px;
	font-weight: 600;
}

.current-price {
	font-size: 16px;
	font-weight: 600;
	color: #111827;
}

.original-price {
	color: #6b7280;
	text-decoration: line-through;
	font-size: 14px;
}

.price-with-discount {
	display: flex;
	align-items: center;
	gap: 8px;
	justify-content: center;
}

.original-price span {
	color: rgba(121, 126, 134, 1);
	font-size: 13px;
	text-decoration: line-through;
}

.discount-badge {
	height: 15px;
	display: flex;
	padding: 0 5px;
	overflow: hidden;
	background: linear-gradient(
		180deg,
		rgba(0, 122, 255, 1) 0%,
		rgba(0, 73, 153, 1) 100%
	);
	align-items: center;
	flex-shrink: 0;
	border-radius: 5px;
	justify-content: center;
	margin-right: 5px;
}

.discount-badge span {
	color: #ffffff !important;
	font-size: 10px;
	font-weight: normal;
}

.discounted-price {
	font-size: 15px;
	font-weight: 700;
}

.discount-info {
	color: rgba(138, 138, 138, 1);
	font-size: 15px;
	font-weight: 300;
}

.game-characteristics,
.game-description {
	gap: 5px;
	display: flex;
	align-self: stretch;
	align-items: flex-start;
	flex-direction: column;
}

.section-title {
	color: #000000;
	font-size: 15px;
	font-weight: 700;
	line-height: 22px;
}

.characteristics-list {
	gap: 3px;
	display: flex;
	align-self: stretch;
	align-items: flex-start;
	flex-direction: column;
}

.characteristic-item {
	display: flex;
	justify-content: space-between;
	margin-bottom: 5px;
}

.characteristic-label {
	color: #8a8a8a;
}

.characteristic-value {
	color: #000000;
}

.description-text {
	white-space: pre-line;
	line-height: 1.5;
	margin: 10px 0;
	color: #000;
}

.loader-container {
	display: flex;
	flex-direction: column;
	justify-content: center;
	align-items: center;
	height: 100vh;
}

.loader {
	width: 50px;
	height: 50px;
	border: 3px solid #f8f8f8;
	border-top: 3px solid #037ee5;
	border-radius: 50%;
	animation: spin 1s linear infinite;
}

@keyframes spin {
	0% {
		transform: rotate(0deg);
	}
	100% {
		transform: rotate(360deg);
	}
}

.loader-text {
	margin-top: 20px;
	font-size: 15px;
	font-weight: 500;
	color: #037ee5;
}

.error-container {
	display: flex;
	justify-content: center;
	align-items: center;
	height: 100vh;
}

.error-text {
	color: #ff3b30;
	font-size: 16px;
	text-align: center;
}

.loading-placeholder {
	display: flex;
	justify-content: center;
	align-items: center;
	height: 100%;
	font-size: 16px;
	color: #037ee5;
}

.cart-content {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	padding: 40px;
	text-align: center;
}

.empty-cart-icon {
	width: 120px;
	height: 120px;
	margin-bottom: 20px;
	opacity: 0.6;
}

.empty-cart-text {
	font-size: 18px;
	color: #666;
	margin-bottom: 20px;
}

.continue-shopping-btn {
	display: inline-block;
	padding: 12px 24px;
	background-color: #007bff;
	color: white;
	text-decoration: none;
	border-radius: 6px;
	font-weight: 500;
	transition: background-color 0.3s ease;
}

.continue-shopping-btn:hover {
	background-color: #0056b3;
}

.button-group {
	display: flex;
	gap: 10px;
	width: 100%;
	padding: 16px;
	max-width: 600px;
	margin: 0 auto;
	background: #ffffff;
}

.main-button {
	flex: 1;
}

.main-button :deep(.custom-button) {
	width: 100%;
	height: 52px;
	background-color: #007aff;
	color: #ffffff;
}

.cancel-button {
	width: auto;
}

.cancel-button :deep(.custom-button) {
	height: 52px;
	padding: 0 20px;
	background-color: #f8f8f8;
	color: rgba(0, 0, 0, 0.5);
}

.price-option-button .promotion-end-date {
	font-size: 12px;
	color: #797e86;
	margin-top: 4px;
}
</style>


