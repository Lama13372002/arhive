export const closeKeyboard = {
  mounted(el) {
    el.addEventListener('click', (event) => {
      // Проверяем, что клик был не по полю ввода
      if (
        !event.target.matches('input') && 
        !event.target.matches('textarea') &&
        !event.target.matches('[contenteditable="true"]')
      ) {
        // Используем Telegram WebApp API для закрытия клавиатуры
        if (window.Telegram?.WebApp?.closeScanQrPopup) {
          window.Telegram.WebApp.closeScanQrPopup();
        }
        // Убираем фокус с активного элемента
        if (document.activeElement instanceof HTMLElement) {
          document.activeElement.blur();
        }
      }
    });
  }
};
