import AdminJSExpress from '@adminjs/express';
import AdminJSSequelize from '@adminjs/sequelize';
import AdminJS from 'adminjs';
import dotenv from 'dotenv';
import express from 'express';
import session from 'express-session';
import fs from 'fs';
import helmet from 'helmet';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import { v4 as uuidv4 } from 'uuid';
import db from './models/index.js';

dotenv.config();

// Синхронизация моделей с базой данных
await db.syncModels();

// Register AdminJS Sequelize adapter before importing adminConfig
AdminJS.registerAdapter(AdminJSSequelize);

// Import adminConfig after registering the adapter
import { adminJsOptions, authOptions } from './admin/adminConfig.js';
import errorHandler from './middlewares/errorHandler.js';
import { preflightMiddleware } from './middlewares/preflightMiddleware.js';
import settingsRouter from './routes/botMessagesRouter.js';
import apiRouter from './routes/index.js';
import paymentRouter from './routes/payment.js';

// Импортируем задачу для рассылок
import './tasks/mailingTask.js';
// Импортируем задачу для проверки истекших скидок
import './tasks/discountExpirationTask.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Определяем пути к директориям
const APP_ROOT =
	process.env.NODE_ENV === 'production' ? '/app' : path.join(__dirname, '..');
const publicDir = path.join(APP_ROOT, 'public');
const uploadsDir = path.join(APP_ROOT, 'uploads');

// Создаем директории, если они не существуют
console.log('Initializing directories...');
[publicDir, uploadsDir].forEach(dir => {
	if (!fs.existsSync(dir)) {
		console.log(`Creating directory: ${dir}`);
		fs.mkdirSync(dir, { recursive: true });
	} else {
		console.log(`Directory exists: ${dir}`);
	}
});

// Проверяем наличие upload.html
const uploadHtmlPath = path.join(publicDir, 'upload.html');
if (!fs.existsSync(uploadHtmlPath)) {
	console.log(`upload.html not found at: ${uploadHtmlPath}`);
	console.log('Contents of public directory:', fs.readdirSync(publicDir));
} else {
	console.log(`upload.html found at: ${uploadHtmlPath}`);
}

// Настройка multer для загрузки файлов
const storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, uploadsDir);
	},
	filename: function (req, file, cb) {
		const ext = path.extname(file.originalname);
		cb(null, `${uuidv4()}${ext}`);
	},
});

const upload = multer({ storage: storage });

const app = express();

// Применяем preflight middleware до всех остальных middleware
app.use(preflightMiddleware);

// Настройка CSP
app.use(
	helmet({
		contentSecurityPolicy: {
			directives: {
				defaultSrc: ["'self'", 'http:', 'https:'],
				styleSrc: [
					"'self'",
					"'unsafe-inline'",
					'http:',
					'https:',
					'https://fonts.googleapis.com',
					'https://45.131.41.247:3443',
				],
				scriptSrc: [
					"'self'",
					"'unsafe-inline'",
					"'unsafe-eval'",
					'http:',
					'https:',
					'https://45.131.41.247:3443',
				],
				fontSrc: [
					"'self'",
					'https://fonts.gstatic.com',
					'http:',
					'https:',
				],
				imgSrc: ["'self'", 'data:', 'blob:', 'http:', 'https:'],
				connectSrc: [
					"'self'",
					'http:',
					'https:',
					'https://45.131.41.247:3443',
					'http://localhost:3000',
				],
				formAction: ["'self'"],
				frameAncestors: ["'none'"],
				objectSrc: ["'none'"],
				upgradeInsecureRequests: null,
			},
		},
		crossOriginEmbedderPolicy: false,
		crossOriginResourcePolicy: { policy: 'cross-origin' },
	})
);

console.log('Public directory:', publicDir);
console.log('Uploads directory:', uploadsDir);

// Middleware для установки CORS заголовков на статические файлы
app.use('/uploads', (req, res, next) => {
	res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
	res.setHeader('Access-Control-Allow-Origin', '*');
	next();
});

// Убедимся, что статические файлы обслуживаются до всех остальных маршрутов
app.use(express.static(publicDir));
app.use('/uploads', express.static(uploadsDir));

// Роут для загрузки файла
app.post('/upload', upload.single('file'), (req, res) => {
	if (!req.file) {
		return res.status(400).json({ error: 'Файл не загружен' });
	}

	const fileUrl = `/uploads/${req.file.filename}`;
	res.json({
		url: fileUrl,
		filename: req.file.filename,
		originalname: req.file.originalname,
		size: req.file.size,
		mimetype: req.file.mimetype,
	});
});

// Сессии
app.use(
	session({
		secret: process.env.SESSION_SECRET || 'some-secret-key',
		resave: false,
		saveUninitialized: false,
		cookie: {
			secure: false, 
			sameSite: 'lax', 
			maxAge: 24 * 60 * 60 * 1000, // 24 hours
		},
	})
);

// Инициализация AdminJS
const admin = new AdminJS({
	...adminJsOptions,
	assets: {
		styles: ['/style.css'],
	},
	branding: {
		companyName: 'Game Shop Admin',
		logo: false,
		softwareBrothers: false,
	},
});

if (process.env.NODE_ENV === 'development') {
	admin.watch();
}

// Создаем роутер AdminJS
const adminRouter = AdminJSExpress.buildAuthenticatedRouter(
	admin,
	authOptions,
	null,
	{
		resave: false,
		saveUninitialized: true,
		secret: process.env.SESSION_SECRET || 'some-secret-key',
		cookie: {
			httpOnly: true,
			secure: false, // Отключаем secure для тестирования
			sameSite: 'lax', // Изменяем с 'none' на 'lax'
			maxAge: 24 * 60 * 60 * 1000, // 24 hours
		},
	}
);

// Монтируем роутер AdminJS
app.use(admin.options.rootPath, adminRouter);

// Парсинг JSON и form data ПОСЛЕ AdminJS
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API роуты
app.use('/api', apiRouter);
app.use('/api/settings', settingsRouter);
app.use('/api/payment', paymentRouter);

// Обработка ошибок
app.use(errorHandler);

export default app;
