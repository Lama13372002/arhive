import pkg from 'pg';
const { Client } = pkg;

const client = new Client({
  host: '193.17.92.132',
  port: 5432,
  database: 'game_shop_db',
  user: 'nkarasyov',
  password: 'pAssW_ord123',
});

async function addCurrencyColumn() {
  try {
    await client.connect();
    console.log('✓ Connected to database\n');

    // Проверяем существует ли таблица
    const tableExists = await client.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables
        WHERE table_name = 'UsedPromos'
      );
    `);

    if (!tableExists.rows[0].exists) {
      console.log('Table UsedPromos does not exist yet. Nothing to do.');
      await client.end();
      return;
    }

    // Проверяем существует ли столбец currencyId
    const columnExists = await client.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.columns
        WHERE table_name = 'UsedPromos'
        AND column_name = 'currencyId'
      );
    `);

    if (columnExists.rows[0].exists) {
      console.log('Column currencyId already exists in UsedPromos table.');
    } else {
      console.log('Adding currencyId column to UsedPromos table...');

      // Добавляем столбец currencyId со значением по умолчанию 1
      await client.query(`
        ALTER TABLE "UsedPromos"
        ADD COLUMN "currencyId" INTEGER NOT NULL DEFAULT 1;
      `);

      console.log('✓ Column currencyId added successfully');
    }

    // Добавляем внешний ключ на таблицу Currencies если он не существует
    const fkExists = await client.query(`
      SELECT EXISTS (
        SELECT 1
        FROM information_schema.table_constraints
        WHERE constraint_type = 'FOREIGN KEY'
        AND table_name = 'UsedPromos'
        AND constraint_name LIKE '%currencyId_fkey%'
      );
    `);

    if (!fkExists.rows[0].exists) {
      console.log('Adding foreign key constraint...');
      await client.query(`
        ALTER TABLE "UsedPromos"
        ADD CONSTRAINT "UsedPromos_currencyId_fkey"
        FOREIGN KEY ("currencyId")
        REFERENCES "Currencies"(id)
        ON UPDATE CASCADE
        ON DELETE CASCADE;
      `);
      console.log('✓ Foreign key constraint added');
    } else {
      console.log('Foreign key constraint already exists');
    }

    // Удаляем старый уникальный индекс если он существует
    console.log('\nDropping old unique index if exists...');
    await client.query('DROP INDEX IF EXISTS "used_promos_user_id_promo_id";');
    console.log('✓ Old index dropped');

    // Создаем новый уникальный индекс с учетом currencyId
    console.log('Creating new unique index...');
    await client.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS "used_promos_user_id_promo_id_currency_id"
      ON "UsedPromos" ("userId", "promoId", "currencyId");
    `);
    console.log('✓ New unique index created');

    console.log('\n✓ Migration completed successfully!');

  } catch (error) {
    console.error('❌ Error:', error.message);
    console.error(error);
  } finally {
    await client.end();
    console.log('\n✓ Disconnected from database');
  }
}

addCurrencyColumn();
