#!/bin/bash

# Load environment variables
export $(cat .env.development | grep -v '^#' | xargs)

# Start backend
cd backend
echo "Installing backend dependencies..."
npm install
echo "Starting backend..."
NODE_ENV=development USE_SSL=false USE_HTTPS=false npm run dev &
cd ..

# Start bot
cd bot
echo "Installing bot dependencies..."
npm install
echo "Starting bot..."
NODE_ENV=development BACKEND_URL=http://localhost:3000/api npm run dev &
cd ..

# Start frontend
cd frontend
echo "Installing frontend dependencies..."
npm install
echo "Starting frontend..."
npm run dev -- --host --port 5312

# The script will keep running until Ctrl+C is pressed
trap "trap - SIGTERM && kill -- -$$" SIGINT SIGTERM EXIT
