#!/bin/bash

# Скрипт автоматической установки nginx для testpw.ru
# Использование: sudo bash install.sh

set -e  # Остановка при ошибке

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Функция для вывода цветного текста
print_status() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

# Проверка что скрипт запущен от root
if [ "$EUID" -ne 0 ]; then
    print_error "Пожалуйста, запустите скрипт с sudo"
    exit 1
fi

DOMAIN="testpw.ru"

echo "================================================"
echo "  Установка nginx для $DOMAIN"
echo "================================================"
echo ""

# 1. Обновление системы
print_status "Обновление списков пакетов..."
apt update -qq

# 2. Установка nginx
if ! command -v nginx &> /dev/null; then
    print_status "Установка nginx..."
    apt install nginx -y
else
    print_status "nginx уже установлен"
fi

# 3. Установка certbot
if ! command -v certbot &> /dev/null; then
    print_status "Установка certbot..."
    apt install certbot -y
else
    print_status "certbot уже установлен"
fi

# 4. Настройка файрвола
print_status "Настройка файрвола..."
if command -v ufw &> /dev/null; then
    ufw allow 80/tcp
    ufw allow 443/tcp
    ufw allow 'Nginx Full'
    print_status "Файрвол настроен (ufw)"
fi

# 5. Создание необходимых директорий
print_status "Создание необходимых директорий..."
mkdir -p /usr/share/nginx/html
mkdir -p /app/uploads
mkdir -p /var/log/nginx

# Установка прав
chown -R www-data:www-data /usr/share/nginx/html
chown -R www-data:www-data /app/uploads
chmod -R 755 /usr/share/nginx/html
chmod -R 755 /app/uploads

# 6. Получение SSL сертификата
print_warning "Получение SSL сертификата для $DOMAIN"
echo "Убедитесь что:"
echo "  1. DNS запись для $DOMAIN указывает на этот сервер"
echo "  2. Порты 80 и 443 открыты"
echo ""
read -p "Продолжить получение сертификата? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    systemctl stop nginx || true

    if [ ! -d "/etc/letsencrypt/live/$DOMAIN" ]; then
        print_status "Получение SSL сертификата..."
        certbot certonly --standalone -d $DOMAIN --non-interactive --agree-tos --register-unsafely-without-email || {
            print_warning "Не удалось получить сертификат автоматически"
            print_warning "Запустите вручную: sudo certbot certonly --standalone -d $DOMAIN"
        }
    else
        print_status "SSL сертификат уже существует"
    fi

    systemctl start nginx
else
    print_warning "Пропуск получения SSL сертификата"
    print_warning "Получите сертификат вручную: sudo certbot certonly --standalone -d $DOMAIN"
fi

# 7. Установка конфигурации nginx
print_status "Установка конфигурации nginx..."

# Бэкап текущей конфигурации
if [ -f /etc/nginx/nginx.conf ]; then
    cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.backup.$(date +%Y%m%d_%H%M%S)
    print_status "Бэкап создан"
fi

# Копирование новой конфигурации
if [ -f "nginx.conf" ]; then
    cp nginx.conf /etc/nginx/nginx.conf
    print_status "Конфигурация установлена"
else
    print_error "Файл nginx.conf не найден в текущей директории"
    exit 1
fi

# 8. Проверка конфигурации
print_status "Проверка конфигурации nginx..."
if nginx -t; then
    print_status "Конфигурация валидна"
else
    print_error "Ошибка в конфигурации nginx"
    exit 1
fi

# 9. Перезагрузка nginx
print_status "Перезагрузка nginx..."
systemctl enable nginx
systemctl restart nginx

# 10. Настройка автообновления SSL
print_status "Настройка автообновления SSL сертификата..."
systemctl enable certbot.timer || {
    # Если systemd timer недоступен, используем cron
    (crontab -l 2>/dev/null; echo "0 0,12 * * * certbot renew --quiet && systemctl reload nginx") | crontab -
    print_status "Настроен cron для автообновления"
}

# 11. Проверка статуса
echo ""
echo "================================================"
print_status "Установка завершена!"
echo "================================================"
echo ""

# Вывод статуса сервисов
systemctl status nginx --no-pager -l

echo ""
echo "Полезные команды:"
echo "  - Проверка конфигурации: sudo nginx -t"
echo "  - Перезагрузка nginx: sudo systemctl reload nginx"
echo "  - Просмотр логов: sudo tail -f /var/log/nginx/error.log"
echo "  - Статус nginx: sudo systemctl status nginx"
echo ""
echo "Проверьте сайт: https://$DOMAIN"
echo ""

# Проверка доступности
if [ -d "/etc/letsencrypt/live/$DOMAIN" ]; then
    print_status "SSL сертификат установлен"
    openssl x509 -in /etc/letsencrypt/live/$DOMAIN/cert.pem -noout -dates
else
    print_warning "SSL сертификат не найден"
    print_warning "Получите сертификат: sudo certbot certonly --standalone -d $DOMAIN"
fi

echo ""
print_warning "Важно:"
echo "  1. Убедитесь что Docker контейнеры backend:3443 и bot:3001 запущены"
echo "  2. Разместите фронтенд файлы в /usr/share/nginx/html"
echo "  3. Проверьте что DNS запись для $DOMAIN указывает на этот сервер"
echo ""
