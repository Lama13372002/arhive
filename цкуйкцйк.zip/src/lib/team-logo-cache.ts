class TeamLogoCache {
  private cache = new Map<string, string>();
  private loadingPromises = new Map<string, Promise<string | null>>();
  private readonly CACHE_KEY = 'team_logos_cache';
  private readonly CACHE_EXPIRY_KEY = 'team_logos_cache_expiry';
  private readonly CACHE_DURATION = 7 * 24 * 60 * 60 * 1000; // 7 дней в миллисекундах

  constructor() {
    this.loadCacheFromStorage();
  }

  // Загружаем кеш из localStorage при инициализации
  private loadCacheFromStorage(): void {
    try {
      const cachedData = localStorage.getItem(this.CACHE_KEY);
      const cacheExpiry = localStorage.getItem(this.CACHE_EXPIRY_KEY);

      if (cachedData && cacheExpiry) {
        const expiryTime = parseInt(cacheExpiry, 10);

        if (Date.now() < expiryTime) {
          const parsedCache = JSON.parse(cachedData);
          this.cache = new Map(Object.entries(parsedCache));
          console.log(`Загружен кеш логотипов: ${this.cache.size} записей`);
        } else {
          // Кеш истек, очищаем
          this.clearExpiredCache();
        }
      }
    } catch (error) {
      console.error('Ошибка загрузки кеша логотипов:', error);
      this.clearExpiredCache();
    }
  }

  // Сохраняем кеш в localStorage
  private saveCacheToStorage(): void {
    try {
      const cacheObject = Object.fromEntries(this.cache);
      localStorage.setItem(this.CACHE_KEY, JSON.stringify(cacheObject));
      localStorage.setItem(this.CACHE_EXPIRY_KEY, (Date.now() + this.CACHE_DURATION).toString());
    } catch (error) {
      console.error('Ошибка сохранения кеша логотипов:', error);
    }
  }

  // Очищаем истекший кеш
  private clearExpiredCache(): void {
    localStorage.removeItem(this.CACHE_KEY);
    localStorage.removeItem(this.CACHE_EXPIRY_KEY);
    this.cache.clear();
  }

  // Нормализация названия команды для кеша
  private normalizeTeamName(teamName: string): string {
    return teamName.toLowerCase().trim().replace(/\s+/g, '_');
  }

  // Получить логотип из кеша
  getCachedLogo(teamName: string): string | null {
    const normalizedName = this.normalizeTeamName(teamName);
    return this.cache.get(normalizedName) || null;
  }

  // Сохранить логотип в кеш
  private setCachedLogo(teamName: string, logoUrl: string): void {
    const normalizedName = this.normalizeTeamName(teamName);
    this.cache.set(normalizedName, logoUrl);
    this.saveCacheToStorage();
  }

  // Загрузить логотип команды через API
  async loadTeamLogo(teamName: string): Promise<string | null> {
    const normalizedName = this.normalizeTeamName(teamName);

    // Проверяем кеш
    const cached = this.getCachedLogo(teamName);
    if (cached) {
      return cached;
    }

    // Проверяем, не загружается ли уже этот логотип
    const existingPromise = this.loadingPromises.get(normalizedName);
    if (existingPromise) {
      return existingPromise;
    }

    // Создаем новый запрос
    const loadingPromise = this.fetchTeamLogoFromAPI(teamName);
    this.loadingPromises.set(normalizedName, loadingPromise);

    try {
      const logoUrl = await loadingPromise;

      if (logoUrl) {
        this.setCachedLogo(teamName, logoUrl);
      }

      return logoUrl;
    } catch (error) {
      console.error(`Ошибка загрузки логотипа для команды ${teamName}:`, error);
      return null;
    } finally {
      this.loadingPromises.delete(normalizedName);
    }
  }

  // Загрузка логотипа через API
  private async fetchTeamLogoFromAPI(teamName: string): Promise<string | null> {
    interface TeamApiResponse {
      teams: Array<{
        id: number;
        name: string;
        logo: string;
        country: string;
        founded?: number;
      }>;
    }

    try {
      const response = await fetch('/api/football/teams', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ search: teamName }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data: TeamApiResponse = await response.json();

      if (data.teams && data.teams.length > 0) {
        // Ищем наиболее подходящее совпадение
        const exactMatch = data.teams.find((team) =>
          team.name.toLowerCase() === teamName.toLowerCase()
        );

        if (exactMatch && exactMatch.logo) {
          return exactMatch.logo;
        }

        // Если точного совпадения нет, ищем частичное
        const partialMatch = data.teams.find((team) =>
          team.name.toLowerCase().includes(teamName.toLowerCase()) ||
          teamName.toLowerCase().includes(team.name.toLowerCase())
        );

        if (partialMatch && partialMatch.logo) {
          return partialMatch.logo;
        }
      }

      return null;
    } catch (error) {
      console.error(`API error for team ${teamName}:`, error);
      return null;
    }
  }

  // Массовая загрузка логотипов для команд
  async loadMultipleTeamLogos(teamNames: string[]): Promise<{ [teamName: string]: string | null }> {
    const uniqueTeams = [...new Set(teamNames)];
    const results: { [teamName: string]: string | null } = {};

    // Ограничиваем количество одновременных запросов
    const BATCH_SIZE = 3;

    for (let i = 0; i < uniqueTeams.length; i += BATCH_SIZE) {
      const batch = uniqueTeams.slice(i, i + BATCH_SIZE);

      const batchPromises = batch.map(async (teamName) => {
        const logoUrl = await this.loadTeamLogo(teamName);
        return { teamName, logoUrl };
      });

      const batchResults = await Promise.all(batchPromises);

      for (const { teamName, logoUrl } of batchResults) {
        results[teamName] = logoUrl;
      }

      // Небольшая задержка между батчами для предотвращения перегрузки API
      if (i + BATCH_SIZE < uniqueTeams.length) {
        await new Promise(resolve => setTimeout(resolve, 100));
      }
    }

    return results;
  }

  // Предзагрузка логотипов для списка ставок
  async preloadLogosForBets(bets: Array<{ match: { homeTeam: string; awayTeam: string } }>): Promise<void> {
    const allTeams: string[] = [];

    for (const bet of bets) {
      if (bet.match.homeTeam) allTeams.push(bet.match.homeTeam);
      if (bet.match.awayTeam) allTeams.push(bet.match.awayTeam);
    }

    if (allTeams.length === 0) return;

    console.log(`Начинаем предзагрузку логотипов для ${allTeams.length} команд...`);

    const results = await this.loadMultipleTeamLogos(allTeams);

    const loadedCount = Object.values(results).filter(logo => logo !== null).length;
    console.log(`Предзагрузка завершена: ${loadedCount}/${allTeams.length} логотипов загружено`);
  }

  // Получить статистику кеша
  getCacheStats(): { size: number; teams: string[] } {
    return {
      size: this.cache.size,
      teams: Array.from(this.cache.keys())
    };
  }

  // Очистить весь кеш
  clearCache(): void {
    this.cache.clear();
    this.clearExpiredCache();
    console.log('Кеш логотипов очищен');
  }
}

// Создаем глобальный экземпляр
export const teamLogoCache = new TeamLogoCache();
