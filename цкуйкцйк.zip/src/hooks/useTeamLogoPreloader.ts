import { useEffect, useState, useCallback, useRef } from 'react';
import { teamLogoCache } from '@/lib/team-logo-cache';

interface TeamData {
  homeTeam: string;
  awayTeam: string;
  homeTeamLogo?: string;
  awayTeamLogo?: string;
}

interface UseTeamLogoPreloaderProps {
  teams: TeamData[];
  enabled?: boolean;
  batchSize?: number;
  delayBetweenBatches?: number;
}

interface UseTeamLogoPreloaderReturn {
  isLoading: boolean;
  loadedCount: number;
  totalCount: number;
  progress: number;
  error: string | null;
  reload: () => void;
  cacheStats: {
    size: number;
    teams: string[];
  };
}

export function useTeamLogoPreloader({
  teams,
  enabled = true,
  batchSize = 3,
  delayBetweenBatches = 100
}: UseTeamLogoPreloaderProps): UseTeamLogoPreloaderReturn {
  const [isLoading, setIsLoading] = useState(false);
  const [loadedCount, setLoadedCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [cacheStats, setCacheStats] = useState(() => teamLogoCache.getCacheStats());

  const abortControllerRef = useRef<AbortController | null>(null);

  // Получить список всех команд без логотипов
  const getTeamsToLoad = useCallback((teamData: TeamData[]): string[] => {
    const teamsToLoad: string[] = [];

    for (const team of teamData) {
      // Проверяем домашнюю команду
      if (team.homeTeam && !team.homeTeamLogo) {
        const cached = teamLogoCache.getCachedLogo(team.homeTeam);
        if (!cached) {
          teamsToLoad.push(team.homeTeam);
        }
      }

      // Проверяем гостевую команду
      if (team.awayTeam && !team.awayTeamLogo) {
        const cached = teamLogoCache.getCachedLogo(team.awayTeam);
        if (!cached) {
          teamsToLoad.push(team.awayTeam);
        }
      }
    }

    // Убираем дубликаты
    return [...new Set(teamsToLoad)];
  }, []);

  // Загрузка логотипов команд
  const loadLogos = useCallback(async (teamNames: string[], signal?: AbortSignal) => {
    if (teamNames.length === 0) {
      return;
    }

    setIsLoading(true);
    setLoadedCount(0);
    setTotalCount(teamNames.length);
    setError(null);

    try {
      // Загружаем логотипы батчами
      for (let i = 0; i < teamNames.length; i += batchSize) {
        if (signal?.aborted) {
          throw new Error('Загрузка отменена');
        }

        const batch = teamNames.slice(i, i + batchSize);

        const batchPromises = batch.map(async (teamName) => {
          try {
            const logoUrl = await teamLogoCache.loadTeamLogo(teamName);
            return { teamName, logoUrl, success: true };
          } catch (error) {
            console.error(`Ошибка загрузки логотипа для ${teamName}:`, error);
            return { teamName, logoUrl: null, success: false };
          }
        });

        await Promise.all(batchPromises);

        setLoadedCount(prev => prev + batch.length);

        // Задержка между батчами
        if (i + batchSize < teamNames.length && delayBetweenBatches > 0) {
          await new Promise(resolve => setTimeout(resolve, delayBetweenBatches));
        }
      }

      // Обновляем статистику кеша
      setCacheStats(teamLogoCache.getCacheStats());

      console.log(`✅ Предзагрузка завершена: ${teamNames.length} логотипов обработано`);

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      if (errorMessage !== 'Загрузка отменена') {
        setError(errorMessage);
        console.error('Ошибка при предзагрузке логотипов:', error);
      }
    } finally {
      setIsLoading(false);
    }
  }, [batchSize, delayBetweenBatches]);

  // Основная функция предзагрузки
  const preloadLogos = useCallback(async () => {
    // Отменяем предыдущую загрузку если она идет
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    const teamsToLoad = getTeamsToLoad(teams);

    if (teamsToLoad.length === 0) {
      console.log('📋 Все логотипы уже загружены или присутствуют в исходных данных');
      return;
    }

    console.log(`🚀 Начинаем предзагрузку логотипов для ${teamsToLoad.length} команд:`, teamsToLoad);

    // Создаем новый AbortController
    abortControllerRef.current = new AbortController();

    await loadLogos(teamsToLoad, abortControllerRef.current.signal);
  }, [teams, getTeamsToLoad, loadLogos]);

  // Функция для принудительной перезагрузки
  const reload = useCallback(() => {
    if (enabled) {
      preloadLogos();
    }
  }, [enabled, preloadLogos]);

  // Автоматическая предзагрузка при изменении команд
  useEffect(() => {
    if (enabled && teams.length > 0) {
      preloadLogos();
    }

    // Cleanup: отменяем загрузку при размонтировании
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [enabled, teams, preloadLogos]);

  // Вычисляем прогресс
  const progress = totalCount > 0 ? Math.round((loadedCount / totalCount) * 100) : 0;

  return {
    isLoading,
    loadedCount,
    totalCount,
    progress,
    error,
    reload,
    cacheStats
  };
}

// Дополнительный хук для компонентов которые просто хотят знать статус кеша
export function useTeamLogoCacheStats() {
  const [stats, setStats] = useState(() => teamLogoCache.getCacheStats());

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(teamLogoCache.getCacheStats());
    }, 5000); // Обновляем каждые 5 секунд

    return () => clearInterval(interval);
  }, []);

  return stats;
}
