import { NextRequest, NextResponse } from 'next/server';
import { footballApi } from '@/lib/football-api';

interface TeamApiResponse {
  team: {
    id: number;
    name: string;
    logo: string;
    country: string;
    founded?: number;
  };
  venue?: {
    id: number;
    name: string;
    address: string;
    city: string;
    capacity: number;
    surface: string;
    image: string;
  };
}

interface TeamsRequestBody {
  search?: string;
  league?: number;
  season?: number;
}

export async function POST(request: NextRequest) {
  try {
    const { search, league, season }: TeamsRequestBody = await request.json();

    if (!search && !league) {
      return NextResponse.json(
        { error: 'Необходимо указать параметр search или league' },
        { status: 400 }
      );
    }

    const params: Record<string, string | number> = {};

    if (search) {
      params.search = search;
    }

    if (league) {
      params.league = league;
    }

    if (season) {
      params.season = season;
    }

    const response = await footballApi.getTeams(params);

    if (!response || !response.response) {
      return NextResponse.json(
        { error: 'Не удалось получить данные команд' },
        { status: 500 }
      );
    }

    // Преобразуем ответ в удобный формат, соответствующий типу Team
    const teams = (response.response as TeamApiResponse[]).map((teamData) => ({
      id: teamData.team.id,
      name: teamData.team.name,
      logo: teamData.team.logo,
      country: teamData.team.country,
      founded: teamData.team.founded,
      venue: teamData.venue ? {
        name: teamData.venue.name,
        capacity: teamData.venue.capacity
      } : undefined
    }));

    return NextResponse.json({
      success: true,
      teams,
      count: teams.length
    });

  } catch (error) {
    console.error('Error fetching teams:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json(
      {
        error: 'Внутренняя ошибка сервера',
        details: errorMessage
      },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const search = searchParams.get('search');
  const league = searchParams.get('league');
  const season = searchParams.get('season');

  try {
    if (!search && !league) {
      return NextResponse.json(
        { error: 'Необходимо указать параметр search или league' },
        { status: 400 }
      );
    }

    const params: Record<string, string | number> = {};

    if (search) {
      params.search = search;
    }

    if (league) {
      params.league = parseInt(league);
    }

    if (season) {
      params.season = parseInt(season);
    }

    const response = await footballApi.getTeams(params);

    if (!response || !response.response) {
      return NextResponse.json(
        { error: 'Не удалось получить данные команд' },
        { status: 500 }
      );
    }

    // Преобразуем ответ в удобный формат, соответствующий типу Team
    const teams = (response.response as TeamApiResponse[]).map((teamData) => ({
      id: teamData.team.id,
      name: teamData.team.name,
      logo: teamData.team.logo,
      country: teamData.team.country,
      founded: teamData.team.founded,
      venue: teamData.venue ? {
        name: teamData.venue.name,
        capacity: teamData.venue.capacity
      } : undefined
    }));

    return NextResponse.json({
      success: true,
      teams,
      count: teams.length
    });

  } catch (error) {
    console.error('Error fetching teams:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json(
      {
        error: 'Внутренняя ошибка сервера',
        details: errorMessage
      },
      { status: 500 }
    );
  }
}
