'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Eye, EyeOff, Settings, DollarSign, Users, TrendingUp, Bell, BarChart3, Shield, Cpu, Activity, Zap, Star, Crown } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import UsersManagement from '@/components/admin/UsersManagement';
import StatisticsPanel from '@/components/admin/StatisticsPanel';

interface Setting {
  setting_key: string;
  setting_value: string;
  description: string;
  created_at: string;
  updated_at: string;
}

interface PushResult {
  totalUsers: number;
  successCount: number;
  errorCount: number;
  errorBreakdown: {
    chatNotFound: number;
    botBlocked: number;
    userDeactivated: number;
    rateLimited: number;
    other: number;
  };
  errors: string[];
}

export default function AdminPanel() {
  const [minimumUsdAmount, setMinimumUsdAmount] = useState('');
  const [commissionRate, setCommissionRate] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState<'success' | 'error'>('success');
  const [allSettings, setAllSettings] = useState<Setting[]>([]);
  const [sessionTimeLeft, setSessionTimeLeft] = useState<number>(0);

  // Состояние для push-уведомлений
  const [pushMessage, setPushMessage] = useState('');
  const [pushLoading, setPushLoading] = useState(false);
  const [pushResult, setPushResult] = useState<PushResult | null>(null);

  // Проверяем кешированную аутентификацию при загрузке
  useEffect(() => {
    const checkCachedAuth = () => {
      try {
        const cachedAuth = localStorage.getItem('admin_auth_cache');
        if (cachedAuth) {
          const authData = JSON.parse(cachedAuth);
          const now = Date.now();
          const tenMinutes = 10 * 60 * 1000; // 10 минут в миллисекундах

          if (now - authData.timestamp < tenMinutes) {
            setAdminPassword(authData.password);
            setIsAuthenticated(true);
            setMessage('Автоматический вход по сохраненным данным');
            setMessageType('success');
            setTimeout(() => setMessage(''), 3000);
          } else {
            // Удаляем устаревший кеш
            localStorage.removeItem('admin_auth_cache');
          }
        }
      } catch (error) {
        console.error('Ошибка при проверке кешированной аутентификации:', error);
        localStorage.removeItem('admin_auth_cache');
      }
    };

    checkCachedAuth();
  }, []);

  // Отслеживаем время сессии
  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isAuthenticated) {
      interval = setInterval(() => {
        try {
          const cachedAuth = localStorage.getItem('admin_auth_cache');
          if (cachedAuth) {
            const authData = JSON.parse(cachedAuth);
            const now = Date.now();
            const tenMinutes = 10 * 60 * 1000;
            const timeLeft = tenMinutes - (now - authData.timestamp);

            if (timeLeft <= 0) {
              // Время истекло, выходим
              setIsAuthenticated(false);
              setAdminPassword('');
              localStorage.removeItem('admin_auth_cache');
              setMessage('Сессия истекла. Войдите заново.');
              setMessageType('error');
              setSessionTimeLeft(0);
            } else {
              setSessionTimeLeft(Math.ceil(timeLeft / 1000)); // в секундах
            }
          }
        } catch (error) {
          console.error('Ошибка при проверке времени сессии:', error);
        }
      }, 1000); // Обновляем каждую секунду
    }

    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isAuthenticated]);

  // Загружаем текущую минимальную сумму и commission_rate при аутентификации
  useEffect(() => {
    if (isAuthenticated) {
      loadMinimumUsdAmount();
      loadCommissionRate();
      loadAllSettings();
    }
  }, [isAuthenticated]);

  const loadMinimumUsdAmount = async () => {
    try {
      const response = await fetch('/api/admin/minimum-usd-amount');
      const data = await response.json();

      if (data.success) {
        setMinimumUsdAmount(data.minimumUsdAmount.toString());
      }
    } catch (error) {
      console.error('Ошибка при загрузке минимальной суммы в USD:', error);
    }
  };

  const loadCommissionRate = async () => {
    try {
      const response = await fetch(`/api/admin/settings?adminPassword=${adminPassword}`);
      const data = await response.json();

      if (data.success) {
        const commissionSetting = data.settings.find((s: Setting) => s.setting_key === 'commission_rate');
        if (commissionSetting) {
          setCommissionRate((parseFloat(commissionSetting.setting_value) * 100).toString());
        }
      }
    } catch (error) {
      console.error('Ошибка при загрузке commission_rate:', error);
    }
  };

  const loadAllSettings = async () => {
    try {
      const response = await fetch(`/api/admin/settings?adminPassword=${adminPassword}`);
      const data = await response.json();

      if (data.success) {
        setAllSettings(data.settings);
      }
    } catch (error) {
      console.error('Ошибка при загрузке настроек:', error);
    }
  };

  const handleAuth = async () => {
    if (!adminPassword) {
      setMessage('Введите пароль администратора');
      setMessageType('error');
      return;
    }

    setLoading(true);
    try {
      // Простая проверка авторизации через API настроек
      const response = await fetch(`/api/admin/settings?adminPassword=${adminPassword}`);
      const data = await response.json();

      if (data.success) {
        setIsAuthenticated(true);
        setMessage('Авторизация успешна');
        setMessageType('success');

        // Сохраняем аутентификацию в localStorage на 10 минут
        const authData = {
          password: adminPassword,
          timestamp: Date.now()
        };
        localStorage.setItem('admin_auth_cache', JSON.stringify(authData));
      } else {
        setMessage('Неверный пароль администратора');
        setMessageType('error');
      }
    } catch (error) {
      setMessage('Ошибка при авторизации');
      setMessageType('error');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateMinimumAmount = async () => {
    if (!minimumUsdAmount) {
      setMessage('Введите минимальную сумму в долларах');
      setMessageType('error');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/admin/minimum-usd-amount', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          minimumUsdAmount: parseFloat(minimumUsdAmount),
          adminPassword
        }),
      });

      const data = await response.json();

      if (data.success) {
        setMessage(data.message);
        setMessageType('success');
        loadAllSettings(); // Перезагружаем все настройки
      } else {
        setMessage(data.error);
        setMessageType('error');
      }
    } catch (error) {
      setMessage('Ошибка при обновлении настроек');
      setMessageType('error');
    } finally {
      setLoading(false);
    }
  };

  const extendSession = () => {
    if (isAuthenticated && adminPassword) {
      const authData = {
        password: adminPassword,
        timestamp: Date.now()
      };
      localStorage.setItem('admin_auth_cache', JSON.stringify(authData));
      setMessage('Сессия продлена на 10 минут');
      setMessageType('success');
      setTimeout(() => setMessage(''), 2000);
    }
  };

  const handleUpdateCommissionRate = async () => {
    if (!commissionRate) {
      setMessage('Введите размер комиссии');
      setMessageType('error');
      return;
    }

    const rate = parseFloat(commissionRate);
    if (isNaN(rate) || rate < 0 || rate > 100) {
      setMessage('Комиссия должна быть от 0% до 100%');
      setMessageType('error');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          settings: [{
            key: 'commission_rate',
            value: (rate / 100).toString(),
            description: 'Commission rate for bet winnings (' + rate + '%)'
          }],
          adminPassword
        }),
      });

      const data = await response.json();

      if (data.success) {
        setMessage(`Комиссия успешно изменена на ${rate}%`);
        setMessageType('success');
        loadAllSettings(); // Перезагружаем все настройки
      } else {
        setMessage(data.error);
        setMessageType('error');
      }
    } catch (error) {
      setMessage('Ошибка при обновлении комиссии');
      setMessageType('error');
    } finally {
      setLoading(false);
    }
  };

  const handleSendPush = async () => {
    if (!pushMessage.trim()) {
      setMessage('Введите текст сообщения');
      setMessageType('error');
      return;
    }

    if (!confirm('Вы уверены, что хотите отправить push-уведомление всем пользователям?')) {
      return;
    }

    setPushLoading(true);
    setPushResult(null);

    try {
      const response = await fetch('/api/admin/send-push', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: pushMessage,
          adminPassword
        }),
      });

      const data = await response.json();

      if (data.success) {
        setPushResult(data.statistics);
        setMessage(`Push-уведомления отправлены! Успешно: ${data.statistics.successCount}, Ошибок: ${data.statistics.errorCount}`);
        setMessageType('success');
        setPushMessage(''); // Очищаем поле после успешной отправки
      } else {
        setMessage(data.error || 'Ошибка при отправке push-уведомлений');
        setMessageType('error');
      }
    } catch (error) {
      setMessage('Ошибка при отправке push-уведомлений');
      setMessageType('error');
    } finally {
      setPushLoading(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 dark:from-slate-950 dark:via-purple-950 dark:to-slate-950 flex items-center justify-center p-4 relative overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-20 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl animate-pulse delay-500"></div>
        </div>

        <Card className="w-full max-w-md backdrop-blur-xl bg-white/10 dark:bg-black/20 border-white/20 dark:border-white/10 shadow-2xl relative z-10">
          <CardHeader className="text-center pb-8">
            <div className="mx-auto w-20 h-20 bg-gradient-to-br from-purple-500 to-cyan-500 rounded-2xl flex items-center justify-center mb-6 shadow-lg transform rotate-3 hover:rotate-0 transition-transform duration-300">
              <Crown className="w-10 h-10 text-white" />
            </div>
            <CardTitle className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 text-transparent bg-clip-text">
              Admin Portal
            </CardTitle>
            <CardDescription className="text-slate-300 dark:text-slate-400 text-lg">
              Добро пожаловать в панель управления
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <Label htmlFor="password" className="text-slate-200 dark:text-slate-300 font-medium">
                Пароль администратора
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  placeholder="Введите секретный пароль"
                  className="bg-white/10 dark:bg-black/20 border-white/20 dark:border-white/10 text-white placeholder-slate-400 backdrop-blur-sm pr-12"
                  onKeyPress={(e) => e.key === 'Enter' && handleAuth()}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-white/10 text-slate-400 hover:text-white"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>

            {message && (
              <Alert className={`backdrop-blur-sm border-0 ${
                messageType === 'error'
                  ? 'bg-red-500/20 text-red-200'
                  : 'bg-green-500/20 text-green-200'
              }`}>
                <AlertDescription className="font-medium">
                  {message}
                </AlertDescription>
              </Alert>
            )}

            <Button
              onClick={handleAuth}
              disabled={loading}
              className="w-full h-12 bg-gradient-to-r from-purple-500 to-cyan-500 hover:from-purple-600 hover:to-cyan-600 text-white font-medium rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200 border-0"
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <Cpu className="w-4 h-4 animate-spin" />
                  Проверка доступа...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  Войти в систему
                </div>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-slate-900 dark:via-purple-900 dark:to-slate-900 relative overflow-hidden">
      {/* Animated background for authenticated view */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-br from-cyan-400/20 to-pink-400/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="relative z-10 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Enhanced Header */}
          <Card className="backdrop-blur-xl bg-white/80 dark:bg-black/40 border-white/50 dark:border-white/10 shadow-xl">
            <CardHeader className="pb-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg transform rotate-3">
                    <Settings className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400 text-transparent bg-clip-text">
                      Control Center
                    </CardTitle>
                    <CardDescription className="text-slate-600 dark:text-slate-400 text-lg">
                      Полное управление платформой ставок
                    </CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  {sessionTimeLeft > 0 && (
                    <div className="flex items-center gap-2">
                      <div className="text-sm text-slate-600 dark:text-slate-400">
                        <div className="flex items-center gap-2">
                          <Activity className="w-4 h-4" />
                          Сессия: {Math.floor(sessionTimeLeft / 60)}:{(sessionTimeLeft % 60).toString().padStart(2, '0')}
                        </div>
                      </div>
                      {sessionTimeLeft < 300 && ( // Показываем кнопку когда остается меньше 5 минут
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={extendSession}
                          className="text-xs bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 dark:hover:bg-blue-900/40 text-blue-700 dark:text-blue-300"
                        >
                          Продлить
                        </Button>
                      )}
                    </div>
                  )}
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsAuthenticated(false);
                      setAdminPassword('');
                      localStorage.removeItem('admin_auth_cache');
                      setMessage('Вы вышли из системы');
                      setMessageType('success');
                    }}
                    className="bg-white/50 dark:bg-black/20 backdrop-blur-sm border-slate-300 dark:border-slate-600 hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-700 dark:text-slate-300"
                  >
                    <Shield className="w-4 h-4 mr-2" />
                    Выйти
                  </Button>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Enhanced Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="backdrop-blur-xl bg-gradient-to-br from-green-500/10 to-emerald-500/10 dark:from-green-500/20 dark:to-emerald-500/20 border-green-200/50 dark:border-green-400/30 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center shadow-lg">
                    <DollarSign className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-green-700 dark:text-green-400 font-medium mb-1">Комиссия</p>
                    <p className="text-2xl font-bold text-green-800 dark:text-green-300">{commissionRate}%</p>
                    <p className="text-xs text-green-600 dark:text-green-500">С выигрышных ставок</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-xl bg-gradient-to-br from-blue-500/10 to-cyan-500/10 dark:from-blue-500/20 dark:to-cyan-500/20 border-blue-200/50 dark:border-blue-400/30 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg">
                    <Cpu className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-blue-700 dark:text-blue-400 font-medium mb-1">Конфигураций</p>
                    <p className="text-2xl font-bold text-blue-800 dark:text-blue-300">{allSettings.filter(s => s.setting_key !== 'minimum_bet_amount').length}</p>
                    <p className="text-xs text-blue-600 dark:text-blue-500">Активных настроек</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-xl bg-gradient-to-br from-purple-500/10 to-pink-500/10 dark:from-purple-500/20 dark:to-pink-500/20 border-purple-200/50 dark:border-purple-400/30 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center shadow-lg">
                    <Activity className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-purple-700 dark:text-purple-400 font-medium mb-1">Статус системы</p>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-sm font-bold text-green-600 dark:text-green-400">Онлайн</span>
                    </div>
                    <p className="text-xs text-purple-600 dark:text-purple-500">Все сервисы работают</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-xl bg-gradient-to-br from-orange-500/10 to-yellow-500/10 dark:from-orange-500/20 dark:to-yellow-500/20 border-orange-200/50 dark:border-orange-400/30 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-xl flex items-center justify-center shadow-lg">
                    <Zap className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-orange-700 dark:text-orange-400 font-medium mb-1">Производительность</p>
                    <p className="text-2xl font-bold text-orange-800 dark:text-orange-300">98%</p>
                    <p className="text-xs text-orange-600 dark:text-orange-500">Uptime за месяц</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Вкладки управления */}
          {/* Enhanced Tabs */}
          <Tabs defaultValue="statistics" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-white/80 dark:bg-black/40 backdrop-blur-xl border-white/50 dark:border-white/10 rounded-2xl p-2">
              <TabsTrigger
                value="statistics"
                className="flex items-center gap-2 rounded-xl data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-purple-500 data-[state=active]:text-white transition-all duration-300"
              >
                <BarChart3 className="w-4 h-4" />
                <span className="hidden sm:inline">Аналитика</span>
              </TabsTrigger>
              <TabsTrigger
                value="settings"
                className="flex items-center gap-2 rounded-xl data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500 data-[state=active]:to-emerald-500 data-[state=active]:text-white transition-all duration-300"
              >
                <Settings className="w-4 h-4" />
                <span className="hidden sm:inline">Настройки</span>
              </TabsTrigger>
              <TabsTrigger
                value="users"
                className="flex items-center gap-2 rounded-xl data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-pink-500 data-[state=active]:text-white transition-all duration-300"
              >
                <Users className="w-4 h-4" />
                <span className="hidden sm:inline">Пользователи</span>
              </TabsTrigger>
              <TabsTrigger
                value="push"
                className="flex items-center gap-2 rounded-xl data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white transition-all duration-300"
              >
                <Bell className="w-4 h-4" />
                <span className="hidden sm:inline">Уведомления</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="statistics" className="space-y-6">
              <StatisticsPanel adminPassword={adminPassword} />
            </TabsContent>

            <TabsContent value="settings" className="space-y-6">
              {/* Форма изменения минимальной суммы */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5" />
                    Минимальная сумма ставки
                  </CardTitle>
                  <CardDescription>
                    Измените минимальную сумму в долларах. Автоматически пересчитается в TON по текущему курсу
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="minimumAmount">Минимальная сумма (USD)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="minimumAmount"
                        type="number"
                        step="0.01"
                        min="0.1"
                        value={minimumUsdAmount}
                        onChange={(e) => setMinimumUsdAmount(e.target.value)}
                        placeholder="Введите минимальную сумму в долларах"
                        className="flex-1"
                      />
                      <Button
                        onClick={handleUpdateMinimumAmount}
                        disabled={loading}
                        className="min-w-[120px]"
                      >
                        {loading ? 'Сохранение...' : 'Сохранить'}
                      </Button>
                    </div>
                  </div>

                  {message && (
                    <Alert className={messageType === 'error' ? 'border-red-500 bg-red-50' : 'border-green-500 bg-green-50'}>
                      <AlertDescription className={messageType === 'error' ? 'text-red-700' : 'text-green-700'}>
                        {message}
                      </AlertDescription>
                    </Alert>
                  )}
                </CardContent>
              </Card>

              {/* Форма изменения комиссии */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" />
                    Комиссия с выигрышных ставок
                  </CardTitle>
                  <CardDescription>
                    Измените размер комиссии, взимаемой с выигрышных ставок (от 0% до 100%)
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="commissionRate">Размер комиссии (%)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="commissionRate"
                        type="number"
                        step="0.1"
                        min="0"
                        max="100"
                        value={commissionRate}
                        onChange={(e) => setCommissionRate(e.target.value)}
                        placeholder="Введите размер комиссии в процентах"
                        className="flex-1"
                      />
                      <Button
                        onClick={handleUpdateCommissionRate}
                        disabled={loading}
                        className="min-w-[120px]"
                      >
                        {loading ? 'Сохранение...' : 'Сохранить'}
                      </Button>
                    </div>
                  </div>
                  <div className="text-sm text-gray-600">
                    Текущая комиссия: {commissionRate}% (в базе данных: {allSettings.find(s => s.setting_key === 'commission_rate')?.setting_value || 'не найдено'})
                  </div>
                </CardContent>
              </Card>

              {/* Все настройки */}
              <Card>
                <CardHeader>
                  <CardTitle>Все настройки приложения</CardTitle>
                  <CardDescription>
                    Просмотр всех настроек в базе данных
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {allSettings
                      .filter(setting => setting.setting_key !== 'minimum_bet_amount')
                      .map((setting, index, filteredArray) => (
                      <div key={setting.setting_key}>
                        <div className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant="outline">{setting.setting_key}</Badge>
                              <span className="text-sm text-gray-700">
                                Обновлено: {new Date(setting.updated_at).toLocaleString('ru')}
                              </span>
                            </div>
                            <p className="font-mono text-sm bg-gray-100 p-2 rounded text-gray-900">
                              {setting.setting_value}
                            </p>
                            {setting.description && (
                              <p className="text-sm text-gray-800 mt-1">
                                {setting.description}
                              </p>
                            )}
                          </div>
                        </div>
                        {index < filteredArray.length - 1 && <Separator className="mt-4" />}
                      </div>
                    ))}

                    {allSettings.filter(s => s.setting_key !== 'minimum_bet_amount').length === 0 && (
                      <div className="text-center py-8 text-gray-700">
                        Настройки не найдены
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="users">
              <UsersManagement adminPassword={adminPassword} />
            </TabsContent>

            <TabsContent value="push" className="space-y-6">
              {/* Форма отправки push-уведомлений */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="w-5 h-5" />
                    Массовая отправка push-уведомлений
                  </CardTitle>
                  <CardDescription>
                    Отправить уведомление всем пользователям бота. Сообщение будет доставлено напрямую в Telegram.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="pushMessage">Текст сообщения</Label>
                    <Textarea
                      id="pushMessage"
                      value={pushMessage}
                      onChange={(e) => setPushMessage(e.target.value)}
                      placeholder="Введите текст push-уведомления..."
                      className="min-h-[120px] resize-vertical"
                      disabled={pushLoading}
                    />
                    <div className="text-sm text-gray-700">
                      Поддерживается HTML разметка: &lt;b&gt;жирный&lt;/b&gt;, &lt;i&gt;курсив&lt;/i&gt;, &lt;code&gt;код&lt;/code&gt;
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={handleSendPush}
                      disabled={pushLoading || !pushMessage.trim()}
                      className="min-w-[150px]"
                    >
                      {pushLoading ? 'Отправка...' : 'Отправить всем'}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setPushMessage('')}
                      disabled={pushLoading}
                    >
                      Очистить
                    </Button>
                  </div>

                  {message && (
                    <Alert className={messageType === 'error' ? 'border-red-500 bg-red-50' : 'border-green-500 bg-green-50'}>
                      <AlertDescription className={messageType === 'error' ? 'text-red-700' : 'text-green-700'}>
                        {message}
                      </AlertDescription>
                    </Alert>
                  )}

                  {/* Результаты отправки */}
                  {pushResult && (
                    <Card className="border-green-200 bg-green-50">
                      <CardHeader>
                        <CardTitle className="text-lg text-green-800">Результаты отправки</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-3 gap-4 mb-6">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-blue-600">{pushResult.totalUsers}</div>
                            <div className="text-sm text-gray-800">Всего пользователей</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-green-600">{pushResult.successCount}</div>
                            <div className="text-sm text-gray-800">Успешно отправлено</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-red-600">{pushResult.errorCount}</div>
                            <div className="text-sm text-gray-800">Всего ошибок</div>
                          </div>
                        </div>

                        {/* Детальная статистика ошибок */}
                        {pushResult.errorCount > 0 && (
                          <div className="mb-4">
                            <h4 className="font-semibold text-gray-700 mb-3">Детализация ошибок:</h4>
                            <div className="grid grid-cols-2 gap-3 text-sm">
                              {pushResult.errorBreakdown.chatNotFound > 0 && (
                                <div className="flex justify-between p-2 bg-yellow-100 rounded">
                                  <span>Чат не найден:</span>
                                  <Badge variant="outline" className="bg-yellow-200">{pushResult.errorBreakdown.chatNotFound}</Badge>
                                </div>
                              )}
                              {pushResult.errorBreakdown.botBlocked > 0 && (
                                <div className="flex justify-between p-2 bg-red-100 rounded">
                                  <span>Бот заблокирован:</span>
                                  <Badge variant="outline" className="bg-red-200">{pushResult.errorBreakdown.botBlocked}</Badge>
                                </div>
                              )}
                              {pushResult.errorBreakdown.userDeactivated > 0 && (
                                <div className="flex justify-between p-2 bg-gray-100 rounded">
                                  <span>Аккаунт деактивирован:</span>
                                  <Badge variant="outline" className="bg-gray-200">{pushResult.errorBreakdown.userDeactivated}</Badge>
                                </div>
                              )}
                              {pushResult.errorBreakdown.rateLimited > 0 && (
                                <div className="flex justify-between p-2 bg-orange-100 rounded">
                                  <span>Превышен лимит:</span>
                                  <Badge variant="outline" className="bg-orange-200">{pushResult.errorBreakdown.rateLimited}</Badge>
                                </div>
                              )}
                              {pushResult.errorBreakdown.other > 0 && (
                                <div className="flex justify-between p-2 bg-purple-100 rounded">
                                  <span>Другие ошибки:</span>
                                  <Badge variant="outline" className="bg-purple-200">{pushResult.errorBreakdown.other}</Badge>
                                </div>
                              )}
                            </div>
                          </div>
                        )}

                        {pushResult.errors && pushResult.errors.length > 0 && (
                          <div>
                            <h4 className="font-semibold text-red-700 mb-2">Примеры ошибок:</h4>
                            <div className="max-h-40 overflow-y-auto">
                              <ul className="list-disc list-inside text-sm text-red-600 space-y-1">
                                {pushResult.errors.map((error, index) => (
                                  <li key={index} className="break-words">{error}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}
                </CardContent>
              </Card>

              {/* Информация об ошибках */}
              <Card className="border-blue-200 bg-blue-50">
                <CardContent className="p-4">
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 text-blue-600 mt-0.5">ℹ️</div>
                    <div>
                      <h4 className="font-semibold text-blue-800">О возможных ошибках доставки</h4>
                      <ul className="text-sm text-blue-700 mt-1 space-y-1">
                        <li>• <strong>"Чат не найден"</strong> - пользователь никогда не писал боту или удалил аккаунт</li>
                        <li>• <strong>"Бот заблокирован"</strong> - пользователь заблокировал бота в Telegram</li>
                        <li>• <strong>"Аккаунт деактивирован"</strong> - пользователь удалил свой Telegram аккаунт</li>
                        <li>• Это нормальные ошибки для любой системы массовых рассылок</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Предупреждение */}
              <Card className="border-yellow-200 bg-yellow-50">
                <CardContent className="p-4">
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 text-yellow-600 mt-0.5">⚠️</div>
                    <div>
                      <h4 className="font-semibold text-yellow-800">Важная информация</h4>
                      <ul className="text-sm text-yellow-700 mt-1 space-y-1">
                        <li>• Уведомления отправляются всем активным пользователям</li>
                        <li>• Заблокированные в приложении пользователи не получат уведомления</li>
                        <li>• Между отправками есть задержка для соблюдения лимитов Telegram</li>
                        <li>• Используйте эту функцию ответственно</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
