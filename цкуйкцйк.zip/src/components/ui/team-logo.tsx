'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { teamLogoCache } from '@/lib/team-logo-cache';

interface TeamLogoProps {
  teamName: string;
  logoUrl?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  autoLoad?: boolean; // Автоматически загружать логотип если его нет
}

export function TeamLogo({ teamName, logoUrl, size = 'md', className = '', autoLoad = true }: TeamLogoProps) {
  const [imageError, setImageError] = useState(false);
  const [cachedLogoUrl, setCachedLogoUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const sizeClasses = {
    sm: 'w-6 h-6 text-xs',
    md: 'w-8 h-8 text-sm',
    lg: 'w-10 h-10 text-base',
    xl: 'w-12 h-12 text-lg'
  };

  // Автоматическая загрузка логотипа если его нет
  useEffect(() => {
    const loadLogo = async () => {
      // Если уже есть logoUrl, не нужно ничего загружать
      if (logoUrl) {
        return;
      }

      // Проверяем кеш
      const cached = teamLogoCache.getCachedLogo(teamName);
      if (cached) {
        setCachedLogoUrl(cached);
        return;
      }

      // Если autoLoad отключен, не загружаем
      if (!autoLoad) {
        return;
      }

      // Загружаем логотип
      setIsLoading(true);
      try {
        const loadedLogo = await teamLogoCache.loadTeamLogo(teamName);
        if (loadedLogo) {
          setCachedLogoUrl(loadedLogo);
        }
      } catch (error) {
        console.error(`Ошибка загрузки логотипа для ${teamName}:`, error);
      } finally {
        setIsLoading(false);
      }
    };

    loadLogo();
  }, [teamName, logoUrl, autoLoad]);

  const handleImageError = () => {
    setImageError(true);
  };

  // Определяем какой URL использовать
  const currentLogoUrl = logoUrl || cachedLogoUrl;

  // Если нет логотипа или произошла ошибка загрузки, показываем буквенный fallback
  if (!currentLogoUrl || imageError) {
    return (
      <div className={`${sizeClasses[size]} rounded-full bg-gradient-cosmic flex items-center justify-center text-white font-bold ${className} relative`}>
        {/* Индикатор загрузки */}
        {isLoading && (
          <div className="absolute inset-0 bg-black/20 rounded-full flex items-center justify-center">
            <div className="w-3 h-3 border border-white/30 border-t-white rounded-full animate-spin"></div>
          </div>
        )}
        {!isLoading && teamName.charAt(0).toUpperCase()}
      </div>
    );
  }

  return (
    <div className={`${sizeClasses[size]} relative ${className}`}>
      <Image
        src={currentLogoUrl}
        alt={teamName}
        fill
        className="object-contain rounded-full"
        onError={handleImageError}
      />
      {/* Индикатор загрузки */}
      {isLoading && (
        <div className="absolute inset-0 bg-black/20 rounded-full flex items-center justify-center">
          <div className="w-3 h-3 border border-white/30 border-t-white rounded-full animate-spin"></div>
        </div>
      )}
    </div>
  );
}
