"use client";

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

type Theme = "dark" | "light" | "system";

interface ThemeProviderContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const ThemeProviderContext = createContext<ThemeProviderContextType | undefined>(
  undefined
);

interface ThemeProviderProps {
  children: ReactNode;
  defaultTheme?: Theme;
  storageKey?: string;
  attribute?: string;
  enableSystem?: boolean;
  disableTransitionOnChange?: boolean;
}

export function ThemeProvider({
  children,
  defaultTheme = "dark",
  storageKey = "vite-ui-theme",
  attribute = "class",
  enableSystem = false,
  disableTransitionOnChange = false,
  ...props
}: ThemeProviderProps) {
  const [theme, setThemeState] = useState<Theme>("dark"); // Принудительно устанавливаем тёмную тему

  useEffect(() => {
    const root = window.document.documentElement;

    root.classList.remove("light", "dark");

    // Всегда устанавливаем тёмную тему, игнорируя системные настройки
    root.classList.add("dark");
  }, [theme, enableSystem]);

  const value = {
    theme: "dark" as Theme, // Всегда возвращаем "dark"
    setTheme: (theme: Theme) => {
      // Принудительно сохраняем только тёмную тему, игнорируя переданный параметр
      if (typeof window !== "undefined") {
        localStorage.setItem(storageKey, "dark");
      }
      setThemeState("dark");
    },
  };

  return (
    <ThemeProviderContext.Provider {...props} value={value}>
      {children}
    </ThemeProviderContext.Provider>
  );
}

export const useTheme = () => {
  const context = useContext(ThemeProviderContext);

  if (context === undefined)
    throw new Error("useTheme must be used within a ThemeProvider");

  return context;
};
