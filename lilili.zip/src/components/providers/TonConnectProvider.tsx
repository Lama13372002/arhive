'use client';

import { TonConnectUIProvider, THEME } from '@tonconnect/ui-react';
import { ReactNode, useEffect } from 'react';

const manifestUrl = typeof window !== 'undefined'
  ? `${window.location.origin}/tonconnect-manifest.json`
  : 'https://example.com/tonconnect-manifest.json';

interface TonConnectProviderProps {
  children: ReactNode;
}

export function TonConnectProvider({ children }: TonConnectProviderProps) {
  useEffect(() => {
    // Обработка ошибок TON Connect, особенно при сворачивании/разворачивании TMA
    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      if (event.reason?.message?.includes('Operation aborted') ||
          event.reason?.message?.includes('TON_CONNECT_SDK_ERROR')) {
        console.warn('TON Connect operation was aborted (likely due to app visibility change):', event.reason);
        event.preventDefault(); // Предотвращаем показ ошибки пользователю
      }
    };

    // Обработка изменения видимости страницы
    const handleVisibilityChange = () => {
      if (document.hidden) {
        console.log('TMA minimized - TON Connect operations may be aborted');
      } else {
        console.log('TMA restored - TON Connect operations resumed');
      }
    };

    // Добавляем обработчики
    window.addEventListener('unhandledrejection', handleUnhandledRejection);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Очистка при размонтировании
    return () => {
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  return (
    <TonConnectUIProvider
      manifestUrl={manifestUrl}
      uiPreferences={{
        theme: THEME.DARK,
        borderRadius: 'm',
      }}
      walletsListConfiguration={{
        includeWallets: [
          {
            appName: "Tonkeeper",
            name: "Tonkeeper",
            imageUrl: "https://tonkeeper.com/assets/tonconnect-icon.png",
            aboutUrl: "https://tonkeeper.com",
            universalLink: "https://app.tonkeeper.com/ton-connect",
            bridgeUrl: "https://bridge.tonapi.io/bridge",
            platforms: ["ios", "android", "chrome", "firefox"]
          },
          {
            appName: "TonWallet",
            name: "TON Wallet",
            imageUrl: "https://wallet.ton.org/assets/ui/qr-logo.png",
            aboutUrl: "https://chrome.google.com/webstore/detail/ton-wallet/nphplpgoakhhjchkkhmiggakijnkhfnd",
            universalLink: "https://wallet.ton.org/ton-connect",
            bridgeUrl: "https://bridge.tonapi.io/bridge",
            platforms: ["chrome", "android"]
          }
        ]
      }}
      actionsConfiguration={{
        twaReturnUrl: 'https://t.me/YOUR_BOT_NAME'
      }}
    >
      {children}
    </TonConnectUIProvider>
  );
}
