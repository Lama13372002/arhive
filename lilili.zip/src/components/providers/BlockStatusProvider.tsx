'use client';

import { createContext, useContext, useEffect, useState } from 'react';
import { useTelegramAuth } from '@/hooks/useTelegramAuth';
import BlockedUserModal from '@/components/BlockedUserModal';

interface BlockStatusContextType {
  isBlocked: boolean;
  isBlockedApp: boolean;
  isBlockedChat: boolean;
  blockReason: string | null;
  blockedAt: string | null;
  checkBlockStatus: () => void;
}

const BlockStatusContext = createContext<BlockStatusContextType | undefined>(undefined);

export function useBlockStatus() {
  const context = useContext(BlockStatusContext);
  if (context === undefined) {
    throw new Error('useBlockStatus must be used within a BlockStatusProvider');
  }
  return context;
}

interface BlockStatusProviderProps {
  children: React.ReactNode;
}

export function BlockStatusProvider({ children }: BlockStatusProviderProps) {
  const { telegramUser } = useTelegramAuth();
  const [isBlocked, setIsBlocked] = useState(false);
  const [isBlockedApp, setIsBlockedApp] = useState(false);
  const [isBlockedChat, setIsBlockedChat] = useState(false);
  const [blockReason, setBlockReason] = useState<string | null>(null);
  const [blockedAt, setBlockedAt] = useState<string | null>(null);

  const checkBlockStatus = async () => {
    if (!telegramUser?.id) return;

    try {
      const response = await fetch(`/api/user/check-block-status?telegramId=${telegramUser.id}`);
      const data = await response.json();

      if (data.success) {
        const userData = data.user;
        setIsBlockedApp(userData.is_blocked_app || false);
        setIsBlockedChat(userData.is_blocked_chat || false);
        setIsBlocked(userData.is_blocked_app || userData.is_blocked_chat || false);
        setBlockReason(userData.block_reason);
        setBlockedAt(userData.blocked_at);
      }
    } catch (error) {
      console.error('Ошибка при проверке статуса блокировки:', error);
    }
  };

  useEffect(() => {
    if (telegramUser?.id) {
      checkBlockStatus();
    }
  }, [telegramUser?.id]);

  const contextValue: BlockStatusContextType = {
    isBlocked,
    isBlockedApp,
    isBlockedChat,
    blockReason,
    blockedAt,
    checkBlockStatus
  };

  return (
    <BlockStatusContext.Provider value={contextValue}>
      {telegramUser?.id && (
        <BlockedUserModal
          telegramId={telegramUser.id.toString()}
          onBlockStatusChange={(blocked) => setIsBlocked(blocked)}
        />
      )}
      {children}
    </BlockStatusContext.Provider>
  );
}
