"use client";

import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import type { Bet, BetStats } from "@/types/api";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { UserAvatar } from "@/components/ui/user-avatar";
import { Separator } from "@/components/ui/separator";
import {
  Filter,
  Users,
  Clock,
  TrendingUp,
  Eye,
  ArrowRight,
  Coins,
  Star,
  Zap,
  Trophy,
  CheckCircle,
  Sparkles,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { motion, useAnimation } from "framer-motion";
import { useTelegram } from "@/components/providers/TelegramProvider";
import { betsApi, ApiError } from "@/lib/api";
import { JoinBetModal } from "@/components/modals/JoinBetModal";
import { BetDetailsModal } from "@/components/modals/BetDetailsModal";
import { OpenBetsI18nProvider, useOpenBetsI18n } from "@/components/providers/OpenBetsI18nProvider";
import { useI18n } from "@/components/providers/I18nProvider";
import { FEATURES } from "@/lib/features";

// Функция для определения статуса матча и времени
const getMatchStatusAndTime = (
  bet: Bet,
  t: (k: string, p?: Record<string | number, string | number>) => string,
  locale: 'ru-RU' | 'en-US'
) => {
  const now = new Date();
  const startTime = (bet.match?.start_time || bet.match_start_time || bet.start_time || bet.created_at) as string;
  const matchStart = new Date(startTime);
  const timeDiffMinutes = Math.floor((matchStart.getTime() - now.getTime()) / (1000 * 60));

  // Используем актуальные данные матча из API
  const matchStatus = (bet.match?.status || bet.match_status || '').toLowerCase();
  const matchMinute = bet.match?.minute;

  // Для live матчей используем минуты из API
  if (matchStatus === 'live' || matchStatus === 'in_progress' || matchStatus === '1h' || matchStatus === '2h') {
    if (matchMinute) {
      return { text: `${matchMinute}'`, color: 'text-green-400', icon: '🔴' };
    } else {
      // Если нет данных о минутах, вычисляем приблизительно
      const elapsedMinutes = Math.abs(timeDiffMinutes);
      return { text: `${Math.max(0, elapsedMinutes)}'`, color: 'text-green-400', icon: '🔴' };
    }
  }

  // Перерыв
  if (matchStatus === 'halftime' || matchStatus === 'ht') {
    return { text: t('halftime'), color: 'text-orange-400', icon: '⏸️' };
  }

  // Завершенные матчи
  if (matchStatus === 'finished' || matchStatus === 'ft' || matchStatus === 'completed') {
    return { text: t('finished'), color: 'text-gray-400', icon: '⚽' };
  }

  // Если матч должен был начаться, но статус неизвестен
  if (timeDiffMinutes <= 0) {
    return { text: t('soon'), color: 'text-orange-400', icon: '⚡' };
  }

  // Матч еще не начался - показываем время до начала или дату/время начала
  if (timeDiffMinutes <= 15) {
    return { text: t('soon'), color: 'text-orange-400', icon: '⚡' };
  } else if (timeDiffMinutes <= 60) {
    return { text: t('in_minutes', { m: timeDiffMinutes }), color: 'text-blue-400', icon: '⏰' };
  } else if (timeDiffMinutes <= 1440) { // Менее суток
    const hours = Math.floor(timeDiffMinutes / 60);
    const minutes = timeDiffMinutes % 60;
    return {
      text: hours > 0 ? t('in_hours_minutes', { h: hours, m: minutes }) : t('in_minutes', { m: minutes }),
      color: 'text-foreground/70',
      icon: '⏰'
    };
  } else {
    // Для далеких матчей показываем дату и время
    const formatTime = `${matchStart.getDate().toString().padStart(2, '0')}.${(matchStart.getMonth() + 1).toString().padStart(2, '0')} ${matchStart.toTimeString().slice(0, 5)}`;
    return {
      text: formatTime,
      color: 'text-foreground/70',
      icon: '📅'
    };
  }
};

const OpenBetsPageContent = () => {
  const { user } = useTelegram();
  const { t, lang } = useI18n();
  const { t: tPage } = useOpenBetsI18n();
  const [selectedCurrency, setSelectedCurrency] = useState<"all" | "TON" | "STARS">("all");
  const [sortBy, setSortBy] = useState<"time" | "amount">("time");
  const [bets, setBets] = useState<Bet[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<BetStats>({
    total_bets: 0,
    total_amount_ton: 0,
    total_amount_stars: 0
  });
  const controls = useAnimation();
  const [joinModalOpen, setJoinModalOpen] = useState(false);
  const [selectedBetId, setSelectedBetId] = useState<number | null>(null);
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);
  const [selectedBetForDetails, setSelectedBetForDetails] = useState<Bet | null>(null);
  const buttonsRef = useRef<HTMLDivElement>(null);
  const sortOptions = useMemo(() => ["time", "amount"], []);
  const sortLabels = {
    time: tPage('sort_time'),
    amount: tPage('sort_amount')
  };

  const getNextSortOption = (direction: "next" | "prev") => {
    const currentIndex = sortOptions.indexOf(sortBy);
    if (direction === "next") {
      return sortOptions[(currentIndex + 1) % sortOptions.length] as "time" | "amount";
    } else {
      return sortOptions[(currentIndex - 1 + sortOptions.length) % sortOptions.length] as "time" | "amount";
    }
  };

  const handleSwipe = (direction: "left" | "right") => {
    // Свайп влево означает переход к следующей опции
    // Свайп вправо означает переход к предыдущей опции
    const newSortBy = direction === "left" ? getNextSortOption("next") : getNextSortOption("prev");

    // Анимация при свайпе
    controls.start({
      x: direction === "left" ? -20 : 20,
      opacity: 0.5,
      transition: { duration: 0.2 }
    }).then(() => {
      setSortBy(newSortBy);
      controls.start({
        x: 0,
        opacity: 1,
        transition: { duration: 0.2 }
      });

      // Прокручиваем до активной кнопки
      scrollToActiveButton(newSortBy);
    });
  };

  // Функция для прокрутки к активной кнопке
  const scrollToActiveButton = useCallback((activeSortBy: "time" | "amount") => {
    if (buttonsRef.current) {
      const container = buttonsRef.current;
      const activeButtonIndex = sortOptions.indexOf(activeSortBy);

      // Расчет позиции прокрутки на основе индекса активной кнопки
      // Предполагаем, что каждая кнопка имеет примерно одинаковую ширину
      const buttonWidth = container.scrollWidth / sortOptions.length;
      const scrollPosition = buttonWidth * activeButtonIndex;

      // Плавная прокрутка до нужной позиции
      container.scrollTo({
        left: scrollPosition,
        behavior: 'smooth'
      });
    }
  }, [sortOptions]);

  // Функция загрузки споров
  const fetchBets = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        currency: selectedCurrency,
        sort_by: sortBy,
        sort_order: 'desc',
        limit: '20'
      });

      const data = await betsApi.getOpen(Object.fromEntries(params), user?.id);
      setBets(data.bets);
      setStats(data.stats);
    } catch (error) {
      console.error('Error fetching bets:', error);
    } finally {
      setLoading(false);
    }
  }, [selectedCurrency, sortBy, user?.id]);

  // Загружаем данные при монтировании и изменении фильтров
  useEffect(() => {
    fetchBets();
  }, [fetchBets]);

  // Эффект для начальной прокрутки к активной кнопке
  useEffect(() => {
    scrollToActiveButton(sortBy);
  }, [scrollToActiveButton, sortBy]);

  const handleJoinBet = (betId: number) => {
    if (!user?.id) {
      alert(tPage('auth_error'));
      return;
    }

    const bet = bets.find(b => b.id === betId);
    if (!bet || bet.can_join === false) {
      alert(tPage('cannot_join'));
      return;
    }

    setSelectedBetId(betId);
    setJoinModalOpen(true);
  };

  const handleJoinSuccess = () => {
    setJoinModalOpen(false);
    setSelectedBetId(null);
    // Обновляем список споров
    fetchBets();
  };

  const handleViewDetails = (betId: number) => {
    const bet = bets.find(b => b.id === betId);
    if (!bet) return;

    setSelectedBetForDetails(bet);
    setDetailsModalOpen(true);
  };

  const handleFilterByStatus = (status: "all" | "TON" | "STARS") => {
    setSelectedCurrency(status);
  };

  const handleSort = (sortType: "time" | "amount") => {
    setSortBy(sortType);
  };

  return (
    <div className="p-4 space-y-5 pb-24">
      {/* Header и Filters */}
      <div className="space-y-4">
        <div className="flex justify-center">
          <Badge className="bg-gradient-to-r from-green-400 to-emerald-500 text-white border-none px-3 py-1 rounded-full">
            <div className="flex items-center space-x-1">
              <CheckCircle className="h-3 w-3" />
              <span>{tPage('active_count', { count: bets.length })}</span>
            </div>
          </Badge>
        </div>



        {/* Сортировка С жестом свайпа */}
        <Card className="glass-card border-none overflow-hidden p-3">
          <CardContent className="p-0 space-y-3">
            {/* Подсказка для свайпа */}
            <div className="flex justify-between items-center">
              <div className="text-sm text-foreground/50 flex items-center space-x-1">
                <ChevronLeft className="h-4 w-4" />
                <span>{tPage('swipe_to_sort')}</span>
                <ChevronRight className="h-4 w-4" />
              </div>
            </div>

            {/* Сортировка с поддержкой свайпов и прокруткой */}
            <motion.div
              drag="x"
              dragConstraints={{ left: 0, right: 0 }}
              dragElastic={0.2}
              onDragEnd={(event, info) => {
                if (info.offset.x < -50) {
                  handleSwipe("left");
                } else if (info.offset.x > 50) {
                  handleSwipe("right");
                }
              }}
              className="touch-none"
            >
              <motion.div
                className="flex overflow-x-auto no-scrollbar snap-x"
                ref={buttonsRef}
                animate={controls}
              >
                <Button
                  variant={sortBy === "time" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    handleSort("time");
                    scrollToActiveButton("time");
                  }}
                  className={`min-w-max shrink-0 mr-2 snap-center rounded-full ${sortBy === "time" ? "bg-gradient-to-r from-blue-400 to-purple-500 text-white border-none shadow-md" : "bg-white/5 backdrop-blur-sm border border-white/10"}`}
                >
                  <Clock className="h-4 w-4 mr-1" />
                  <span>{sortLabels.time}</span>
                </Button>
                <Button
                  variant={sortBy === "amount" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    handleSort("amount");
                    scrollToActiveButton("amount");
                  }}
                  className={`min-w-max shrink-0 mr-2 snap-center rounded-full ${sortBy === "amount" ? "bg-gradient-to-r from-blue-400 to-purple-500 text-white border-none shadow-md" : "bg-white/5 backdrop-blur-sm border border-white/10"}`}
                >
                  <Coins className="h-4 w-4 mr-1" />
                  <span>{sortLabels.amount}</span>
                </Button>

              </motion.div>
            </motion.div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="glass-card border-none overflow-hidden relative">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-blue-600/10 rounded-xl"></div>
          <CardContent className="p-3 text-center relative z-10">
            <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-blue-600 text-transparent bg-clip-text">{stats.total_bets || 0}</div>
            <div className="text-xs text-blue-400 font-medium">{tPage('total_bets')}</div>
          </CardContent>
        </Card>
        <Card className="glass-card border-none overflow-hidden relative">
          <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-green-600/10 rounded-xl"></div>
          <CardContent className="p-3 text-center relative z-10">
            <div className="text-2xl font-bold bg-gradient-to-r from-green-400 to-green-600 text-transparent bg-clip-text">{(stats.total_amount_ton || 0).toFixed(1)}</div>
            <div className="text-xs text-green-400 font-medium">{tPage('ton_in_game')}</div>
          </CardContent>
        </Card>

      </div>

      {/* Bets List */}
      <div className="space-y-4">
        {loading ? (
          <div className="text-center py-12">
            <div className="text-foreground/60">{tPage('loading_bets')}</div>
          </div>
        ) : bets.map((bet, index) => (
          <motion.div
            key={bet.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.02, transition: { duration: 0.2 } }}
          >
            <Card className="glass-card border-none overflow-hidden relative">
              <CardHeader className="pb-2 relative z-10">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <UserAvatar
                      telegramId={bet.creator_telegram_id}
                      userName={bet.creator_username || bet.creator_first_name || 'Anonymous'}
                      size="md"
                    />
                    <div>
                      <p className="font-semibold">{bet.creator_username || bet.creator_first_name || tPage('anonymous')}</p>
                      <div className="flex items-center space-x-2 mt-0.5">
                        <Badge variant="outline" className="text-xs bg-white/10 border-white/10">
                          {bet.league}
                        </Badge>
                        <div className="flex items-center space-x-1 text-xs">
                          <Clock className="h-3 w-3 text-blue-400" />
                          {(() => {
                            const matchStatus = getMatchStatusAndTime(bet, tPage, lang === 'ru' ? 'ru-RU' : 'en-US');
                            return (
                              <span className={matchStatus.color}>
                                {matchStatus.icon} {matchStatus.text}
                              </span>
                            );
                          })()}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="flex items-center space-x-1 justify-end">
                      <div className="h-5 w-5 rounded-full flex items-center justify-center">
                        {bet.currency === "TON" ? (
                          <img src="/images/ton.png" alt="TON" className="h-4 w-4" />
                        ) : (
                          <img src="/images/stars.png" alt="Stars" className="h-4 w-4" />
                        )}
                      </div>
                      <span className="font-bold text-lg">{bet.amount}</span>
                    </div>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="pt-0 relative z-10">
                <div className="space-y-3">
                  {/* Match Info */}
                  <div className="p-3 rounded-xl bg-white/5 backdrop-blur-sm space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 rounded-full bg-gradient-cosmic flex items-center justify-center text-white text-xs font-bold">
                          {bet.home_team.charAt(0)}
                        </div>
                        <span className="font-medium text-sm">{bet.home_team}</span>
                      </div>
                      <div className="flex items-center space-x-1 text-xs text-foreground/70">
                        <Zap className="h-3 w-3 text-blue-400" />
                        <span>{new Date(bet.match_start_time).toTimeString().slice(0, 5)}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 rounded-full bg-gradient-fire flex items-center justify-center text-white text-xs font-bold">
                          {bet.away_team.charAt(0)}
                        </div>
                        <span className="font-medium text-sm">{bet.away_team}</span>
                      </div>
                      <Badge
                        variant="outline"
                        className="text-xs font-medium bg-white/5 border-white/10 text-foreground/80"
                      >
                        {bet.prediction_text}
                      </Badge>
                    </div>
                  </div>

                  <Separator className="bg-white/10" />

                  {/* Participants */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Users className="h-4 w-4 text-blue-400" />
                      <span className="text-sm">
                        <span className="font-semibold">{bet.participants_count}</span>
                        <span className="text-foreground/70">/{bet.max_participants} {tPage('participants')}</span>
                      </span>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleViewDetails(bet.id)}
                        className="rounded-full h-9 w-9 p-0 flex items-center justify-center bg-white/5 backdrop-blur-sm border border-white/10 hover:bg-white/10"
                      >
                        <Eye className="h-4 w-4" />
                      </Button>

                      <Button
                        size="sm"
                        onClick={() => handleJoinBet(bet.id)}
                        disabled={bet.can_join === false}
                        className={`rounded-full ${
                          bet.can_join === false
                            ? "bg-foreground/20 text-foreground/50"
                            : "bg-gradient-to-r from-green-400 to-emerald-500 hover:from-green-500 hover:to-emerald-600 text-white"
                        }`}
                      >
                        <div className="flex items-center space-x-1">
                          {bet.can_join === false ? (
                            <span>{tPage('unavailable')}</span>
                          ) : (
                            <>
                              <span>{tPage('join')}</span>
                              <ArrowRight className="h-4 w-4" />
                            </>
                          )}
                        </div>
                      </Button>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-blue-400 to-purple-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${bet.max_participants ? (bet.participants_count / bet.max_participants) * 100 : 0}%` }}
                    />
                  </div>

                  {/* Потенциальный выигрыш - общий банк */}
                  {bet.can_join !== false && (
                    <div className="flex items-center justify-center space-x-1 text-sm">
                      <Sparkles className="h-3 w-3 text-yellow-400" />
                      <span className="text-foreground/70">{tPage('potential_win')}</span>
                      <span className="font-semibold bg-gradient-to-r from-green-400 to-emerald-500 text-transparent bg-clip-text">
                        {(bet.potential_winnings || bet.amount).toFixed(2)} {bet.currency}
                      </span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {!loading && bets.length === 0 && (
        <div className="text-center py-12 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10">
          <Trophy className="h-12 w-12 text-foreground/30 mx-auto mb-3" />
          <p className="text-foreground/60 font-medium">{tPage('no_open_bets')}</p>
          <Button
            variant="outline"
            className="mt-4 rounded-full bg-white/5 backdrop-blur-sm border border-white/10 hover:bg-white/10"
            onClick={() => setSelectedCurrency("all")}
          >
            {tPage('reset_filters')}
          </Button>
        </div>
      )}

      {/* Join Bet Modal */}
      {selectedBetId && (
        <JoinBetModal
          isOpen={joinModalOpen}
          onClose={() => {
            setJoinModalOpen(false);
            setSelectedBetId(null);
          }}
          betId={selectedBetId}
          onJoinSuccess={handleJoinSuccess}
        />
      )}

      {/* Bet Details Modal */}
      <BetDetailsModal
        isOpen={detailsModalOpen}
        onClose={() => {
          setDetailsModalOpen(false);
          setSelectedBetForDetails(null);
        }}
        bet={selectedBetForDetails}
      />
    </div>
  );
};

export const OpenBetsPage = () => (
  <OpenBetsI18nProvider>
    <OpenBetsPageContent />
  </OpenBetsI18nProvider>
);
