import { useCallback } from 'react';

interface WebRTCAudioForcerReturn {
  configureRTCForSpeaker: (pc: RTCPeerConnection) => void;
  forceAudioToSpeaker: (audioElement: HTMLAudioElement) => Promise<void>;
  createSpeakerAudioContext: () => Promise<AudioContext | null>;
}

/**
 * Хук для принудительной настройки WebRTC на использование внешнего динамика
 */
export function useWebRTCAudioForcer(): WebRTCAudioForcerReturn {

  // Настройка RTCPeerConnection для принудительного использования динамика
  const configureRTCForSpeaker = useCallback((pc: RTCPeerConnection) => {
    try {
      // 1. Настраиваем обработчики для всех входящих треков
      pc.ontrack = (event) => {
        console.log('🔊 Настраиваем входящий аудио трек для внешнего динамика');

        event.streams.forEach(stream => {
          stream.getAudioTracks().forEach(track => {
            // Применяем constraints для оптимального качества звука с внешним динамиком
            const constraints = {
              echoCancellation: true,   // Включаем эхоподавление для лучшего качества
              noiseSuppression: true,   // Включаем шумоподавление для чистого звука
              autoGainControl: true     // Включаем автогейн для стабильной громкости
            };

            if (track.applyConstraints) {
              track.applyConstraints(constraints).catch(err =>
                console.warn('⚠️ Не удалось применить constraints к треку:', err)
              );
            }
          });
        });
      };

      // 2. Настраиваем статистику для мониторинга
      const monitorAudioOutput = () => {
        pc.getStats().then(stats => {
          stats.forEach(report => {
            if (report.type === 'outbound-rtp' && report.kind === 'audio') {
              console.log('📊 Аудио выход активен:', report);
            }
          });
        }).catch(err => console.warn('Не удалось получить статистику:', err));
      };

      // Мониторим каждые 5 секунд
      const statsInterval = setInterval(monitorAudioOutput, 5000);

      // Очистка при закрытии соединения
      pc.addEventListener('connectionstatechange', () => {
        if (pc.connectionState === 'closed' || pc.connectionState === 'failed') {
          clearInterval(statsInterval);
        }
      });

      console.log('✅ RTCPeerConnection настроен для внешнего динамика');
    } catch (error) {
      console.error('❌ Ошибка настройки RTC для динамика:', error);
    }
  }, []);

  // Принудительная настройка аудио элемента на динамик
  const forceAudioToSpeaker = useCallback(async (audioElement: HTMLAudioElement) => {
    try {
      console.log('🔊 Принудительная настройка аудио элемента на внешний динамик');

      // 1. Базовые настройки
      audioElement.volume = 1.0;
      audioElement.muted = false;
      audioElement.autoplay = true;

      // Атрибуты для мобильных браузеров
      audioElement.setAttribute('playsinline', 'true');
      audioElement.setAttribute('webkit-playsinline', 'true');
      audioElement.setAttribute('x-webkit-airplay', 'allow');

      // 2. Попытка принудительно установить устройство вывода
      const audioElementExtended = audioElement as HTMLAudioElement & {
        setSinkId?: (deviceId: string) => Promise<void>;
        sinkId?: string;
      };

      if (audioElementExtended.setSinkId) {
        try {
          // Пытаемся получить список аудио устройств
          const devices = await navigator.mediaDevices.enumerateDevices();
          const audioOutputs = devices.filter(device => device.kind === 'audiooutput');

          console.log('🎵 Найденные аудио выходы:', audioOutputs);

          // Ищем основной динамик (обычно это устройство по умолчанию)
          const defaultOutput = audioOutputs.find(device =>
            device.deviceId === 'default' ||
            device.label.toLowerCase().includes('speaker') ||
            device.label.toLowerCase().includes('динамик')
          );

          if (defaultOutput) {
            await audioElementExtended.setSinkId(defaultOutput.deviceId);
            console.log('✅ Установлен внешний динамик:', defaultOutput.label);
          } else {
            // Используем устройство по умолчанию
            await audioElementExtended.setSinkId('');
            console.log('✅ Установлено устройство по умолчанию');
          }
        } catch (sinkError) {
          console.warn('⚠️ Не удалось установить конкретное устройство вывода:', sinkError);
          // Устанавливаем пустую строку для использования устройства по умолчанию
          await audioElementExtended.setSinkId('');
        }
      }

      // 3. Создаем Web Audio контекст для дополнительного контроля
      const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) {
        console.warn('AudioContext не поддерживается');
        return;
      }
      const audioContext = new AudioContextClass();
      const source = audioContext.createMediaElementSource(audioElement);
      const gainNode = audioContext.createGain();

      // Устанавливаем максимальную громкость
      gainNode.gain.setValueAtTime(1.0, audioContext.currentTime);

      source.connect(gainNode);
      gainNode.connect(audioContext.destination);

      console.log('🎚️ Web Audio контекст настроен для максимальной громкости');

      return audioContext;
    } catch (error) {
      console.error('❌ Ошибка принудительной настройки аудио:', error);
    }
  }, []);

  // Создание специального аудио контекста для громкого воспроизведения
  const createSpeakerAudioContext = useCallback(async (): Promise<AudioContext | null> => {
    try {
      // Создаем аудио контекст
      const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      const audioContext = new AudioContextClass();

      // Запрашиваем разрешение на аудио (это помогает разблокировать autoplay)
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,      // Включаем для лучшего качества
          noiseSuppression: true,      // Включаем для чистого звука
          autoGainControl: true        // Включаем для стабильной громкости
        }
      });

      // Создаем узлы для обработки
      const source = audioContext.createMediaStreamSource(stream);
      const gainNode = audioContext.createGain();

      // Устанавливаем минимальную громкость для источника (мы его не слышим)
      gainNode.gain.setValueAtTime(0.001, audioContext.currentTime);

      source.connect(gainNode);
      gainNode.connect(audioContext.destination);

      // Останавливаем микрофон, он нам был нужен только для активации контекста
      stream.getTracks().forEach(track => track.stop());

      console.log('🎼 Аудио контекст для динамика создан');
      return audioContext;
    } catch (error) {
      console.error('❌ Не удалось создать аудио контекст для динамика:', error);
      return null;
    }
  }, []);

  return {
    configureRTCForSpeaker,
    forceAudioToSpeaker,
    createSpeakerAudioContext
  };
}
