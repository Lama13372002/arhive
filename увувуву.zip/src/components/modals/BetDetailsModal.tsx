'use client';

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { UserAvatar } from '@/components/ui/user-avatar';
import {
  Trophy,
  Users,
  Clock,
  MapPin,
  MessageSquare,
  Calendar,
  User,
  Zap,
  X,
  Coins,
  Star
} from 'lucide-react';
import Image from 'next/image';
import { type Bet } from '@/types/api';
import { useOpenBetsI18n } from '@/components/providers/OpenBetsI18nProvider';
import { useI18n } from '@/components/providers/I18nProvider';
import { parseMatchDateTime } from '@/lib/timezone';

interface BetComment {
  id: string;
  user_id: number;
  username?: string;
  first_name?: string;
  last_name?: string;
  telegram_id: number;
  comment: string;
  prediction_type: string;
  amount: number;
  joined_at: string;
  is_creator: boolean;
}

interface BetDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  bet: Bet | null;
}

// Функция для определения статуса матча и времени
const getMatchStatusAndTime = (
  bet: Bet,
  t: (k: string, p?: Record<string, string | number>) => string,
  locale: 'ru-RU' | 'en-US'
) => {
  const now = new Date();
  const startTime = (bet.match?.start_time || bet.match_start_time || bet.start_time || bet.created_at) as string;
  const matchStart = new Date(startTime);
  const timeDiffMinutes = Math.floor((matchStart.getTime() - now.getTime()) / (1000 * 60));

  const matchStatus = (bet.match?.status || bet.match_status || '').toLowerCase();
  const matchMinute = bet.match?.minute;

  if (matchStatus === 'live' || matchStatus === 'in_progress' || matchStatus === '1h' || matchStatus === '2h') {
    if (matchMinute) {
      return { text: `${matchMinute}'`, color: 'text-green-400', icon: '🔴' };
    } else {
      const elapsedMinutes = Math.abs(timeDiffMinutes);
      return { text: `${Math.max(0, elapsedMinutes)}'`, color: 'text-green-400', icon: '🔴' };
    }
  }

  if (matchStatus === 'halftime' || matchStatus === 'ht') {
    return { text: t('halftime'), color: 'text-orange-400', icon: '⏸️' };
  }

  if (matchStatus === 'finished' || matchStatus === 'ft' || matchStatus === 'completed') {
    return { text: t('finished'), color: 'text-gray-400', icon: '⚽' };
  }

  if (timeDiffMinutes <= 0) {
    return { text: t('soon'), color: 'text-orange-400', icon: '⚡' };
  }

  if (timeDiffMinutes <= 15) {
    return { text: t('soon'), color: 'text-orange-400', icon: '⚡' };
  } else if (timeDiffMinutes <= 60) {
    return { text: t('in_minutes', { m: timeDiffMinutes }), color: 'text-blue-400', icon: '⏰' };
  } else if (timeDiffMinutes <= 1440) {
    const hours = Math.floor(timeDiffMinutes / 60);
    const minutes = timeDiffMinutes % 60;
    return {
      text: hours > 0 ? t('in_hours_minutes', { h: hours, m: minutes }) : t('in_minutes', { m: minutes }),
      color: 'text-foreground/70',
      icon: '⏰'
    };
  } else {
    // Используем parseMatchDateTime для корректной работы с часовыми поясами
    try {
      const { formattedDate, formattedTime } = parseMatchDateTime(startTime);
      return {
        text: `${formattedDate} ${formattedTime}`,
        color: 'text-foreground/70',
        icon: '📅'
      };
    } catch (error) {
      // Fallback к старому формату в случае ошибки
      const formatTime = `${matchStart.getDate().toString().padStart(2, '0')}.${(matchStart.getMonth() + 1).toString().padStart(2, '0')} ${matchStart.toTimeString().slice(0, 5)}`;
      return {
        text: formatTime,
        color: 'text-foreground/70',
        icon: '📅'
      };
    }
  }
};

export const BetDetailsModal: React.FC<BetDetailsModalProps> = ({
  isOpen,
  onClose,
  bet
}) => {
  const { t: tPage } = useOpenBetsI18n();
  const { lang } = useI18n();
  const [comments, setComments] = useState<BetComment[]>([]);
  const [loadingComments, setLoadingComments] = useState(false);

  // Загружаем комментарии при открытии модалки
  useEffect(() => {
    if (isOpen && bet?.id) {
      loadComments();
    }
  }, [isOpen, bet?.id]);

  const loadComments = async () => {
    if (!bet?.id) return;

    setLoadingComments(true);
    try {
      const response = await fetch(`/api/bets/participants?bet_id=${bet.id}`);
      if (response.ok) {
        const data = await response.json();
        setComments(data.comments || []);
      }
    } catch (error) {
      console.error('Error loading comments:', error);
    } finally {
      setLoadingComments(false);
    }
  };

  if (!bet || !isOpen) return null;

  const creatorName = bet.creator_username || bet.creator_first_name || tPage('anonymous');
  const matchStatus = getMatchStatusAndTime(bet, tPage, lang === 'ru' ? 'ru-RU' : 'en-US');
  // Используем parseMatchDateTime для корректного отображения времени
  const timeStr = (() => {
    try {
      const { formattedTime } = parseMatchDateTime(bet.match_start_time);
      return formattedTime;
    } catch (error) {
      // Fallback к старому формату
      return new Date(bet.match_start_time).toTimeString().slice(0, 5);
    }
  })();

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const handleContentClick = (e: React.MouseEvent) => {
    e.stopPropagation();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 pt-16 pb-16"
      style={{
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        backdropFilter: 'blur(8px)',
        WebkitBackdropFilter: 'blur(8px)',
        touchAction: 'none',
        WebkitTouchCallout: 'none',
        WebkitUserSelect: 'none',
        userSelect: 'none'
      }}
      onClick={handleOverlayClick}
      onTouchStart={(e) => e.preventDefault()}
      onTouchMove={(e) => e.preventDefault()}
    >
      <div
        className="w-full max-w-sm"
        style={{
          position: 'relative',
          transform: 'none',
          touchAction: 'auto',
          WebkitTouchCallout: 'default',
          WebkitUserSelect: 'text',
          userSelect: 'text',
          maxHeight: '60vh'
        }}
        onClick={handleContentClick}
      >
        <div
          className="no-scrollbar"
          style={{
            background: 'rgba(15, 23, 42, 0.95)',
            backdropFilter: 'blur(25px)',
            WebkitBackdropFilter: 'blur(25px)',
            border: '1px solid rgba(255, 255, 255, 0.15)',
            borderRadius: '20px',
            boxShadow: '0 20px 40px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.1)',
            padding: '16px',
            transform: 'none',
            position: 'relative',
            overflowY: 'auto',
            maxHeight: '60vh'
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text">
              {tPage('details_title', { id: bet.id })}
            </h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0 rounded-full hover:bg-white/10"
              style={{ transform: 'none' }}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-3">
            {/* Создатель спора */}
            <Card style={{
              background: 'rgba(255, 255, 255, 0.05)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              borderRadius: '12px',
              transform: 'none'
            }}>
              <CardContent className="p-3">
                <div className="flex items-center space-x-3">
                  <UserAvatar
                    telegramId={bet.creator_telegram_id}
                    userName={creatorName}
                    size="sm"
                  />
                  <div>
                    <div className="flex items-center space-x-2">
                      <User className="h-3 w-3 text-blue-400" />
                      <span className="font-semibold text-sm">{creatorName}</span>
                    </div>
                    <div className="text-xs text-foreground/70">{tPage('details_creator', { creator: '' }).replace(': ', '')}</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Информация о матче с логотипами */}
            <Card style={{
              background: 'rgba(255, 255, 255, 0.05)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              borderRadius: '12px',
              transform: 'none'
            }}>
              <CardContent className="p-3 space-y-3">
                {/* Команды с логотипами */}
                <div className="text-center">
                  <div className="flex items-center justify-center gap-3 mb-2">
                    {/* Домашняя команда */}
                    <div className="flex items-center space-x-2">
                      {bet.home_team_logo ? (
                        <div className="w-8 h-8 relative">
                          <Image
                            src={bet.home_team_logo}
                            alt={bet.home_team}
                            fill
                            className="object-contain rounded-full"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.style.display = 'none';
                              target.nextElementSibling?.classList.remove('hidden');
                            }}
                          />
                          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-xs hidden">
                            {bet.home_team.charAt(0)}
                          </div>
                        </div>
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-xs">
                          {bet.home_team.charAt(0)}
                        </div>
                      )}
                      <span className="font-semibold text-sm">{bet.home_team}</span>
                    </div>

                    <span className="text-sm font-bold text-gray-400">VS</span>

                    {/* Гостевая команда */}
                    <div className="flex items-center space-x-2">
                      <span className="font-semibold text-sm">{bet.away_team}</span>
                      {bet.away_team_logo ? (
                        <div className="w-8 h-8 relative">
                          <Image
                            src={bet.away_team_logo}
                            alt={bet.away_team}
                            fill
                            className="object-contain rounded-full"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.style.display = 'none';
                              target.nextElementSibling?.classList.remove('hidden');
                            }}
                          />
                          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-orange-500 to-red-600 flex items-center justify-center text-white font-bold text-xs hidden">
                            {bet.away_team.charAt(0)}
                          </div>
                        </div>
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-gradient-to-r from-orange-500 to-red-600 flex items-center justify-center text-white font-bold text-xs">
                          {bet.away_team.charAt(0)}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <MapPin className="h-3 w-3 text-green-400" />
                  <span className="text-xs">{bet.league}</span>
                </div>

                <div className="flex items-center space-x-2">
                  <Calendar className="h-3 w-3 text-blue-400" />
                  <span className="text-xs">{timeStr}</span>
                </div>

                <div className="flex items-center space-x-2">
                  <Clock className={`h-3 w-3 ${matchStatus.color}`} />
                  <span className={`text-xs ${matchStatus.color}`}>
                    {matchStatus.icon} {matchStatus.text}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Прогноз и сумма */}
            <Card style={{
              background: 'rgba(255, 255, 255, 0.05)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              borderRadius: '12px',
              transform: 'none'
            }}>
              <CardContent className="p-3 space-y-2">
                <div className="flex items-center space-x-2">
                  <Zap className="h-3 w-3 text-purple-400" />
                  <span className="font-medium text-sm">{bet.prediction_text}</span>
                </div>

                <Separator className="bg-white/10" />

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    {bet.currency === "TON" ? (
                      <img src="/images/ton.png" alt="TON" className="h-4 w-4" />
                    ) : (
                      <img src="/images/stars.png" alt="Stars" className="h-4 w-4" />
                    )}
                    <span className="text-base font-bold">{bet.amount} {bet.currency}</span>
                  </div>
                  <Badge className="bg-gradient-to-r from-green-400/20 to-emerald-500/20 text-green-400 border-green-400/20 text-xs">
                    {tPage('details_amount', { amount: '', currency: '' }).replace(': ', '')}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Участники */}
            <Card style={{
              background: 'rgba(255, 255, 255, 0.05)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              borderRadius: '12px',
              transform: 'none'
            }}>
              <CardContent className="p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Users className="h-3 w-3 text-blue-400" />
                    <span className="font-medium text-xs">
                      {bet.participants_count}/{bet.max_participants} {tPage('participants')}
                    </span>
                  </div>
                  <div className="w-16 bg-white/10 rounded-full h-1.5">
                    <div
                      className="bg-gradient-to-r from-blue-400 to-purple-500 h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${bet.max_participants ? (bet.participants_count / bet.max_participants) * 100 : 0}%` }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Комментарии участников */}
            {comments.length > 0 && (
              <Card style={{
                background: 'rgba(255, 255, 255, 0.05)',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                borderRadius: '12px',
                transform: 'none'
              }}>
                <CardContent className="p-3">
                  <div className="flex items-center space-x-2 mb-3">
                    <MessageSquare className="h-3 w-3 text-blue-400" />
                    <span className="font-medium text-xs text-blue-400">
                      Комментарии ({comments.length})
                    </span>
                  </div>

                  <div className="space-y-3">
                    {comments.map((comment) => {
                      const userName = comment.username || comment.first_name || 'Аноним';

                      return (
                        <div key={comment.id} className="flex items-start space-x-2">
                          <UserAvatar
                            telegramId={comment.telegram_id}
                            userName={userName}
                            size="sm"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center space-x-2 mb-1">
                              <span className="text-xs font-medium text-foreground/90">
                                {userName}
                              </span>
                              {comment.is_creator && (
                                <Badge className="bg-gradient-to-r from-purple-400/20 to-blue-500/20 text-purple-400 border-purple-400/20 text-xs px-1 py-0">
                                  Создатель
                                </Badge>
                              )}
                            </div>
                            <div className="text-xs text-foreground/80 leading-relaxed bg-white/5 rounded p-2 break-words whitespace-pre-wrap overflow-wrap-anywhere max-w-full">
                              {comment.comment}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Комментарий создателя (старый код - оставляем для совместимости) */}
            {bet.comment && bet.comment.trim() && comments.length === 0 && (
              <Card style={{
                background: 'rgba(255, 193, 7, 0.1)',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255, 193, 7, 0.2)',
                borderRadius: '12px',
                transform: 'none'
              }}>
                <CardContent className="p-3">
                  <div className="flex items-start space-x-2">
                    <MessageSquare className="h-3 w-3 text-yellow-400 mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="text-xs font-medium text-yellow-400 mb-1">
                        {tPage('details_comment', { comment: '' }).replace(': ', '')}
                      </div>
                      <div className="text-xs text-foreground/90 leading-relaxed break-words whitespace-pre-wrap overflow-wrap-anywhere max-w-full">
                        {bet.comment}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Кнопка закрыть */}
            <Button
              onClick={onClose}
              className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white border-none rounded-xl"
              style={{ transform: 'none', minHeight: '40px' }}
            >
              {lang === 'ru' ? 'Закрыть' : 'Close'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
