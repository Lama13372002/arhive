"use client";

import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Trophy, X } from "lucide-react";

interface BetResultBadgeProps {
  status: "won" | "lost" | "refunded" | "active" | "cancelled";
  winAmount?: number;
  lossAmount?: number;
  currency: "TON" | "STARS";
}

export function BetResultBadge({
  status,
  winAmount,
  lossAmount,
  currency
}: BetResultBadgeProps) {
  // Определяем данные для отображения
  const isWin = status === "won" && winAmount;
  const isLoss = status === "lost" && lossAmount;

  if (!isWin && !isLoss) return null;

  const amount = isWin ? winAmount : lossAmount;

  return (
    <motion.div
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{
        type: "spring",
        stiffness: 200,
        damping: 15,
        delay: 0.2
      }}
      className={`absolute -top-1 -right-1 z-20 px-2 py-1 rounded-full shadow-lg border ${
        isWin
          ? "bg-gradient-to-r from-green-500 to-emerald-600 border-green-400/50 text-white"
          : "bg-gradient-to-r from-red-500 to-rose-600 border-red-400/50 text-white"
      }`}
      style={{
        boxShadow: isWin
          ? "0 4px 20px rgba(34, 197, 94, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.2)"
          : "0 4px 20px rgba(239, 68, 68, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.2)"
      }}
    >
      <motion.div
        className="flex items-center space-x-1"
        animate={isWin ? {
          scale: [1, 1.05, 1],
        } : {
          scale: [1, 0.95, 1],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      >
        {/* Иконка */}
        <motion.div
          animate={isWin ? { rotate: [0, 5, -5, 0] } : { rotate: [0, -3, 3, 0] }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          {isWin ? (
            <Trophy className="h-2.5 w-2.5" />
          ) : (
            <TrendingDown className="h-2.5 w-2.5" />
          )}
        </motion.div>

        {/* Сумма */}
        <motion.span
          className="text-[10px] font-bold"
          animate={{
            textShadow: isWin
              ? ["0 0 5px rgba(255, 255, 255, 0.5)", "0 0 10px rgba(255, 255, 255, 0.8)", "0 0 5px rgba(255, 255, 255, 0.5)"]
              : ["0 0 5px rgba(255, 255, 255, 0.3)", "0 0 8px rgba(255, 255, 255, 0.6)", "0 0 5px rgba(255, 255, 255, 0.3)"]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          {isWin ? '+' : '-'}{Number(amount).toFixed(2)} {currency}
        </motion.span>
      </motion.div>

      {/* Анимированный блик */}
      <motion.div
        className="absolute inset-0 rounded-full bg-gradient-to-r from-transparent via-white/20 to-transparent"
        animate={{
          x: [-100, 100],
          opacity: [0, 0.5, 0]
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
    </motion.div>
  );
}
