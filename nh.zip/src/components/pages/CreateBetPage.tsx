"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  ArrowLeft,
  Coins,
  Star,
  AlertCircle,
  CheckCircle,
  TrendingUp,
  Trophy,
  Zap,
  ChevronRight,
  MessageCircle,
  CurrencyIcon
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useTelegram } from "@/components/providers/TelegramProvider";
import { betsApi, ApiError } from "@/lib/api";
import { useTelegramAuth } from "@/hooks/useTelegramAuth";
import { BalanceDisplay } from "@/components/ui/balance-display";
import { CreateBetI18nProvider, useCreateBetI18n } from "@/components/providers/CreateBetI18nProvider";
import { useRouter } from "next/navigation";
import { useBalance } from "@/hooks/useBalance";
import { FEATURES } from "@/lib/features";
import { parseMatchDateTime } from "@/lib/timezone";

// USD_MIN теперь загружается из API

// Helper to round to sensible precision for TON
const formatTon = (v: number) => {
  if (!isFinite(v)) return 0;
  // keep 3 decimals min, but avoid 0 due to tiny values
  const rounded = Math.max(0, Number.parseFloat(v.toFixed(3)));
  return rounded;
};

interface CreateBetPageProps {
  onBack: () => void;
  onInputFocusChange?: (focused: boolean) => void;
}

const allCurrencies = [
  { id: "TON", name: "TON", icon: "/images/ton.png", color: "from-blue-500 to-blue-600" },
  { id: "STARS", name: "STARS", icon: "/images/stars.png", color: "from-yellow-500 to-yellow-600" }
];

const currencies = allCurrencies.filter(currency =>
  currency.id === "TON" || (currency.id === "STARS" && FEATURES.SHOW_STARS)
);

// outcomes будет создаваться динамически на основе выбранного матча

const CreateBetPageContent = ({ onBack, onInputFocusChange }: CreateBetPageProps) => {
  const { t } = useCreateBetI18n();
  const { user } = useTelegram();
  const [selectedCurrency, setSelectedCurrency] = useState("TON");
  const [amount, setAmount] = useState("");
  const [selectedOutcome, setSelectedOutcome] = useState("");
  const [comment, setComment] = useState("");
  const [showPreview, setShowPreview] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [isInputFocused, setIsInputFocused] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const initialViewportHeight = useRef<number>(0);
  const [selectedMatch, setSelectedMatch] = useState({
    homeTeam: "",
    awayTeam: "",
    league: "",
    startTime: "",
    date: ""
  });
  const router = useRouter();
  const [hasSelectedMatch, setHasSelectedMatch] = useState(false);

  // Курс TON/STARS к USD
  const [rates, setRates] = useState<{ tonToUsd: number; starsToUsd: number; ts: number } | null>(null);
  const [dynamicMin, setDynamicMin] = useState<{ TON: number; STARS: number }>({ TON: 0, STARS: 0 });

  // Минимальная сумма в USD (загружается из API)
  const [usdMin, setUsdMin] = useState<number | null>(null);

  const { balance } = useBalance();

  const fetchMinimumUsd = useCallback(async () => {
    try {
      const res = await fetch('/api/minimum-usd', { cache: 'no-store' });
      const json = await res.json();
      if (json && json.minimumUsdAmount) {
        setUsdMin(json.minimumUsdAmount);
      }
    } catch (e) {
      console.error('Failed to fetch minimum USD amount', e);
    }
  }, []);

  const fetchRates = useCallback(async () => {
    try {
      const res = await fetch('/api/ton-rate', { cache: 'no-store' });
      const json = await res.json();
      if (json && json.tonToUsd && json.starsToUsd) {
        setRates({ tonToUsd: json.tonToUsd, starsToUsd: json.starsToUsd, ts: Date.now() });
      }
    } catch (e) {
      console.error('Failed to fetch rates', e);
    }
  }, []);

  // Пересчитываем минимальные значения при изменении usdMin или rates
  useEffect(() => {
    if (rates && usdMin && usdMin > 0) {
      const tonMin = formatTon(usdMin / rates.tonToUsd);
      const starsMin = Math.ceil(usdMin / rates.starsToUsd);
      setDynamicMin({ TON: tonMin, STARS: starsMin });
      console.log(`Recalculating mins: USD=${usdMin}, TON=${tonMin}, STARS=${starsMin}, rate=${rates.tonToUsd}`);
    }
  }, [usdMin, rates]);

  // Загружаем минимальную сумму в USD при загрузке компонента
  useEffect(() => {
    fetchMinimumUsd();
  }, [fetchMinimumUsd]);

  // Poll every 10s
  useEffect(() => {
    fetchRates();
    const id = setInterval(fetchRates, 10000);
    return () => clearInterval(id);
  }, [fetchRates]);

  // Получаем данные о выбранном событии, если оно было передано
  useEffect(() => {
    // Проверяем, пришли ли мы сюда через выбор матча
    let cameFromSelection = false;
    try {
      cameFromSelection = localStorage.getItem('navigateBackTo') === 'create_bet';
    } catch {}

    const storedEvent = (() => {
      try {
        return localStorage.getItem('selectedEvent');
      } catch {
        return null;
      }
    })();

    if (storedEvent && cameFromSelection) {
      try {
        const eventData = JSON.parse(storedEvent);
        setSelectedMatch({
          homeTeam: eventData.homeTeam,
          awayTeam: eventData.awayTeam,
          league: eventData.league,
          startTime: eventData.startTime,
          date: eventData.date || "Tomorrow"
        });
        setHasSelectedMatch(true);
      } catch (error) {
        console.error('Ошибка при загрузке данных события:', error);
        setHasSelectedMatch(false);
      }
    } else {
      // Если пришли не через выбор матча, очищаем потенциальные остатки
      try {
        localStorage.removeItem('selectedEvent');
        localStorage.removeItem('navigateBackTo');
      } catch {}
      setHasSelectedMatch(false);
    }
  }, []);

  // Отслеживание закрытия клавиатуры через изменение размера
  useEffect(() => {
    initialViewportHeight.current = window.innerHeight;

    const handleViewportChange = () => {
      const currentHeight = window.innerHeight;
      const heightDifference = initialViewportHeight.current - currentHeight;

      // Если инпут в фокусе, но высота экрана восстановилась (клавиатура закрылась)
      if (isInputFocused && heightDifference < 100) {
        console.log('Keyboard closed detected - showing bottom nav');
        setIsInputFocused(false);
        onInputFocusChange?.(false);

        // Убираем фокус с инпута
        if (inputRef.current) {
          inputRef.current.blur();
        }
      }
    };

    // Используем Visual Viewport API если доступно, иначе resize
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', handleViewportChange);
    } else {
      window.addEventListener('resize', handleViewportChange);
    }

    return () => {
      if (window.visualViewport) {
        window.visualViewport.removeEventListener('resize', handleViewportChange);
      } else {
        window.removeEventListener('resize', handleViewportChange);
      }
    };
  }, [isInputFocused, onInputFocusChange]);

  // Создаем outcomes динамически на основе выбранного матча
  const outcomes = [
    { id: "home", label: t('p1_win', { homeTeam: selectedMatch.homeTeam }) },
    { id: "draw", label: t('draw') },
    { id: "away", label: t('p2_win', { awayTeam: selectedMatch.awayTeam }) }
  ];

  const currentCurrency = currencies.find(c => c.id === selectedCurrency)!;
  const minForSelected = selectedCurrency === 'TON' ? dynamicMin.TON : dynamicMin.STARS;
  const amountNum = Number.parseFloat(amount) || 0;
  // Проверяем валидность только если динамические минималки загружены
  const isValidAmount = minForSelected > 0 ? amountNum >= minForSelected : false;

  const validateForm = () => {
    // Если динамические минималки еще не загружены, не валидируем
    if (minForSelected <= 0) {
      setValidationError(t('loading_settings'));
      return false;
    }

    if (!isValidAmount) {
      setValidationError(t('minimum_amount_inline', { min: minForSelected, currency: selectedCurrency, usdMin: usdMin || 0 }));
      return false;
    }

    if (!selectedOutcome) {
      setValidationError(t('choose_prediction'));
      return false;
    }

    setValidationError(null);
    return true;
  };

  const handleCreateBet = () => {
    if (!validateForm()) return;
    setShowPreview(true);
  };

  const handleConfirmBet = async () => {
    if (!user?.id) {
      alert(t('auth_error'));
      return;
    }

    try {
      setIsCreating(true);

      // Создаем уникальный ID для матча на основе команд и времени
      const matchId = Math.abs(
        (selectedMatch.homeTeam + selectedMatch.awayTeam + selectedMatch.startTime).split('').reduce((a, b) => {
          a = ((a << 5) - a) + b.charCodeAt(0);
          return a & a;
        }, 0)
      );

      // Используем полное время матча из API если доступно, иначе создаем на основе startTime
      let startTime: Date;
      try {
        const storedEvent = localStorage.getItem('selectedEvent');
        if (storedEvent) {
          const eventData = JSON.parse(storedEvent);
          if (eventData.fullDateTime) {
            // Используем полное время из API
            startTime = new Date(eventData.fullDateTime);
          } else {
            // Fallback: завтра + указанное время
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            const [hours, minutes] = selectedMatch.startTime.split(':');
            startTime = new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), Number.parseInt(hours), Number.parseInt(minutes));
          }
        } else {
          // Fallback: завтра + указанное время
          const tomorrow = new Date();
          tomorrow.setDate(tomorrow.getDate() + 1);
          const [hours, minutes] = selectedMatch.startTime.split(':');
          startTime = new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), Number.parseInt(hours), Number.parseInt(minutes));
        }
      } catch {
        // Fallback в случае ошибки
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const [hours, minutes] = selectedMatch.startTime.split(':');
        startTime = new Date(tomorrow.getFullYear(), tomorrow.getMonth(), tomorrow.getDate(), Number.parseInt(hours), Number.parseInt(minutes));
      }

      const betData = {
        match_id: matchId,
        match_data: {
          home_team: selectedMatch.homeTeam,
          away_team: selectedMatch.awayTeam,
          league: selectedMatch.league,
          start_time: startTime.toISOString(),
          venue: 'Stadium'
        },
        prediction_type: selectedOutcome,
        prediction_text: outcomes.find(o => o.id === selectedOutcome)?.label || '',
        amount: Number.parseFloat(amount),
        currency: selectedCurrency,
        odds: 2.0,
        max_participants: 3,
        comment: comment || undefined
      };

      await betsApi.create(betData, user.id);

      alert(t('created_success'));
      localStorage.removeItem('selectedEvent');
      onBack();

    } catch (error) {
      console.error('Error creating bet:', error);

      if (error instanceof ApiError) {
        if (error.status === 400 && error.details) {
          // Показываем детали валидации
          const errorMsg = Array.isArray(error.details)
            ? error.details.join('\n')
            : (error.message || 'Unknown validation error');
          alert(t('validation_error_prefix', { details: errorMsg }));
        } else {
          alert(t('error_generic', { message: error instanceof Error ? error.message : 'Unknown error' }));
        }
      } else {
        alert(t('error_create_generic'));
      }
    } finally {
      setIsCreating(false);
    }
  };

  const handleChangeCurrency = (currency: string) => {
    const prevCurrency = selectedCurrency;
    setSelectedCurrency(currency);

    const newMin = currency === 'TON' ? dynamicMin.TON : dynamicMin.STARS;
    const amountNum = Number.parseFloat(amount);

    // Always clear when switching between TON and STARS to prevent invalid carry-over
    const switchingBetweenTonAndStars = (prevCurrency === 'TON' && currency === 'STARS') || (prevCurrency === 'STARS' && currency === 'TON');

    if (switchingBetweenTonAndStars) {
      setAmount("");
      setValidationError(null);
      return;
    }

    // For other currencies, clear if amount is below new minimum or not a valid number
    if (!Number.isFinite(amountNum) || amountNum < Number(newMin)) {
      setAmount("");
      setValidationError(null);
    }
  };

  const handleSetAmount = (value: string) => {
    // Проверяем, что введено число
    if (/^\d*\.?\d*$/.test(value) || value === "") {
      setAmount(value);
      setValidationError(null);
    }
  };

  const handleSelectOutcome = (outcome: string) => {
    setSelectedOutcome(outcome);
    setValidationError(null);
  };

  const handleSetPresetAmount = (preset: number) => {
    setAmount(preset.toString());
    setValidationError(null);
  };

  const handleCommentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    if (value.length <= 222) {
      setComment(value);
    }
  };

  // Убрали автоизменение высоты для суммы, так как теперь это однострочный input

  // ПРОСТЫЕ обработчики фокуса
  const handleInputFocus = () => {
    console.log('Input focused - hiding bottom nav');
    setIsInputFocused(true);
    onInputFocusChange?.(true);
  };

  const handleInputBlur = () => {
    console.log('Input blurred - showing bottom nav');
    setIsInputFocused(false);
    onInputFocusChange?.(false);
  };

  const handleSelectMatchClick = () => {
    // Помечаем, что после выбора матча надо вернуться сюда
    try {
      localStorage.setItem('navigateBackTo', 'create_bet');
    } catch {}
    router.push('/');
  };

  // MIN/MAX handlers for amount input
  const applyMin = () => {
    const min = selectedCurrency === 'TON' ? dynamicMin.TON : dynamicMin.STARS;
    // Не применяем если данные еще не загружены
    if (min <= 0) return;

    setAmount(String(min));
    setValidationError(null);
  };

  const applyMax = (val: number) => {
    if (!Number.isFinite(val) || val <= 0) return;
    // Не применяем если минималки еще не загружены
    const min = selectedCurrency === 'TON' ? dynamicMin.TON : dynamicMin.STARS;
    if (min <= 0) return;

    const formatted = selectedCurrency === 'TON' ? formatTon(val) : Math.floor(val);
    setAmount(String(formatted));
    setValidationError(null);
  };

  if (showPreview) {
    return (
      <div className="p-4 space-y-4">
        <div className="flex items-center space-x-3 mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowPreview(false)}
            className="hover:bg-white/10 rounded-full h-10 w-10 p-0 flex items-center justify-center"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h2 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text">
            {t('confirm_bet')}
          </h2>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ type: "spring", stiffness: 350, damping: 25 }}
        >
          <Card className="glass-card border-none overflow-hidden relative shadow-xl">
            <div className="absolute top-0 left-0 right-0 h-3 bg-gradient-to-r from-green-400 to-emerald-500 rounded-t-xl"></div>

            <CardHeader className="pt-6">
              <CardTitle className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-green-400 to-emerald-500 flex items-center justify-center shadow-md">
                  <CheckCircle className="h-4 w-4 text-white" />
                </div>
                <span className="font-bold">{t('bet_details')}</span>
              </CardTitle>
            </CardHeader>

            <CardContent className="space-y-6">
              <div className="space-y-4 p-4 rounded-xl bg-white/5 backdrop-blur-sm border border-white/10">
                <div className="flex justify-between items-center">
                  <span className="text-foreground/70">{t('match')}</span>
                  <span className="font-bold">{selectedMatch.homeTeam} vs {selectedMatch.awayTeam}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-foreground/70">{t('league')}</span>
                  <Badge className="bg-white/10 border-none">{selectedMatch.league}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-foreground/70">{t('time')}</span>
                  <div className="flex items-center space-x-1">
                    <Zap className="h-3 w-3 text-blue-400" />
                    <span>{(() => {
                      try {
                        // Если есть полное время в ISO формате, используем parseMatchDateTime
                        const eventData = localStorage.getItem('selectedEvent');
                        if (eventData) {
                          const parsed = JSON.parse(eventData);
                          if (parsed.fullDateTime) {
                            const { formattedDate, formattedTime } = parseMatchDateTime(parsed.fullDateTime);
                            return `${formattedDate} ${formattedTime}`;
                          }
                        }
                        // Fallback к старому формату
                        return `${selectedMatch.date} ${selectedMatch.startTime}`;
                      } catch {
                        return `${selectedMatch.date} ${selectedMatch.startTime}`;
                      }
                    })()}</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-foreground/70">{t('prediction')}</span>
                  <Badge variant="outline" className="font-semibold bg-white/5 border-white/10">
                    {outcomes.find(o => o.id === selectedOutcome)?.label}
                  </Badge>
                </div>

                <Separator className="bg-white/10" />

                <div className="flex justify-between items-center">
                  <span className="text-foreground/70">{t('sum_label')}</span>
                  <div className="flex items-center space-x-2">
                    <div className="h-6 w-6 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 flex items-center justify-center">
                      <img src={currentCurrency.icon} alt={currentCurrency.name} className="h-3 w-3" />
                    </div>
                    <span className="font-bold text-lg">{amount} {selectedCurrency}</span>
                  </div>
                </div>
                {comment && (
                  <div className="flex flex-col space-y-1">
                    <span className="text-foreground/70 text-sm">{t('comment_optional')}</span>
                    <span className="text-foreground/80 italic break-words leading-relaxed">{comment}</span>
                  </div>
                )}
              </div>

              <div className="space-y-3">
                <Button
                  onClick={handleConfirmBet}
                  disabled={isCreating}
                  className="w-full h-12 rounded-xl bg-gradient-to-r from-green-400 to-emerald-500 hover:from-green-500 hover:to-emerald-600 border-none relative overflow-hidden shadow-lg group disabled:opacity-50"
                >
                  <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-all duration-700"></span>
                  <div className="flex items-center justify-center space-x-2">
                    <CheckCircle className="h-5 w-5" />
                    <span className="font-semibold">
                      {isCreating ? t('creating') : t('confirm_bet')}
                    </span>
                  </div>
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setShowPreview(false)}
                  className="w-full rounded-xl bg-white/5 backdrop-blur-sm border border-white/10 hover:bg-white/10"
                >
                  {t('change')}
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-6 pb-24">

      {/* Selected Match */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="glass-card border-none overflow-hidden">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center space-x-2">
              <Trophy className="h-5 w-5 text-blue-400" />
              <span>{t('selected_match')}</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {hasSelectedMatch ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-cosmic flex items-center justify-center text-white font-bold">
                      {selectedMatch.homeTeam.charAt(0)}
                    </div>
                    <span className="font-semibold">{selectedMatch.homeTeam}</span>
                  </div>
                  <Badge variant="outline" className="bg-white/10 border-white/10">{selectedMatch.league}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-fire flex items-center justify-center text-white font-bold">
                      {selectedMatch.awayTeam.charAt(0)}
                    </div>
                    <span className="font-semibold">{selectedMatch.awayTeam}</span>
                  </div>
                  <div className="flex items-center space-x-1 text-sm text-foreground/70">
                    <Zap className="h-4 w-4 text-blue-400" />
                    <span>{(() => {
                      try {
                        // Если есть полное время в ISO формате, используем parseMatchDateTime
                        const eventData = localStorage.getItem('selectedEvent');
                        if (eventData) {
                          const parsed = JSON.parse(eventData);
                          if (parsed.fullDateTime) {
                            const { formattedDate, formattedTime } = parseMatchDateTime(parsed.fullDateTime);
                            return `${formattedDate} ${formattedTime}`;
                          }
                        }
                        // Fallback к старому формату
                        return `${selectedMatch.date} ${selectedMatch.startTime}`;
                      } catch {
                        return `${selectedMatch.date} ${selectedMatch.startTime}`;
                      }
                    })()}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <span className="text-foreground/70">{t('no_match_selected_hint')}</span>
                <Button onClick={handleSelectMatchClick} className="rounded-xl">
                  {t('select_match')}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Currency Selection */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="glass-card border-none overflow-hidden">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center space-x-2">
              <CurrencyIcon className="h-5 w-5 text-blue-400" />
              <span>{t('currency')}</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              {currencies.map((currency) => (
                <motion.div key={currency.id} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant={selectedCurrency === currency.id ? "default" : "outline"}
                    onClick={() => handleChangeCurrency(currency.id)}
                    className={`w-full p-4 h-auto flex flex-col space-y-2 rounded-xl ${
                      selectedCurrency === currency.id
                        ? `bg-gradient-to-r ${currency.color} text-white shadow-lg border-none`
                        : "bg-white/5 backdrop-blur-sm border border-white/10"
                    }`}
                  >
                    <img src={currency.icon} alt={currency.name} className="h-6 w-6" />
                    <span className="font-semibold">{currency.name}</span>
                    <span className="text-xs opacity-80">
                      {t('minimum_label_short')} {
                        currency.id === "TON"
                          ? (dynamicMin.TON > 0 ? dynamicMin.TON : "...")
                          : (dynamicMin.STARS > 0 ? dynamicMin.STARS : "...")
                      }
                    </span>
                  </Button>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Amount */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="glass-card border-none overflow-hidden">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center space-x-2">
              <Coins className="h-5 w-5 text-blue-400" />
              <span>{t('amount')}</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="relative">
              <Input
                placeholder={
                  minForSelected > 0
                    ? `${t('minimum_label_short')} ${minForSelected} ${selectedCurrency}`
                    : t('loading_settings')
                }
                value={amount}
                onChange={(e) => handleSetAmount(e.target.value)}
                onFocus={handleInputFocus}
                onBlur={handleInputBlur}
                inputMode="decimal"
                pattern="^[0-9]*[.,]?[0-9]*$"
                // prevent iOS from showing suggestions/autocorrect
                autoComplete="off"
                autoCorrect="off"
                spellCheck={false}
                className={`text-base h-10 rounded-xl bg-white/5 backdrop-blur-sm border border-white/10 focus:border-blue-400 focus:ring-1 focus:ring-blue-400 ${!isValidAmount && amount ? "border-red-500 focus:border-red-500 focus:ring-red-500" : ""}`}
                maxLength={12}
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-2">
                <button
                  type="button"
                  onClick={applyMin}
                  className="px-2 py-1 text-[10px] leading-none rounded-md bg-white/10 border border-white/15 hover:bg-white/15 text-foreground/80"
                  disabled={minForSelected <= 0}
                >
                  {t('min_btn')}
                </button>
                <button
                  type="button"
                  onClick={() => applyMax(selectedCurrency === 'TON' ? balance.TON : balance.STARS)}
                  className="px-2 py-1 text-[10px] leading-none rounded-md bg-white/10 border border-white/15 hover:bg-white/15 text-foreground/80"
                  disabled={minForSelected <= 0}
                >
                  {t('max_btn')}
                </button>
              </div>
            </div>

            {!isValidAmount && amount && (
              <div className="flex items-center space-x-2 text-red-500 text-sm">
                <AlertCircle className="h-4 w-4" />
                <span>{t('minimum_amount_inline', { min: minForSelected, currency: selectedCurrency, usdMin: usdMin || 0 })}</span>
              </div>
            )}

            {validationError && (
              <div className="flex items-center space-x-2 text-red-500 text-sm">
                <AlertCircle className="h-4 w-4" />
                <span>{validationError}</span>
              </div>
            )}

            <div className="text-sm text-foreground/80 py-1">
              {usdMin && t('global_minimum_note', { usdMin: usdMin })}
              {rates && (
                <span className="ml-2 text-xs text-foreground/60">
                  {t('', { tonToUsd: rates.tonToUsd.toFixed(2) })}
                </span>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Outcome Selection */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <Card className="glass-card border-none overflow-hidden">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-blue-400" />
              <span>{t('outcome')}</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {outcomes.map((outcome) => (
              <motion.div key={outcome.id} whileTap={{ scale: 0.98 }}>
                <Button
                  variant={selectedOutcome === outcome.id ? "default" : "outline"}
                  onClick={() => handleSelectOutcome(outcome.id)}
                  className={`w-full justify-center p-4 h-auto rounded-xl ${
                    selectedOutcome === outcome.id
                      ? "bg-gradient-to-r from-blue-400 to-purple-500 text-white border-none"
                      : "bg-white/5 backdrop-blur-sm border border-white/10"
                  }`}
                >
                  <span className="font-medium">{outcome.label}</span>
                </Button>
              </motion.div>
            ))}
          </CardContent>
        </Card>
      </motion.div>

      {/* Comment */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <Card className="glass-card border-none overflow-hidden">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center space-x-2">
              <MessageCircle className="h-5 w-5 text-blue-400" />
              <span>{t('comment_optional')}</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <textarea
              ref={inputRef}
              placeholder={t('comment_placeholder')}
              value={comment}
              onChange={handleCommentChange}
              onFocus={handleInputFocus}
              onBlur={handleInputBlur}
              className="w-full p-3 rounded-xl resize-none h-20 bg-white/5 backdrop-blur-sm border border-white/10 focus:border-blue-400 focus:ring-1 focus:ring-blue-400"
              maxLength={222}
            />
            <div className="text-right text-sm text-foreground/60 mt-1">
              {comment.length}/222
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Create Button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
      >
        <Button
          onClick={handleCreateBet}
          disabled={!hasSelectedMatch || minForSelected <= 0 || !isValidAmount || !selectedOutcome}
          className="w-full h-12 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 disabled:opacity-50 border-none relative overflow-hidden shadow-lg group"
        >
          <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-all duration-700"></span>
          <div className="flex items-center justify-center space-x-2">
            <Trophy className="h-5 w-5" />
            <span className="font-semibold">{t('create_bet')}</span>
            <ChevronRight className="h-5 w-5" />
          </div>
        </Button>
      </motion.div>
    </div>
  );
};

export const CreateBetPage = (props: CreateBetPageProps) => (
  <CreateBetI18nProvider>
    <CreateBetPageContent {...props} />
  </CreateBetI18nProvider>
);
