#!/bin/sh

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

success() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] ✓${NC} $1"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ✗${NC} $1"
}

warning() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] ⚠${NC} $1"
}

log "🚀 Начинаем деплой TMA без Docker..."

# Проверяем Node.js
if ! command -v node &> /dev/null; then
    error "Node.js не установлен!"
    log "Устанавливаем Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi

# Проверяем Bun
if ! command -v bun &> /dev/null; then
    log "Устанавливаем Bun..."
    curl -fsSL https://bun.sh/install | bash
    source ~/.bashrc
    export PATH="$HOME/.bun/bin:$PATH"
fi

# Проверяем PM2 для управления процессами
if ! command -v pm2 &> /dev/null; then
    log "Устанавливаем PM2..."
    npm install -g pm2
fi

# Обновляем код из git (если это репозиторий)
if [ -d ".git" ]; then
    log "📥 Обновляем код из git..."
    git pull
fi

# Останавливаем старое приложение
log "🛑 Останавливаем старое приложение..."
pm2 stop tma-app 2>/dev/null || true
pm2 delete tma-app 2>/dev/null || true

# Устанавливаем зависимости
log "📦 Устанавливаем зависимости..."
bun install

# Проверяем .env файл
if [ ! -f ".env" ]; then
    if [ -f ".env" ]; then
        cp .env.production .env.production.local
        warning "Скопирован .env в .env"
        warning "Отредактируйте файл .env.production.local с вашими настройками!"
    else
        error "Создайте файл .env.production.local с настройками!"
        exit 1
    fi
fi

# Загружаем переменные окружения
export NODE_ENV=production
if [ -f ".env" ]; then
    set -a
    source .env
    set +a
elif [ -f ".env.production.local" ]; then
    set -a
    source .env.production.local
    set +a
fi

# Собираем приложение
log "🔨 Собираем приложение..."
if ! bun run build; then
    error "Ошибка при сборке приложения!"
    exit 1
fi

# Запускаем приложение через PM2
log "🚀 Запускаем приложение..."
pm2 start npm --name "tma-app" -- start

# Настраиваем cron для автоматической проверки матчей
log "⏰ Настраиваем автоматическую проверку матчей..."

# Определяем URL для cron - используем прямой домен
CRON_URL="https://testdomen.site/api/cron/check-matches"
log "Используем URL: $CRON_URL"

# Удаляем старые cron задачи для этого приложения
crontab -l 2>/dev/null | grep -v "check-matches" | crontab -

# Добавляем новую cron задачу (каждые 15 минут)
(crontab -l 2>/dev/null; echo "*/15 * * * * curl -s -X POST '$CRON_URL' >> /var/log/tma-cron.log 2>&1") | crontab -

success "✅ Cron задача настроена (каждые 15 минут)"

# Сохраняем конфигурацию PM2
pm2 save
pm2 startup

# Ждем запуска
log "⏳ Ожидаем запуска приложения..."
sleep 5

# Проверяем статус
log "📊 Статус приложения:"
pm2 status tma-app

# Проверяем доступность
log "🔍 Проверяем доступность..."
if curl -f -s http://localhost:3000 > /dev/null; then
    success "✅ Приложение успешно запущено!"
else
    warning "⚠️  Приложение может быть еще не готово. Проверьте логи: pm2 logs tma-app"
fi

success "🎉 Деплой завершен!"
echo ""
echo "🌐 Приложение запущено на порту 3000"
echo "⏰ Автоматическая проверка матчей настроена (каждые 15 минут)"
echo ""
echo "📝 Полезные команды:"
echo "   pm2 status           - статус приложений"
echo "   pm2 logs tma-app     - логи приложения"
echo "   pm2 restart tma-app  - перезапуск"
echo "   pm2 stop tma-app     - остановка"
echo "   pm2 monit            - мониторинг в реальном времени"
echo ""
echo "🔧 Cron команды:"
echo "   crontab -l           - посмотреть активные cron задачи"
echo "   tail -f /var/log/tma-cron.log - логи автопроверки матчей"
echo "   curl -X POST https://testdomen.site/api/cron/check-matches - ручная проверка"
echo ""
