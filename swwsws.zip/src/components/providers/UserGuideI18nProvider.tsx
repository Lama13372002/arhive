"use client";
import React, { createContext, useCallback, useContext, useMemo } from "react";
import { useI18n } from "./I18nProvider";

type Dict = Record<string, string>;

const ru: Dict = {
  // Modal title
  modal_title: "Руководство FanFray",
  close_button: "Закрыть",

  // Section titles
  section_intro: "Введение",
  section_how_it_works: "Как работают споры",
  section_pages: "Страницы и функции",
  section_balance: "Баланс и TON",
  section_referral: "Реферальная программа",

  // Introduction section
  intro_what_is_title: "Что такое FanFray?",
  intro_description_1: "Приложение FanFray — это **не букмекерская контора**, а платформа для споров на футбольные матчи.",
  intro_description_2: "Здесь пользователи спорят друг с другом: один прогнозирует победу 1-й команды, другой — победу 2-й команды и возможен третий игрок, который уверен в ничейном результате.",
  intro_point_1: "Вы не ставите против букмекера",
  intro_point_2: "Спор идет только между людьми",
  intro_point_3: "Тут нет коэффициентов!",
  intro_point_3_desc: "На каждый спор устанавливается статичная сумма, на которую мы с вами спорим",
  intro_example_title: "Пример спора:",
  intro_example_text: "В споре участвуют 3 человека, каждый ставит по 10 TON. Общий банк: 30 TON. Если побеждает ставка на 1-ю команду, то выбравший её игрок получает весь банк — 30 TON (за вычетом комиссии FanFray).",

  // How it works section
  how_it_works_title: "Как работает спор",
  how_it_works_step_1: "Один игрок создаёт спор, выбирает матч и начинает спор",
  how_it_works_step_2: "Другие игроки могут присоединиться, выбрав противоположный исход (или ничью)",
  how_it_works_step_3: "Сумма всех участников блокируются до конца матча",
  how_it_works_step_4: "После завершения система автоматически определяет исход и распределяет выигрыш",
  how_it_works_step_5: "Комиссия удерживается только за использование сервиса",

  bet_statuses_title: "Статусы споров:",
  status_active: "Активный",
  status_active_desc: "Матч еще идет",
  status_won: "Выигран",
  status_won_desc: "Ваш прогноз оказался верным",
  status_lost: "Проигран",
  status_lost_desc: "Ваш прогноз оказался неверным",
  status_refund: "Возврат",
  status_refund_desc: "Матч отменен или спор не собрал участников",

  // Pages section
  pages_title: "Страницы и функции",
  page_home_title: "🏠 Главная",
  page_home_1: "• Отображение всех матчей (популярные и Live)",
  page_home_2: "• Строка поиска команд",
  page_home_3: "• Фильтр по лигам (Premier League, Bundesliga и др.)",
  page_home_4: "• Кнопка \"Создать спор\"",

  page_bets_title: "⚽ Споры",
  page_bets_1: "• Все открытые и завершённые споры",
  page_bets_2: "• Фильтрация: Все, Активные, Выигранные, Проигранные, Возврат",
  page_bets_3: "• Информация о прогнозе, сумме, участниках, счете",
  page_bets_4: "• Возможность повторить спор",

  page_create_title: "➕ Создать",
  page_create_1: "• Выбор матча и валюты (TON)",
  page_create_2: "• Ввод суммы (минимум $10)",
  page_create_3: "• Прогноз: П1 (Победа хозяев), Х (Ничья), П2 (Победа гостей)",
  page_create_4: "• Добавление комментария",

  page_my_title: "📊 Мои",
  page_my_1: "• Личная статистика и процент побед",
  page_my_2: "• Количество выигранных споров",
  page_my_3: "• История завершённых матчей",

  page_chat_title: "💬 Чат",
  page_chat_1: "• Общение между пользователями",
  page_chat_2: "• Обсуждение матчей и договоренности о спорах",
  page_chat_3: "• Модерация для поддержания порядка",

  page_menu_title: "⚙️ Меню",
  page_menu_1: "• Профиль: ник, статистика",
  page_menu_2: "• Баланс: пополнение и вывод TON",
  page_menu_3: "• Реферальная программа: приглашение друзей (5% с депозитов)",
  page_menu_4: "• FAQ: ответы на часто задаваемые вопросы",
  page_menu_5: "• Язык: переключение между RU и ENG",

  // Balance section
  balance_title: "Баланс и работа с TON",
  deposit_title: "💰 Пополнение:",
  deposit_step_1: "Зайдите в Меню → Баланс → Пополнить",
  deposit_step_2: "Подключите TON-кошелек",
  deposit_step_3: "Переведите нужное количество TON",

  withdrawal_title: "💸 Вывод:",
  withdrawal_step_1: "Зайдите в Меню → Баланс → Вывести",
  withdrawal_step_2: "Укажите адрес своего TON-кошелька",
  withdrawal_step_3: "Подтвердите операцию",

  security_title: "Безопасность",
  security_desc: "Все операции идут через блокчейн TON, поэтому средства надежно защищены.",

  // Referral section
  referral_title: "Реферальная программа",
  referral_main_title: "Получайте 5% с депозитов друзей!",
  referral_step_1: "Приглашайте друзей через свою ссылку",
  referral_step_2: "Получайте 5% с их депозитов",
  referral_step_3: "Смотрите статистику в разделе \"Реферальная программа\"",
  referral_tip: "💡 **Совет:** Чем больше активных рефералов, тем больше ваш доход!",
};

const en: Dict = {
  // Modal title
  modal_title: "FanFray Guide",
  close_button: "Close",

  // Section titles
  section_intro: "Introduction",
  section_how_it_works: "How Disputes Work",
  section_pages: "Pages and Features",
  section_balance: "Balance and TON",
  section_referral: "Referral Program",

  // Introduction section
  intro_what_is_title: "What is FanFray?",
  intro_description_1: "FanFray app is **not a bookmaker**, but a platform for disputes on football matches.",
  intro_description_2: "Here users dispute with each other: one predicts the victory of the 1st team, another - the victory of the 2nd team, and there can be a third player who is confident in a draw result.",
  intro_point_1: "You don't bet against the bookmaker",
  intro_point_2: "The dispute is only between people",
  intro_point_3: "There are no odds here!",
  intro_point_3_desc: "A static amount is set for each dispute that we bet with you",
  intro_example_title: "Dispute example:",
  intro_example_text: "3 people participate in the dispute, each betting 10 TON. Total pool: 30 TON. If the bet on the 1st team wins, then the player who chose it receives the entire pool — 30 TON (minus FanFray commission).",

  // How it works section
  how_it_works_title: "How a dispute works",
  how_it_works_step_1: "One player creates a dispute, chooses a match and starts the dispute",
  how_it_works_step_2: "Other players can join by choosing the opposite outcome (or draw)",
  how_it_works_step_3: "The sum of all participants is locked until the end of the match",
  how_it_works_step_4: "After completion, the system automatically determines the outcome and distributes the winnings",
  how_it_works_step_5: "Commission is charged only for using the service",

  bet_statuses_title: "Dispute statuses:",
  status_active: "Active",
  status_active_desc: "Match is still ongoing",
  status_won: "Won",
  status_won_desc: "Your prediction was correct",
  status_lost: "Lost",
  status_lost_desc: "Your prediction was incorrect",
  status_refund: "Refund",
  status_refund_desc: "Match canceled or dispute didn't gather participants",

  // Pages section
  pages_title: "Pages and Features",
  page_home_title: "🏠 Home",
  page_home_1: "• Display of all matches (popular and Live)",
  page_home_2: "• Team search bar",
  page_home_3: "• Filter by leagues (Premier League, Bundesliga, etc.)",
  page_home_4: "• \"Create dispute\" button",

  page_bets_title: "⚽ Disputes",
  page_bets_1: "• All open and completed disputes",
  page_bets_2: "• Filtering: All, Active, Won, Lost, Refund",
  page_bets_3: "• Information about prediction, amount, participants, score",
  page_bets_4: "• Ability to repeat dispute",

  page_create_title: "➕ Create",
  page_create_1: "• Match and currency selection (TON)",
  page_create_2: "• Amount input (minimum $10)",
  page_create_3: "• Prediction: P1 (Home win), X (Draw), P2 (Away win)",
  page_create_4: "• Adding a comment",

  page_my_title: "📊 My",
  page_my_1: "• Personal statistics and win percentage",
  page_my_2: "• Number of won disputes",
  page_my_3: "• History of completed matches",

  page_chat_title: "💬 Chat",
  page_chat_1: "• Communication between users",
  page_chat_2: "• Discussion of matches and dispute arrangements",
  page_chat_3: "• Moderation to maintain order",

  page_menu_title: "⚙️ Menu",
  page_menu_1: "• Profile: nickname, statistics",
  page_menu_2: "• Balance: deposit and withdraw TON",
  page_menu_3: "• Referral program: invite friends (5% from deposits)",
  page_menu_4: "• FAQ: answers to frequently asked questions",
  page_menu_5: "• Language: switching between RU and ENG",

  // Balance section
  balance_title: "Balance and TON Operations",
  deposit_title: "💰 Deposit:",
  deposit_step_1: "Go to Menu → Balance → Deposit",
  deposit_step_2: "Connect TON wallet",
  deposit_step_3: "Transfer the required amount of TON",

  withdrawal_title: "💸 Withdrawal:",
  withdrawal_step_1: "Go to Menu → Balance → Withdraw",
  withdrawal_step_2: "Specify your TON wallet address",
  withdrawal_step_3: "Confirm the operation",

  security_title: "Security",
  security_desc: "All operations go through TON blockchain, so funds are securely protected.",

  // Referral section
  referral_title: "Referral Program",
  referral_main_title: "Get 5% from friends' deposits!",
  referral_step_1: "Invite friends through your link",
  referral_step_2: "Get 5% from their deposits",
  referral_step_3: "View statistics in \"Referral Program\" section",
  referral_tip: "💡 **Tip:** The more active referrals, the more your income!",
};

const dicts = { ru, en };

type Ctx = { t: (key: string, params?: Record<string, string | number>) => string };
const Ctx = createContext<Ctx | undefined>(undefined);

export const UserGuideI18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useI18n();
  const t = useCallback((key: string, params?: Record<string, string | number>) => {
    const dict = dicts[lang] || en;
    let text = dict[key] ?? key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
      });
    }
    return text;
  }, [lang]);
  const value = useMemo(() => ({ t }), [t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export const useUserGuideI18n = () => {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useUserGuideI18n must be used within UserGuideI18nProvider");
  return ctx;
};
