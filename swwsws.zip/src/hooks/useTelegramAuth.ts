import { useEffect, useState } from 'react';
import { useTelegram } from '@/components/providers/TelegramProvider';
import { userApi } from '@/lib/api';
import type { UserData } from '@/types/api';

export function useTelegramAuth() {
  const { user: telegramUser, isReady } = useTelegram();
  const [userData, setUserData] = useState<UserData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const registerOrLoginUser = async () => {
      if (!isReady || !telegramUser?.id) {
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        setError(null);

        // Извлекаем реферальный код из URL
        let referralCode: string | undefined = undefined;

        if (typeof window !== 'undefined') {
          // Проверяем start parameter из Telegram WebApp
          const telegramWebApp = window.Telegram?.WebApp;
          if (telegramWebApp?.initDataUnsafe?.start_param) {
            const startParam = telegramWebApp.initDataUnsafe.start_param;
            if (startParam.startsWith('ref_')) {
              referralCode = startParam.substring(4); // Убираем префикс 'ref_'
              console.log('Referral code from Telegram start param:', referralCode);
            }
          }

          // Альтернативно, проверяем URL параметры (для веб-версии)
          const urlParams = new URLSearchParams(window.location.search);
          const urlRef = urlParams.get('ref');
          if (urlRef && !referralCode) {
            referralCode = urlRef;
            console.log('Referral code from URL param:', referralCode);
          }
        }

        // Подготавливаем данные для регистрации
        const registrationData: Record<string, unknown> = {
          telegram_id: telegramUser.id,
          username: telegramUser.username,
          first_name: telegramUser.first_name,
          last_name: telegramUser.last_name
        };

        // Добавляем реферальный код, если найден
        if (referralCode) {
          registrationData.referral_code = referralCode;
          console.log('Registering with referral code:', referralCode);
        }

        // Регистрируем пользователя (или получаем существующего)
        const response = await userApi.register(registrationData);

        setUserData(response.user);

        // Логируем информацию о реферальной регистрации
        if (response.referral?.created) {
          console.log('User registered with referral bonus:', response.referral.welcome_bonus);
        }

      } catch (err) {
        console.error('Auth error:', err);
        setError('Ошибка авторизации');
      } finally {
        setIsLoading(false);
      }
    };

    registerOrLoginUser();
  }, [telegramUser, isReady]);

  const refreshBalance = async () => {
    if (!telegramUser?.id) return;

    try {
      const response = await userApi.getBalance(telegramUser.id);
      setUserData(response.user);
    } catch (err) {
      console.error('Error refreshing balance:', err);
    }
  };

  const refreshUserData = refreshBalance; // Alias для совместимости

  return {
    userData,
    isLoading,
    error,
    refreshBalance,
    refreshUserData,
    telegramUser
  };
}
