import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';

// GET - получить список всех пользователей с полной статистикой
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const adminPassword = searchParams.get('adminPassword');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const search = searchParams.get('search') || '';
    const sortBy = searchParams.get('sortBy') || 'created_at';
    const sortOrder = searchParams.get('sortOrder') || 'DESC';

    // Простая проверка админ пароля
    if (adminPassword !== process.env.ADMIN_PASSWORD) {
      return NextResponse.json(
        { success: false, error: 'Неверный пароль администратора' },
        { status: 401 }
      );
    }

    const offset = (page - 1) * limit;

    // Условие поиска
    const searchCondition = search ? `
      WHERE (LOWER(u.username) LIKE LOWER($3)
         OR LOWER(u.first_name) LIKE LOWER($3)
         OR LOWER(u.last_name) LIKE LOWER($3)
         OR u.telegram_id::text LIKE $3)
    ` : '';

    const searchParams_query = search ? [`%${search}%`] : [];

    // Получаем пользователей с полной статистикой
    const usersQuery = `
      SELECT
        u.id,
        u.telegram_id,
        u.username,
        u.first_name,
        u.last_name,
        u.ton_balance,
        u.stars_balance,
        u.created_at as registration_date,
        u.updated_at as last_update,
        u.referral_code,
        u.referred_by_code,
        u.referral_earnings,
        u.total_referrals,
        u.active_referrals,
        u.is_blocked_app,
        u.is_blocked_chat,
        u.blocked_at,
        u.blocked_by_admin,
        u.block_reason,

        -- Статистика ставок как создатель
        COUNT(CASE WHEN b.creator_id = u.id THEN 1 END) as total_bets_created,
        COUNT(CASE WHEN b.creator_id = u.id AND b.status = 'completed' THEN 1 END) as completed_bets_created,
        COUNT(CASE WHEN b.creator_id = u.id AND b.status = 'refunded' THEN 1 END) as refunded_bets_created,
        COUNT(CASE WHEN b.creator_id = u.id AND b.status = 'open' THEN 1 END) as open_bets_created,

        -- Статистика участия в ставках
        COUNT(CASE WHEN bp.user_id = u.id THEN 1 END) as total_bets_joined,

        -- Общие суммы ставок
        COALESCE(SUM(CASE WHEN b.creator_id = u.id AND b.currency = 'TON' THEN b.amount ELSE 0 END), 0) as total_ton_created,
        COALESCE(SUM(CASE WHEN b.creator_id = u.id AND b.currency = 'STARS' THEN b.amount ELSE 0 END), 0) as total_stars_created,
        COALESCE(SUM(CASE WHEN bp.user_id = u.id AND b.currency = 'TON' THEN bp.amount ELSE 0 END), 0) as total_ton_joined,
        COALESCE(SUM(CASE WHEN bp.user_id = u.id AND b.currency = 'STARS' THEN bp.amount ELSE 0 END), 0) as total_stars_joined,

        -- Последняя активность
        GREATEST(
          COALESCE(MAX(b.created_at), '1970-01-01'::timestamp),
          COALESCE(MAX(bp.joined_at), '1970-01-01'::timestamp)
        ) as last_activity,

        -- Подсчет побед и поражений (будет 0, пока не добавим логику результатов)
        0 as wins,
        0 as losses

      FROM users u
      LEFT JOIN bets b ON b.creator_id = u.id
      LEFT JOIN bet_participants bp ON bp.user_id = u.id
      ${searchCondition}
      GROUP BY u.id, u.telegram_id, u.username, u.first_name, u.last_name,
               u.ton_balance, u.stars_balance, u.created_at, u.updated_at,
               u.referral_code, u.referred_by_code, u.referral_earnings,
               u.total_referrals, u.active_referrals
      ORDER BY ${sortBy} ${sortOrder}
      LIMIT $1 OFFSET $2
    `;

    const params = [limit, offset, ...searchParams_query];

    const result = await query(usersQuery, params);

    // Получаем общее количество пользователей для пагинации
    const countQuery = `
      SELECT COUNT(*) as total
      FROM users u
      ${searchCondition}
    `;

    const countParams = search ? [`%${search}%`] : [];
    const countResult = await query(countQuery, countParams);
    const total = parseInt(countResult.rows[0].total);

    // Форматируем данные пользователей
    const users = result.rows.map(user => ({
      ...user,
      ton_balance: parseFloat(user.ton_balance),
      stars_balance: parseFloat(user.stars_balance),
      total_ton_created: parseFloat(user.total_ton_created),
      total_stars_created: parseFloat(user.total_stars_created),
      total_ton_joined: parseFloat(user.total_ton_joined),
      total_stars_joined: parseFloat(user.total_stars_joined),
      referral_earnings: parseFloat(user.referral_earnings),
      registration_date: user.registration_date,
      last_activity: user.last_activity !== '1970-01-01T00:00:00.000Z' ? user.last_activity : null,
      total_bets: parseInt(user.total_bets_created) + parseInt(user.total_bets_joined),
    }));

    return NextResponse.json({
      success: true,
      users,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Ошибка при получении пользователей:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка при получении данных пользователей' },
      { status: 500 }
    );
  }
}
