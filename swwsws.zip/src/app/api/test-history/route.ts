import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const telegramId = searchParams.get('telegramId') || '1017292193';

  try {
    // Простейший запрос
    const result = await pool.query(
      `SELECT
        ct.id,
        ct.user_id,
        ct.stars_amount,
        ct.ton_amount::text as ton_amount_text,
        ct.ton_amount::float as ton_amount_float,
        ct.status,
        ct.created_at,
        u.telegram_id,
        u.username,
        u.first_name
       FROM conversion_transactions ct
       LEFT JOIN users u ON ct.user_id = u.id
       WHERE u.telegram_id = $1
       ORDER BY ct.created_at DESC`,
      [telegramId]
    );

    return NextResponse.json({
      telegramId: telegramId,
      telegramIdType: typeof telegramId,
      found: result.rows.length,
      data: result.rows,
      testTime: new Date().toISOString()
    });

  } catch (error) {
    return NextResponse.json({
      error: 'Error',
      details: error instanceof Error ? error.message : 'Unknown error',
      telegramId: telegramId
    }, { status: 500 });
  }
}
