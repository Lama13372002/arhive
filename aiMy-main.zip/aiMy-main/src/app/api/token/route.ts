import { NextResponse, NextRequest } from 'next/server';
import { createDbConnection } from '@/lib/database';

// Функция для получения промта из базы данных или дефолтного
const getSystemPrompt = async (voice: string, conversationHistory: string, userId?: number): Promise<string> => {
  const baseContext = conversationHistory ? conversationHistory : '';
  let promptContent = '';

  // Пытаемся получить пользовательский промпт из базы данных
  if (userId) {
    const client = createDbConnection();
    try {
      await client.connect();

      // Получаем выбранный промпт пользователя
      const promptResult = await client.query(`
        SELECT vp.content, vp.voice_gender, vp.title
        FROM users u
        LEFT JOIN voice_prompts vp ON u.selected_prompt_id = vp.id
        WHERE u.id = $1 AND (vp.is_active = true OR vp.id IS NULL)
      `, [userId]);

      if (promptResult.rows.length > 0 && promptResult.rows[0].content) {
        const prompt = promptResult.rows[0];
        promptContent = prompt.content;

        // Добавляем специальные инструкции для женских голосов
        if (voice === 'marin' || voice === 'coral' || voice === 'shimmer' || prompt.voice_gender === 'female') {
          promptContent += '\n\nВАЖНО: Ты используешь женский голос, поэтому всегда говори в женском роде (поняла вместо понял, готова вместо готов, и т.д.).';
        }

        promptContent += baseContext;
        await client.end();
        return promptContent;
      }

      await client.end();
    } catch (dbError) {
      console.error('Ошибка получения промпта из БД:', dbError);
    }
  }

  // Если не удалось получить промпт из БД, используем дефолтный
  if (voice === 'marin' || voice === 'coral' || voice === 'shimmer') {
    return `Ты дружелюбная и внимательная ИИ-ассистентка. Ты говоришь женским голосом и должна использовать женский род в речи.

    Основные принципы:
    - Используй женский род (поняла вместо понял, готова вместо готов, etc.)
    - Говори естественно и дружелюбно
    - Будь полезной и отзывчивой
    - Отвечай кратко, но информативно
    - Поддерживай живую беседу
    - Всегда отвечай на том же языке, на котором к тебе обращается пользователь

    Помни: ты не просто ИИ, а именно ассистентка с женским голосом, общайся соответственно.${baseContext}`;
  }

  // Общий промт для всех остальных голосов
  return `Ты дружелюбный и полезный ИИ-ассистент. Отвечай естественно и по делу.

  Основные принципы:
  - Говори кратко, но информативно
  - Будь полезным и отзывчивым
  - Поддерживай живую беседу
  - Всегда отвечай на том же языке, на котором к тебе обращается пользователь${baseContext}`;
};

export async function GET(request: NextRequest) {
  try {
    const apiKey = process.env.OPENAI_API_KEY;

    if (!apiKey) {
      return NextResponse.json(
        { error: 'OpenAI API key не настроен' },
        { status: 500 }
      );
    }

    // Получаем user_id из параметров запроса
    const { searchParams } = new URL(request.url);
    const userIdParam = searchParams.get('user_id');

    let conversationHistory = '';
    let selectedVoice = 'ash'; // Голос по умолчанию
    let userId: number | null = null;

    if (userIdParam) {
      userId = parseInt(userIdParam);
      const client = createDbConnection();

      try {
        await client.connect();

        // Получаем выбранный голос пользователя
        const voiceResult = await client.query(
          'SELECT selected_voice FROM users WHERE id = $1',
          [userId]
        );

        if (voiceResult.rows.length > 0 && voiceResult.rows[0].selected_voice) {
          selectedVoice = voiceResult.rows[0].selected_voice;
        }

        // Получаем последние 6 сообщений для контекста
        const historyResult = await client.query(`
          SELECT role, content, msg_timestamp
          FROM get_user_conversation_context($1, 6)
          ORDER BY msg_timestamp ASC
        `, [userId]);

        if (historyResult.rows.length > 0) {
          conversationHistory = '\n\nКОНТЕКСТ ПРЕДЫДУЩЕГО РАЗГОВОРА:\n';
          for (const msg of historyResult.rows) {
            const timeAgo = new Date(Date.now() - new Date(msg.msg_timestamp).getTime()).getMinutes();
            conversationHistory += `${msg.role === 'user' ? 'Пользователь' : 'Ты'} (${timeAgo} мин назад): ${msg.content}\n`;
          }
          conversationHistory += '\nПродолжи разговор, учитывая этот контекст. Если пользователь спросит "о чем мы говорили", ссылайся на этот контекст.';
        }

        await client.end();
      } catch (dbError) {
        console.error('Ошибка получения данных пользователя:', dbError);
        // Продолжаем с голосом по умолчанию, если есть ошибка с БД
      }
    }

    const sessionConfig = {
      session: {
        type: "realtime",
        model: "gpt-realtime",
        audio: {
          output: {
            voice: selectedVoice, // Используем выбранный голос пользователя
          },
        },
        instructions: await getSystemPrompt(selectedVoice, conversationHistory, userId || undefined),
      },
    };

    console.log(`🎙️ Создаем сессию с голосом: ${selectedVoice} для пользователя: ${userIdParam}`);

    const response = await fetch(
      "https://api.openai.com/v1/realtime/client_secrets",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(sessionConfig),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error('OpenAI API error:', response.status, errorText);
      throw new Error(`OpenAI API вернул статус: ${response.status}. Детали: ${errorText}`);
    }

    const data = await response.json();
    return NextResponse.json(data);
  } catch (error) {
    console.error("Ошибка при получении токена:", error);
    return NextResponse.json(
      { error: "Не удалось получить токен" },
      { status: 500 }
    );
  }
}
