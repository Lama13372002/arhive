import { NextRequest, NextResponse } from 'next/server';
import { createDbConnection } from '@/lib/database';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const userId = searchParams.get('user_id');

  if (!userId) {
    return NextResponse.json(
      { success: false, error: 'User ID is required' },
      { status: 400 }
    );
  }

  const client = createDbConnection();

  try {
    await client.connect();

    // Получаем текущий активный план пользователя
    const currentPlanQuery = `
      SELECT
        us.id as subscription_id,
        us.start_date,
        us.end_date,
        us.status,
        sp.name as plan_name,
        sp.token_amount,
        sp.features,
        u.token_balance,
        COALESCE(SUM(tu.cost_tokens), 0) as tokens_used_in_plan
      FROM users u
      LEFT JOIN user_subscriptions us ON u.id = us.user_id AND us.status = 'active'
      LEFT JOIN subscription_plans sp ON us.plan_id = sp.id
      LEFT JOIN token_usage tu ON tu.user_id = u.id
        AND us.start_date IS NOT NULL
        AND tu.created_at >= us.start_date
        AND (us.end_date IS NULL OR tu.created_at <= us.end_date)
      WHERE u.id = $1
      GROUP BY us.id, us.start_date, us.end_date, us.status, sp.name, sp.token_amount, sp.features, u.token_balance
      ORDER BY us.created_at DESC
      LIMIT 1
    `;

    const result = await client.query(currentPlanQuery, [userId]);

    if (result.rows.length === 0) {
      await client.end();
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const row = result.rows[0];

    // Если у пользователя есть активная подписка
    if (row.subscription_id && row.status === 'active') {
      const tokensUsedInPlan = parseInt(row.tokens_used_in_plan) || 0;
      const tokensRemainingInPlan = Math.max(0, row.token_amount - tokensUsedInPlan);

      // Проверяем, не закончились ли токены в плане
      const shouldClosePlan = tokensRemainingInPlan <= 0;

      if (shouldClosePlan) {
        // Автоматически закрываем план, если токены закончились
        await client.query(
          'UPDATE user_subscriptions SET status = $1, end_date = NOW(), updated_at = NOW() WHERE id = $2',
          ['expired', row.subscription_id]
        );

        await client.end();

        return NextResponse.json({
          success: true,
          has_active_subscription: false,
          current_plan_name: 'Бесплатный план',
          plan_expired: true
        });
      }

      await client.end();

      return NextResponse.json({
        success: true,
        has_active_subscription: true,
        current_plan_name: row.plan_name,
        subscription_id: row.subscription_id,
        plan_token_amount: row.token_amount,
        tokens_used_in_plan: tokensUsedInPlan,
        tokens_remaining_in_plan: tokensRemainingInPlan,
        start_date: row.start_date,
        end_date: row.end_date,
        features: row.features || []
      });
    } else {
      // У пользователя нет активной подписки
      await client.end();

      return NextResponse.json({
        success: true,
        has_active_subscription: false,
        current_plan_name: 'Бесплатный план'
      });
    }

  } catch (error) {
    console.error('Error fetching user current plan:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch user current plan' },
      { status: 500 }
    );
  } finally {
    await client.end();
  }
}
