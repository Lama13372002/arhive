import { NextResponse } from 'next/server';
import { createDbConnection, type RawUser } from '@/lib/database';

export async function POST(request: Request) {
  try {
    const { telegram_id, username, first_name, last_name, language_code } = await request.json();

    if (!telegram_id || !first_name) {
      return NextResponse.json(
        { error: 'telegram_id и first_name обязательны' },
        { status: 400 }
      );
    }

    const client = createDbConnection();
    await client.connect();

    // Проверяем, существует ли пользователь
    let result = await client.query(
      'SELECT * FROM users WHERE telegram_id = $1',
      [telegram_id]
    );

    let user;
    const defaultTokenBalance = 1000; // Начальный баланс токенов для новых пользователей

    if (result.rows.length === 0) {
      // Создаем нового пользователя с начальным балансом токенов
      result = await client.query(`
        INSERT INTO users (telegram_id, username, first_name, last_name, language_code, token_balance, created_at, updated_at, last_active)
        VALUES ($1, $2, $3, $4, $5, $6, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        RETURNING *
      `, [telegram_id, username, first_name, last_name, language_code, defaultTokenBalance]);

      user = result.rows[0];
    } else {
      // Обновляем существующего пользователя
      result = await client.query(`
        UPDATE users
        SET username = $2, first_name = $3, last_name = $4, language_code = $5,
            last_active = CURRENT_TIMESTAMP,
            updated_at = CURRENT_TIMESTAMP
        WHERE telegram_id = $1
        RETURNING *
      `, [telegram_id, username, first_name, last_name, language_code]);

      user = result.rows[0];

      // Если у пользователя нет поля token_balance (старые пользователи), добавляем его
      if (user.token_balance === null || user.token_balance === undefined) {
        await client.query(`
          UPDATE users
          SET token_balance = $1
          WHERE telegram_id = $2
        `, [defaultTokenBalance, telegram_id]);
        user.token_balance = defaultTokenBalance;
      }
    }

    // Проверяем активную подписку
    const subscriptionResult = await client.query(`
      SELECT sp.name as plan_name, us.end_date
      FROM user_subscriptions us
      JOIN subscription_plans sp ON us.plan_id = sp.id
      WHERE us.user_id = $1
        AND us.status = 'active'
        AND us.end_date > CURRENT_TIMESTAMP
      ORDER BY us.end_date DESC
      LIMIT 1
    `, [user.id]);

    await client.end();

    // Преобразуем сырые данные в нужный формат
    const userData = {
      id: user.id,
      telegram_id: user.telegram_id,
      username: user.username,
      first_name: user.first_name,
      last_name: user.last_name,
      language_code: user.language_code,
      is_premium: user.is_premium,
      token_balance: user.token_balance || 0,
      selected_voice: user.selected_voice || 'ash',
      has_active_subscription: subscriptionResult.rows.length > 0,
      current_plan_name: subscriptionResult.rows.length > 0 ? subscriptionResult.rows[0].plan_name : null,
      created_at: new Date(user.created_at),
      updated_at: new Date(user.updated_at),
      last_active: new Date(user.last_active)
    };

    return NextResponse.json({
      success: true,
      user: userData
    });

  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const telegram_id = searchParams.get('telegram_id');

  if (!telegram_id) {
    return NextResponse.json(
      { error: 'telegram_id обязателен' },
      { status: 400 }
    );
  }

  const client = createDbConnection();

  try {
    await client.connect();

    const result = await client.query(
      'SELECT * FROM users WHERE telegram_id = $1',
      [telegram_id]
    );

    if (result.rows.length === 0) {
      return NextResponse.json(
        { error: 'Пользователь не найден' },
        { status: 404 }
      );
    }

    const user = result.rows[0];

    // Проверяем активную подписку
    const subscriptionResult = await client.query(`
      SELECT sp.name as plan_name, us.end_date
      FROM user_subscriptions us
      JOIN subscription_plans sp ON us.plan_id = sp.id
      WHERE us.user_id = $1
        AND us.status = 'active'
        AND us.end_date > CURRENT_TIMESTAMP
      ORDER BY us.end_date DESC
      LIMIT 1
    `, [user.id]);

    await client.end();

    // Преобразуем сырые данные в нужный формат
    const userData = {
      id: user.id,
      telegram_id: user.telegram_id,
      username: user.username,
      first_name: user.first_name,
      last_name: user.last_name,
      language_code: user.language_code,
      is_premium: user.is_premium,
      token_balance: user.token_balance || 0,
      selected_voice: user.selected_voice || 'ash',
      has_active_subscription: subscriptionResult.rows.length > 0,
      current_plan_name: subscriptionResult.rows.length > 0 ? subscriptionResult.rows[0].plan_name : null,
      created_at: new Date(user.created_at),
      updated_at: new Date(user.updated_at),
      last_active: new Date(user.last_active)
    };

    return NextResponse.json({
      success: true,
      user: userData
    });

  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
