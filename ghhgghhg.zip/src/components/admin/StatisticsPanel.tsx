'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  Target,
  RefreshCw,
  ArrowUpCircle,
  ArrowDownCircle,
  Trophy,
  X
} from 'lucide-react';

interface StatisticsData {
  deposits: {
    total_count: number;
    total_amount: number;
    stars_conversions: {
      count: number;
      amount: number;
    };
  };
  withdrawals: {
    total_count: number;
    total_amount: number;
  };
  disputes: {
    total_completed: number;
    total_refunded: number;
    won_disputes: number;
    lost_disputes: number;
    unique_winners: number;
    unique_participants: number;
    total_won_amount: number;
    total_bet_amount: number;
    total_refund_amount: number;
    participants_by_position: Array<{
      position: string;
      total_participants: string;
      total_amount: string;
    }>;
    detailed_stats: {
      total_participations: number;
      refunded_participations: number;
      unique_refunded_users: number;
    };
  };
  transactions: Array<{
    transaction_type: string;
    count: string;
    total_amount: string;
  }>;
  summary: {
    net_flow: number;
    total_platform_volume: number;
  };
}

interface StatisticsPanelProps {
  adminPassword: string;
}

export default function StatisticsPanel({ adminPassword }: StatisticsPanelProps) {
  const [statistics, setStatistics] = useState<StatisticsData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const loadStatistics = async () => {
    setLoading(true);
    setError('');

    try {
      const response = await fetch(`/api/admin/statistics?adminPassword=${adminPassword}`);
      const data = await response.json();

      if (data.success) {
        setStatistics(data.statistics);
      } else {
        setError(data.error || 'Ошибка при загрузке статистики');
      }
    } catch (err) {
      setError('Ошибка при загрузке статистики');
      console.error('Ошибка при загрузке статистики:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStatistics();
  }, [adminPassword]);

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('ru-RU', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 6
    }).format(amount);
  };

  if (loading && !statistics) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-center p-8">
          <RefreshCw className="w-6 h-6 animate-spin text-blue-600" />
          <span className="ml-2">Загрузка статистики...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Заголовок с кнопкой обновления */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Статистика платформы</h2>
          <p className="text-gray-700">Общая статистика по депозитам, выводам и спорам</p>
        </div>
        <Button
          onClick={loadStatistics}
          disabled={loading}
          variant="outline"
          size="sm"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Обновить
        </Button>
      </div>

      {error && (
        <Alert className="border-red-500 bg-red-50">
          <AlertDescription className="text-red-700">
            {error}
          </AlertDescription>
        </Alert>
      )}

      {statistics && (
        <>
          {/* Основные метрики */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {/* Депозиты */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-800 mb-1">Депозиты</p>
                    <p className="text-2xl font-bold text-green-600">
                      {statistics.deposits.total_count}
                    </p>
                    <p className="text-sm text-gray-700">
                      {formatAmount(statistics.deposits.total_amount)} TON
                    </p>
                  </div>
                  <ArrowUpCircle className="w-8 h-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            {/* Выводы */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-800 mb-1">Выводы</p>
                    <p className="text-2xl font-bold text-red-600">
                      {statistics.withdrawals.total_count}
                    </p>
                    <p className="text-sm text-gray-700">
                      {formatAmount(statistics.withdrawals.total_amount)} TON
                    </p>
                  </div>
                  <ArrowDownCircle className="w-8 h-8 text-red-600" />
                </div>
              </CardContent>
            </Card>

            {/* Исполненные споры */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-800 mb-1">Споры исполнены</p>
                    <p className="text-2xl font-bold text-blue-600">
                      {statistics.disputes.total_completed}
                    </p>
                    <p className="text-sm text-gray-700">
                      Возвращено: {statistics.disputes.total_refunded}
                    </p>
                  </div>
                  <Target className="w-8 h-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            {/* Чистый поток */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-800 mb-1">Чистый поток</p>
                    <p className={`text-2xl font-bold ${statistics.summary.net_flow >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {statistics.summary.net_flow >= 0 ? '+' : ''}{formatAmount(statistics.summary.net_flow)}
                    </p>
                    <p className="text-sm text-gray-700">TON</p>
                  </div>
                  {statistics.summary.net_flow >= 0 ? (
                    <TrendingUp className="w-8 h-8 text-green-600" />
                  ) : (
                    <TrendingDown className="w-8 h-8 text-red-600" />
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Объем платформы */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-800 mb-1">Объем ставок</p>
                    <p className="text-2xl font-bold text-purple-600">
                      {formatAmount(statistics.summary.total_platform_volume)}
                    </p>
                    <p className="text-sm text-gray-700">TON</p>
                  </div>
                  <DollarSign className="w-8 h-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Детальная статистика по спорам */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Статистика по выигранным/проигранным спорам */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="w-5 h-5" />
                  Статистика по спорам
                </CardTitle>
                <CardDescription>
                  Результаты участников в исполненных спорах
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Trophy className="w-4 h-4 text-green-600" />
                      <span className="font-medium text-gray-900">Выигрышные транзакции</span>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline" className="bg-green-100 text-green-800">
                        {statistics.disputes.won_disputes}
                      </Badge>
                      <p className="text-xs text-gray-700 mt-1">
                        {formatAmount(statistics.disputes.total_won_amount)} TON
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <X className="w-4 h-4 text-red-600" />
                      <span className="font-medium text-gray-900">Проигрышные участия</span>
                    </div>
                    <Badge variant="outline" className="bg-red-100 text-red-800">
                      {statistics.disputes.lost_disputes}
                    </Badge>
                  </div>

                  <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-blue-600" />
                      <span className="font-medium text-gray-900">Уникальные победители</span>
                    </div>
                    <Badge variant="outline" className="bg-blue-100 text-blue-800">
                      {statistics.disputes.unique_winners}
                    </Badge>
                  </div>

                  <div className="pt-2 border-t">
                    <div className="grid grid-cols-2 gap-4 text-sm text-gray-800">
                      <div>
                        <span className="font-medium text-gray-900">Всего участий:</span> {statistics.disputes.detailed_stats.total_participations}
                      </div>
                      <div>
                        <span className="font-medium text-gray-900">Уникальных участников:</span> {statistics.disputes.unique_participants}
                      </div>
                      <div>
                        <span className="font-medium text-gray-900">Объем ставок:</span> {formatAmount(statistics.disputes.total_bet_amount)} TON
                      </div>
                      <div>
                        <span className="font-medium text-gray-900">Возвращено:</span> {formatAmount(statistics.disputes.total_refund_amount)} TON
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Статистика по депозитам через Stars */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Депозиты через Stars
                </CardTitle>
                <CardDescription>
                  Конвертация Telegram Stars в TON
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-800">Конвертаций</span>
                    <span className="font-bold text-gray-900">{statistics.deposits.stars_conversions.count}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-800">Общая сумма</span>
                    <span className="font-bold text-gray-900">{formatAmount(statistics.deposits.stars_conversions.amount)} TON</span>
                  </div>

                  <div className="pt-2 border-t">
                    <p className="text-sm text-gray-800">
                      {statistics.deposits.stars_conversions.count > 0
                        ? `Средняя конвертация: ${formatAmount(statistics.deposits.stars_conversions.amount / statistics.deposits.stars_conversions.count)} TON`
                        : 'Конвертаций пока не было'
                      }
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Детальная статистика по транзакциям */}
          {statistics.transactions && statistics.transactions.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Статистика по типам транзакций
                </CardTitle>
                <CardDescription>
                  Детализация всех транзакций в системе
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {statistics.transactions.map((transaction, index) => (
                    <div key={index} className="p-3 border rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium capitalize text-gray-900">{transaction.transaction_type}</span>
                        <Badge variant="outline">{transaction.count}</Badge>
                      </div>
                      <p className="text-sm text-gray-800">
                        Сумма: {formatAmount(parseFloat(transaction.total_amount))} TON
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
