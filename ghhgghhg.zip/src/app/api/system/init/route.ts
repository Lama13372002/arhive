import { type NextRequest, NextResponse } from 'next/server';
import { withdrawalDaemon } from '@/lib/withdrawal-daemon';

export async function POST(req: NextRequest) {
  try {
    console.log('🚀 Initializing system...');

    // Проверяем, что система еще не инициализирована
    const daemonStatus = withdrawalDaemon.getStatus();

    if (!daemonStatus.isRunning) {
      console.log('Starting withdrawal daemon...');
      withdrawalDaemon.start();
    }

    // Запускаем первоначальную проверку автовыводов
    setTimeout(async () => {
      try {
        await withdrawalDaemon.triggerAutoWithdrawalCheck();
        console.log('Initial auto-withdrawal check completed');
      } catch (error) {
        console.error('Error in initial auto-withdrawal check:', error);
      }
    }, 5000); // Запускаем через 5 секунд после старта

    return NextResponse.json({
      success: true,
      message: 'System initialized successfully',
      daemonStatus: withdrawalDaemon.getStatus(),
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Error initializing system:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to initialize system',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

export async function GET(req: NextRequest) {
  try {
    const daemonStatus = withdrawalDaemon.getStatus();

    return NextResponse.json({
      systemStatus: 'running',
      daemonStatus,
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
      nodeVersion: process.version,
      environment: process.env.NODE_ENV || 'development'
    });

  } catch (error) {
    console.error('Error getting system status:', error);
    return NextResponse.json(
      { error: 'Failed to get system status' },
      { status: 500 }
    );
  }
}
